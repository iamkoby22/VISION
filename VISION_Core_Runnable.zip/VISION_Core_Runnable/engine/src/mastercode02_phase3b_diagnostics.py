"""Phase 3B fertility calibration diagnostics — reporting + birth trace only."""
from __future__ import annotations

import mastercode02_globals as g
from mastercode02_config_and_rates import RATES, FERTILITY_PROBABILITY_SCALE, TARGET_CRUDE_BIRTH_RATE_PER_1000

PHASE3B_LOG: dict[str, list] = {
    "birth_trace": [],
    "immigration_by_year": [],
    "calibration_metrics": [],
}


def _marital_key(marital_status: str) -> str:
    return "Married" if "Married" in marital_status else "Unmarried"


def _raw_and_scaled_prob(woman) -> tuple[float, float, float, bool]:
    """Return (raw_final_before_scale, scaled_final, marriage_mult, marriage_applied)."""
    ag = woman.get_age_group()
    mkey = _marital_key(woman.marital_status)
    base = RATES["Fertility Rate"][mkey].get(ag, 0.0)
    raw = base * g.city_birth_rate_modifier * g.annual_birth_rate_modifier * g.event_birth_rate_modifier  # Gate 2
    marriage_mult = 1.0
    marriage_applied = False
    if woman.years_married is not None and woman.years_married <= 10:
        marriage_mult = 1.5
        marriage_applied = True
        raw *= marriage_mult
    scaled = max(0.0, min(raw * FERTILITY_PROBABILITY_SCALE, 1.0))
    return raw, scaled, marriage_mult, marriage_applied


def record_birth_trace(mother, info: dict, newborn_id: int, year: int) -> None:
    PHASE3B_LOG["birth_trace"].append({
        "year": year,
        "mother_id": mother.id,
        "mother_age": mother.age,
        "mother_age_group": info.get("age_group"),
        "mother_marital_status": mother.marital_status,
        "mother_years_married": mother.years_married,
        "base_birth_probability": info.get("base_birth_prob"),
        "arima_modifier": info.get("arima_modifier"),
        "event_modifier": info.get("event_modifier"),
        "marriage_multiplier": info.get("marriage_multiplier"),
        "marriage_multiplier_applied": info.get("marriage_multiplier_applied"),
        "fertility_scale": info.get("fertility_scale"),
        "final_scaled_birth_probability": info.get("final_scaled_birth_prob"),
        "household_id": mother.household_id,
        "newborn_id": newborn_id,
    })


def record_immigration(year: int, count: int) -> None:
    PHASE3B_LOG["immigration_by_year"].append({"year": year, "immigration_count": count})


def snapshot_yearly_fertility_calibration(year: int) -> None:
    """End-of-year exposure: raw expected, scaled expected, actual births (before counter reset)."""
    pop_n = len(g.POPULATION)
    fertile = [p for p in g.POPULATION if p.sex == "Female" and 15 <= p.age < 50]
    raw_expected = 0.0
    scaled_expected = 0.0
    marriage_mult_women = 0
    for p in fertile:
        raw, scaled, _mm, applied = _raw_and_scaled_prob(p)
        raw_expected += raw
        scaled_expected += scaled
        if applied:
            marriage_mult_women += 1
    actual_births = sum(h.get("births", 0) for h in g.HOUSEHOLDS.values())
    PHASE3B_LOG["calibration_metrics"].append({
        "year": year,
        "population": pop_n,
        "fertile_female_count": len(fertile),
        "raw_expected_births": round(raw_expected, 4),
        "scaled_expected_births": round(scaled_expected, 4),
        "actual_births": actual_births,
        "raw_expected_cbr_per_1000": round(raw_expected / pop_n * 1000, 4) if pop_n else 0.0,
        "scaled_expected_cbr_per_1000": round(scaled_expected / pop_n * 1000, 4) if pop_n else 0.0,
        "actual_cbr_per_1000": round(actual_births / pop_n * 1000, 4) if pop_n else 0.0,
        "fertility_scale": FERTILITY_PROBABILITY_SCALE,
        "target_cbr_per_1000": TARGET_CRUDE_BIRTH_RATE_PER_1000,
        "births_per_fertile_female": round(actual_births / len(fertile), 6) if fertile else 0.0,
        "women_with_marriage_multiplier": marriage_mult_women,
        "city_birth_rate_modifier": g.city_birth_rate_modifier,
        "annual_birth_rate_modifier": g.annual_birth_rate_modifier,
        "event_birth_rate_modifier": g.event_birth_rate_modifier,
    })
