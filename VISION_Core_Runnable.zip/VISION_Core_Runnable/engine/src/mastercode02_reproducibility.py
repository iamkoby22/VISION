"""Phase 2 reproducibility helpers — seed control and state snapshots only."""
from __future__ import annotations

import json
import platform
import random
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np

import mastercode02_globals as g
from mastercode02_config_and_rates import SIMULATION_DURATION

DEFAULT_SEED = 123

# Salabim Environment uses random_seed= on construction (see run notebook).
# Python random and NumPy are centralized here for any non-Salabim draws.


def set_reproducibility_seed(seed: int = DEFAULT_SEED) -> dict[str, Any]:
    """Set Python and NumPy seeds. Does not alter Salabim env seed (set on Environment)."""
    random.seed(seed)
    np.random.seed(seed)
    return {
        "python_random_seed": seed,
        "numpy_random_seed": seed,
        "salabim_mechanism": "sim.Environment(random_seed=...) at environment construction",
        "salabim_seed_set_in_this_helper": False,
    }


def _git_commit_hash() -> str | None:
    try:
        root = Path(__file__).resolve().parents[3]
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=root,
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass
    return None


def build_run_manifest(
    run_dir: Path,
    seed: int = DEFAULT_SEED,
    baseline_source: str | None = None,
) -> dict[str, Any]:
    import pandas as pd
    import salabim as sim
    import statsmodels

    run_dir = Path(run_dir)
    manifest = {
        "run_id": run_dir.name,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "python_version": sys.version,
        "salabim_version": getattr(sim, "__version__", "unknown"),
        "pandas_version": pd.__version__,
        "numpy_version": np.__version__,
        "statsmodels_version": getattr(statsmodels, "__version__", "unknown"),
        "operating_system": platform.platform(),
        "seed": seed,
        "simulation_duration": SIMULATION_DURATION,
        "source_folder": str(run_dir / "src"),
        "output_folder": str(run_dir / "outputs"),
        "diagnostics_folder": str(run_dir / "diagnostics"),
        "git_commit_hash": _git_commit_hash(),
        "original_code_untouched": True,
        "baseline_source_copied_from": baseline_source,
        "reproducibility": set_reproducibility_seed(seed),
    }
    out = run_dir / "diagnostics" / "phase2_run_manifest.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    # Alias required by spec
    alias = run_dir / "diagnostics" / "run_manifest.json"
    alias.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def _snapshot_dict_container(obj: Any, name: str) -> dict[str, Any]:
    if isinstance(obj, dict):
        return {"name": name, "type": "dict", "count": len(obj), "present": True}
    if isinstance(obj, list):
        return {"name": name, "type": "list", "count": len(obj), "present": True}
    return {"name": name, "type": type(obj).__name__, "value": obj, "present": True}


def capture_global_state_snapshot(label: str = "pre_run") -> dict[str, Any]:
    """Document global state before simulation. No mutation."""
    modifier_names = [
        "event_birth_rate_modifier", "event_death_rate_modifier", "event_employment_rate_modifier",
        "event_inflation_modifier", "event_income_modifier", "event_gov_support_modifier",
        "event_gov_cap_modifier", "event_dropout_prob", "event_housing_cost_modifier",
        "city_birth_rate_modifier", "city_death_rate_modifier", "city_marriage_rate_modifier",  # Gate 2
        "annual_birth_rate_modifier", "annual_death_rate_modifier", "annual_marriage_rate_modifier",  # Gate 2
        "arima_owner_preference_modifier",
    ]
    modifiers = {n: getattr(g, n, "MISSING") for n in modifier_names}

    finance_names = ["annual_savings_accepted", "annual_loans_disbursed", "annual_gov_support_disbursed", "refused_log"]
    finance = {n: getattr(g, n, "MISSING") for n in finance_names}

    containers = [
        _snapshot_dict_container(g.POPULATION, "POPULATION"),
        _snapshot_dict_container(g.HOUSEHOLDS, "HOUSEHOLDS"),
        _snapshot_dict_container(g.MARRIAGES, "MARRIAGES"),
        _snapshot_dict_container(g.EDUCATION_RESOURCE, "EDUCATION_RESOURCE"),
        _snapshot_dict_container(g.EMPLOYER_RESOURCE, "EMPLOYER_RESOURCE"),
        _snapshot_dict_container(g.HOUSING_RESOURCE, "HOUSING_RESOURCE"),
        _snapshot_dict_container(g.ANNUAL_SUMMARY_DATA, "ANNUAL_SUMMARY_DATA"),
        _snapshot_dict_container(g.VEHICLE_EVENTS, "VEHICLE_EVENTS"),
        _snapshot_dict_container(g.TRIP_SUMMARY, "TRIP_SUMMARY"),
        _snapshot_dict_container(g.RATES_LOG, "RATES_LOG"),
    ]

    missing = [c["name"] for c in containers if not c.get("present")]
    missing += [k for k, v in modifiers.items() if v == "MISSING"]
    missing += [k for k, v in finance.items() if v == "MISSING"]

    return {
        "label": label,
        "containers": containers,
        "event_modifiers": modifiers,
        "arima_modifiers": {k: v for k, v in modifiers.items() if k.startswith("arima_")},
        "finance_counters": finance,
        "latest_economic_index": getattr(g, "latest_economic_index", "MISSING"),
        "current_rental_vacancy_rate": getattr(g, "current_rental_vacancy_rate", "MISSING"),
        "current_renter_cost_burden_ratio": getattr(g, "current_renter_cost_burden_ratio", "MISSING"),
        "missing_attributes": missing,
    }
