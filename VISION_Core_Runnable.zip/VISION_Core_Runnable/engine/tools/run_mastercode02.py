#!/usr/bin/env python
"""Phase 9D-CO CLI runner for mastercode02 (FU3-aligned; 9A-R1 / 9C-S base).

Wraps the approved FU3 run path with argparse for seed/duration/output/diagnostics.
- Phase 9C-S: --events-json (preserved; default events=[])
- Phase 9D-CO: --config-overrides-json applied to mastercode02_config_and_rates
  AFTER that module is imported and BEFORE any consumer modules that from-import
  config names (agents/setup/utils/logging/renter_to_owner). No model logic changes.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
import traceback
from copy import deepcopy
from pathlib import Path

# Ensure sibling tools/ modules are importable when run as a script
_TOOLS_DIR = Path(__file__).resolve().parent
if str(_TOOLS_DIR) not in sys.path:
    sys.path.insert(0, str(_TOOLS_DIR))

# Existing event types implemented by ScenarioManager in the approved FU3 source
# (mastercode02_agents.py). Pass-through only; no new effects are defined here.
ALLOWED_EVENT_TYPES = ("public_health", "political_stability", "panic")
REQUIRED_EVENT_FIELDS = ("enabled", "type", "start_year", "end_year", "level")

# Ticket 11: mirrors backend/app/schemas/runs.py::EVENT_LEVEL_CONTRACT's
# "hard_domain" values exactly (this CLI parser is a standalone script and
# cannot import the backend package, so the domain is intentionally duplicated
# here — same dual-validation pattern already used for every other event
# field in this file). See that module's EVENT_LEVEL_CONTRACT docstring for
# the full derivation and the authoritative-evidence citation (original
# approved model's own interactive driver script: "-5 for crisis to 5 for
# boom" for public_health; "1-5" for panic and political_stability).
EVENT_LEVEL_HARD_DOMAINS = {
    "public_health": (-10, 10),
    "panic": (0, 10),
    "political_stability": (-10, 20),
}


class EventValidationError(ValueError):
    pass


# --- Gate 2: city vital-rate modifier helpers (module-level, independently
# testable). Extracted out of reset_global_state()'s closure so tests can
# call them directly against the real code path, not a reimplementation.
# g is imported locally in each function because mastercode02_globals only
# becomes importable once --source-dir has been added to sys.path, which
# happens at CLI-argument-parse time inside main(), not at module-import time. ---

def apply_city_vital_rate_modifiers(config_module):
    """Set g.city_{death,birth,marriage}_rate_modifier from the approved
    config override (BIRTH_RATE_MODIFIER / DEATH_RATE_MODIFIER /
    MARRIAGE_RATE_MODIFIER on config_module). getattr(...,1.0) default
    reproduces the exact pre-R11 baseline for a city with no override.
    These globals must never be reassigned by any manager after this call
    -- see assert_city_modifiers_intact() and
    RESSEARCH/03_FORENSIC_AUDIT/vital_rate_gate1_report.md for the defect
    this separation corrects."""
    import mastercode02_globals as g
    g.city_birth_rate_modifier = getattr(config_module, "BIRTH_RATE_MODIFIER", 1.0)
    g.city_death_rate_modifier = getattr(config_module, "DEATH_RATE_MODIFIER", 1.0)
    g.city_marriage_rate_modifier = getattr(config_module, "MARRIAGE_RATE_MODIFIER", 1.0)
    return {
        "city_birth_rate_modifier": g.city_birth_rate_modifier,
        "city_death_rate_modifier": g.city_death_rate_modifier,
        "city_marriage_rate_modifier": g.city_marriage_rate_modifier,
    }


def assert_city_modifiers_intact(config_module):
    """Gate 2 fail-fast regression guard. Call after every manager has been
    constructed and before env.run() begins. Raises RuntimeError if any
    city_*_rate_modifier no longer equals what apply_city_vital_rate_modifiers()
    set from the approved config override -- i.e. some component has
    silently overwritten a city-specific vital-rate calibration value (the
    exact defect class Gate 1 found and Gate 2 fixed)."""
    import mastercode02_globals as g
    expected = {
        "city_death_rate_modifier": getattr(config_module, "DEATH_RATE_MODIFIER", 1.0),
        "city_birth_rate_modifier": getattr(config_module, "BIRTH_RATE_MODIFIER", 1.0),
        "city_marriage_rate_modifier": getattr(config_module, "MARRIAGE_RATE_MODIFIER", 1.0),
    }
    for g_name, expected_value in expected.items():
        actual_value = getattr(g, g_name)
        if actual_value != expected_value:
            raise RuntimeError(
                f"FAIL-FAST (Gate 2 regression guard): g.{g_name} = {actual_value!r} "
                f"but the approved config override specifies {expected_value!r}. "
                f"A manager has overwritten a city-specific vital-rate calibration "
                f"value after apply_city_vital_rate_modifiers() set it -- refusing "
                f"to run with silently incorrect calibration."
            )


def _resolve_json_arg(raw: str) -> str:
    """Accept inline JSON, @path, or an existing .json file path (Windows-safe)."""
    text = (raw or "").strip()
    if text.startswith("@"):
        path = Path(text[1:])
        if not path.is_file():
            raise FileNotFoundError(f"JSON file not found: {path}")
        return path.read_text(encoding="utf-8")
    path = Path(text)
    if path.is_file() and path.suffix.lower() == ".json":
        return path.read_text(encoding="utf-8")
    return raw


def parse_events_json(raw: str):
    """Validate --events-json and return the event list for ScenarioManager.

    Enforces the schema in shared/scenario_event_schema.json:
    array of {enabled: bool, type: whitelisted str, start_year: int >= 0,
    end_year: int > start_year, level: finite number}. enabled=false is
    allowed (the model simply skips such events). Unknown fields rejected.
    Accepts inline JSON, @path, or an existing .json file path.
    """
    try:
        raw = _resolve_json_arg(raw)
    except FileNotFoundError as exc:
        raise EventValidationError(str(exc)) from exc
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise EventValidationError(f"--events-json is not valid JSON: {exc}") from exc
    if not isinstance(data, list):
        raise EventValidationError(
            f"--events-json must be a JSON array of event objects, got {type(data).__name__}")
    events = []
    for i, ev in enumerate(data):
        if not isinstance(ev, dict):
            raise EventValidationError(f"event[{i}] must be an object, got {type(ev).__name__}")
        missing = [f for f in REQUIRED_EVENT_FIELDS if f not in ev]
        if missing:
            raise EventValidationError(f"event[{i}] missing required fields: {missing}")
        unknown = [k for k in ev if k not in REQUIRED_EVENT_FIELDS]
        if unknown:
            raise EventValidationError(f"event[{i}] has unknown fields: {unknown}")
        if not isinstance(ev["enabled"], bool):
            raise EventValidationError(f"event[{i}].enabled must be a boolean")
        if ev["type"] not in ALLOWED_EVENT_TYPES:
            raise EventValidationError(
                f"event[{i}].type {ev['type']!r} is not an implemented model event type; "
                f"allowed: {list(ALLOWED_EVENT_TYPES)}")
        for f in ("start_year", "end_year"):
            if not isinstance(ev[f], int) or isinstance(ev[f], bool):
                raise EventValidationError(f"event[{i}].{f} must be an integer")
        if ev["start_year"] < 0:
            raise EventValidationError(f"event[{i}].start_year must be >= 0")
        if ev["end_year"] <= ev["start_year"]:
            raise EventValidationError(
                f"event[{i}].end_year ({ev['end_year']}) must be > start_year "
                f"({ev['start_year']}) — end_year is exclusive")
        lvl = ev["level"]
        if isinstance(lvl, bool) or not isinstance(lvl, (int, float)) or not math.isfinite(lvl):
            raise EventValidationError(f"event[{i}].level must be a finite number")
        domain = EVENT_LEVEL_HARD_DOMAINS.get(ev["type"])
        if domain and not (domain[0] <= float(lvl) <= domain[1]):
            # Ticket 10/11: every event type's own documented ScenarioManager
            # formula stays a valid (non-negative) rate/probability multiplier
            # only within its own hard domain (see EVENT_LEVEL_HARD_DOMAINS
            # above). Reject here rather than let a nonsensical negative rate
            # silently saturate the affected quantity at its floor/ceiling.
            raise EventValidationError(
                f"event[{i}].level ({lvl}) is outside the valid {ev['type']} "
                f"range [{domain[0]}, {domain[1]}] — at least one affected "
                "rate/probability multiplier goes negative (undefined) outside "
                "this range")
        events.append({
            "enabled": ev["enabled"],
            "type": ev["type"],
            "start_year": ev["start_year"],
            "end_year": ev["end_year"],
            "level": float(lvl),
        })
    return events


def _parse_args(argv=None):
    p = argparse.ArgumentParser(
        description="Run mastercode02 via Phase 9D-CO CLI "
                    "(seed/duration/events/config-overrides).")
    p.add_argument("--seed", type=int, default=123)
    p.add_argument("--duration", type=int, default=None,
                   help="Simulation years (default: SIMULATION_DURATION from config = 5)")
    p.add_argument("--output-dir", type=str, required=True)
    p.add_argument("--diagnostics-dir", type=str, required=True)
    p.add_argument("--run-label", type=str, default="mastercode02_cli")
    p.add_argument("--source-dir", type=str, default=None,
                   help="Path to src/ (default: <phase>/src)")
    p.add_argument("--skip-postrun", action="store_true",
                   help="Skip dumping education overflow diagnostics JSON")
    p.add_argument("--force", action="store_true",
                   help="Allow writing into a non-empty output directory")
    p.add_argument("--base-filename", type=str, default=None,
                   help="CSV basename (default: mastercode02_output_<run-label>)")
    p.add_argument("--events-json", type=str, default=None,
                   help="Optional JSON array of existing model scenario events "
                        "(public_health / political_stability / panic) passed to "
                        "ScenarioManager. Inline JSON, @path, or .json file path. "
                        "Omit for identical Phase 9A-R1 no-event behavior.")
    p.add_argument("--config-overrides-json", type=str, default=None,
                   help="Optional JSON object of config/rates overrides applied to "
                        "mastercode02_config_and_rates before consumer imports. "
                        "Inline JSON, @path, or .json file path. "
                        "Omit or {} for identical no-override baseline behavior.")
    p.add_argument("--t0-json", type=str, default=None,
                   help="Optional JSON object of t=0 generator data "
                        "(demographics/households/employment/marital_status) applied "
                        "in-place to the generator DATA before initial population "
                        "generation. Inline JSON, @path, or .json file path. "
                        "Omit for identical Phase 9A-R1 default t=0 behavior.")
    p.add_argument("--checkpoint-every-years", type=int, default=1,
                   help="R11.1 Phase 6: write a non-destructive partial CSV "
                        "checkpoint (diagnostics_dir/_checkpoint/) every N "
                        "simulated years. 0 disables checkpointing. Default: 1. "
                        "Does not alter real output; purely additive.")
    return p.parse_args(argv)


def _phase9a_root() -> Path:
    return Path(__file__).resolve().parents[1]


def main(argv=None) -> int:
    args = _parse_args(argv)
    root = _phase9a_root()
    source_dir = Path(args.source_dir) if args.source_dir else (root / "src")
    output_dir = Path(args.output_dir)
    if not output_dir.is_absolute():
        output_dir = (root / output_dir).resolve()
    diagnostics_dir = Path(args.diagnostics_dir)
    if not diagnostics_dir.is_absolute():
        diagnostics_dir = (root / diagnostics_dir).resolve()
    base_filename = args.base_filename or f"mastercode02_output_{args.run_label}"

    status_path = diagnostics_dir / "run_status.json"
    cli_command = " ".join([sys.executable, str(Path(__file__).resolve())] +
                           (argv if argv is not None else sys.argv[1:]))

    # Manifest fields filled as we go
    config_overrides: dict = {}
    config_override_keys: list = []
    config_overrides_applied = False
    config_override_hash = ""
    effective_config_snapshot_path = ""
    config_override_diff_path = ""

    # Phase 9E-T0 t=0 manifest fields
    t0_payload = None
    t0_data_applied = False
    t0_data_hash = ""
    t0_source = ""
    effective_t0_data_path = ""
    t0_diff_path = ""
    t0_population_total = None
    t0_household_total = None
    t0_person_id_seed = None
    t0_household_id_seed = None

    def write_status(status: str, error: str = "", elapsed: float = 0.0, **extra):
        diagnostics_dir.mkdir(parents=True, exist_ok=True)
        payload = {
            "status": status, "error": error, "elapsed_seconds": elapsed,
            "seed": args.seed, "duration": duration_used,
            "output_dir": str(output_dir), "diagnostics_dir": str(diagnostics_dir),
            "run_label": args.run_label, "base_filename": base_filename,
            "source_dir": str(source_dir), "cli_command": cli_command,
            "scenario_events": scenario_events,
            "scenario_events_applied": bool(scenario_events),
            "config_overrides_applied": config_overrides_applied,
            "config_override_hash": config_override_hash,
            "config_override_keys": config_override_keys,
            "effective_config_snapshot_path": effective_config_snapshot_path,
            "config_override_diff_path": config_override_diff_path,
            "t0_data_applied": t0_data_applied,
            "t0_data_hash": t0_data_hash,
            "t0_source": t0_source,
            "effective_t0_data_path": effective_t0_data_path,
            "t0_diff_path": t0_diff_path,
            "t0_population_total": t0_population_total,
            "t0_household_total": t0_household_total,
            "t0_person_id_seed": t0_person_id_seed,
            "t0_household_id_seed": t0_household_id_seed,
            **extra,
        }
        status_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    # --- Phase 9C-S: validate --events-json before any model import ---
    scenario_events: list = []
    if args.events_json is not None:
        try:
            scenario_events = parse_events_json(args.events_json)
        except EventValidationError as exc:
            duration_used = args.duration if args.duration is not None else 5
            diagnostics_dir.mkdir(parents=True, exist_ok=True)
            write_status("FAIL", error=f"Invalid --events-json: {exc}")
            print(f"ERROR: invalid --events-json: {exc}", file=sys.stderr)
            return 2
        diagnostics_dir.mkdir(parents=True, exist_ok=True)
        (diagnostics_dir / "scenario_events.json").write_text(
            json.dumps({
                "events": scenario_events,
                "allowed_event_types": list(ALLOWED_EVENT_TYPES),
                "note": ("Pass-through of existing ScenarioManager event types only; "
                         "no new scenario logic (Phase 9C-S)."),
            }, indent=2),
            encoding="utf-8")

    # --- Phase 9D-CO: parse/validate --config-overrides-json (no model import yet) ---
    if args.config_overrides_json is not None:
        from validate_config_overrides import (
            ConfigOverrideValidationError, parse_and_validate)
        try:
            override_raw = _resolve_json_arg(args.config_overrides_json)
            config_overrides, validation_report = parse_and_validate(override_raw)
        except FileNotFoundError as exc:
            duration_used = args.duration if args.duration is not None else 5
            diagnostics_dir.mkdir(parents=True, exist_ok=True)
            write_status("FAIL", error=f"Invalid --config-overrides-json: {exc}")
            print(f"ERROR: invalid --config-overrides-json: {exc}", file=sys.stderr)
            return 2
        except ConfigOverrideValidationError as exc:
            duration_used = args.duration if args.duration is not None else 5
            diagnostics_dir.mkdir(parents=True, exist_ok=True)
            (diagnostics_dir / "config_override_validation.json").write_text(
                json.dumps({"valid": False, "errors": exc.errors}, indent=2), encoding="utf-8")
            try:
                input_text = _resolve_json_arg(args.config_overrides_json)
            except Exception:
                input_text = args.config_overrides_json
            (diagnostics_dir / "config_override_input.json").write_text(
                input_text, encoding="utf-8")
            write_status("FAIL", error=f"Invalid --config-overrides-json: {exc}")
            print(f"ERROR: invalid --config-overrides-json: {exc}", file=sys.stderr)
            return 2
        diagnostics_dir.mkdir(parents=True, exist_ok=True)
        (diagnostics_dir / "config_override_input.json").write_text(
            json.dumps(config_overrides, indent=2), encoding="utf-8")
        (diagnostics_dir / "config_override_validation.json").write_text(
            json.dumps(validation_report, indent=2), encoding="utf-8")
        config_override_keys = sorted(config_overrides.keys())

    # --- Phase 9E-T0: parse/validate --t0-json (no model import yet) ---
    if args.t0_json is not None:
        from validate_t0_data import validate_t0_data
        try:
            t0_input_text = _resolve_json_arg(args.t0_json)
        except FileNotFoundError as exc:
            duration_used = args.duration if args.duration is not None else 5
            diagnostics_dir.mkdir(parents=True, exist_ok=True)
            write_status("FAIL", error=f"Invalid --t0-json: {exc}")
            print(f"ERROR: invalid --t0-json: {exc}", file=sys.stderr)
            return 2
        try:
            t0_candidate = json.loads(t0_input_text)
        except json.JSONDecodeError as exc:
            duration_used = args.duration if args.duration is not None else 5
            diagnostics_dir.mkdir(parents=True, exist_ok=True)
            write_status("FAIL", error=f"--t0-json is not valid JSON: {exc}")
            print(f"ERROR: --t0-json is not valid JSON: {exc}", file=sys.stderr)
            return 2
        vres = validate_t0_data(t0_candidate)
        diagnostics_dir.mkdir(parents=True, exist_ok=True)
        (diagnostics_dir / "t0_validation_report.json").write_text(
            json.dumps({
                "ok": vres.ok, "errors": vres.errors,
                "warnings": vres.warnings, "computed": vres.computed,
            }, indent=2), encoding="utf-8")
        if not vres.ok:
            duration_used = args.duration if args.duration is not None else 5
            write_status("FAIL", error=f"Invalid --t0-json: {vres.errors}")
            print(f"ERROR: invalid --t0-json: {vres.errors}", file=sys.stderr)
            return 2
        (diagnostics_dir / "selected_t0_input.json").write_text(
            json.dumps(t0_candidate, indent=2), encoding="utf-8")
        t0_payload = t0_candidate
        t0_data_applied = True
        t0_source = args.t0_json

    if not source_dir.is_dir():
        output_dir.mkdir(parents=True, exist_ok=True)
        diagnostics_dir.mkdir(parents=True, exist_ok=True)
        duration_used = args.duration if args.duration is not None else 5
        write_status("FAIL", error=f"Invalid source-dir: {source_dir}")
        print(f"ERROR: source-dir does not exist: {source_dir}", file=sys.stderr)
        return 1

    output_dir.mkdir(parents=True, exist_ok=True)
    diagnostics_dir.mkdir(parents=True, exist_ok=True)

    # Refuse overwrite unless --force
    probe = list(output_dir.glob("*_annual_summary.csv"))
    if probe and not args.force:
        duration_used = args.duration if args.duration is not None else 5
        write_status("FAIL", error=f"Output dir not empty (found {probe[0].name}); use --force")
        print(f"ERROR: output dir already has results; use --force: {output_dir}", file=sys.stderr)
        return 1

    # Import model from source-copy only
    sys.path.insert(0, str(source_dir.resolve()))
    prev_cwd = os.getcwd()
    os.chdir(output_dir)

    duration_used = 5
    t0 = time.time()
    status, error = "SUCCESS", ""
    heartbeat = None  # R11.1 Phase 6: bound once model import reaches the heartbeat setup point
    try:
        import salabim as sim
        sim.yieldless(False)

        from mastercode02_reproducibility import set_reproducibility_seed
        import mastercode02_globals as g
        # Phase 9D-CO critical order: config module FIRST, apply overrides, THEN consumers.
        import mastercode02_config_and_rates as config
        from config_snapshot import snapshot_config, snapshot_hash
        from config_diff import diff_snapshots
        from apply_config_overrides import apply_config_overrides

        baseline_snap = snapshot_config(config)

        if config_overrides:
            apply_report = apply_config_overrides(config, config_overrides)
            config_overrides_applied = bool(apply_report.get("config_overrides_applied"))
        else:
            config_overrides_applied = False

        # CLI --duration wins when provided; applied BEFORE consumer from-imports
        # so SIMULATION_DURATION bindings match env.run(till=...).
        if args.duration is not None:
            config.SIMULATION_DURATION = int(args.duration)
        duration_used = int(config.SIMULATION_DURATION)

        effective_snap = snapshot_config(config)
        diff = diff_snapshots(baseline_snap, effective_snap)
        # Hash of the *override input* (empty object when none), plus effective snap path
        from validate_config_overrides import ALLOWED_TOP_LEVEL  # noqa: F401
        config_override_hash = snapshot_hash(config_overrides if config_overrides else {})
        effective_path = diagnostics_dir / "effective_config_snapshot.json"
        diff_path = diagnostics_dir / "config_override_diff.json"
        effective_path.write_text(json.dumps(effective_snap, indent=2), encoding="utf-8")
        diff_path.write_text(json.dumps(diff, indent=2), encoding="utf-8")
        if not (diagnostics_dir / "config_override_input.json").exists():
            (diagnostics_dir / "config_override_input.json").write_text(
                json.dumps(config_overrides, indent=2), encoding="utf-8")
        if not (diagnostics_dir / "config_override_validation.json").exists():
            (diagnostics_dir / "config_override_validation.json").write_text(
                json.dumps({
                    "valid": True,
                    "errors": [],
                    "n_top_level_keys": len(config_overrides),
                    "top_level_keys": sorted(config_overrides.keys()),
                    "note": "No --config-overrides-json provided (empty override).",
                }, indent=2), encoding="utf-8")
        effective_config_snapshot_path = str(effective_path)
        config_override_diff_path = str(diff_path)
        config_override_keys = sorted(config_overrides.keys())

        # Consumer imports AFTER override application (scalars bind correctly)
        import mastercode02_logging as logging_mod
        from mastercode02_config_and_rates import RATES as BASE_RATES
        from mastercode02_agents import (
            Person, MarriageManager, WorldManager, EconomicManager, PublicTransitManager,
            TrafficManager, EducationManager, GovernmentManager, CommuteManager,
            ScenarioManager, HouseholdFinanceManager, ImmigrationManager, HousingManager,
            PEPNetMigrationExtension,
        )
        import mastercode02_agents as agents_module
        from mastercode02_setup import Initializer
        import mastercode02_generator as generator
        from mastercode02_logging import log_yearly_data, write_and_close_csv_logs
        from mastercode02_housing_ledger import reset_housing_ledger
        from mastercode02_renter_to_owner import reset_r2o_diagnostics
        from mastercode02_phase7a_diagnostics import reset_phase7a_diagnostics
        from mastercode02_phase7b_diagnostics import reset_phase7b_diagnostics
        from mastercode02_household_archive import reset_household_archive
        from mastercode02_education_overflow import (
            snapshot_year, reset_education_overflow, dump_overflow_log)
        # R11.1 Phase 6: heartbeat/checkpoint infra. Purely additive diagnostics
        # (see mastercode02_heartbeat.py docstring) -- no simulation semantics touched.
        from mastercode02_heartbeat import HeartbeatWriter, write_year_checkpoint

        def reset_global_state():
            """Identical to approved FU3/FU2 runner reset (call existing reset helpers only)."""
            g.POPULATION.clear()
            g.HOUSEHOLDS.clear()
            g.MARRIAGES.clear()
            g.EDUCATION_RESOURCE.clear()
            g.EMPLOYER_RESOURCE.clear()
            g.HOUSING_RESOURCE.clear()
            g.ANNUAL_SUMMARY_DATA.clear()
            g.VEHICLE_EVENTS.clear()
            g.TRIP_SUMMARY.clear()
            g.RATES_LOG.clear()
            reset_housing_ledger()
            reset_r2o_diagnostics()
            reset_phase7a_diagnostics()
            reset_phase7b_diagnostics()
            reset_household_archive()
            g._person_id_counter = 73440
            g._household_id_counter = 31162
            g._marriage_id_counter = 0
            g._car_id_counter = 0
            g.event_birth_rate_modifier = 1.0
            g.event_death_rate_modifier = 1.0
            g.event_employment_rate_modifier = 1.0
            g.event_inflation_modifier = 1.0
            g.event_income_modifier = 1.0
            g.event_gov_support_modifier = 1.0
            g.event_gov_cap_modifier = 1.0
            g.event_dropout_prob = 0.0
            g.event_housing_cost_modifier = 1.0
            # R11: sourced from config so a city-scoped config-overrides draft can set
            # these; getattr default of 1.0 reproduces the exact pre-R11 hardcoded
            # behavior when BIRTH_RATE_MODIFIER/DEATH_RATE_MODIFIER/MARRIAGE_RATE_MODIFIER
            # are absent or left at their config-module default.
            # Gate 2 correction: delegates to the module-level
            # apply_city_vital_rate_modifiers() (see top of this file) so the
            # exact same logic is independently testable. These city_* globals
            # must never be reassigned by any manager after this call --
            # previously they were written into arima_*_modifier, the SAME
            # variable name WorldManager independently reset every run -- the
            # root cause identified in RESSEARCH/03_FORENSIC_AUDIT/vital_rate_gate1_report.md.
            apply_city_vital_rate_modifiers(config)
            g.arima_owner_preference_modifier = 1.0
            g.latest_economic_index = 100.0
            g.current_rental_vacancy_rate = 0.05
            g.current_renter_cost_burden_ratio = 0.40
            g.annual_savings_accepted = 0
            g.annual_loans_disbursed = 0
            g.annual_gov_support_disbursed = 0
            g.refused_log = {"savings": 0, "loans": 0, "gov_support": 0}

        def reset_log_data():
            for value in logging_mod.LOG_DATA.values():
                if isinstance(value, list):
                    value.clear()

        class YearlyReporter(sim.Component):
            def setup(self, file_path):
                self.file_path = file_path
                self.last_year_pop = 0

            def process(self):
                yield self.hold(0)
                self.last_year_pop = len(g.POPULATION)
                log_yearly_data(0, self.env, 0.0)
                snapshot_year(0, self.env)
                heartbeat.write("RUNNING", year=0, note="post-init year 0 logged")
                if checkpoint_every_years:
                    write_year_checkpoint(checkpoint_dir, self.file_path, self.env, 0)
                while True:
                    yield self.hold(1)
                    year = int(self.env.now())
                    current_pop = len(g.POPULATION)
                    growth = ((current_pop - self.last_year_pop) / self.last_year_pop
                              if self.last_year_pop > 0 else 0)
                    self.last_year_pop = current_pop
                    log_yearly_data(year, self.env, growth)
                    snapshot_year(year, self.env)
                    heartbeat.write("RUNNING", year=year)
                    if checkpoint_every_years and year % checkpoint_every_years == 0:
                        write_year_checkpoint(checkpoint_dir, self.file_path, self.env, year)

        set_reproducibility_seed(args.seed)
        reset_global_state()

        # --- Phase 9E-T0: apply t=0 payload in-place + derive ID counter seeds ---
        # Canonical default blocks (captured at generator import, pre-injection).
        default_t0_blocks = generator.get_default_t0_data()
        if t0_payload is not None:
            # Mutate generator.DATA IN PLACE (never rebind) so setup's
            # from-imported DATA reference observes the injected values.
            generator.apply_t0_data_in_place(t0_payload)
        # Derive ID counter seeds from the ACTIVE DATA totals. For the default
        # and explicit-default runs this equals the hardcoded 73440 / 31162,
        # preserving FU3/9A-R1 identity; for injected payloads it prevents ID
        # collisions between initial and newly-generated people/households.
        _t0_totals = generator.compute_t0_totals()
        t0_population_total = _t0_totals["population_total"]
        t0_household_total = _t0_totals["household_total"]
        g._person_id_counter = t0_population_total
        g._household_id_counter = t0_household_total
        t0_person_id_seed = t0_population_total
        t0_household_id_seed = t0_household_total

        # Effective t=0 snapshot + diff vs canonical default + hash artifacts
        from t0_snapshot import snapshot_t0, t0_hash
        from t0_diff import diff_t0
        effective_blocks = snapshot_t0(generator.DATA)
        t0_data_hash = t0_hash(effective_blocks)
        t0_blocks_diff = diff_t0(default_t0_blocks, effective_blocks)
        _eff_t0_path = diagnostics_dir / "effective_t0_data.json"
        _t0_diff_path = diagnostics_dir / "t0_diff.json"
        _eff_t0_path.write_text(json.dumps(effective_blocks, indent=2), encoding="utf-8")
        _t0_diff_path.write_text(json.dumps(t0_blocks_diff, indent=2), encoding="utf-8")
        effective_t0_data_path = str(_eff_t0_path)
        t0_diff_path = str(_t0_diff_path)
        (diagnostics_dir / "t0_metadata.json").write_text(json.dumps({
            "t0_data_applied": t0_data_applied,
            "t0_source": t0_source,
            "t0_data_hash": t0_data_hash,
            "t0_population_total": t0_population_total,
            "t0_household_total": t0_household_total,
            "t0_person_id_seed": t0_person_id_seed,
            "t0_household_id_seed": t0_household_id_seed,
            "effective_t0_data_path": effective_t0_data_path,
            "t0_diff_path": t0_diff_path,
            "n_diff_entries": len(t0_blocks_diff),
            "data_mutation": "in_place (DATA.clear() + DATA.update()); DATA never rebound",
        }, indent=2), encoding="utf-8")

        reset_log_data()
        # R11.1 Phase 4: stream education-overflow events to disk in chunks
        # instead of retaining the full run's events in memory (was 120-400MB
        # for Johnson City/Knoxville at 24 years) -- dump_overflow_log() below
        # still produces byte-identical final JSON.
        reset_education_overflow(spill_dir=diagnostics_dir / "_overflow_spill")

        try:
            from mastercode02_phase4d_diagnostics import wrap_update_education_cyclical
            wrap_update_education_cyclical(Person)
        except Exception:
            pass

        # R11.1 Phase 6: heartbeat/checkpoint setup. checkpoint_dir is separate
        # from output_dir so checkpoints never collide with or alter real output.
        checkpoint_every_years = max(0, args.checkpoint_every_years)
        checkpoint_dir = diagnostics_dir / "_checkpoint"
        heartbeat = HeartbeatWriter(
            diagnostics_dir / "heartbeat.json", args.run_label, args.seed, duration_used)
        heartbeat.write("INITIALIZING", note="entering env.run(till=0) (Initializer)")

        env = sim.Environment(time_unit="years", random_seed=args.seed, trace=False)
        g.RATES = deepcopy(BASE_RATES)
        env.RATES = g.RATES
        Initializer(env=env)
        # Phase 9C-S: pass validated events through; default [] == Phase 9A-R1 behavior
        ScenarioManager(env=env, events=scenario_events)
        EconomicManager(env=env)
        WorldManager(env=env)
        env.run(till=0)
        heartbeat.write("T0_COMPLETE", note="env.run(till=0) returned; year-loop about to start")
        PublicTransitManager(env=env)
        MarriageManager(env, g.HOUSEHOLDS, g.POPULATION, g.MARRIAGES)
        TrafficManager(env=env)
        CommuteManager(env=env)
        GovernmentManager(env=env)
        HouseholdFinanceManager(env=env)
        EducationManager(env=env)
        ImmigrationManager(env=env)
        # R12.4 ISOLATED EXPERIMENT ONLY: registered immediately after the existing
        # ImmigrationManager, preserving its relative tick position, per
        # reports/r12_4_m1_event_order.md.
        #
        # R6.1 Gate G correction: this class previously registered
        # unconditionally for every run (R6-ISSUE-001) once the candidate tree
        # was consolidated from the JC-PEP snapshot. The scenario/city
        # discriminator is now explicit config, not source-tree identity --
        # the city check is a safety guard (a malformed config can never
        # activate PEP outside Johnson City); the flag is the actual
        # experiment selector.
        _pep_enabled = bool(getattr(config, "PEP_STRUCTURAL_MIGRATION_ENABLED", False))
        _city_id = getattr(config, "CITY_ID", "unspecified")
        pep_manager_registered = bool(_pep_enabled and _city_id == "johnson_city_tn")
        if pep_manager_registered:
            PEPNetMigrationExtension(env=env)
        # R7.10: RESIDUAL_EMPIRICAL_MIGRATION mechanism, additive to and independent of the
        # existing ImmigrationManager above (registered immediately after it, preserving its
        # relative tick position, matching the PEP-registration convention). Default OFF; the
        # city guard below is a safety guard mirroring PEP's -- a malformed config can never
        # activate this outside Knoxville, matching the standing "Johnson City must remain
        # unaffected" constraint. The flag is the actual experiment selector.
        _residual_enabled = bool(getattr(config, "RESIDUAL_MIGRATION_ENABLED", False))
        residual_manager_registered = bool(_residual_enabled and _city_id == "knoxville_tn")
        if residual_manager_registered:
            from mastercode02_residual_migration import ResidualMigrationManager
            ResidualMigrationManager(env=env, base_seed=args.seed)
        HousingManager(env=env)
        YearlyReporter(env=env, file_path=base_filename)
        assert_city_modifiers_intact(config)  # Gate 2: fail fast if any manager clobbered a city_* modifier
        print(f"Starting CLI run label={args.run_label} seed={args.seed} "
              f"duration={duration_used} events={len(scenario_events)} "
              f"config_overrides={len(config_override_keys)}")
        env.run(till=duration_used)
        heartbeat.write("FINALIZING", year=duration_used, note="writing final CSV logs")
        write_and_close_csv_logs(base_filename, env)

        if not args.skip_postrun:
            dump_overflow_log(diagnostics_dir / "education_overflow_log.json")
            print(f"Overflow log written to {diagnostics_dir / 'education_overflow_log.json'}")

        # R12.4 ISOLATED EXPERIMENT ONLY: persist the in-memory PEP_MIGRATION_LOG
        # (per-year domestic/international targets, created counts, and the exact
        # person_id list) to disk -- required for post-run population accounting.
        pep_log_path = diagnostics_dir / "pep_migration_log.json"
        with open(pep_log_path, "w", encoding="utf-8") as f:
            json.dump(agents_module.PEP_MIGRATION_LOG, f, indent=2)
        print(f"PEP migration log written to {pep_log_path}")

        # R12.4 ISOLATED EXPERIMENT ONLY: purely additive diagnostics dump of the
        # pre-existing baseline ImmigrationManager's per-year counts (already
        # recorded in-memory by the unmodified record_immigration() call), needed
        # as the baseline-migration term in population accounting since
        # ImmigrationManager remains active and unmodified in this run.
        from mastercode02_phase3c_diagnostics import PHASE3C_LOG
        baseline_immigration_log_path = diagnostics_dir / "baseline_immigration_by_year.json"
        with open(baseline_immigration_log_path, "w", encoding="utf-8") as f:
            json.dump(PHASE3C_LOG["immigration_by_year"], f, indent=2)
        print(f"Baseline immigration log written to {baseline_immigration_log_path}")

        heartbeat.write("COMPLETED", year=duration_used)

    except Exception:
        status = "FAIL"
        error = traceback.format_exc()
        print(error, file=sys.stderr)
        if heartbeat is not None:
            heartbeat.write("FAILED", note=error.splitlines()[-1] if error else "")
    finally:
        os.chdir(prev_cwd)
        write_status(status, error=error, elapsed=time.time() - t0,
                     pep_manager_registered=locals().get("pep_manager_registered"),
                     residual_manager_registered=locals().get("residual_manager_registered"),
                     city_id=locals().get("_city_id"))

    if status != "SUCCESS":
        print("CLI run FAILED")
        return 1
    print(f"CLI run SUCCESS. Outputs: {output_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
