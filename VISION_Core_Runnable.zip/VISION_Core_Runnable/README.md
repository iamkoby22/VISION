# VISION Core — portable execution package

VISION Core is a rule-based demographic, actuarial and economic microsimulation. Each transition
is an individual draw from a fixed schedule indexed principally by age and sex, with nonlinear
aggregate feedback through context.

This package wraps the **frozen, unmodified** Core engine. `run_core.py` handles paths,
parameters and provenance and then launches the original entry point,
`engine/tools/run_mastercode02.py`. No demographic logic is reimplemented here.

## Python

Built and smoke-tested on Python 3.12.4 (Windows-11-10.0.26200-SP0).

## Setup

    python -m venv .venv
    .venv\Scripts\activate          # Windows
    pip install -r requirements.txt
    # or, to reproduce the exact smoke-test environment:
    pip install -r requirements-lock.txt

## Run it from the notebook

    jupyter notebook VISION_Core_RUN.ipynb

Edit the parameters in the first code cell, then run top to bottom.

## Run it from the command line

    python run_core.py --years 23 --seed 20230101 --scenario canonical --run-label example_core
    python run_core.py --years 2  --seed 314159   --scenario smoke     --run-label core_smoke_100

## Changing the run

| I want to change | Do this |
|---|---|
| number of years | `MODEL_YEARS` in the notebook, or `--years N` on the command line |
| random seed | `SEED`, or `--seed N` |
| scenario | `SCENARIO`, or `--scenario canonical\|baseline\|smoke\|custom` |
| output name | `RUN_LABEL`, or `--run-label NAME` |

### Duration semantics — read this before changing the year count

`MODEL_YEARS` is the number of **annual transitions**, not the number of rows.

    MODEL_YEARS = N  ->  N + 1 annual rows, calendar 2000 .. 2000+N

So `MODEL_YEARS = 23` means calendar **2000 through 2023**: 23 transitions and 24 checkpoints.
That is exactly the authoritative production configuration. This was verified by reading the
engine source and cross-checking against both completed runs; do not change it without
re-verifying.

## Scenarios

| Scenario | T0 | Config overrides |
|---|---|---|
| `canonical` | governed Johnson City 2000 T0 (55,469 persons, 23,720 households) | production overrides |
| `baseline` | same governed T0 | none |
| `smoke` | ~100-person engineering fixture | none |
| `custom` | your own `--t0-json` | your own `--config-overrides-json` |

A custom scenario works through the engine's **existing** supported switches: config overrides,
scenario events, duration and seed. No new scientific scenario is invented here.

## Where outputs go

Your runs:

    outputs/user_runs/<RUN_LABEL>/
        outputs/       model CSVs
        diagnostics/   run_status.json, checkpoints, ledgers
        logs/          stdout.log, stderr.log
        provenance/    run_request.json, environment.json, source_manifest.json

## Smoke versus canonical

The smoke fixture is a ~100-person engineering population. Its only purpose is to prove the
package can instantiate the engine, advance the clock and write outputs. **It is not a
scientific run and must not appear in any result.** A canonical run uses the full governed
55,469-person T0.

## The supplied historical outputs are frozen evidence

Everything under `outputs/authoritative_2000_2023/`, split into `primary/` (the published Core result) and `alternate_comparator/` is the real, completed,
published run, copied verbatim. **Do not overwrite it.** It is there so you can inspect the
published results without re-running an expensive experiment.
