"""Phase 8A read-only state snapshot diagnostics.

Captures global-state fingerprints at defined stages WITHOUT mutating model state or consuming
RNG. `random.getstate()` / `np.random.get_state()` do not advance the generators, so digests
are side-effect free.
"""
from __future__ import annotations

import hashlib
import random

import numpy as np

import mastercode02_globals as g

STATE_SNAPSHOTS: list = []


def reset_phase8a_diagnostics() -> None:
    STATE_SNAPSHOTS.clear()


def _sha16(obj) -> str:
    return hashlib.sha256(repr(obj).encode("utf-8", "replace")).hexdigest()[:16]


def _python_random_digest() -> str:
    try:
        return _sha16(random.getstate())
    except Exception:
        return ""


def _numpy_random_digest() -> str:
    try:
        return _sha16(np.random.get_state())
    except Exception:
        return ""


def _ledger_counts():
    try:
        import mastercode02_housing_ledger as L
        active = len(L.HOUSING_LEDGER_ACTIVE)
        history = len(L.HOUSING_LEDGER_HISTORY)
        rental = sale = 0
        from mastercode02_config_and_rates import HOUSING_STOCK
        for name, stock in HOUSING_STOCK.items():
            c = int(L.HOUSING_ACTIVE_CLAIMS_BY_UNIT.get(name, 0))
            if stock["type"] == "Rental":
                rental += c
            elif stock["type"] == "For-Sale":
                sale += c
        return active, history, rental, sale
    except Exception:
        return "", "", "", ""


def _archive_counts():
    try:
        import mastercode02_household_archive as A
        archived = len(A.ARCHIVED_HOUSEHOLDS)
        active = len([h for h in g.HOUSEHOLDS.values() if not h.get("archived")])
        return active, archived
    except Exception:
        return "", ""


def _education_claims():
    try:
        total = 0
        for res in g.EDUCATION_RESOURCE.values():
            total += int(res.claimed_quantity())
        return total
    except Exception:
        return ""


def _annual_log_rows():
    try:
        import mastercode02_logging as logging_mod
        return len(logging_mod.LOG_DATA.get("annual_summary", []))
    except Exception:
        return ""


def _bus_refused():
    try:
        import mastercode02_logging as logging_mod
        rows = logging_mod.LOG_DATA.get("summary_resources", [])
        tot = 0
        for r in rows:
            if r.get("name") == "Bus Service":
                tot += int(r.get("waiting_or_refused", 0) or 0)
        return tot
    except Exception:
        return ""


def capture_state_snapshot(run_label: str, stage: str, year=None, env=None) -> dict:
    active_hh, archived_hh = _archive_counts()
    ledger_active, ledger_history, rental_claims, sale_claims = _ledger_counts()
    try:
        salabim_now = float(env.now()) if env is not None else ""
    except Exception:
        salabim_now = ""
    row = {
        "run_label": run_label,
        "snapshot_stage": stage,
        "year": year if year is not None else "",
        "population_count": len(g.POPULATION),
        "household_record_count": len(g.HOUSEHOLDS),
        "active_household_count": active_hh,
        "archived_household_count": archived_hh,
        "housing_ledger_active_claims": ledger_active,
        "housing_ledger_history_events": ledger_history,
        "housing_archive_count": archived_hh,
        "education_claim_count_if_available": _education_claims(),
        "rental_active_claims": rental_claims,
        "for_sale_active_claims": sale_claims,
        "bus_refused_if_available": _bus_refused(),
        "annual_log_rows": _annual_log_rows(),
        "max_person_id_if_available": getattr(g, "_person_id_counter", ""),
        "max_household_id_if_available": getattr(g, "_household_id_counter", ""),
        "random_state_digest_if_available": _python_random_digest(),
        "numpy_random_state_digest_if_available": _numpy_random_digest(),
        "salabim_now_if_available": salabim_now,
        "notes": "",
    }
    STATE_SNAPSHOTS.append(row)
    return row
