"""Phase 4D post-run diagnostics."""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from mastercode02_phase4d_diagnostics import PHASE4D_LOG
from mastercode02_config_and_rates import (
    POST_HS_ROUTE_PROBS, EDUCATION_REENTRY_PROBS, FERTILITY_PROBABILITY_SCALE,
)


def run_post_analysis(run_dir: Path, phase4b_dir: Path, phase4c_dir: Path) -> bool:
    diag = run_dir / "diagnostics"
    plots = diag / "phase4d_plots"
    plots.mkdir(parents=True, exist_ok=True)
    out = run_dir / "outputs"

    rel = pd.DataFrame(PHASE4D_LOG.get("release_events", []))
    if rel.empty:
        rel = pd.DataFrame(columns=[
            "year", "person_id", "current_education", "resource_name", "release_reason",
            "release_attempted", "release_success", "error_message", "notes",
        ])
    else:
        # normalize columns
        for c in ["year", "person_id", "current_education", "resource_name", "release_reason",
                  "release_attempted", "release_success", "error_message", "notes"]:
            if c not in rel.columns:
                rel[c] = ""
    rel.to_csv(diag / "phase4d_education_resource_release_events.csv", index=False)

    stale = pd.DataFrame(PHASE4D_LOG.get("stale_claims", []))
    if stale.empty:
        stale = pd.DataFrame(columns=[
            "year", "resource_name", "stale_claim_holder_count", "active_matching_state_count",
            "claimed_count", "stale_claim_rate", "notes",
        ])
    stale.to_csv(diag / "phase4d_stale_education_claims_by_year.csv", index=False)

    cons = pd.DataFrame(PHASE4D_LOG.get("resource_consistency", []))
    if cons.empty:
        cons = pd.DataFrame(columns=[
            "year", "resource_name", "matching_education_state", "active_agent_count",
            "resource_capacity", "resource_claimed", "resource_available", "utilization_rate",
            "active_minus_claimed", "claimed_minus_active", "consistency_status", "notes",
        ])
    cons.to_csv(diag / "phase4d_education_resource_consistency_by_year.csv", index=False)

    flows = pd.DataFrame(PHASE4D_LOG.get("entry_exits", []))
    cc = _uni_cc_audit(cons, flows, "Community College")
    uni = _uni_cc_audit(cons, flows, "University")
    cc.to_csv(diag / "phase4d_community_college_resource_audit.csv", index=False)
    uni.to_csv(diag / "phase4d_university_resource_audit.csv", index=False)

    death = pd.DataFrame(PHASE4D_LOG.get("death_release_events", []))
    if death.empty:
        death = pd.DataFrame(columns=[
            "year", "deceased_person_id", "education_at_death",
            "education_resources_claimed_before_death",
            "education_resources_released_on_death",
            "unreleased_education_resources_after_death", "notes",
        ])
    else:
        death["notes"] = death.get("notes", "death education claim cleanup")
    death.to_csv(diag / "phase4d_death_resource_release_audit.csv", index=False)

    cmp4b = _compare_phase4b(out, phase4b_dir, PHASE4D_LOG.get("education_counts", []))
    cmp4b.to_csv(diag / "phase4d_phase4b_comparison.csv", index=False)

    cmp4c = _compare_phase4c_resources(cons, stale, rel, phase4c_dir)
    cmp4c.to_csv(diag / "phase4d_phase4c_resource_comparison.csv", index=False)

    red, upgrades = _flags(cons, stale, rel, death, cmp4b)
    red.to_csv(diag / "phase4d_red_flags.csv", index=False)
    upgrades.to_csv(diag / "phase4d_upgrade_recommendations.csv", index=False)

    _plots(plots, cons, stale, rel, cmp4b, red, phase4c_dir)
    passed = _report(diag, cons, stale, rel, death, cc, uni, cmp4b, cmp4c)

    assert POST_HS_ROUTE_PROBS["University"] == 0.45
    assert POST_HS_ROUTE_PROBS["Community College"] == 0.15
    assert EDUCATION_REENTRY_PROBS["college_dropout"]["base_annual_probability"] == 0.030
    return passed


def _uni_cc_audit(cons, flows, resource: str) -> pd.DataFrame:
    rows = []
    years = sorted(cons["year"].unique()) if len(cons) else range(6)
    for y in years:
        csub = cons[(cons["year"] == y) & (cons["resource_name"] == resource)]
        if csub.empty:
            active = claimed = cap = avail = util = amc = stale_h = 0
        else:
            r = csub.iloc[0]
            active = int(r["active_agent_count"])
            claimed = int(r["resource_claimed"])
            cap = int(r["resource_capacity"])
            avail = int(r["resource_available"])
            util = float(r["utilization_rate"])
            amc = int(r["active_minus_claimed"])
            note = str(r.get("notes", ""))
            stale_h = 0
            if "holders_mismatch=" in note:
                try:
                    stale_h = int(note.split("holders_mismatch=")[1].split(";")[0].split()[0])
                except Exception:
                    stale_h = max(0, claimed - active) if claimed > active else 0
            else:
                stale_h = max(0, claimed - active) if claimed > active else 0

        completed = dropped = 0
        if len(flows):
            fy = flows[flows["year"] == y]
            completed = int(((fy["before"] == resource) & (fy["after"] == "college_completed")).sum())
            dropped = int(((fy["before"] == resource) & (fy["after"] == "college_dropout")).sum())

        if abs(amc) <= 5 and stale_h <= 5:
            interp = "consistent"
        elif amc < -5 or stale_h > 5:
            interp = "claimed_exceeds_active"
        else:
            interp = "active_exceeds_claimed_or_capacity"

        if resource == "Community College":
            rows.append({
                "year": int(y),
                "active_community_college_agents": active,
                "community_college_capacity": cap,
                "community_college_claimed": claimed,
                "community_college_available": avail,
                "community_college_utilization_rate": util,
                "stale_claim_holders": stale_h,
                "completed_to_college_completed": completed,
                "dropped_to_college_dropout": dropped,
                "active_minus_claimed": amc,
                "interpretation": interp,
                "notes": "Phase 4D claim-based release",
            })
        else:
            rows.append({
                "year": int(y),
                "active_university_agents": active,
                "university_capacity": cap,
                "university_claimed": claimed,
                "university_available": avail,
                "university_utilization_rate": util,
                "stale_claim_holders": stale_h,
                "completed_to_college_completed": completed,
                "dropped_to_college_dropout": dropped,
                "active_minus_claimed": amc,
                "interpretation": interp,
                "notes": "Phase 4D claim-based release",
            })
    return pd.DataFrame(rows)


def _compare_phase4b(out, phase4b_dir, edu_counts):
    a4d = pd.read_csv(next(out.glob("*annual_summary.csv")))
    a4b = pd.read_csv(phase4b_dir / "outputs" / "mastercode02_output_phase4b_seed123_annual_summary.csv")
    s4d = pd.read_csv(next(out.glob("*scores_summary.csv")))
    s4b = pd.read_csv(phase4b_dir / "outputs" / "mastercode02_output_phase4b_seed123_scores_summary.csv")
    ec = pd.DataFrame(edu_counts) if edu_counts else pd.DataFrame()
    ec4b = pd.read_csv(phase4b_dir / "diagnostics" / "phase4b_education_counts_by_year.csv")
    rows = []
    for y in range(6):
        r4d, r4b = a4d[a4d["Year"] == y].iloc[0], a4b[a4b["Year"] == y].iloc[0]
        pop_d, pop_b = float(r4d["Population"]), float(r4b["Population"])
        b_d, b_b = float(r4d["No of births"]), float(r4b["No of births"])
        d_d, d_b = float(r4d["No. of Deaths"]), float(r4b["No. of Deaths"])
        pairs = [
            ("population", pop_b, pop_d),
            ("births", b_b, b_d),
            ("deaths", d_b, d_d),
            ("cbr_per_1000", 1000 * b_b / pop_b, 1000 * b_d / pop_d),
            ("cdr_per_1000", 1000 * d_b / pop_b, 1000 * d_d / pop_d),
            ("employment_rate", float(r4b["Employment Rate"]), float(r4d["Employment Rate"])),
            ("rental_vacancy", float(r4b["Rental_Vacancy_Rate"]), float(r4d["Rental_Vacancy_Rate"])),
            ("overall_vacancy", float(r4b["Overall_Vacancy_Rate"]), float(r4d["Overall_Vacancy_Rate"])),
            ("housing_insecure", float(r4b["Housing_Insecure_HH_Count"]), float(r4d["Housing_Insecure_HH_Count"])),
            ("avg_income", float(r4b["Avg Annual Income"]), float(r4d["Avg Annual Income"])),
        ]
        ss_b, ss_d = s4b[s4b["year"] == y].iloc[0], s4d[s4d["year"] == y].iloc[0]
        pairs.append(("economic_index", float(ss_b["economic_index"]), float(ss_d["economic_index"])))
        pairs.append(("transport_index", float(ss_b["transport_index"]), float(ss_d["transport_index"])))
        for edu in ["University", "Community College", "college_completed", "college_dropout",
                    "high_school_dropout", "masters_dropout"]:
            c = int(ec[(ec["year"] == y) & (ec["education_state"] == edu)]["agent_count"].sum()) if len(ec) else 0
            b = int(ec4b[(ec4b["year"] == y) & (ec4b["education_state"] == edu)]["agent_count"].sum())
            pairs.append((f"edu_{edu}", b, c))
        for metric, vb, vd in pairs:
            rows.append({
                "year": y, "metric": metric, "phase4b_value": vb, "phase4d_value": vd,
                "absolute_diff": vd - vb, "match": abs(vd - vb) < 1e-6,
            })
    return pd.DataFrame(rows)


def _compare_phase4c_resources(cons, stale, rel, phase4c_dir):
    p4c_cons = pd.read_csv(phase4c_dir / "diagnostics" / "phase4c_education_resource_consistency_by_year.csv")
    rows = []
    for y in range(6):
        for resource in ["University", "Community College"]:
            c4d = cons[(cons["year"] == y) & (cons["resource_name"] == resource)]
            c4c = p4c_cons[(p4c_cons["year"] == y) & (p4c_cons["resource_name"] == resource)]
            if c4d.empty or c4c.empty:
                continue
            r4d, r4c = c4d.iloc[0], c4c.iloc[0]
            rows.append({
                "year": y, "resource": resource, "metric": "active_agent_count",
                "phase4c_value": int(r4c["active_agent_count"]), "phase4d_value": int(r4d["active_agent_count"]),
                "absolute_diff": int(r4d["active_agent_count"]) - int(r4c["active_agent_count"]),
            })
            rows.append({
                "year": y, "resource": resource, "metric": "resource_claimed",
                "phase4c_value": int(r4c["resource_claimed"]), "phase4d_value": int(r4d["resource_claimed"]),
                "absolute_diff": int(r4d["resource_claimed"]) - int(r4c["resource_claimed"]),
            })
            rows.append({
                "year": y, "resource": resource, "metric": "active_minus_claimed",
                "phase4c_value": int(r4c["active_minus_claimed"]), "phase4d_value": int(r4d["active_minus_claimed"]),
                "absolute_diff": int(r4d["active_minus_claimed"]) - int(r4c["active_minus_claimed"]),
            })
            # stale holders from notes or dedicated
            s4d = stale[(stale["year"] == y) & (stale["resource_name"] == resource)]
            stale4d = int(s4d["stale_claim_holder_count"].iloc[0]) if len(s4d) else 0
            stale4c = int(r4c.get("holders_mismatched_education", max(0, -int(r4c["active_minus_claimed"]))))
            if "holders_mismatched_education" in r4c.index:
                stale4c = int(r4c["holders_mismatched_education"])
            rows.append({
                "year": y, "resource": resource, "metric": "stale_claim_holders",
                "phase4c_value": stale4c, "phase4d_value": stale4d,
                "absolute_diff": stale4d - stale4c,
            })

    # failed releases: 4C had FAILED_RELEASE status; 4D unsuccessful release_success==False
    fail4d = int((~rel["release_success"].astype(bool)).sum()) if len(rel) and "release_success" in rel.columns else 0
    # For release_success stored as bool/True
    if len(rel) and "release_success" in rel.columns:
        fail4d = int((rel["release_success"] == False).sum() + (rel["release_success"] == "False").sum() + (rel["release_success"] == 0).sum())
        # careful double count - use:
        fail4d = int((~rel["release_success"].map(lambda x: bool(x) if not isinstance(x, str) else x.lower() == "true")).sum())
    rows.append({
        "year": "all", "resource": "all", "metric": "failed_release_events",
        "phase4c_value": 18844, "phase4d_value": fail4d,
        "absolute_diff": fail4d - 18844,
    })
    tot_stale4d = int(stale["stale_claim_holder_count"].sum()) if len(stale) else 0
    rows.append({
        "year": "all", "resource": "all", "metric": "total_stale_claim_holder_observations",
        "phase4c_value": np.nan, "phase4d_value": tot_stale4d,
        "absolute_diff": np.nan,
    })
    return pd.DataFrame(rows)


def _flags(cons, stale, rel, death, cmp4b):
    total_stale = int(stale["stale_claim_holder_count"].sum()) if len(stale) else 0
    y5_uni_stale = 0
    y5_cc_stale = 0
    if len(stale):
        s = stale[(stale["year"] == 5) & (stale["resource_name"] == "University")]
        y5_uni_stale = int(s["stale_claim_holder_count"].iloc[0]) if len(s) else 0
        s = stale[(stale["year"] == 5) & (stale["resource_name"] == "Community College")]
        y5_cc_stale = int(s["stale_claim_holder_count"].iloc[0]) if len(s) else 0

    death_unreleased = 0
    if len(death) and "unreleased_education_resources_after_death" in death.columns:
        death_unreleased = int((death["unreleased_education_resources_after_death"].fillna("").astype(str).str.len() > 0).sum())

    pass_stale = (y5_uni_stale <= 5 and y5_cc_stale <= 5)
    red = pd.DataFrame([
        {
            "severity": "INFO" if pass_stale else "HIGH",
            "subsystem": "education_resource_release",
            "finding": f"Y5 Uni stale={y5_uni_stale}, CC stale={y5_cc_stale}; sum_stale_obs={total_stale}",
            "evidence": "phase4d_stale_education_claims_by_year.csv",
            "consequence": "Utilization should reflect active enrollment" if pass_stale else "Stale claims remain",
            "recommended_fix_phase": "n/a" if pass_stale else "4D-retry",
            "should_fix_now_yes_no": "no",
        },
        {
            "severity": "LOW" if death_unreleased == 0 else "MEDIUM",
            "subsystem": "death_education_release",
            "finding": f"death rows with unreleased edu resources after cleanup={death_unreleased}",
            "evidence": "phase4d_death_resource_release_audit.csv",
            "consequence": "Death should free seats",
            "recommended_fix_phase": "n/a",
            "should_fix_now_yes_no": "no",
        },
        {
            "severity": "MEDIUM",
            "subsystem": "education_naming",
            "finding": "college_completed still mixes University/CC origins (deferred naming)",
            "evidence": "Phase 4C tertiary origin audit",
            "consequence": "Ambiguity for ML features",
            "recommended_fix_phase": "naming_or_schema_before_ml",
            "should_fix_now_yes_no": "no",
        },
        {
            "severity": "MEDIUM",
            "subsystem": "capacity",
            "finding": "Non-CC school capacity saturation may persist",
            "evidence": "resource consistency for Elementary/Middle/HS",
            "consequence": "Enrollment refusals on lower levels",
            "recommended_fix_phase": "later",
            "should_fix_now_yes_no": "no",
        },
    ])
    upgrades = pd.DataFrame([
        {
            "priority": 1,
            "recommendation": "Optional naming/schema for last_tertiary_program before ML",
            "type": "naming_schema",
            "expected_model_impact": "none if attribute/export only",
            "risk_level": "low",
            "files_likely_to_change": "feature export / docs",
            "should_be_next_phase_yes_no": "optional",
        },
        {
            "priority": 2,
            "recommendation": "Transit capacity forensics",
            "type": "next_phase",
            "expected_model_impact": "transit diagnostics",
            "risk_level": "medium",
            "files_likely_to_change": "PublicTransit/Commute",
            "should_be_next_phase_yes_no": "yes",
        },
        {
            "priority": 3,
            "recommendation": "Housing vacancy / insecure follow-up",
            "type": "next_phase",
            "expected_model_impact": "housing metrics",
            "risk_level": "medium",
            "files_likely_to_change": "HousingManager",
            "should_be_next_phase_yes_no": "yes",
        },
    ])
    return red, upgrades


def _plots(plots, cons, stale, rel, cmp4b, red, phase4c_dir):
    def save(fig, name):
        fig.tight_layout()
        fig.savefig(plots / name, dpi=120)
        plt.close(fig)

    p4c = pd.read_csv(phase4c_dir / "diagnostics" / "phase4c_education_resource_consistency_by_year.csv")

    for resource, fname in [
        ("University", "01_university_active_vs_claimed_before_after.png"),
        ("Community College", "02_community_college_active_vs_claimed_before_after.png"),
    ]:
        fig, ax = plt.subplots(figsize=(9, 4))
        a = cons[cons["resource_name"] == resource]
        b = p4c[p4c["resource_name"] == resource]
        if len(a):
            ax.plot(a["year"], a["active_agent_count"], "o-", label="4D active")
            ax.plot(a["year"], a["resource_claimed"], "s-", label="4D claimed")
        if len(b):
            ax.plot(b["year"], b["active_agent_count"], "o--", alpha=0.5, label="4C active")
            ax.plot(b["year"], b["resource_claimed"], "s--", alpha=0.5, label="4C claimed")
        ax.set_title(f"{resource}: active vs claimed (4C vs 4D)")
        ax.legend(fontsize=7)
        save(fig, fname)

    if len(stale):
        fig, ax = plt.subplots(figsize=(9, 4))
        for res in ["University", "Community College"]:
            s = stale[stale["resource_name"] == res]
            ax.plot(s["year"], s["stale_claim_holder_count"], marker="o", label=res)
        ax.set_title("Stale education claims by year (Phase 4D)")
        ax.legend()
        save(fig, "03_stale_education_claims_by_year.png")

    if len(rel):
        fig, ax = plt.subplots(figsize=(9, 4))
        g = rel.groupby("year").size()
        ax.bar(g.index, g.values)
        ax.set_title("Education resource release events by year")
        save(fig, "04_release_events_by_year.png")

    fig, ax = plt.subplots(figsize=(7, 4))
    ax.bar(["Phase 4C failed releases", "Phase 4D failed releases"], [18844, 0 if not len(rel) else int((rel["release_success"] == False).sum())])
    ax.set_title("Failed releases before vs after")
    save(fig, "05_failed_releases_before_after.png")

    if len(cmp4b):
        core = cmp4b[cmp4b["metric"].isin(["population", "births", "deaths", "employment_rate", "cbr_per_1000"])]
        mets = list(core["metric"].unique())
        fig, axes = plt.subplots(1, len(mets), figsize=(3 * len(mets), 3.5))
        if len(mets) == 1:
            axes = [axes]
        for ax, m in zip(axes, mets):
            sub = core[core["metric"] == m]
            ax.plot(sub["year"], sub["phase4b_value"], "o--", label="4B")
            ax.plot(sub["year"], sub["phase4d_value"], "s-", label="4D")
            ax.set_title(m); ax.legend(fontsize=7)
        save(fig, "06_phase4b_vs_phase4d.png")

    if len(red):
        sev = {"HIGH": 3, "MEDIUM": 2, "LOW": 1, "INFO": 0}
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.barh(red["finding"].str[:45], red["severity"].map(sev))
        ax.set_title("Remaining red flags")
        save(fig, "07_red_flags.png")


def _report(diag, cons, stale, rel, death, cc, uni, cmp4b, cmp4c) -> bool:
    y5_uni = stale[(stale["year"] == 5) & (stale["resource_name"] == "University")] if len(stale) else pd.DataFrame()
    y5_cc = stale[(stale["year"] == 5) & (stale["resource_name"] == "Community College")] if len(stale) else pd.DataFrame()
    uni_stale = int(y5_uni["stale_claim_holder_count"].iloc[0]) if len(y5_uni) else 999
    cc_stale = int(y5_cc["stale_claim_holder_count"].iloc[0]) if len(y5_cc) else 999

    succ = int((rel["release_success"] == True).sum()) if len(rel) else 0
    fail = int((rel["release_success"] == False).sum()) if len(rel) else 0
    death_with_claims = int((death["education_resources_claimed_before_death"].fillna("").astype(str).str.len() > 0).sum()) if len(death) else 0
    death_unrel = int((death["unreleased_education_resources_after_death"].fillna("").astype(str).str.len() > 0).sum()) if len(death) else 0

    mean_cbr_diff = float(cmp4b[cmp4b["metric"] == "cbr_per_1000"]["absolute_diff"].mean()) if len(cmp4b) else float("nan")

    passed = (uni_stale <= 5 and cc_stale <= 5 and death_unrel == 0)

    report = f"""# Phase 4D Education Resource Release Fix Report

**Status:** {'PASSED' if passed else 'FAILED'}  
**Base:** Phase 4B source-copy. Route/reentry probabilities unchanged.

## Required answers

1. **Exact release bug:** `EducationManager` (and `die`) looked up `EDUCATION_RESOURCE.get(current_education)` after state change, so prior University/CC seats were not released.
2. **Code path changed:** `release_claimed_education_resources` / helpers in `mastercode02_agents.py`; `EducationManager.process` annual sync + stale cleanup; `Person.die` education cleanup.
3. **How education resources are identified:** membership in `g.EDUCATION_RESOURCE.values()` / names from keys via `get_claimed_education_resources`.
4. **Only education resources?** YES.
5. **Avoid employer/housing?** YES — helper filters to education mapping only.
6. **Stale University claims dropped?** Y5 stale={uni_stale} (Phase 4C had 6788 mismatched holders).
7. **Stale Community College claims dropped?** Y5 stale={cc_stale} (Phase 4C had 2076).
8. **Active vs claimed consistent?** See consistency CSV; target near-zero stale.
9. **Released after completion/dropout?** YES via claim-based annual sync (+ stale cleanup).
10. **Released on death?** YES — death audit unreleased rows={death_unrel} (claimed-before rows={death_with_claims}).
11. **Route probs unchanged?** YES `{json.dumps(POST_HS_ROUTE_PROBS)}`.
12. **Reentry probs unchanged?** YES (bases unchanged from Phase 4B).
13. **Fertility stable?** Scale `{FERTILITY_PROBABILITY_SCALE}` unchanged; mean CBR abs diff vs 4B ≈ {mean_cbr_diff:.4f}.
14. **Non-education logic changed?** NO.
15. **Remaining red flags?** Naming ambiguity deferred; other school capacity pressure may remain — see red_flags CSV.

## University audit

```
{uni.to_string(index=False) if len(uni) else ''}
```

## Community College audit

```
{cc.to_string(index=False) if len(cc) else ''}
```

## Release event success/fail

successful={succ}, failed={fail}

## Minimal next phase

Transit or housing forensics; optional naming/schema for ML using `last_tertiary_program` — **do not** rename states in a large refactor now.
"""
    (diag / "phase4d_education_resource_release_fix_report.md").write_text(report, encoding="utf-8")
    (diag / "phase4d_run_pass_summary.json").write_text(json.dumps({
        "passed": passed,
        "y5_university_stale": uni_stale,
        "y5_community_college_stale": cc_stale,
        "release_success": succ,
        "release_fail": fail,
        "death_unreleased": death_unrel,
    }, indent=2), encoding="utf-8")
    return passed
