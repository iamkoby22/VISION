"""Phase 3C post-run analysis."""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from mastercode02_phase3c_diagnostics import PHASE3C_LOG
from mastercode02_utils import is_married_status
from mastercode02_config_and_rates import FERTILITY_PROBABILITY_SCALE, TARGET_CRUDE_BIRTH_RATE_PER_1000


def write_classification_audit(diag_dir: Path) -> pd.DataFrame:
    status_df = pd.DataFrame(PHASE3C_LOG["status_counts_by_year"])
    if status_df.empty:
        return pd.DataFrame()
    y0 = status_df[status_df["year"] == 0].set_index("raw_status")["count"]
    yf = status_df[status_df["year"] == status_df["year"].max()].set_index("raw_status")["count"]
    all_statuses = sorted(set(status_df["raw_status"]))
    rows = []
    for raw in all_statuses:
        status_val = None if raw == "<None>" else raw
        classified = is_married_status(status_val)
        norm = "" if status_val is None else str(status_val).strip().lower()
        note = "classified married for fertility table" if classified else "classified unmarried for fertility table"
        if status_val and "except separated" in str(status_val).lower():
            note = "Now married (except separated) -> Married table"
        if status_val and str(status_val).lower() in ("separated",):
            note = "Separated -> Unmarried table (Phase 3C rule)"
        rows.append({
            "raw_status": raw,
            "normalized_status": norm,
            "classified_as_married": classified,
            "count_year0": int(y0.get(raw, 0)),
            "count_final_year": int(yf.get(raw, 0)),
            "note": note,
        })
    audit = pd.DataFrame(rows)
    audit.to_csv(diag_dir / "phase3c_marital_status_classification_audit.csv", index=False)
    return audit


def write_metrics_and_trace(diag_dir: Path, annual: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    metrics = pd.DataFrame(PHASE3C_LOG["fertility_metrics"])
    births_map = dict(zip(annual["Year"], annual["No of births"]))
    deaths_map = dict(zip(annual["Year"], annual["No. of Deaths"]))
    pop_map = dict(zip(annual["Year"], annual["Population"]))
    if len(metrics):
        metrics["population"] = metrics["year"].map(pop_map)
        metrics["births"] = metrics["year"].map(births_map)
        metrics["actual_births"] = metrics["births"]
        metrics["deaths"] = metrics["year"].map(deaths_map)
        metrics["cbr_per_1000"] = metrics.apply(
            lambda r: r["births"] / r["population"] * 1000 if r["population"] else 0, axis=1
        )
        metrics["cdr_per_1000"] = metrics.apply(
            lambda r: r["deaths"] / r["population"] * 1000 if r["population"] else 0, axis=1
        )
        metrics.to_csv(diag_dir / "phase3c_fertility_metrics.csv", index=False)
    trace = pd.DataFrame(PHASE3C_LOG["birth_trace"])
    trace.to_csv(diag_dir / "phase3c_birth_trace_sample.csv", index=False)
    return metrics, trace


def _wa_rate(path: Path) -> float:
    if not path.exists():
        return float("nan")
    pop = pd.read_csv(path)
    wa = pop[(pop["age"] >= 18) & (pop["age"] < 65)]
    if len(wa) == 0:
        return float("nan")
    return float((wa["employment_status"] == "Employed").sum() / len(wa))


def compare_runs(current_out: Path, other_out: Path, other_label: str, current_prefix: str, other_prefix: str) -> pd.DataFrame:
    cur = pd.read_csv(current_out / f"{current_prefix}_annual_summary.csv")
    oth = pd.read_csv(other_out / f"{other_prefix}_annual_summary.csv")
    curs = pd.read_csv(current_out / f"{current_prefix}_scores_summary.csv")
    oths = pd.read_csv(other_out / f"{other_prefix}_scores_summary.csv")
    wa_cur = _wa_rate(current_out / f"{current_prefix}_population_datasheet.csv")
    wa_oth = _wa_rate(other_out / f"{other_prefix}_population_datasheet.csv")
    rows = []
    for y in range(6):
        c = cur[cur["Year"] == y].iloc[0]
        o = oth[oth["Year"] == y].iloc[0]
        pairs = [
            ("population", float(o["Population"]), float(c["Population"])),
            ("births", float(o["No of births"]), float(c["No of births"])),
            ("deaths", float(o["No. of Deaths"]), float(c["No. of Deaths"])),
            ("cbr_per_1000", float(o["No of births"]) / float(o["Population"]) * 1000,
             float(c["No of births"]) / float(c["Population"]) * 1000),
            ("cdr_per_1000", float(o["No. of Deaths"]) / float(o["Population"]) * 1000,
             float(c["No. of Deaths"]) / float(c["Population"]) * 1000),
            ("employment_rate", float(o["Employment Rate"]), float(c["Employment Rate"])),
            ("rental_vacancy", float(o["Rental_Vacancy_Rate"]), float(c["Rental_Vacancy_Rate"])),
            ("overall_vacancy", float(o["Overall_Vacancy_Rate"]), float(c["Overall_Vacancy_Rate"])),
            ("housing_insecure", float(o["Housing_Insecure_HH_Count"]), float(c["Housing_Insecure_HH_Count"])),
            ("avg_income", float(o["Avg Annual Income"]), float(c["Avg Annual Income"])),
        ]
        for label, vo, vc in pairs:
            rows.append({
                "year": y, "metric": label,
                f"{other_label}_value": vo, "phase3c_value": vc,
                "absolute_diff": vc - vo,
                "relative_diff_pct": ((vc - vo) / vo * 100) if vo != 0 else (0 if vc == 0 else np.nan),
            })
        rows.append({
            "year": y, "metric": "working_age_employment_rate",
            f"{other_label}_value": wa_oth if y == 5 else np.nan,
            "phase3c_value": wa_cur if y == 5 else np.nan,
            "absolute_diff": (wa_cur - wa_oth) if y == 5 else np.nan,
            "relative_diff_pct": ((wa_cur - wa_oth) / wa_oth * 100) if y == 5 and wa_oth else np.nan,
        })
        for label, col in [("economic_index", "economic_index"), ("transport_index", "transport_index")]:
            vo = float(oths.loc[oths["year"] == y, col].iloc[0])
            vc = float(curs.loc[curs["year"] == y, col].iloc[0])
            rows.append({
                "year": y, "metric": label,
                f"{other_label}_value": vo, "phase3c_value": vc,
                "absolute_diff": vc - vo,
                "relative_diff_pct": ((vc - vo) / vo * 100) if vo != 0 else 0,
            })
    return pd.DataFrame(rows)


def generate_plots(
    diag_dir: Path,
    annual_3c: pd.DataFrame,
    annual_3b: pd.DataFrame,
    annual_2: pd.DataFrame,
    metrics: pd.DataFrame,
    audit: pd.DataFrame,
    red: pd.DataFrame,
) -> None:
    pdir = diag_dir / "phase3c_plots"
    pdir.mkdir(parents=True, exist_ok=True)
    years = annual_3c["Year"]

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(years, annual_2["No of births"], "o--", label="Phase 2")
    ax.plot(years, annual_3b["No of births"], "s--", label="Phase 3B")
    ax.plot(years, annual_3c["No of births"], "^-", label="Phase 3C")
    ax.set_title("Births by Year: Phase 2 vs 3B vs 3C")
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(pdir / "01_births_comparison.png", dpi=150)
    plt.close(fig)

    def cbr(df):
        return df["No of births"] / df["Population"] * 1000

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(years, cbr(annual_2), "o--", label="Phase 2")
    ax.plot(years, cbr(annual_3b), "s--", label="Phase 3B")
    ax.plot(years, cbr(annual_3c), "^-", label="Phase 3C")
    ax.axhline(12, color="gray", linestyle=":")
    ax.axhline(10, color="green", linestyle=":", alpha=0.5)
    ax.axhline(14, color="green", linestyle=":", alpha=0.5, label="Target 10–14")
    ax.set_title("CBR by Year: Phase 2 vs 3B vs 3C")
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(pdir / "02_cbr_comparison.png", dpi=150)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(years, annual_3b["Population"], "s--", label="Phase 3B")
    ax.plot(years, annual_3c["Population"], "^-", label="Phase 3C")
    ax.set_title("Population: Phase 3B vs Phase 3C")
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(pdir / "03_population_3b_vs_3c.png", dpi=150)
    plt.close(fig)

    if len(metrics):
        fig, ax = plt.subplots(figsize=(8, 5))
        ax.plot(metrics["year"], metrics["married_fertile_female_count"], "o-", label="Married fertile")
        ax.plot(metrics["year"], metrics["unmarried_fertile_female_count"], "s-", label="Unmarried fertile")
        ax.set_title("Married vs Unmarried Fertile Female Counts")
        ax.legend()
        ax.grid(True, alpha=0.3)
        fig.tight_layout()
        fig.savefig(pdir / "04_married_unmarried_fertile.png", dpi=150)
        plt.close(fig)

        fig, ax = plt.subplots(figsize=(8, 5))
        ax.bar(metrics["year"] - 0.15, metrics["expected_births_married_table"], width=0.3, label="Expected married table")
        ax.bar(metrics["year"] + 0.15, metrics["expected_births_unmarried_table"], width=0.3, label="Expected unmarried table")
        ax.set_title("Expected Births by Fertility Table Used")
        ax.legend()
        fig.tight_layout()
        fig.savefig(pdir / "05_expected_by_table.png", dpi=150)
        plt.close(fig)

    if len(audit):
        fig, ax = plt.subplots(figsize=(10, 5))
        ax.barh(audit["raw_status"].astype(str), audit["count_final_year"], color=["C2" if x else "C1" for x in audit["classified_as_married"]])
        ax.set_title("Final-Year Marital Status Counts (green=married class)")
        fig.tight_layout()
        fig.savefig(pdir / "06_classification_counts.png", dpi=150)
        plt.close(fig)

    if len(red):
        fig, ax = plt.subplots(figsize=(8, 5))
        sev = red["severity"].value_counts()
        ax.bar(sev.index.astype(str), sev.values)
        ax.set_title("Remaining Red Flags by Severity")
        fig.tight_layout()
        fig.savefig(pdir / "07_remaining_red_flags.png", dpi=150)
        plt.close(fig)


def build_red_flags(annual: pd.DataFrame, cmp_3b: pd.DataFrame, audit: pd.DataFrame, trace: pd.DataFrame) -> pd.DataFrame:
    flags = []
    active = annual[annual["Year"] >= 1]
    avg_cbr = float((active["No of births"] / active["Population"] * 1000).mean())
    if 10 <= avg_cbr <= 14:
        sev = "LOW"
    elif avg_cbr < 10:
        sev = "HIGH"
    else:
        sev = "HIGH"
    flags.append({
        "severity": sev, "category": "fertility_cbr",
        "finding": f"Average CBR years 1–5 = {avg_cbr:.2f} per 1,000",
        "detail": f"Target band 10–14; scale unchanged at {FERTILITY_PROBABILITY_SCALE}",
    })
    # Now married should classify as married
    now_married = audit[audit["raw_status"].str.contains("Now married", case=False, na=False)]
    if len(now_married) and bool(now_married["classified_as_married"].all()):
        flags.append({
            "severity": "LOW", "category": "marital_classification",
            "finding": "'Now married (except separated)' classified as married",
            "detail": "Phase 3C helper applied",
        })
    else:
        flags.append({
            "severity": "HIGH", "category": "marital_classification",
            "finding": "Now married classification missing or incorrect",
            "detail": "Check is_married_status",
        })
    if len(trace) and "classified_as_married" in trace.columns:
        flags.append({
            "severity": "LOW", "category": "birth_trace",
            "finding": f"Birth trace rows={len(trace)}; married-class births={(trace['classified_as_married']==True).sum()}",
            "detail": "Trace confirms fertility_table_used field present",
        })
    flags.append({
        "severity": "MEDIUM", "category": "deferred",
        "finding": "Fertility scale not retuned in Phase 3C",
        "detail": "Optional Phase 3D scale bump only if still below band",
    })
    flags.append({
        "severity": "MEDIUM", "category": "deferred",
        "finding": "Education / transit / housing fixes deferred",
        "detail": "Per stopping rule",
    })
    return pd.DataFrame(flags)


def build_upgrade_recommendations(avg_cbr: float) -> pd.DataFrame:
    return pd.DataFrame([
        {"priority": 1, "phase": "3D", "area": "optional_fertility_scale_bump",
         "rationale": f"Avg CBR={avg_cbr:.2f}; raise scale only if still below 10"},
        {"priority": 2, "phase": "4", "area": "education_routing", "rationale": "Community College unused"},
        {"priority": 3, "phase": "4", "area": "transit_capacity", "rationale": "Bus refusal"},
        {"priority": 4, "phase": "4", "area": "housing_metric_definitions", "rationale": "Vacancy / insecure HH"},
    ])


def write_report(diag_dir: Path, run_dir: Path, passed: bool, annual: pd.DataFrame,
                 cmp_3b: pd.DataFrame, avg_cbr: float) -> None:
    birth = cmp_3b[cmp_3b["metric"] == "births"].sort_values("year")
    cbr = cmp_3b[cmp_3b["metric"] == "cbr_per_1000"].sort_values("year")
    pop5 = cmp_3b[(cmp_3b["metric"] == "population") & (cmp_3b["year"] == 5)].iloc[0]
    lines = [
        "# Phase 3C Marital Classification Report",
        "",
        f"**Run:** `{run_dir.name}`",
        f"**Status:** {'PASSED' if passed else 'FAILED'}",
        "",
        "## Scope",
        "",
        "- Fertility scale: **unchanged** from Phase 3B",
        f"- Scale value: `{FERTILITY_PROBABILITY_SCALE}`",
        "- Raw fertility table: **unchanged**",
        "- Only marital classification for fertility table selection changed",
        "",
        f"## Average CBR years 1–5: **{avg_cbr:.2f}** per 1,000 (target 10–14)",
        "",
        f"Year 5 population Phase 3B → Phase 3C: {pop5['phase3b_value']:.0f} → {pop5['phase3c_value']:.0f} (Δ {pop5['absolute_diff']:.0f})",
        "",
        "## Births Phase 3B vs Phase 3C",
        "",
        "| Year | Phase 3B | Phase 3C | Diff |",
        "|-----:|---------:|---------:|-----:|",
    ]
    for _, r in birth.iterrows():
        lines.append(f"| {int(r['year'])} | {r['phase3b_value']:.0f} | {r['phase3c_value']:.0f} | {r['absolute_diff']:.0f} |")
    lines += [
        "",
        "## CBR Phase 3B vs Phase 3C",
        "",
        "| Year | Phase 3B | Phase 3C |",
        "|-----:|---------:|---------:|",
    ]
    for _, r in cbr.iterrows():
        lines.append(f"| {int(r['year'])} | {r['phase3b_value']:.2f} | {r['phase3c_value']:.2f} |")
    lines += [
        "",
        "## Next",
        "",
        "Stop after Phase 3C. Do not retune scale in this phase.",
        "Recommended next: optional Phase 3D scale bump only if still below band; else education/transit/housing.",
    ]
    (diag_dir / "phase3c_marital_classification_report.md").write_text("\n".join(lines), encoding="utf-8")


def run_post_analysis(run_dir: Path, phase3b_dir: Path, phase2_dir: Path) -> bool:
    diag_dir = run_dir / "diagnostics"
    out_dir = run_dir / "outputs"
    annual = pd.read_csv(out_dir / "mastercode02_output_phase3c_seed123_annual_summary.csv")
    annual_3b = pd.read_csv(phase3b_dir / "outputs" / "mastercode02_output_phase3b_seed123_annual_summary.csv")
    annual_2 = pd.read_csv(phase2_dir / "outputs" / "mastercode02_output_phase2_seed123_annual_summary.csv")

    audit = write_classification_audit(diag_dir)
    metrics, trace = write_metrics_and_trace(diag_dir, annual)

    cmp_3b = compare_runs(
        out_dir, phase3b_dir / "outputs", "phase3b",
        "mastercode02_output_phase3c_seed123", "mastercode02_output_phase3b_seed123",
    )
    cmp_3b.to_csv(diag_dir / "phase3c_phase3b_comparison.csv", index=False)

    cmp_2 = compare_runs(
        out_dir, phase2_dir / "outputs", "phase2",
        "mastercode02_output_phase3c_seed123", "mastercode02_output_phase2_seed123",
    )
    cmp_2.to_csv(diag_dir / "phase3c_phase2_comparison.csv", index=False)

    active = annual[annual["Year"] >= 1]
    avg_cbr = float((active["No of births"] / active["Population"] * 1000).mean())
    red = build_red_flags(annual, cmp_3b, audit, trace)
    red.to_csv(diag_dir / "phase3c_red_flags.csv", index=False)
    build_upgrade_recommendations(avg_cbr).to_csv(diag_dir / "phase3c_upgrade_recommendations.csv", index=False)

    generate_plots(diag_dir, annual, annual_3b, annual_2, metrics, audit, red)

    # Pass: implementation criteria + run success; CBR band is preferred but not hard-fail if classification works
    helper_ok = len(audit) > 0 and audit[audit["raw_status"].str.contains("Now married", case=False, na=False)]["classified_as_married"].all() if len(audit) else False
    scale_ok = abs(FERTILITY_PROBABILITY_SCALE - 0.16282731901148145) < 1e-12
    overshoot = avg_cbr > 14
    # Pass if classification fixed and scale unchanged and no overshoot; below-band is allowed with report
    passed = bool(helper_ok and scale_ok and not overshoot and len(trace) > 0)
    write_report(diag_dir, run_dir, passed, annual, cmp_3b, avg_cbr)
    return passed
