# r2_marital_crosswalk.py
# R2 -- POST-PROCESSING ONLY. Builds a validation-side marital-status crosswalk
# from an already-written population_datasheet.csv. Does NOT touch
# MarriageManager or any marital_status write logic in the simulation --
# per R1's 08_r1_marital_scope_decision.md, MAR-003 is fixed as an
# OBSERVABILITY_FIX/VALIDATION_FIX (export a harmonized field alongside the
# raw ones), never a runtime behavior change. Preserves every raw label
# untouched; adds a derived column.

import csv, sys, os

# Mirrors mastercode02_utils.is_married_status() EXACTLY (read-only reference
# copy for post-processing use; the runtime's own copy is the sole source of
# truth used during simulation -- this crosswalk must never diverge from it,
# so if that function is ever edited, this copy must be updated to match).
def is_married_status(status) -> bool:
    if status is None:
        return False
    s = str(status).strip().lower()
    if not s:
        return False
    if s in ("never married", "unmarried", "divorced", "separated", "widowed", "single"):
        return False
    if s.startswith("never married") or s.startswith("divorced") or s.startswith("widowed"):
        return False
    if "separated" in s and "married" not in s:
        return False
    if s.startswith("separated"):
        return False
    if "married" in s:
        return True
    return False


# ACS DP02 categories this project's own observed data already uses
# (validation/observed_2023_long.csv MARITAL_* rows) -- the crosswalk target.
ACS_DP02_CATEGORIES = [
    'Never married', 'Now married (except separated)', 'Separated', 'Widowed', 'Divorced',
]


def canonical_validation_status(raw_status):
    """Harmonizes VISION Core's raw marital_status strings (which currently
    mix T0-origin 'Now married (except separated)' and runtime-origin
    'Married' as two different strings for the same married state -- MAR-003)
    into a single ACS-DP02-comparable category. Never mutates the raw value;
    this is purely a derived mapping for validation use."""
    if raw_status is None:
        return 'UNMAPPED'
    s = str(raw_status).strip()
    if s in ACS_DP02_CATEGORIES:
        return s  # already canonical (T0-origin records)
    if is_married_status(s):
        return 'Now married (except separated)'  # runtime-origin 'Married' -> canonical
    if s.lower() in ('never married', 'unmarried', 'single'):
        return 'Never married'
    return 'UNMAPPED'


def build_crosswalk(population_datasheet_path, out_path):
    rows_out = []
    mapping_status_counts = {}
    with open(population_datasheet_path, encoding='utf-8', newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            raw = row.get('marital_status')
            canonical = canonical_validation_status(raw)
            mapping_status = 'MAPPED' if canonical != 'UNMAPPED' else 'UNMAPPED_REQUIRES_REVIEW'
            mapping_status_counts[mapping_status] = mapping_status_counts.get(mapping_status, 0) + 1
            rows_out.append({
                'person_id': row.get('person_id'),
                'year': row.get('year'),
                'calendar_year': row.get('calendar_year'),
                'raw_model_status': raw,
                'canonical_validation_status': canonical,
                'observed_status': '',  # filled in by a separate join against observed_2023_long.csv, not this script
                'mapping_status': mapping_status,
            })
    with open(out_path, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=['person_id', 'year', 'calendar_year', 'raw_model_status',
                                           'canonical_validation_status', 'observed_status', 'mapping_status'])
        w.writeheader()
        w.writerows(rows_out)
    return len(rows_out), mapping_status_counts


if __name__ == '__main__':
    if len(sys.argv) != 3:
        print("usage: r2_marital_crosswalk.py <population_datasheet.csv> <out_crosswalk.csv>")
        sys.exit(1)
    n, counts = build_crosswalk(sys.argv[1], sys.argv[2])
    print(f"Wrote {n} crosswalk rows to {sys.argv[2]}. mapping_status counts: {counts}")
