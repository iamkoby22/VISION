# mastercode02_setup.py
import salabim as sim, random
from mastercode02_config_and_rates import (
    EMPLOYERS, EMPLOYER_PROBS, EDUCATION_CAPACITIES, HOUSING_STOCK,
    INITIAL_TENURE_SYNTHESIS_ENABLED,
)
from mastercode02_agents import Person
import mastercode02_globals as g
from mastercode02_generator import generate_initial_population, DATA
from mastercode02_housing_ledger import (
    reset_housing_ledger,
    get_housing_available_count,
    assign_housing_to_household,
    mark_household_insecure,
)
from mastercode02_initial_tenure import synthesize_initial_housing

class Initializer(sim.Component):
    def __init__(self, env):
        super().__init__(env=env)

    def process(self):
        print("\n--- RUNNING MASTERCODE02 INITIALIZER ---\n")

        g.POPULATION.clear(); g.HOUSEHOLDS.clear()
        reset_housing_ledger()
        generated_agents_data = generate_initial_population()
        for agent_data in generated_agents_data:
            initial_data = {'id': g.next_person_id(),'age': agent_data.age,'sex': agent_data.sex,'education': agent_data.education,'employment': agent_data.employment,'household_id': None,'marital_status': agent_data.marital_status}
            Person(self.env, initial_data, g.POPULATION)

        household_ids = []
        for hh_type, count in DATA['households'].items():
            for _ in range(count):
                hh_id = g.next_household_id()
                g.HOUSEHOLDS[hh_id] = {'id': hh_id, 'type': hh_type, 'members': []}
                household_ids.append(hh_id)

        unplaced_agents = list(g.POPULATION)
        random.shuffle(unplaced_agents)
        for person in unplaced_agents:
            # R11.1: household_ids is built once above, in the same order
            # g.HOUSEHOLDS was populated, so random.choice(household_ids) selects
            # from an identical sequence to the prior random.choice(list(g.HOUSEHOLDS.keys()))
            # -- same RNG consumption per person, same eligible population -- without
            # rebuilding an O(H) list on every one of the P iterations.
            target_hh_id = random.choice(household_ids)
            person.household_id = target_hh_id
            g.HOUSEHOLDS[target_hh_id]['members'].append(person)

        for name, capacity in EDUCATION_CAPACITIES.items(): g.EDUCATION_RESOURCE[name] = sim.Resource(name, capacity=capacity, env=self.env)
        for emp_id, emp_data in EMPLOYERS.items(): g.EMPLOYER_RESOURCE[emp_id] = sim.Resource(emp_data['name'], capacity=emp_data['capacity'], env=self.env)
        for name, data in HOUSING_STOCK.items(): g.HOUSING_RESOURCE[name] = sim.Resource(name, capacity=data['capacity'], env=self.env)

        print("Initializer: Pre-assigning initial employers and income...")
        employer_ids = list(EMPLOYERS.keys())
        for person in g.POPULATION:
            if person.employment_status == 'Employed':
                chosen_employer_id = random.choices(employer_ids, weights=EMPLOYER_PROBS, k=1)[0]
                person.employer = chosen_employer_id
                person._assign_skill_and_income()

        print("Initializer: Placing initial households into housing units...")
        year0 = 0
        if INITIAL_TENURE_SYNTHESIS_ENABLED:
            print("Initializer: Phase 6D tenure synthesis (matrix + ledger; baseline owners, no purchase event)")
            synthesize_initial_housing(year0)
        else:
            # Legacy Phase 6B rental-only path (fallback)
            for hh_id, hh_data in g.HOUSEHOLDS.items():
                if not hh_data.get('members'):
                    mark_household_insecure(hh_id, year0, reason='initializer_empty_household')
                    continue
                placed = False
                for unit_name, unit_data in HOUSING_STOCK.items():
                    if unit_data['type'] == 'Rental' and get_housing_available_count(unit_name) > 0:
                        if assign_housing_to_household(hh_id, unit_name, 'Renter', year0, reason='initializer_rental'):
                            placed = True
                            break
                if not placed:
                    mark_household_insecure(hh_id, year0, reason='initializer_no_rental_capacity')

        print("Initializer: Initial state setup is complete.")

        for person in g.POPULATION:
            person.activate()

        print(f"\nSUCCESS: Initialized and activated {len(g.POPULATION)} people in {len(g.HOUSEHOLDS)} households.")
        yield self.hold(0)
