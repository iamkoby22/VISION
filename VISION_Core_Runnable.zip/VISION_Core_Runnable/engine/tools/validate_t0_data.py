"""Phase 9E-T0 — t=0 data validator (Checkpoint 1).

Validates a t=0 payload against the canonical generator DATA contract.
Standalone: no third-party deps, importable by the backend/runner in later checkpoints.

This module does NOT apply t=0 data. It only validates structure/values.

Public API:
    validate_t0_data(payload, *, allow_partial=False) -> ValidationResult
    load_and_validate(path_or_text, *, allow_partial=False) -> ValidationResult

CLI:
    python validate_t0_data.py <file.json>        # exit 0 valid, 2 invalid, 3 usage
"""
from __future__ import annotations

import json
import math
import sys
from dataclasses import dataclass, field
from typing import Any

# --- Canonical labels (authoritative, from Subphase A forensics of approved DATA) ---
SEXES = ("Male", "Female")

AGE_GROUP_LABELS = (
    "Under 5 years", "5 to 9 years", "10 to 14 years", "15 to 19 years",
    "20 to 24 years", "25 to 29 years", "30 to 34 years", "35 to 39 years",
    "40 to 44 years", "45 to 49 years", "50 to 54 years", "55 to 59 years",
    "60 to 64 years", "65 to 69 years", "70 to 74 years", "75 to 79 years",
    "80 to 84 years", "85 years and over",
)

HOUSEHOLD_TYPES = (
    "Married-couple family household",
    "Male householder, no spouse present, family household",
    "Female householder, no spouse present, family household",
    "Nonfamily household",
)

EMPLOYMENT_BANDS = (
    "16-19", "20-24", "25-29", "30-34", "35-44",
    "45-54", "55-59", "60-64", "65-74", "75+",
)
EMPLOYMENT_FIELDS = ("emp_ratio", "unemp_rate")

MARITAL_AGE_BANDS = ("15-19", "20-34", "35-44", "45-54", "55-64", "65+")
MARITAL_STATUSES = (
    "Never married",
    "Now married (except separated)",
    "Widowed",
    "Divorced",
    "Separated",
)

REQUIRED_BLOCKS = ("demographics", "households", "employment", "marital_status")
ALLOWED_TOP_LEVEL = set(REQUIRED_BLOCKS) | {"metadata"}

# Probability sum tolerance. Must be >= 0.001 so the verbatim default (which contains
# distributions summing to 0.999 / 1.001) passes its own validation. Set to 0.01.
PROB_SUM_TOL = 0.01


@dataclass
class ValidationResult:
    ok: bool
    errors: list[dict] = field(default_factory=list)
    warnings: list[dict] = field(default_factory=list)
    computed: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "ok": self.ok,
            "errors": self.errors,
            "warnings": self.warnings,
            "computed": self.computed,
        }


def _err(errors: list[dict], path: str, message: str) -> None:
    errors.append({"path": path, "message": message})


def _is_finite_number(v: Any) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def _is_nonneg_int(v: Any) -> bool:
    return isinstance(v, int) and not isinstance(v, bool) and v >= 0


def validate_t0_data(payload: Any, *, allow_partial: bool = False) -> ValidationResult:
    errors: list[dict] = []
    warnings: list[dict] = []
    computed: dict = {}

    # 1. Accept JSON object only
    if not isinstance(payload, dict):
        _err(errors, "$", "t0 payload must be a JSON object (dict).")
        return ValidationResult(False, errors, warnings, computed)

    # 12. Reject unknown top-level keys (destructive structural change)
    for key in payload:
        if key not in ALLOWED_TOP_LEVEL:
            _err(errors, f"$.{key}", f"Unknown top-level key '{key}'. Allowed: {sorted(ALLOWED_TOP_LEVEL)}.")

    # 2. Required top-level blocks (unless partial explicitly allowed)
    present_blocks = [b for b in REQUIRED_BLOCKS if b in payload]
    if not allow_partial:
        for b in REQUIRED_BLOCKS:
            if b not in payload:
                _err(errors, f"$.{b}", f"Missing required block '{b}'. "
                                       f"(Set allow_partial=True to validate a partial override.)")
    elif not present_blocks:
        _err(errors, "$", "Partial validation requested but no known t0 block present.")

    # ---- demographics ----
    if "demographics" in payload:
        demo = payload["demographics"]
        if not isinstance(demo, dict):
            _err(errors, "$.demographics", "demographics must be an object.")
        else:
            for sex in demo:
                if sex not in SEXES:
                    _err(errors, f"$.demographics.{sex}", f"Unknown sex label '{sex}'. Allowed: {list(SEXES)}.")
            pop_total = 0
            for sex, groups in demo.items():
                if sex not in SEXES:
                    continue
                if not isinstance(groups, dict):
                    _err(errors, f"$.demographics.{sex}", "must be an object of age_group -> count.")
                    continue
                for label, count in groups.items():
                    p = f"$.demographics.{sex}.{label}"
                    if label not in AGE_GROUP_LABELS:
                        _err(errors, p, f"Unknown age group label '{label}'.")
                    # 3. nonnegative integer population count
                    if not _is_nonneg_int(count):
                        _err(errors, p, f"Population count must be a nonnegative integer, got {count!r}.")
                    else:
                        pop_total += count
            computed["population_total"] = pop_total
            # 10. total population consistency where possible
            meta = payload.get("metadata") or {}
            exp = meta.get("expected_population_total")
            if isinstance(exp, int) and not isinstance(exp, bool) and exp != pop_total:
                _err(errors, "$.metadata.expected_population_total",
                     f"expected_population_total ({exp}) != sum of demographics counts ({pop_total}).")

    # ---- households ----
    if "households" in payload:
        hh = payload["households"]
        if not isinstance(hh, dict):
            _err(errors, "$.households", "households must be an object.")
        else:
            hh_total = 0
            for htype, count in hh.items():
                p = f"$.households.{htype}"
                if htype not in HOUSEHOLD_TYPES:
                    _err(errors, p, f"Unknown household type '{htype}'.")
                # 4. nonnegative integer household count
                if not _is_nonneg_int(count):
                    _err(errors, p, f"Household count must be a nonnegative integer, got {count!r}.")
                else:
                    hh_total += count
            computed["household_total"] = hh_total
            # 11. total household consistency where possible
            meta = payload.get("metadata") or {}
            exp = meta.get("expected_household_total")
            if isinstance(exp, int) and not isinstance(exp, bool) and exp != hh_total:
                _err(errors, "$.metadata.expected_household_total",
                     f"expected_household_total ({exp}) != sum of household counts ({hh_total}).")

    # ---- employment ----
    if "employment" in payload:
        emp = payload["employment"]
        if not isinstance(emp, dict):
            _err(errors, "$.employment", "employment must be an object.")
        else:
            for band, rates in emp.items():
                p = f"$.employment.{band}"
                if band not in EMPLOYMENT_BANDS:
                    _err(errors, p, f"Unknown employment band '{band}'.")
                if not isinstance(rates, dict):
                    _err(errors, p, "employment band must be an object with emp_ratio, unemp_rate.")
                    continue
                for fld in EMPLOYMENT_FIELDS:
                    if fld not in rates:
                        _err(errors, f"{p}.{fld}", f"Missing required field '{fld}'.")
                        continue
                    v = rates[fld]
                    # 5. finite, nonnegative; probability in [0,1]
                    if not _is_finite_number(v):
                        _err(errors, f"{p}.{fld}", f"'{fld}' must be a finite number, got {v!r}.")
                    elif not (0.0 <= v <= 1.0):
                        _err(errors, f"{p}.{fld}", f"'{fld}' must be within [0,1], got {v}.")
                for extra in rates:
                    if extra not in EMPLOYMENT_FIELDS:
                        _err(errors, f"{p}.{extra}", f"Unknown employment field '{extra}'.")

    # ---- marital_status ----
    if "marital_status" in payload:
        mar = payload["marital_status"]
        if not isinstance(mar, dict):
            _err(errors, "$.marital_status", "marital_status must be an object.")
        else:
            for sex in mar:
                if sex not in SEXES:
                    _err(errors, f"$.marital_status.{sex}", f"Unknown sex label '{sex}'.")
            for sex, bands in mar.items():
                if sex not in SEXES or not isinstance(bands, dict):
                    if not isinstance(bands, dict):
                        _err(errors, f"$.marital_status.{sex}", "must be an object of age_band -> dist.")
                    continue
                for band, dist in bands.items():
                    p = f"$.marital_status.{sex}.{band}"
                    if band not in MARITAL_AGE_BANDS:
                        _err(errors, p, f"Unknown marital age band '{band}'.")
                    if not isinstance(dist, dict):
                        _err(errors, p, "distribution must be an object of status -> probability.")
                        continue
                    total = 0.0
                    total_ok = True
                    for status, prob in dist.items():
                        sp = f"{p}.{status}"
                        if status not in MARITAL_STATUSES:
                            _err(errors, sp, f"Unknown marital status '{status}'.")
                        if not _is_finite_number(prob):
                            _err(errors, sp, f"probability must be a finite number, got {prob!r}.")
                            total_ok = False
                        elif not (0.0 <= prob <= 1.0):
                            _err(errors, sp, f"probability must be within [0,1], got {prob}.")
                            total_ok = False
                        else:
                            total += prob
                    # 6. probability vector sums ~1 (tolerance)
                    if total_ok and abs(total - 1.0) > PROB_SUM_TOL:
                        _err(errors, p, f"probabilities sum to {round(total, 6)}; "
                                        f"must be within {PROB_SUM_TOL} of 1.0.")

    return ValidationResult(ok=(len(errors) == 0), errors=errors, warnings=warnings, computed=computed)


def load_and_validate(path_or_text: str, *, allow_partial: bool = False) -> ValidationResult:
    """Load JSON from a file path or raw text, then validate. Malformed JSON -> ok=False."""
    text = path_or_text
    try:
        import os
        if os.path.exists(path_or_text):
            with open(path_or_text, "r", encoding="utf-8") as f:
                text = f.read()
    except (OSError, ValueError):
        pass
    # 13. Reject malformed JSON
    try:
        payload = json.loads(text)
    except (json.JSONDecodeError, TypeError) as e:
        return ValidationResult(False, [{"path": "$", "message": f"Malformed JSON: {e}"}])
    return validate_t0_data(payload, allow_partial=allow_partial)


def _main(argv: list[str]) -> int:
    if len(argv) < 2:
        print("usage: python validate_t0_data.py <file.json> [--allow-partial]", file=sys.stderr)
        return 3
    allow_partial = "--allow-partial" in argv[2:]
    res = load_and_validate(argv[1], allow_partial=allow_partial)
    print(json.dumps(res.to_dict(), indent=2))
    return 0 if res.ok else 2


if __name__ == "__main__":
    raise SystemExit(_main(sys.argv))
