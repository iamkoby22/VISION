"""Phase 5B transit units reconciliation diagnostics — observation around fixed units."""
from __future__ import annotations

from collections import defaultdict

import mastercode02_globals as g
from mastercode02_config_and_rates import (
    PUBLIC_TRANSIT_CONFIG, BUS_OPERATING_DAYS_PER_YEAR,
    BUS_CAPACITY_UTILIZATION_FACTOR, BUS_CAPACITY_UNIT_MODE,
)


PHASE5B_LOG: dict = {
    "metrics": [],
    "trip_groups": [],
    "car_mobility": [],
    "transport_index": [],
}


def _group_label(p) -> str:
    if p.age < 5:
        return "children_0_4"
    if p.age < 18:
        return "students_school_age_5_17"
    if p.age >= 65:
        return "retirees_65plus"
    if p.employment_status == "Employed":
        return "workers_employed"
    if p.employment_status == "Unemployed":
        return "unemployed_adults"
    return "other_adults_nilf"


def snapshot_yearly_phase5b(year: int, env) -> None:
    pop = list(g.POPULATION)
    n = len(pop) or 1
    fleet = getattr(env, "bus_fleet_size", 0) or 0
    seats = PUBLIC_TRANSIT_CONFIG["bus_capacity"]
    trips = PUBLIC_TRANSIT_CONFIG["trips_per_bus_per_day"]
    daily = getattr(env, "bus_daily_capacity", fleet * seats * trips)
    annual = getattr(env, "bus_annual_capacity", daily * BUS_OPERATING_DAYS_PER_YEAR * BUS_CAPACITY_UTILIZATION_FACTOR)
    days = getattr(env, "bus_operating_days_per_year", BUS_OPERATING_DAYS_PER_YEAR)
    util_f = getattr(env, "bus_capacity_utilization_factor", BUS_CAPACITY_UTILIZATION_FACTOR)
    mode = getattr(env, "bus_capacity_unit_mode", BUS_CAPACITY_UNIT_MODE)

    served = getattr(env, "bus_passengers_served", 0) or 0
    refused = getattr(env, "bus_passengers_refused", 0) or 0
    demand = getattr(env, "bus_annual_demand", served + refused)

    # Counterfactual: old daily-basis refused
    old_served = int(min(demand, daily))
    old_refused = max(0, demand - old_served)
    old_rate = (old_refused / demand) if demand else 0.0
    new_rate = (refused / demand) if demand else 0.0

    PHASE5B_LOG["metrics"].append({
        "year": year,
        "fleet_size": fleet,
        "seats_per_bus": seats,
        "trips_per_day": trips,
        "bus_daily_capacity": daily,
        "bus_operating_days_per_year": days,
        "bus_capacity_utilization_factor": util_f,
        "bus_annual_capacity": annual,
        "bus_annual_demand": demand,
        "bus_accepted_annual": served,
        "bus_refused_annual": refused,
        "bus_refusal_rate_annual": new_rate,
        "bus_refused_old_daily_basis_if_available": old_refused,
        "bus_refusal_rate_old_daily_basis_if_available": old_rate,
        "unit_mode": mode,
        "notes": "Phase 5B annualized capacity used for accepted/refused; daily preserved",
    })

    by_group = defaultdict(lambda: {
        "pop": 0, "eligible": 0, "car_owners": 0, "accepted": 0, "refused_proxy": 0,
    })
    car_owners = 0
    non_car = 0
    car_on_bus = 0
    for p in pop:
        gl = _group_label(p)
        by_group[gl]["pop"] += 1
        if p.cars:
            car_owners += 1
            by_group[gl]["car_owners"] += 1
            if getattr(p, "use_bus", False):
                car_on_bus += 1
        else:
            non_car += 1
            if p.commute_purpose in ("Work", "School"):
                by_group[gl]["eligible"] += 1
                if getattr(p, "use_bus", False):
                    by_group[gl]["accepted"] += 1
                else:
                    by_group[gl]["refused_proxy"] += 1

    for gl, d in by_group.items():
        PHASE5B_LOG["trip_groups"].append({
            "year": year,
            "population_group": gl,
            "bus_eligible_count": d["eligible"],
            "car_owner_count": d["car_owners"],
            "excluded_car_owner_count": d["car_owners"],
            "annual_demand_count": d["eligible"],
            "accepted_count": d["accepted"],
            "refused_count": d["refused_proxy"],
            "notes": "refused_count among eligible with use_bus=False (stochastic under service_ratio)",
        })

    PHASE5B_LOG["car_mobility"].append({
        "year": year,
        "total_population": n,
        "total_cars": sum(len(p.cars) for p in pop),
        "car_owner_count": car_owners,
        "non_car_owner_count": non_car,
        "bus_eligible_non_car_owners": sum(1 for p in pop if (not p.cars) and p.commute_purpose in ("Work", "School")),
        "car_owners_using_bus_count": car_on_bus,
        "notes": "Car owners remain excluded from bus demand",
    })

    # transport index filled in postrun from scores CSV; stub row for year linkage
    PHASE5B_LOG["transport_index"].append({
        "year": year,
        "accepted_bus_trips": served,
        "refused_bus_trips": refused,
        "total_cars": sum(len(p.cars) for p in pop),
        "num_accidents": g.ANNUAL_SUMMARY_DATA.get("num_accidents", 0),
    })
