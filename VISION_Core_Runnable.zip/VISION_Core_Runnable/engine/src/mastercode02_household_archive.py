"""Phase 7B empty household shell archival.

Flag-based archival: empty, claim-free household shells are recorded in a durable archive
registry and flagged inactive, but are NOT hard-deleted from g.HOUSEHOLDS. This preserves
death/birth accounting (deaths are summed on the household dict at year-end), keeps all
manager iteration sets identical to Phase 7A, and preserves full historical traceability.

Archived shells already have 0 members, 0 active ledger claim, and contribute 0 to future
births/deaths, so archival cannot change population, demography, occupancy, or vacancy.
"""
from __future__ import annotations

import mastercode02_globals as g
from mastercode02_housing_ledger import (
    household_has_active_housing_claim, get_household_housing_claim,
)

# Durable archive registry (household_id -> archive record)
ARCHIVED_HOUSEHOLDS: dict = {}
# Per-household archive attempt log
ARCHIVE_EVENTS: list = []
# Per-year archival summary (before/after counts)
ARCHIVE_YEARLY: list = []


def reset_household_archive() -> None:
    ARCHIVED_HOUSEHOLDS.clear()
    ARCHIVE_EVENTS.clear()
    ARCHIVE_YEARLY.clear()


def is_archived(household_id) -> bool:
    return household_id in ARCHIVED_HOUSEHOLDS


def _referenced_household_ids() -> set:
    """Set of household_ids referenced as current household by any living person."""
    refs = set()
    for p in g.POPULATION:
        hid = getattr(p, "household_id", None)
        if hid is not None:
            refs.add(hid)
    return refs


def can_archive(household_id, referenced_ids=None):
    """Return (ok, reason, member_count, has_claim, active_ref_found)."""
    hh = g.HOUSEHOLDS.get(household_id)
    if hh is None:
        return False, "household_missing", 0, False, False
    if household_id in ARCHIVED_HOUSEHOLDS:
        return False, "already_archived", 0, False, False
    members = hh.get("members", []) or []
    n = len(members)
    has_claim = household_has_active_housing_claim(household_id)
    if referenced_ids is None:
        referenced_ids = _referenced_household_ids()
    active_ref = household_id in referenced_ids
    if n != 0:
        return False, "has_members", n, has_claim, active_ref
    if has_claim:
        return False, "has_active_housing_claim", n, has_claim, active_ref
    if hh.get("housing_unit_name"):
        return False, "has_active_housing_unit", n, has_claim, active_ref
    if active_ref:
        return False, "active_person_reference_found", n, has_claim, active_ref
    return True, "ok", n, has_claim, active_ref


def archive_empty_household_shell(household_id, year: int, reason: str = "empty_shell",
                                  referenced_ids=None) -> bool:
    """Archive a single empty, claim-free household shell (flag-based, no hard delete)."""
    ok, why, n, has_claim, active_ref = can_archive(household_id, referenced_ids)
    hh = g.HOUSEHOLDS.get(household_id)
    event = {
        "year": year,
        "household_id": household_id,
        "archive_attempted": True,
        "archive_success": False,
        "archive_reason": reason,
        "member_count": n,
        "had_active_housing_claim": has_claim,
        "active_person_reference_found": active_ref,
        "failure_reason": "" if ok else why,
        "notes": "",
    }
    if not ok:
        ARCHIVE_EVENTS.append(event)
        return False

    prev_status = hh.get("tenure")
    prev_unit = hh.get("housing_unit_name")
    ARCHIVED_HOUSEHOLDS[household_id] = {
        "household_id": household_id,
        "archived_year": year,
        "archive_reason": reason,
        "previous_housing_status": prev_status,
        "previous_housing_unit_name": prev_unit,
        "member_count_at_archive": n,
        "had_active_housing_claim_at_archive": has_claim,
        "household_type": hh.get("type", ""),
        "notes": "flag-based archive; record retained in g.HOUSEHOLDS",
    }
    # Flag inactive; do NOT remove from g.HOUSEHOLDS (preserves accounting/iteration)
    hh["active"] = False
    hh["archived"] = True
    hh["archived_year"] = year
    event["archive_success"] = True
    ARCHIVE_EVENTS.append(event)
    return True


def count_active_empty_shells() -> int:
    """Empty, claim-free households not yet archived."""
    n = 0
    for hh_id, hh in g.HOUSEHOLDS.items():
        if hh.get("archived"):
            continue
        members = hh.get("members", []) or []
        if len(members) == 0 and not household_has_active_housing_claim(hh_id) \
                and not hh.get("housing_unit_name"):
            n += 1
    return n


def archive_empty_household_shells(year: int) -> dict:
    """Archive all eligible empty shells for the year. Returns a summary dict."""
    before = count_active_empty_shells()
    referenced_ids = _referenced_household_ids()
    archived_this_year = 0
    for hh_id in list(g.HOUSEHOLDS.keys()):
        hh = g.HOUSEHOLDS.get(hh_id)
        if hh is None or hh.get("archived"):
            continue
        members = hh.get("members", []) or []
        if len(members) != 0:
            continue
        if household_has_active_housing_claim(hh_id) or hh.get("housing_unit_name"):
            continue
        if archive_empty_household_shell(hh_id, year, reason="empty_shell",
                                         referenced_ids=referenced_ids):
            archived_this_year += 1
    after = count_active_empty_shells()
    summary = {
        "year": year,
        "empty_shells_before": before,
        "archived_this_year": archived_this_year,
        "empty_shells_after": after,
        "archived_total": len(ARCHIVED_HOUSEHOLDS),
    }
    ARCHIVE_YEARLY.append(summary)
    return summary


def active_household_count() -> int:
    return len([hh for hh in g.HOUSEHOLDS.values() if not hh.get("archived")])


def archived_household_count() -> int:
    return len(ARCHIVED_HOUSEHOLDS)
