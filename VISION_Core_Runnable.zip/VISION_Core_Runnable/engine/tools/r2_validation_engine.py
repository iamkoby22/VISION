# r2_validation_engine.py
# R2 (Observability and Validation Infrastructure) -- POST-PROCESSING ONLY.
# This module never touches, imports, or is imported by any simulation-runtime
# file (mastercode02_agents.py, mastercode02_logging.py, etc.). It operates
# exclusively on already-written output CSVs from a completed run. It cannot,
# by construction, affect simulation state, RNG consumption, or event ordering.
#
# Implements R1's frozen validation-compatibility contract
# (RESSEARCH/24_PHASE_R1_CORRECTION_CONTRACT/17_r1_pre_rerun_gate_contract.csv
# Gate N; 14_r1_validation_contract_frozen.csv) and spec Section 21's exact
# compatibility-status enum. Per spec Section 21: if compatibility is
# INVALID_* or NO_COMPARATOR, this engine returns that status INSTEAD of
# computing a headline accuracy/error metric -- it never silently produces an
# APE/error score for an incompatible comparison.

import csv

COMPATIBILITY_STATUSES = {
    'VALID_EXACT', 'VALID_PROXY_WITH_DISCLOSURE', 'VALID_DERIVED_WITH_DISCLOSURE',
    'DIAGNOSTIC_ONLY', 'INVALID_YEAR', 'INVALID_GEOGRAPHY', 'INVALID_UNIVERSE',
    'INVALID_UNIT', 'INVALID_CATEGORY', 'NO_COMPARATOR',
}

COMPATIBILITY_CHECK_FIELDS = [
    'metric_id', 'simulation_year', 'observed_year', 'simulation_geography', 'observed_geography',
    'simulation_universe', 'observed_universe', 'simulation_unit', 'observed_unit',
    'simulation_category_definition', 'observed_category_definition',
    'compatibility_status', 'reason',
]


def check_compatibility(metric_id, simulation_year, observed_year, simulation_geography, observed_geography,
                         simulation_universe, observed_universe, simulation_unit, observed_unit,
                         simulation_category_definition, observed_category_definition,
                         has_observed_comparator=True):
    """Pure function: given the declared properties of a simulated quantity and
    its candidate observed comparator, return a compatibility record. Never
    computes an error score itself -- callers must check compatibility_status
    before calling any error-metric function, and must not call one at all if
    status is not VALID_* or DIAGNOSTIC_ONLY."""
    if not has_observed_comparator:
        return _record(metric_id, simulation_year, observed_year, simulation_geography, observed_geography,
                        simulation_universe, observed_universe, simulation_unit, observed_unit,
                        simulation_category_definition, observed_category_definition,
                        'NO_COMPARATOR', 'No observed comparator is declared for this metric.')

    if simulation_year != observed_year:
        return _record(metric_id, simulation_year, observed_year, simulation_geography, observed_geography,
                        simulation_universe, observed_universe, simulation_unit, observed_unit,
                        simulation_category_definition, observed_category_definition,
                        'INVALID_YEAR',
                        f"simulation_year ({simulation_year}) != observed_year ({observed_year}). "
                        f"This is the exact defect class Phase V1 (POP-003) and R1 Gate B/D exist to catch: "
                        f"a Year-24 terminal snapshot must never be silently compared to a 2023 observed value.")

    if simulation_geography != observed_geography:
        return _record(metric_id, simulation_year, observed_year, simulation_geography, observed_geography,
                        simulation_universe, observed_universe, simulation_unit, observed_unit,
                        simulation_category_definition, observed_category_definition,
                        'INVALID_GEOGRAPHY', f"simulation_geography ({simulation_geography}) != observed_geography ({observed_geography}).")

    if simulation_universe != observed_universe:
        return _record(metric_id, simulation_year, observed_year, simulation_geography, observed_geography,
                        simulation_universe, observed_universe, simulation_unit, observed_unit,
                        simulation_category_definition, observed_category_definition,
                        'INVALID_UNIVERSE',
                        f"simulation_universe ({simulation_universe}) != observed_universe ({observed_universe}). "
                        f"E.g. 'total population' vs 'age 16+' vs 'civilian labor force' are NOT interchangeable "
                        f"universes (see R1 06_r1_employment_state_machine_contract.md).")

    if simulation_unit != observed_unit:
        return _record(metric_id, simulation_year, observed_year, simulation_geography, observed_geography,
                        simulation_universe, observed_universe, simulation_unit, observed_unit,
                        simulation_category_definition, observed_category_definition,
                        'INVALID_UNIT', f"simulation_unit ({simulation_unit}) != observed_unit ({observed_unit}).")

    if simulation_category_definition != observed_category_definition:
        return _record(metric_id, simulation_year, observed_year, simulation_geography, observed_geography,
                        simulation_universe, observed_universe, simulation_unit, observed_unit,
                        simulation_category_definition, observed_category_definition,
                        'INVALID_CATEGORY',
                        f"simulation_category_definition ({simulation_category_definition}) != "
                        f"observed_category_definition ({observed_category_definition}). "
                        f"E.g. raw model label 'Married' vs T0-origin label 'Now married (except separated)' "
                        f"vs ACS DP02's category are three different strings for a married state -- must be "
                        f"reconciled via a crosswalk, not compared directly (see R1 08_r1_marital_scope_decision.md).")

    # All checks passed -- caller/metadata determines EXACT vs PROXY_WITH_DISCLOSURE
    # vs DERIVED_WITH_DISCLOSURE; this engine defaults to VALID_EXACT when every
    # declared property matches exactly, since PROXY/DERIVED require the caller
    # to explicitly say so via a disclosure_note (not modeled as a parameter here
    # to keep this function's contract simple -- callers needing PROXY/DERIVED
    # status should call check_compatibility_with_disclosure below instead).
    return _record(metric_id, simulation_year, observed_year, simulation_geography, observed_geography,
                    simulation_universe, observed_universe, simulation_unit, observed_unit,
                    simulation_category_definition, observed_category_definition,
                    'VALID_EXACT', 'All declared properties match exactly.')


def check_compatibility_with_disclosure(metric_id, disclosure_kind, disclosure_note, **kwargs):
    """Wrapper for the PROXY/DERIVED/DIAGNOSTIC_ONLY cases: run the same
    property checks as check_compatibility, then, ONLY if they all pass,
    downgrade the resulting VALID_EXACT status to the caller-declared
    disclosure_kind (must be VALID_PROXY_WITH_DISCLOSURE, VALID_DERIVED_WITH_DISCLOSURE,
    or DIAGNOSTIC_ONLY) rather than fabricating VALID_EXACT for a comparison
    that is not actually exact."""
    assert disclosure_kind in {'VALID_PROXY_WITH_DISCLOSURE', 'VALID_DERIVED_WITH_DISCLOSURE', 'DIAGNOSTIC_ONLY'}, \
        f"disclosure_kind must be one of the three disclosed-validity statuses, got {disclosure_kind}"
    rec = check_compatibility(metric_id=metric_id, **kwargs)
    if rec['compatibility_status'] == 'VALID_EXACT':
        rec['compatibility_status'] = disclosure_kind
        rec['reason'] = f"{rec['reason']} DISCLOSED: {disclosure_note}"
    return rec


def _record(metric_id, simulation_year, observed_year, simulation_geography, observed_geography,
            simulation_universe, observed_universe, simulation_unit, observed_unit,
            simulation_category_definition, observed_category_definition, status, reason):
    assert status in COMPATIBILITY_STATUSES, f"unknown compatibility_status {status}"
    return {
        'metric_id': metric_id, 'simulation_year': simulation_year, 'observed_year': observed_year,
        'simulation_geography': simulation_geography, 'observed_geography': observed_geography,
        'simulation_universe': simulation_universe, 'observed_universe': observed_universe,
        'simulation_unit': simulation_unit, 'observed_unit': observed_unit,
        'simulation_category_definition': simulation_category_definition,
        'observed_category_definition': observed_category_definition,
        'compatibility_status': status, 'reason': reason,
    }


def compute_error_metric_if_valid(compatibility_record, simulated_value, observed_value, metric='APE'):
    """The ONLY function in this module allowed to compute an accuracy/error
    score, and it refuses to do so unless compatibility_record's status is
    VALID_* or DIAGNOSTIC_ONLY (diagnostic values may still be informative even
    if not citable as a primary validation result -- caller must still label
    them as such downstream). Returns None (not a fabricated 0 or NaN-as-zero)
    for any INVALID_*/NO_COMPARATOR status, per spec Section 21's explicit
    'do not calculate an error score' instruction."""
    status = compatibility_record['compatibility_status']
    if status not in {'VALID_EXACT', 'VALID_PROXY_WITH_DISCLOSURE', 'VALID_DERIVED_WITH_DISCLOSURE', 'DIAGNOSTIC_ONLY'}:
        return None
    if metric == 'APE':
        if observed_value == 0:
            return None  # undefined; do not silently divide by zero
        return abs(simulated_value - observed_value) / abs(observed_value) * 100.0
    if metric == 'ABS_DIFF':
        return abs(simulated_value - observed_value)
    raise ValueError(f"unsupported metric {metric}")


def write_compatibility_csv(records, out_path):
    with open(out_path, 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(COMPATIBILITY_CHECK_FIELDS)
        for r in records:
            w.writerow([r[k] for k in COMPATIBILITY_CHECK_FIELDS])
