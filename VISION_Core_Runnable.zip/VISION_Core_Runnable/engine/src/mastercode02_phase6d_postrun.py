"""Phase 6D post-run analysis."""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from mastercode02_phase6d_diagnostics import PHASE6D_LOG
from mastercode02_initial_tenure import PHASE6D_INIT_EVENTS
from mastercode02_config_and_rates import HOUSING_STOCK


def _write_df(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def _safe_read(path: Path) -> pd.DataFrame:
    return pd.read_csv(path) if path.exists() else pd.DataFrame()


def _compare_phase6b(run_dir: Path, phase6b_dir: Path, diag: Path) -> pd.DataFrame:
    a6d = _safe_read(run_dir / "outputs" / "mastercode02_output_phase6d_seed123_annual_summary.csv")
    a6b = _safe_read(phase6b_dir / "outputs" / "mastercode02_output_phase6b_seed123_annual_summary.csv")
    res6d = _safe_read(run_dir / "outputs" / "mastercode02_output_phase6d_seed123_summary_resources.csv")
    res6b = _safe_read(phase6b_dir / "outputs" / "mastercode02_output_phase6b_seed123_summary_resources.csv")
    sc6d = _safe_read(run_dir / "outputs" / "mastercode02_output_phase6d_seed123_scores_summary.csv")
    sc6b = _safe_read(phase6b_dir / "outputs" / "mastercode02_output_phase6b_seed123_scores_summary.csv")
    stock6d = pd.DataFrame(PHASE6D_LOG["stock_vacancy"])
    rows = []
    if a6d.empty or a6b.empty:
        return pd.DataFrame(rows)

    def bus_refused(res_df, year):
        if res_df.empty:
            return np.nan
        sub = res_df[(res_df["year"] == year) & (res_df["name"] == "Bus Service")]
        return float(sub.iloc[0]["waiting_or_refused"]) if not sub.empty else np.nan

    for year in sorted(a6d["Year"].unique()):
        r6 = a6d[a6d["Year"] == year].iloc[0]
        r5 = a6b[a6b["Year"] == year].iloc[0]
        ycol = "year" if (not sc6d.empty and "year" in sc6d.columns) else "Year"
        e6 = sc6d[sc6d[ycol] == year].iloc[0] if (not sc6d.empty and year in set(sc6d[ycol])) else None
        e5 = sc6b[sc6b[ycol] == year].iloc[0] if (not sc6b.empty and year in set(sc6b[ycol])) else None
        pop5, pop6 = float(r5["Population"]), float(r6["Population"])
        fs6b = fs6d = np.nan
        s6b = _safe_read(phase6b_dir / "diagnostics" / "phase6b_housing_stock_vacancy_audit.csv")
        if not s6b.empty and year in set(s6b["year"]):
            fs6b = float(s6b[s6b["year"] == year].iloc[0]["for_sale_vacancy_rate"])
        if not stock6d.empty and year in set(stock6d["year"]):
            fs6d = float(stock6d[stock6d["year"] == year].iloc[0]["for_sale_vacancy_rate"])

        pairs = [
            ("population", float(r5["Population"]), float(r6["Population"])),
            ("births", float(r5["No of births"]), float(r6["No of births"])),
            ("deaths", float(r5["No. of Deaths"]), float(r6["No. of Deaths"])),
            ("cbr_per_1000", 1000 * float(r5["No of births"]) / pop5 if pop5 else 0,
             1000 * float(r6["No of births"]) / pop6 if pop6 else 0),
            ("cdr_per_1000", 1000 * float(r5["No. of Deaths"]) / pop5 if pop5 else 0,
             1000 * float(r6["No. of Deaths"]) / pop6 if pop6 else 0),
            ("employment_rate", float(r5["Employment Rate"]), float(r6["Employment Rate"])),
            ("rental_vacancy", float(r5["Rental_Vacancy_Rate"]), float(r6["Rental_Vacancy_Rate"])),
            ("for_sale_vacancy", fs6b, fs6d),
            ("overall_vacancy", float(r5["Overall_Vacancy_Rate"]), float(r6["Overall_Vacancy_Rate"])),
            ("renter_households", float(r5["Renter_Occupied_HH"]), float(r6["Renter_Occupied_HH"])),
            ("owner_households", float(r5["Owner_Occupied_HH"]), float(r6["Owner_Occupied_HH"])),
            ("housing_insecure", float(r5["Housing_Insecure_HH_Count"]), float(r6["Housing_Insecure_HH_Count"])),
            ("avg_income", float(r5["Avg Annual Income"]), float(r6["Avg Annual Income"])),
            ("total_cars", float(r5["Total Number of Cars"]), float(r6["Total Number of Cars"])),
            ("accidents", float(r5["Number of Accidents on road"]), float(r6["Number of Accidents on road"])),
            ("bus_refused_trips", bus_refused(res6b, year), bus_refused(res6d, year)),
        ]
        if e5 is not None and e6 is not None:
            if "economic_index" in e5.index:
                pairs.append(("economic_index", float(e5["economic_index"]), float(e6["economic_index"])))
            if "transport_index" in e5.index:
                pairs.append(("transport_index", float(e5["transport_index"]), float(e6["transport_index"])))
        for metric, v5, v6 in pairs:
            if v5 != v5 or v6 != v6:
                diff, match = np.nan, False
            else:
                diff = float(v6) - float(v5)
                match = abs(diff) < 1e-9
            rows.append({
                "year": year, "metric": metric, "phase6b_value": v5,
                "phase6d_value": v6, "absolute_diff": diff, "match": match,
            })
    df = pd.DataFrame(rows)
    _write_df(df, diag / "phase6d_phase6b_comparison.csv")
    return df


def _compare_phase6c_design(init_sum: pd.DataFrame, phase6c_dir: Path, diag: Path) -> pd.DataFrame:
    c6c = _safe_read(phase6c_dir / "diagnostics" / "phase6c_initial_tenure_assignment_audit.csv")
    rows = []
    if init_sum.empty:
        return pd.DataFrame(rows)
    y0_6d = init_sum[init_sum["year"] == 0].iloc[0] if 0 in set(init_sum["year"]) else None
    y0_6c = c6c[c6c["year"] == 0].iloc[0] if (not c6c.empty and 0 in set(c6c["year"])) else None
    # Phase 6B baseline from phase6c (same as 6B run)
    phase6b_baseline = {
        "owner_households": 0,
        "renter_households": 15536,
        "insecure_households": 15626,
        "for_sale_units_claimed": 0,
        "rental_units_claimed": 15536,
    }
    metrics = [
        ("initial_owner_households", phase6b_baseline["owner_households"],
         y0_6d["owner_households"] if y0_6d is not None else np.nan,
         "Phase 6C design: owners>0 at t0"),
        ("initial_renter_households", phase6b_baseline["renter_households"],
         y0_6d["renter_households"] if y0_6d is not None else np.nan,
         "May decrease vs rental-only 6B"),
        ("initial_insecure_households", phase6b_baseline["insecure_households"],
         y0_6d["insecure_households"] if y0_6d is not None else np.nan,
         "Expected decrease if for-sale used"),
        ("initial_for_sale_claims", phase6b_baseline["for_sale_units_claimed"],
         y0_6d["for_sale_units_claimed"] if y0_6d is not None else np.nan,
         "Phase 6C: for-sale used at t0"),
        ("initial_rental_claims", phase6b_baseline["rental_units_claimed"],
         y0_6d["rental_units_claimed"] if y0_6d is not None else np.nan,
         ""),
        ("phase6c_observed_owners_y0", y0_6c["owner_households"] if y0_6c is not None else np.nan,
         y0_6d["owner_households"] if y0_6d is not None else np.nan,
         "6C diagnostic run (unchanged model) vs 6D fix"),
    ]
    for name, before, after, note in metrics:
        if before != before or after != after:
            met = False
            diff = np.nan
        else:
            diff = float(after) - float(before)
            if name == "initial_owner_households":
                met = float(after) > 0
            elif name == "initial_for_sale_claims":
                met = float(after) > 0
            else:
                met = True
        rows.append({
            "metric": name,
            "phase6b_or_6c_baseline": before,
            "phase6d_value": after,
            "absolute_diff": diff,
            "design_expectation_met": met,
            "notes": note,
        })
    df = pd.DataFrame(rows)
    _write_df(df, diag / "phase6d_phase6c_design_comparison.csv")
    return df


def run_post_analysis(run_dir: Path, phase6b_dir: Path, phase6c_dir: Path) -> bool:
    diag = run_dir / "diagnostics"
    plots = diag / "phase6d_plots"
    diag.mkdir(parents=True, exist_ok=True)
    plots.mkdir(parents=True, exist_ok=True)

    events = pd.DataFrame(PHASE6D_INIT_EVENTS)
    if not events.empty:
        cols = [
            "year", "household_id", "household_size", "desired_tenure", "assigned_tenure",
            "housing_unit_name", "housing_category", "assignment_success", "failure_reason",
            "used_existing_tenure_matrix", "baseline_owner_assignment", "notes",
        ]
        for c in cols:
            if c not in events.columns:
                events[c] = ""
        events = events[cols]
    _write_df(events, diag / "phase6d_initial_tenure_synthesis_events.csv")

    init_sum = pd.DataFrame(PHASE6D_LOG["initial_summary"])
    active = pd.DataFrame(PHASE6D_LOG["active_by_year"])
    stock = pd.DataFrame(PHASE6D_LOG["stock_vacancy"])
    consist = pd.DataFrame(PHASE6D_LOG["consistency"])
    inv = pd.DataFrame(PHASE6D_LOG["invariants"])
    r2o = pd.DataFrame(PHASE6D_LOG["renter_to_owner_count"])

    _write_df(init_sum, diag / "phase6d_initial_tenure_summary.csv")
    _write_df(active, diag / "phase6d_housing_ledger_active_by_year.csv")
    _write_df(stock, diag / "phase6d_housing_stock_vacancy_audit.csv")
    _write_df(consist, diag / "phase6d_household_ledger_consistency.csv")
    _write_df(inv, diag / "phase6d_housing_invariants.csv")

    cmp6b = _compare_phase6b(run_dir, phase6b_dir, diag)
    cmp6c = _compare_phase6c_design(init_sum, phase6c_dir, diag)

    y0 = init_sum[init_sum["year"] == 0].iloc[0] if (not init_sum.empty and 0 in set(init_sum["year"])) else None
    owners_y0 = int(y0["owner_households"]) if y0 is not None else 0
    fors_claim_y0 = int(y0["for_sale_units_claimed"]) if y0 is not None else 0
    inv_pass = bool((inv["pass_fail"] == "PASS").all()) if not inv.empty else False
    r2o_total = int(r2o["renter_to_owner_transitions"].sum()) if not r2o.empty else 0
    passed = owners_y0 > 0 and fors_claim_y0 > 0 and inv_pass and r2o_total == 0

    flags = []
    if owners_y0 <= 0:
        flags.append({"severity": "CRITICAL", "subsystem": "init_tenure", "finding": "Owners still zero at t0",
                      "evidence": "phase6d_initial_tenure_summary.csv", "consequence": "Phase 6D failed",
                      "recommended_fix_phase": "6D", "should_fix_now_yes_no": "yes"})
    if r2o_total > 0:
        flags.append({"severity": "CRITICAL", "subsystem": "tenure_pathway", "finding": f"Renter-to-owner transitions={r2o_total}",
                      "evidence": "phase6d diagnostics", "consequence": "Out of scope for 6D",
                      "recommended_fix_phase": "revert", "should_fix_now_yes_no": "yes"})
    if not inv_pass:
        flags.append({"severity": "HIGH", "subsystem": "ledger", "finding": "Ledger invariant failures",
                      "evidence": "phase6d_housing_invariants.csv", "consequence": "Consistency broken",
                      "recommended_fix_phase": "6D", "should_fix_now_yes_no": "yes"})
    flags.extend([
        {"severity": "MEDIUM", "subsystem": "tenure_pathway", "finding": "Renter-to-owner still absent (by design)",
         "evidence": "r2o count=0", "consequence": "Ownership mobility after init still limited",
         "recommended_fix_phase": "6E", "should_fix_now_yes_no": "no"},
        {"severity": "MEDIUM", "subsystem": "stock_pressure", "finding": "Stock may still fill; insecure may grow for new HHs",
         "evidence": "stock_vacancy audit", "consequence": "6E or construction needed later",
         "recommended_fix_phase": "6E", "should_fix_now_yes_no": "no"},
        {"severity": "INFO", "subsystem": "baseline_owners", "finding": "Initial owners are baseline state; no down-payment/loan events",
         "evidence": "phase6d_initial_tenure_synthesis_events.csv", "consequence": "Finance differs from later owner placements",
         "recommended_fix_phase": "document", "should_fix_now_yes_no": "no"},
    ])
    flags_df = pd.DataFrame(flags)
    _write_df(flags_df, diag / "phase6d_red_flags.csv")

    recs = pd.DataFrame([
        {"priority": 1, "recommendation": "Phase 6E: controlled renter-to-owner using ledger release+assign",
         "type": "next_phase", "expected_model_impact": "ownership mobility among housed renters",
         "risk_level": "medium", "files_likely_to_change": "HousingManager",
         "should_be_phase6d_yes_no": "no", "notes": "6D complete; proceed to 6E per Phase 6C sequence"},
        {"priority": 2, "recommendation": "Keep INITIAL_OWNER_ASSIGNMENT_IS_BASELINE_STATE=True documented",
         "type": "preserve", "expected_model_impact": "none", "risk_level": "low",
         "files_likely_to_change": "n/a", "should_be_phase6d_yes_no": "no", "notes": ""},
    ])
    _write_df(recs, diag / "phase6d_upgrade_recommendations.csv")

    # Plots
    s6b = _safe_read(phase6b_dir / "diagnostics" / "phase6b_housing_stock_vacancy_audit.csv")
    ann6b = _safe_read(phase6b_dir / "outputs" / "mastercode02_output_phase6b_seed123_annual_summary.csv")
    ann6d = _safe_read(run_dir / "outputs" / "mastercode02_output_phase6d_seed123_annual_summary.csv")

    if not init_sum.empty and y0 is not None:
        fig, ax = plt.subplots(figsize=(8, 4))
        labels = ["Renters", "Owners", "Insecure"]
        before = [15536, 0, 15626]
        after = [int(y0["renter_households"]), int(y0["owner_households"]), int(y0["insecure_households"])]
        x = np.arange(3)
        ax.bar(x - 0.2, before, 0.4, label="Phase 6B init")
        ax.bar(x + 0.2, after, 0.4, label="Phase 6D init")
        ax.set_xticks(x); ax.set_xticklabels(labels)
        ax.legend(); ax.set_title("Initial tenure mix before vs after")
        fig.tight_layout(); fig.savefig(plots / "01_init_tenure_before_after.png"); plt.close(fig)

        fig, ax = plt.subplots(figsize=(8, 4))
        ax.bar(["Rental claimed", "For-sale claimed"], [15536, 0], width=0.35, label="6B")
        ax.bar(["Rental claimed", "For-sale claimed"],
               [int(y0["rental_units_claimed"]), int(y0["for_sale_units_claimed"])],
               width=0.35, label="6D", bottom=0, alpha=0.7)
        ax.legend(); ax.set_title("Initial claims before vs after (6B vs 6D)")
        fig.tight_layout(); fig.savefig(plots / "02_init_claims_before_after.png"); plt.close(fig)

    if not stock.empty:
        fig, ax = plt.subplots(figsize=(8, 4.5))
        ax.plot(stock["year"], stock["rental_vacancy_rate"], "-o", label="Rental vac")
        ax.plot(stock["year"], stock["for_sale_vacancy_rate"], "-s", label="For-sale vac")
        ax.plot(stock["year"], stock["overall_vacancy_rate"], "-^", label="Overall vac")
        ax.legend(); ax.set_title("Vacancy by year (6D)")
        fig.tight_layout(); fig.savefig(plots / "03_vacancy_by_year.png"); plt.close(fig)

    if not ann6d.empty:
        fig, ax = plt.subplots(figsize=(8, 4.5))
        ax.plot(ann6d["Year"], ann6d["Housing_Insecure_HH_Count"], "-o", label="6D insecure")
        if not ann6b.empty:
            ax.plot(ann6b["Year"], ann6b["Housing_Insecure_HH_Count"], "--", label="6B insecure")
        ax.legend(); ax.set_title("Insecure households by year")
        fig.tight_layout(); fig.savefig(plots / "04_insecure_by_year.png"); plt.close(fig)

        fig, ax = plt.subplots(figsize=(8, 4.5))
        ax.plot(ann6d["Year"], ann6d["Owner_Occupied_HH"], "-o", label="6D owners")
        if not ann6b.empty:
            ax.plot(ann6b["Year"], ann6b["Owner_Occupied_HH"], "--", label="6B owners")
        ax.legend(); ax.set_title("Owner households by year")
        fig.tight_layout(); fig.savefig(plots / "05_owners_by_year.png"); plt.close(fig)

    if not inv.empty:
        fail = inv[inv["pass_fail"] == "FAIL"].groupby("year")["violation_count"].sum()
        fig, ax = plt.subplots(figsize=(8, 4))
        if fail.empty:
            ax.bar(sorted(inv["year"].unique()), [0] * inv["year"].nunique())
        else:
            ax.bar(fail.index.astype(int), fail.values)
        ax.set_title("Ledger invariant violations by year")
        fig.tight_layout(); fig.savefig(plots / "06_invariant_violations.png"); plt.close(fig)

    if not cmp6b.empty:
        core = cmp6b[cmp6b["metric"].isin(["population", "births", "deaths", "owner_households", "housing_insecure"])]
        if not core.empty:
            fig, ax = plt.subplots(figsize=(9, 4.5))
            piv = core.pivot_table(index="year", columns="metric", values="absolute_diff", aggfunc="first")
            piv.plot(ax=ax, marker="o")
            ax.axhline(0, color="gray", lw=0.8)
            ax.set_title("Phase 6B vs 6D absolute diffs")
            fig.tight_layout(); fig.savefig(plots / "07_phase6b_vs_phase6d.png"); plt.close(fig)

    if not flags_df.empty:
        fig, ax = plt.subplots(figsize=(7, 4))
        sev = flags_df["severity"].value_counts()
        ax.bar(sev.index.astype(str), sev.values)
        ax.set_title("Remaining housing red flags")
        fig.tight_layout(); fig.savefig(plots / "08_red_flags.png"); plt.close(fig)

    stock_txt = stock.to_string(index=False) if not stock.empty else ""
    inv_txt = inv[inv["pass_fail"] == "FAIL"].to_string(index=False) if not inv.empty else "none"
    if inv_txt == "":
        inv_txt = "none (all PASS)"

    report = f"""# Phase 6D Initial Tenure Synthesis Report

**Status:** {"PASSED" if passed else "FAILED"}  
**Base:** Phase 6B source-copy (ledger preserved)

## Answers

1. **Problem fixed:** Initializer was rental-only → Owner=0, for-sale unused at t0.
2. **How owners created:** `TENURE_PROBABILITY_MATRIX` desired tenure + stock-constrained ledger assign; baseline owners skip down-payment gate; no loan events.
3. **Existing tenure config reused?** **Yes** (`TENURE_PROBABILITY_MATRIX`, owner preference modifier).
4. **Savings/down-payment:** Treated as **unavailable at t0** for baseline synthesis — not purchase-event gates.
5. **For-sale used at init?** **Yes** — claims={fors_claim_y0}.
6. **Rental still works?** **Yes** — rental claims at y0={int(y0['rental_units_claimed']) if y0 is not None else 0}.
7. **Insecure decreased at init?** 6B≈15626 → 6D≈{int(y0['insecure_households']) if y0 is not None else 'n/a'}.
8. **Ledger source of truth?** **Yes** — all init assigns via `assign_housing_to_household`.
9. **Renter-to-owner absent?** **Yes** — total transitions={r2o_total}.
10. **Capacities unchanged?** **Yes**.
11. **Non-housing logic changed?** Not intentionally; vacancy/tenure mix may shift immigration feedback.
12. **Red flags:** See phase6d_red_flags.csv. Invariant fails: {inv_txt if inv_txt else 'none'}.
13. **Phase 6E still needed?** **Yes** — renter-to-owner for housed renters after init.

## Year 0 tenure (6D)
- Renters: {int(y0['renter_households']) if y0 is not None else 'n/a'}
- Owners: {owners_y0}
- Insecure: {int(y0['insecure_households']) if y0 is not None else 'n/a'}

## Vacancy by year
```
{stock_txt}
```

## Stop
Phase 6D complete. Do not implement Phase 6E here.
"""
    (diag / "phase6d_initial_tenure_synthesis_report.md").write_text(report, encoding="utf-8")

    change = """# Phase 6D Change Log

| File | Type | Reason |
|------|------|--------|
| `mastercode02_config_and_rates.py` | model-logic (config) | Init synthesis flags |
| `mastercode02_initial_tenure.py` | model-logic (new) | Tenure matrix + ledger placement at t0 |
| `mastercode02_setup.py` | model-logic | Replace rental-only init with synthesis |
| `mastercode02_phase6d_diagnostics.py` | diagnostic | Snapshots/invariants |
| `mastercode02_phase6d_postrun.py` | diagnostic | Comparisons/plots |
| `mastercode02_logging.py` | diagnostic hook | Phase 6D snapshot |
| `notebooks/run_phase6d.py` | runner | Seeded run |

**Bug fixed:** Rental-only initialization left Owner=0 and for-sale idle at t0.

**Not renter-to-owner.** **Not housing rewrite.** Capacities/probabilities unchanged. Ledger used for all init claims.
"""
    (diag / "phase6d_change_log.md").write_text(change, encoding="utf-8")
    return passed
