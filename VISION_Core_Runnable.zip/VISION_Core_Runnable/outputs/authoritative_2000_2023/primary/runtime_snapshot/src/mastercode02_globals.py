# mastercode02_globals.py

# --- Main Simulation Containers ---
POPULATION = []
HOUSEHOLDS = {}
MARRIAGES = []

# --- Resource Dictionaries ---
EDUCATION_RESOURCE = {}
EMPLOYER_RESOURCE = {}
HOUSING_RESOURCE = {} # ADDED

# Phase 6B: durable housing ledger mirrors (canonical state in mastercode02_housing_ledger)
HOUSING_LEDGER_ACTIVE = {}
HOUSING_LEDGER_HISTORY = []
HOUSING_ACTIVE_CLAIMS_BY_UNIT = {}

# --- ID Counters ---
_person_id_counter = 73440
_household_id_counter = 31162
_marriage_id_counter = 0
_car_id_counter = 0

def next_person_id():
    global _person_id_counter
    _person_id_counter += 1
    return _person_id_counter

def next_household_id():
    global _household_id_counter
    _household_id_counter += 1
    return _household_id_counter

def next_marriage_id():
    global _marriage_id_counter
    _marriage_id_counter += 1
    return _marriage_id_counter

def next_car_id():
    global _car_id_counter
    _car_id_counter += 1
    return f"CAR_{_car_id_counter}"

# --- Annual Data for Logging ---
ANNUAL_SUMMARY_DATA = {}
VEHICLE_EVENTS = []
TRIP_SUMMARY = []
RATES_LOG = []

# --- Global Modifiers for Trigger Events ---
event_birth_rate_modifier = 1.0
event_death_rate_modifier = 1.0
event_employment_rate_modifier = 1.0
event_inflation_modifier = 1.0
event_income_modifier = 1.0
event_gov_support_modifier = 1.0
event_gov_cap_modifier = 1.0
event_dropout_prob = 0.0
event_housing_cost_modifier = 1.0 # ADDED

# --- Global Modifiers: CITY-SPECIFIC CALIBRATION (Gate 2 correction) ---
# Set exactly once, at run start, by reset_global_state() from the approved
# config override (BIRTH_RATE_MODIFIER / DEATH_RATE_MODIFIER /
# MARRIAGE_RATE_MODIFIER). No per-year manager may ever reassign these --
# this is the exact defect Gate 2 corrects (WorldManager previously
# silently overwrote them via a shared variable name with the ARIMA-trend
# modifiers below). See RESSEARCH/03_FORENSIC_AUDIT/vital_rate_gate1_report.md.
city_birth_rate_modifier = 1.0
city_death_rate_modifier = 1.0
city_marriage_rate_modifier = 1.0

# --- Global Modifiers for ARIMA Forecasts (ANNUAL trend component only) ---
# City-agnostic by construction (fit on a single shared historical table).
# Renamed from arima_*_modifier to annual_*_modifier so this concept can
# never again share a variable name with the city_* modifiers above.
annual_birth_rate_modifier = 1.0
annual_death_rate_modifier = 1.0
annual_marriage_rate_modifier = 1.0  # No legitimate annual marriage forecast series exists; stays at this neutral default always (see Gate 2 report Section 3).
arima_owner_preference_modifier = 1.0 # ADDED (unchanged -- economic subsystem, out of this gate's scope)

# --- Latest calculated score for dynamic managers ---
latest_economic_index = 100.0

# --- ADDED: Current Housing Market State for Feedback Loops ---
current_rental_vacancy_rate = 0.05
current_renter_cost_burden_ratio = 0.40