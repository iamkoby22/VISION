# r2_population_accounting.py
# R2 -- POST-PROCESSING ONLY. Builds the annual population-accounting output
# required by R1's 13_r1_population_accounting_contract.md, using the NEW
# direct event ledgers (r2_birth_ledger, r2_death_ledger, r2_migration_ledger)
# rather than the old household-cumulative counters (whose reliability VR-007
# disputes). Reads already-written CSVs from a completed run; never touches
# the simulation itself.
#
# Identity: N(t+1) = N(t) + B(t) - D(t) + I(t) - O(t) + A(t)
# RESIDUAL(t) = N(t+1) - [N(t) + B(t) - D(t) + I(t) - O(t) + A(t)]
# A(t) = 0 (no additional flow currently identified in current VISION Core evidence).

import csv, sys, os
from collections import defaultdict


def _read_csv(path):
    if not os.path.exists(path):
        return []
    with open(path, encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f))


def build_population_accounting(annual_summary_path, birth_ledger_path, death_ledger_path, migration_ledger_path, out_path):
    annual = _read_csv(annual_summary_path)
    births = _read_csv(birth_ledger_path)
    deaths = _read_csv(death_ledger_path)
    migrations = _read_csv(migration_ledger_path)

    births_by_year = defaultdict(int)
    for r in births:
        births_by_year[int(r['simulation_year'])] += 1

    deaths_by_year = defaultdict(int)
    for r in deaths:
        deaths_by_year[int(r['simulation_year'])] += 1

    background_immigration_by_year = defaultdict(int)
    pep_immigration_by_year = defaultdict(int)
    other_immigration_by_year = defaultdict(int)
    emigration_by_year = defaultdict(int)
    for r in migrations:
        y = int(r['simulation_year'])
        mech = r['migration_mechanism']
        direction = r['direction']
        if direction == 'IN':
            if mech == 'BACKGROUND_IMMIGRATION':
                background_immigration_by_year[y] += 1
            elif mech == 'PEP_STRUCTURAL_MIGRATION':
                pep_immigration_by_year[y] += 1
            else:
                other_immigration_by_year[y] += 1
        elif direction == 'OUT':
            emigration_by_year[y] += 1

    pop_by_year = {int(r['Year']): int(r['Population']) for r in annual}
    years_sorted = sorted(pop_by_year.keys())

    rows_out = []
    for i in range(len(years_sorted) - 1):
        t = years_sorted[i]
        t_next = years_sorted[i + 1]
        n_t = pop_by_year[t]
        n_t1 = pop_by_year[t_next]
        b = births_by_year.get(t_next, 0)  # events logged in year t->t+1 transition carry simulation_year = t_next per hook placement
        d = deaths_by_year.get(t_next, 0)
        i_bg = background_immigration_by_year.get(t_next, 0)
        i_pep = pep_immigration_by_year.get(t_next, 0)
        i_other = other_immigration_by_year.get(t_next, 0)
        o = emigration_by_year.get(t_next, 0)
        a = 0
        i_total = i_bg + i_pep + i_other
        expected_n_end = n_t + b - d + i_total - o + a
        residual = n_t1 - expected_n_end
        rows_out.append({
            'year_start': t, 'year_end': t_next,
            'N_start': n_t, 'births': b, 'deaths': d,
            'background_immigration': i_bg, 'PEP_immigration': i_pep, 'other_immigration': i_other,
            'emigration': o, 'other_population_additions': 0, 'other_population_removals': 0,
            'N_end': n_t1, 'expected_N_end': expected_n_end, 'residual': residual,
        })

    with open(out_path, 'w', newline='', encoding='utf-8') as f:
        fieldnames = ['year_start', 'year_end', 'N_start', 'births', 'deaths', 'background_immigration',
                      'PEP_immigration', 'other_immigration', 'emigration', 'other_population_additions',
                      'other_population_removals', 'N_end', 'expected_N_end', 'residual']
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows_out)

    return rows_out


if __name__ == '__main__':
    if len(sys.argv) != 6:
        print("usage: r2_population_accounting.py <annual_summary.csv> <birth_ledger.csv> <death_ledger.csv> <migration_ledger.csv> <out.csv>")
        sys.exit(1)
    rows = build_population_accounting(*sys.argv[1:6])
    nonzero_residuals = [r for r in rows if r['residual'] != 0]
    print(f"Wrote {len(rows)} accounting rows. Nonzero residuals: {len(nonzero_residuals)}")
    for r in rows:
        print(r)
