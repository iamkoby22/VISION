# mastercode02_utils.py
from mastercode02_config_and_rates import COST_GRID, HOUSING_STOCK
import mastercode02_globals as g


def is_married_status(status) -> bool:
    """Classify marital status for fertility table selection (Phase 3C).

    Currently married -> True. Never married / unmarried / divorced / separated /
    widowed / missing / unknown -> False.
    'Now married (except separated)' counts as married because 'married' is present
    and the phrase is not a separated-only status.
    """
    if status is None:
        return False
    s = str(status).strip().lower()
    if not s:
        return False
    # Explicit non-current-married statuses
    if s in ("never married", "unmarried", "divorced", "separated", "widowed", "single"):
        return False
    if s.startswith("never married") or s.startswith("divorced") or s.startswith("widowed"):
        return False
    # Separated alone (not "except separated" inside a married phrase)
    if "separated" in s and "married" not in s:
        return False
    if s.startswith("separated"):
        return False
    # Currently married indicators (Married, Now married, married-couple, ...)
    if "married" in s:
        return True
    return False


def classify_household_for_cost(members):
    """Determines a household's composition for non-housing cost calculation."""
    adults = sum(1 for p in members if p.age >= 18)
    children = sum(1 for p in members if p.age < 18)
    working_adults = sum(1 for p in members if p.age >= 18 and p.employment_status == 'Employed')

    if adults <= 1:
        adults_key = "1_adult"
    else: 
        adults_key = "2_adults_2_working" if working_adults >= 2 else "2_adults_1_working"

    return adults, children, adults_key

def compute_household_cost(household_data, cpi_inflation_multiplier, mortgage_rate):
    """Calculates the detailed annual cost for a household, including dynamic housing costs."""
    members = household_data.get('members', [])
    if not members:
        return 0

    # --- 1. Calculate Non-Housing Costs ---
    adults, children, adults_key = classify_household_for_cost(members)
    child_idx = min(children, 3)
    non_housing_cost = sum(COST_GRID[category][adults_key][child_idx] for category in COST_GRID)

    if children > 3:
        cost_3_children = sum(COST_GRID[category][adults_key][3] for category in COST_GRID)
        cost_2_children = sum(COST_GRID[category][adults_key][2] for category in COST_GRID)
        marginal_child_cost = cost_3_children - cost_2_children
        non_housing_cost += (children - 3) * marginal_child_cost
    
    if adults > 2:
        cost_2_adults = sum(COST_GRID[category]["2_adults_2_working"][0] for category in COST_GRID)
        cost_1_adult = sum(COST_GRID[category]["1_adult"][0] for category in COST_GRID)
        marginal_adult_cost = cost_2_adults - cost_1_adult
        non_housing_cost += (adults - 2) * marginal_adult_cost

    # --- 2. Calculate Dynamic Housing Cost ---
    housing_cost = 0
    tenure = household_data.get('tenure')
    housing_unit_name = household_data.get('housing_unit_name')
    
    if tenure == 'Renter' and housing_unit_name:
        base_rent = HOUSING_STOCK[housing_unit_name]['base_cost']
        housing_cost = base_rent * g.event_housing_cost_modifier
    elif tenure == 'Owner' and housing_unit_name:
        loan_balance = household_data.get('loan_balance', 0)
        # Simplified annual mortgage payment (interest + principal)
        interest_payment = loan_balance * mortgage_rate
        principal_payment = loan_balance * 0.02 # Assuming ~50 year loan term
        housing_cost = interest_payment + principal_payment
    elif tenure == 'Insecure':
        # Assign a higher, penalty cost for unstable conditions
        housing_cost = 30000 
        
    household_data['housing_cost'] = housing_cost
    total_cost = (non_housing_cost * cpi_inflation_multiplier) + housing_cost
    
    # --- 3. Update Cost Burden Status ---
    total_income = household_data.get('total_income', 0)
    if total_income > 0 and housing_cost > 0:
        is_cost_burdened = (housing_cost / total_income) > 0.30
        household_data['is_cost_burdened'] = is_cost_burdened
    else:
        household_data['is_cost_burdened'] = False

    return total_cost