"""Phase 7A diagnostics — READ-ONLY per-year household classification snapshots.

Feeds the Phase 7A reconciliation / audit CSVs. Performs no state writes, no RNG draws.
"""
from __future__ import annotations

import mastercode02_globals as g
from mastercode02_household_lifecycle import (
    classify_household_housing_status, household_status_counts, old_basis_insecure_count,
    GENUINE_INSECURE, EMPTY_SHELL,
)
from mastercode02_housing_ledger import (
    household_has_active_housing_claim, get_household_housing_claim, stock_vacancy_snapshot,
)


PHASE7A_LOG: dict = {
    "households": [],  # one row per household per year
    "status_counts": [],  # one row per year (aggregate)
    "stock": [],  # one row per year (ledger vacancy)
}


def reset_phase7a_diagnostics() -> None:
    PHASE7A_LOG["households"].clear()
    PHASE7A_LOG["status_counts"].clear()
    PHASE7A_LOG["stock"].clear()


def _formation_reason(hh_type: str) -> str:
    t = (hh_type or "").lower()
    if "married-couple" in t:
        return "marriage_new_household"
    if "nonfamily" in t:
        return "immigration_or_nonfamily"
    return "initial_or_other"


def snapshot_yearly_phase7a(year: int, env=None) -> None:
    counts = household_status_counts()
    PHASE7A_LOG["status_counts"].append({"year": year, **counts,
                                         "old_basis_insecure": old_basis_insecure_count()})
    PHASE7A_LOG["stock"].append({"year": year, **stock_vacancy_snapshot()})

    for hh_id, hh in g.HOUSEHOLDS.items():
        members = hh.get("members", []) or []
        n = len(members)
        classification = classify_household_housing_status(hh_id)
        has_claim = household_has_active_housing_claim(hh_id)
        claim = get_household_housing_claim(hh_id)
        head_age = ""
        if members:
            try:
                head_age = max(getattr(p, "age", 0) for p in members)
            except Exception:
                head_age = ""
        PHASE7A_LOG["households"].append({
            "year": year,
            "household_id": hh_id,
            "household_type": hh.get("type", ""),
            "member_count": n,
            "is_empty": n == 0,
            "old_insecure_label": hh.get("tenure") == "Insecure",
            "tenure_label": hh.get("tenure", "") or "",
            "has_active_housing_ledger_claim": has_claim,
            "active_housing_unit_name": claim.get("housing_unit_name", "") if claim else "",
            "active_housing_tenure_type": claim.get("tenure_type", "") if claim else "",
            "classification": classification,
            "genuine_insecure": classification == GENUINE_INSECURE,
            "empty_shell": classification == EMPTY_SHELL,
            "income": float(hh.get("total_income", 0) or 0),
            "head_age": head_age,
            "formation_reason": _formation_reason(hh.get("type", "")),
        })
