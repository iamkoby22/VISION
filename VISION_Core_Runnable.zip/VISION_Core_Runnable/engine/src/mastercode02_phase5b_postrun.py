"""Phase 5B post-run diagnostics."""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from mastercode02_phase5b_diagnostics import PHASE5B_LOG
from mastercode02_config_and_rates import (
    BUS_OPERATING_DAYS_PER_YEAR, BUS_CAPACITY_UTILIZATION_FACTOR, BUS_CAPACITY_UNIT_MODE,
    POST_HS_ROUTE_PROBS, EDUCATION_REENTRY_PROBS, FERTILITY_PROBABILITY_SCALE,
    PUBLIC_TRANSIT_CONFIG,
)


def run_post_analysis(run_dir: Path, phase4d_dir: Path, phase5a_dir: Path) -> bool:
    diag = run_dir / "diagnostics"
    plots = diag / "phase5b_plots"
    plots.mkdir(parents=True, exist_ok=True)
    out = run_dir / "outputs"

    metrics = pd.DataFrame(PHASE5B_LOG.get("metrics", []))
    trips = pd.DataFrame(PHASE5B_LOG.get("trip_groups", []))
    cars = pd.DataFrame(PHASE5B_LOG.get("car_mobility", []))
    ti_stub = pd.DataFrame(PHASE5B_LOG.get("transport_index", []))

    metrics.to_csv(diag / "phase5b_transit_units_reconciliation_metrics.csv", index=False)
    trips.to_csv(diag / "phase5b_trip_generation_by_group.csv", index=False)
    cars.to_csv(diag / "phase5b_car_ownership_mobility_audit.csv", index=False)

    # Before/after from Phase 5A refusal audit + Phase 5B metrics
    p5a_ref = pd.read_csv(phase5a_dir / "diagnostics" / "phase5a_refused_trip_audit.csv")
    before_after = []
    for _, r in metrics.iterrows():
        y = int(r["year"])
        a = p5a_ref[p5a_ref["year"] == y]
        if len(a):
            ab = a.iloc[0]
            accepted_b, refused_b = int(ab["bus_served"]), int(ab["bus_refused"])
            rate_b = float(ab["refusal_rate"])
            daily_old = float(ab.get("service_ratio", 0))  # not capacity
        else:
            accepted_b = refused_b = rate_b = np.nan
        # daily capacity from 5A inventory if available
        p5a_cap = pd.read_csv(phase5a_dir / "diagnostics" / "phase5a_bus_capacity_audit.csv")
        c = p5a_cap[p5a_cap["year"] == y]
        old_daily = float(c.iloc[0]["env_total_bus_capacity"]) if len(c) else float(r["bus_daily_capacity"])
        before_after.append({
            "year": y,
            "old_daily_capacity": old_daily,
            "corrected_annual_capacity": float(r["bus_annual_capacity"]),
            "annual_demand": float(r["bus_annual_demand"]),
            "accepted_before": accepted_b,
            "refused_before": refused_b,
            "refusal_rate_before": rate_b,
            "accepted_after": int(r["bus_accepted_annual"]),
            "refused_after": int(r["bus_refused_annual"]),
            "refusal_rate_after": float(r["bus_refusal_rate_annual"]),
            "interpretation": (
                "annual capacity covers demand" if r["bus_refused_annual"] == 0
                else "residual refusal after annualization"
            ),
        })
    ba = pd.DataFrame(before_after)
    ba.to_csv(diag / "phase5b_bus_before_after_capacity_comparison.csv", index=False)

    # Transport index audit
    s5b = pd.read_csv(next(out.glob("*scores_summary.csv")))
    s4d = pd.read_csv(phase4d_dir / "outputs" / "mastercode02_output_phase4d_seed123_scores_summary.csv")
    ti_rows = []
    for y in range(6):
        after = float(s5b[s5b["year"] == y].iloc[0]["transport_index"])
        before = float(s4d[s4d["year"] == y].iloc[0]["transport_index"])
        stub = ti_stub[ti_stub["year"] == y]
        ti_rows.append({
            "year": y,
            "transport_index_before_if_available": before,
            "transport_index_after": after,
            "accepted_bus_trips": int(stub.iloc[0]["accepted_bus_trips"]) if len(stub) else "",
            "refused_bus_trips": int(stub.iloc[0]["refused_bus_trips"]) if len(stub) else "",
            "road_utilization_component": "cars/sum(road_capacities) in score formula",
            "car_component": int(stub.iloc[0]["total_cars"]) if len(stub) else "",
            "accident_component_if_available": int(stub.iloc[0]["num_accidents"]) if len(stub) else "",
            "notes": "Transport index formula does not directly use bus refused; may match Phase 4D if cars/accidents unchanged",
        })
    ti = pd.DataFrame(ti_rows)
    ti.to_csv(diag / "phase5b_transport_index_audit.csv", index=False)

    cmp4d = _compare_phase4d(out, phase4d_dir)
    cmp4d.to_csv(diag / "phase5b_phase4d_comparison.csv", index=False)
    cmp5a = _compare_phase5a(metrics, ba, phase5a_dir)
    cmp5a.to_csv(diag / "phase5b_phase5a_transit_comparison.csv", index=False)

    match_core = False
    if not cmp4d.empty:
        core = cmp4d[cmp4d["metric"].isin(["population", "births", "deaths", "employment_rate", "cbr_per_1000"])]
        match_core = bool(core["match"].astype(bool).all()) if len(core) else False

    mean_ref_after = float(metrics["bus_refusal_rate_annual"].mean()) if len(metrics) else 1.0
    mean_ref_before = float(ba["refusal_rate_before"].mean()) if len(ba) else 1.0
    refusal_dropped = mean_ref_after < mean_ref_before - 0.05

    red = pd.DataFrame([
        {
            "severity": "INFO" if refusal_dropped else "HIGH",
            "subsystem": "bus_units",
            "finding": f"Mean refusal before≈{mean_ref_before:.3f} after≈{mean_ref_after:.3f}",
            "evidence": "phase5b_bus_before_after_capacity_comparison.csv",
            "consequence": "Units reconciliation effect",
            "recommended_fix_phase": "n/a",
            "should_fix_now_yes_no": "no",
        },
        {
            "severity": "MEDIUM",
            "subsystem": "road_metrics",
            "finding": "Same total_cars still applied to each road type (Phase 5A finding)",
            "evidence": "TrafficManager unchanged",
            "consequence": "Road utilization remains non-partitioned",
            "recommended_fix_phase": "later_optional",
            "should_fix_now_yes_no": "no",
        },
        {
            "severity": "LOW",
            "subsystem": "transit_architecture",
            "finding": "Bus remains scalar (not Salabim Resource); no person-level daily schedules",
            "evidence": "Phase 5B design choice",
            "consequence": "Acceptable for annual cycle model",
            "recommended_fix_phase": "optional_later",
            "should_fix_now_yes_no": "no",
        },
        {
            "severity": "LOW",
            "subsystem": "calibration",
            "finding": "BUS_OPERATING_DAYS_PER_YEAR=250 provisional",
            "evidence": "config",
            "consequence": "May revisit if empirical operating-days needed",
            "recommended_fix_phase": "optional",
            "should_fix_now_yes_no": "no",
        },
        {
            "severity": "INFO" if match_core else "MEDIUM",
            "subsystem": "parity",
            "finding": f"Phase 5B vs 4D core demography match={match_core}",
            "evidence": "phase5b_phase4d_comparison.csv",
            "consequence": "Units fix should not alter fertility/population paths",
            "recommended_fix_phase": "n/a",
            "should_fix_now_yes_no": "no",
        },
    ])
    red.to_csv(diag / "phase5b_red_flags.csv", index=False)

    upgrades = pd.DataFrame([
        {
            "priority": 1,
            "recommendation": "Proceed to Phase 6A housing market forensics (playbook)",
            "type": "next_phase",
            "expected_model_impact": "diagnostic",
            "risk_level": "low",
            "files_likely_to_change": "new Phase 6A folder",
            "should_be_next_phase_yes_no": "yes",
        },
        {
            "priority": 2,
            "recommendation": "Optional later: road load partitioning / mode-choice / fleet calibration",
            "type": "deferred",
            "expected_model_impact": "mobility realism",
            "risk_level": "medium",
            "files_likely_to_change": "TrafficManager/CommuteManager",
            "should_be_next_phase_yes_no": "no",
        },
    ])
    upgrades.to_csv(diag / "phase5b_upgrade_recommendations.csv", index=False)

    _plots(plots, metrics, ba, cars, ti, cmp4d, red)
    passed = bool(refusal_dropped or mean_ref_after < 0.05) and bool(PUBLIC_TRANSIT_CONFIG["initial_buses"] == 25)
    _report(diag, metrics, ba, ti, cmp4d, match_core, mean_ref_before, mean_ref_after, passed)
    return passed


def _compare_phase4d(out, phase4d_dir):
    a5 = pd.read_csv(next(out.glob("*annual_summary.csv")))
    a4 = pd.read_csv(phase4d_dir / "outputs" / "mastercode02_output_phase4d_seed123_annual_summary.csv")
    s5 = pd.read_csv(next(out.glob("*scores_summary.csv")))
    s4 = pd.read_csv(phase4d_dir / "outputs" / "mastercode02_output_phase4d_seed123_scores_summary.csv")
    rows = []
    for y in range(6):
        r5, r4 = a5[a5["Year"] == y].iloc[0], a4[a4["Year"] == y].iloc[0]
        pop5, pop4 = float(r5["Population"]), float(r4["Population"])
        b5, b4 = float(r5["No of births"]), float(r4["No of births"])
        d5, d4 = float(r5["No. of Deaths"]), float(r4["No. of Deaths"])
        pairs = [
            ("population", pop4, pop5),
            ("births", b4, b5),
            ("deaths", d4, d5),
            ("cbr_per_1000", 1000 * b4 / pop4, 1000 * b5 / pop5),
            ("cdr_per_1000", 1000 * d4 / pop4, 1000 * d5 / pop5),
            ("employment_rate", float(r4["Employment Rate"]), float(r5["Employment Rate"])),
            ("rental_vacancy", float(r4["Rental_Vacancy_Rate"]), float(r5["Rental_Vacancy_Rate"])),
            ("overall_vacancy", float(r4["Overall_Vacancy_Rate"]), float(r5["Overall_Vacancy_Rate"])),
            ("housing_insecure", float(r4["Housing_Insecure_HH_Count"]), float(r5["Housing_Insecure_HH_Count"])),
            ("avg_income", float(r4["Avg Annual Income"]), float(r5["Avg Annual Income"])),
            ("total_cars", float(r4["Total Number of Cars"]), float(r5["Total Number of Cars"])),
            ("accidents", float(r4["Number of Accidents on road"]), float(r5["Number of Accidents on road"])),
            ("economic_index", float(s4[s4["year"] == y].iloc[0]["economic_index"]), float(s5[s5["year"] == y].iloc[0]["economic_index"])),
            ("transport_index", float(s4[s4["year"] == y].iloc[0]["transport_index"]), float(s5[s5["year"] == y].iloc[0]["transport_index"])),
        ]
        for metric, v4, v5 in pairs:
            rows.append({
                "year": y, "metric": metric, "phase4d_value": v4, "phase5b_value": v5,
                "absolute_diff": v5 - v4, "match": abs(v5 - v4) < 1e-6,
            })
    return pd.DataFrame(rows)


def _compare_phase5a(metrics, ba, phase5a_dir):
    rows = []
    for _, r in ba.iterrows():
        y = int(r["year"])
        rows.append({
            "year": y, "metric": "bus_refusal_rate",
            "phase5a_value": r["refusal_rate_before"], "phase5b_value": r["refusal_rate_after"],
            "absolute_diff": r["refusal_rate_after"] - r["refusal_rate_before"],
        })
        rows.append({
            "year": y, "metric": "bus_refused",
            "phase5a_value": r["refused_before"], "phase5b_value": r["refused_after"],
            "absolute_diff": r["refused_after"] - r["refused_before"],
        })
        rows.append({
            "year": y, "metric": "bus_accepted",
            "phase5a_value": r["accepted_before"], "phase5b_value": r["accepted_after"],
            "absolute_diff": r["accepted_after"] - r["accepted_before"],
        })
        rows.append({
            "year": y, "metric": "capacity_used_for_comparison",
            "phase5a_value": r["old_daily_capacity"], "phase5b_value": r["corrected_annual_capacity"],
            "absolute_diff": r["corrected_annual_capacity"] - r["old_daily_capacity"],
        })
    if len(metrics):
        for _, r in metrics.iterrows():
            rows.append({
                "year": int(r["year"]), "metric": "bus_daily_capacity_preserved",
                "phase5a_value": r["bus_daily_capacity"], "phase5b_value": r["bus_daily_capacity"],
                "absolute_diff": 0,
            })
    return pd.DataFrame(rows)


def _plots(plots, metrics, ba, cars, ti, cmp4d, red):
    def save(fig, name):
        fig.tight_layout()
        fig.savefig(plots / name, dpi=120)
        plt.close(fig)

    if len(metrics):
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.plot(metrics["year"], metrics["bus_daily_capacity"], "o--", label="daily capacity")
        ax.plot(metrics["year"], metrics["bus_annual_demand"], "s-", label="annual demand")
        ax.set_title("Old daily capacity vs annual demand")
        ax.legend()
        save(fig, "01_daily_capacity_vs_annual_demand.png")

        fig, ax = plt.subplots(figsize=(8, 4))
        ax.plot(metrics["year"], metrics["bus_annual_capacity"], "o-", label="annual capacity")
        ax.plot(metrics["year"], metrics["bus_annual_demand"], "s-", label="annual demand")
        ax.set_title("Corrected annual capacity vs annual demand")
        ax.legend()
        save(fig, "02_annual_capacity_vs_demand.png")

    if len(ba):
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.bar(ba["year"] - 0.2, ba["accepted_before"], width=0.2, label="accepted before")
        ax.bar(ba["year"], ba["refused_before"], width=0.2, label="refused before")
        ax.bar(ba["year"] + 0.2, ba["accepted_after"], width=0.2, label="accepted after")
        ax.bar(ba["year"] + 0.4, ba["refused_after"], width=0.2, label="refused after")
        ax.set_title("Bus accepted/refused before vs after")
        ax.legend(fontsize=7)
        save(fig, "03_accepted_refused_before_after.png")

        fig, ax = plt.subplots(figsize=(8, 4))
        ax.plot(ba["year"], ba["refusal_rate_before"], "o--", label="before (daily basis)")
        ax.plot(ba["year"], ba["refusal_rate_after"], "s-", label="after (annual)")
        ax.set_ylim(0, 1.05)
        ax.set_title("Bus refusal rate before vs after")
        ax.legend()
        save(fig, "04_refusal_rate_before_after.png")

    if len(cars):
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.plot(cars["year"], cars["bus_eligible_non_car_owners"], "o-", label="bus demand")
        ax.plot(cars["year"], cars["car_owner_count"], "s-", label="car owners")
        ax.set_title("Car ownership vs bus demand")
        ax.legend()
        save(fig, "05_car_ownership_vs_bus_demand.png")

    if len(ti):
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.plot(ti["year"], ti["transport_index_before_if_available"], "o--", label="4D/before")
        ax.plot(ti["year"], ti["transport_index_after"], "s-", label="5B after")
        ax.set_title("Transport index before vs after")
        ax.legend()
        save(fig, "06_transport_index_before_after.png")

    if len(cmp4d):
        core = cmp4d[cmp4d["metric"].isin(["population", "births", "deaths", "employment_rate", "cbr_per_1000"])]
        mets = list(core["metric"].unique())
        fig, axes = plt.subplots(1, len(mets), figsize=(3 * len(mets), 3.5))
        if len(mets) == 1:
            axes = [axes]
        for ax, m in zip(axes, mets):
            sub = core[core["metric"] == m]
            ax.plot(sub["year"], sub["phase4d_value"], "o--", label="4D")
            ax.plot(sub["year"], sub["phase5b_value"], "s-", label="5B")
            ax.set_title(m); ax.legend(fontsize=7)
        save(fig, "07_phase4d_vs_phase5b.png")

    if len(red):
        sev = {"HIGH": 3, "MEDIUM": 2, "LOW": 1, "INFO": 0}
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.barh(red["finding"].str[:45], red["severity"].map(sev))
        ax.set_title("Remaining transit red flags")
        save(fig, "08_red_flags.png")


def _report(diag, metrics, ba, ti, cmp4d, match_core, mean_before, mean_after, passed):
    report = f"""# Phase 5B Transit Units Reconciliation Report

**Status:** {'PASSED' if passed else 'FAILED'}  
**Base:** Phase 4D source-copy. Fleet size unchanged. Demand eligibility unchanged.

## Required answers

1. **Units mismatch:** Daily capacity (`fleet×33×10`) was compared to annual carless Work/School headcount.
2. **Code path changed:** `PublicTransitManager` (expose daily+annual); `CommuteManager` uses `bus_annual_capacity` for service_ratio/served/refused.
3. **Old daily formula:** `fleet_size × seats_per_bus × trips_per_day`.
4. **New annual formula:** `daily × BUS_OPERATING_DAYS_PER_YEAR × BUS_CAPACITY_UTILIZATION_FACTOR`.
5. **Operating days:** `{BUS_OPERATING_DAYS_PER_YEAR}` (provisional). Utilization factor `{BUS_CAPACITY_UTILIZATION_FACTOR}`. Mode `{BUS_CAPACITY_UNIT_MODE}`.
6. **Fleet size changed?** **NO** (still `initial_buses=25` scaled by population).
7. **Demand logic changed?** **NO** (same carless Work/School filter).
8. **Car-owner exclusion preserved?** **YES**.
9. **Bus refusal decrease?** Mean rate before≈**{mean_before:.4f}** after≈**{mean_after:.4f}**.
10. **Transport index change?** See `phase5b_transport_index_audit.csv` (formula uses cars/accidents, not bus refused).
11. **Core demography stable?** Match Phase 4D core={match_core}.
12. **Road metrics changed?** **NO**.
13. **Remaining red flags?** Road load partitioning; provisional operating-days; optional later mode-choice/fleet calibration.

## Metrics

```
{metrics.to_string(index=False) if len(metrics) else ''}
```

## Before/after refusal

```
{ba.to_string(index=False) if len(ba) else ''}
```

## Stop

Phase 5B complete. Do not implement road fix, fleet calibration, housing, or ML here.
"""
    (diag / "phase5b_transit_units_reconciliation_report.md").write_text(report, encoding="utf-8")
    (diag / "phase5b_run_pass_summary.json").write_text(json.dumps({
        "passed": passed,
        "mean_refusal_before": mean_before,
        "mean_refusal_after": mean_after,
        "phase4d_core_match": match_core,
        "fleet_unchanged": True,
        "demand_logic_unchanged": True,
        "unit_mode": BUS_CAPACITY_UNIT_MODE,
        "operating_days": BUS_OPERATING_DAYS_PER_YEAR,
    }, indent=2), encoding="utf-8")
