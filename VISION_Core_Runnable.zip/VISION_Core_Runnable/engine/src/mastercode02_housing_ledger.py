"""Minimal durable household-level housing claim ledger (Phase 6B).

Source of truth for housing occupancy / vacancy. Households are dicts and cannot
own Salabim Resource claims; this ledger provides durable household_id ownership
and release without rewriting housing market selection logic.
"""
from __future__ import annotations

from typing import Any, Optional

import mastercode02_globals as g
from mastercode02_config_and_rates import HOUSING_STOCK


# Durable occupancy state (also mirrored on g for reset/snapshots)
HOUSING_LEDGER_ACTIVE: dict = {}
HOUSING_LEDGER_HISTORY: list = []
HOUSING_ACTIVE_CLAIMS_BY_UNIT: dict = {}

# Diagnostic event buffers (observation)
LEDGER_DIAG_EVENTS: list = []
LEDGER_RELEASE_AUDIT: list = []
LEDGER_TRANSFER_AUDIT: list = []


def reset_housing_ledger() -> None:
    HOUSING_LEDGER_ACTIVE.clear()
    HOUSING_LEDGER_HISTORY.clear()
    HOUSING_ACTIVE_CLAIMS_BY_UNIT.clear()
    LEDGER_DIAG_EVENTS.clear()
    LEDGER_RELEASE_AUDIT.clear()
    LEDGER_TRANSFER_AUDIT.clear()
    g.HOUSING_LEDGER_ACTIVE = HOUSING_LEDGER_ACTIVE
    g.HOUSING_LEDGER_HISTORY = HOUSING_LEDGER_HISTORY
    g.HOUSING_ACTIVE_CLAIMS_BY_UNIT = HOUSING_ACTIVE_CLAIMS_BY_UNIT
    for name in HOUSING_STOCK:
        HOUSING_ACTIVE_CLAIMS_BY_UNIT[name] = 0


def _ensure_unit_counter(unit_name: str) -> None:
    if unit_name not in HOUSING_ACTIVE_CLAIMS_BY_UNIT:
        HOUSING_ACTIVE_CLAIMS_BY_UNIT[unit_name] = 0


def get_housing_capacity(unit_name: str) -> int:
    stock = HOUSING_STOCK.get(unit_name)
    if not stock:
        return 0
    return int(stock.get("capacity", 0))


def get_housing_active_claim_count(unit_name: str) -> int:
    _ensure_unit_counter(unit_name)
    return int(HOUSING_ACTIVE_CLAIMS_BY_UNIT.get(unit_name, 0))


def get_housing_available_count(unit_name: str) -> int:
    return max(0, get_housing_capacity(unit_name) - get_housing_active_claim_count(unit_name))


def household_has_active_housing_claim(household_id) -> bool:
    return household_id in HOUSING_LEDGER_ACTIVE


def get_household_housing_claim(household_id) -> Optional[dict]:
    return HOUSING_LEDGER_ACTIVE.get(household_id)


def _category_for_unit(unit_name: str) -> str:
    stock = HOUSING_STOCK.get(unit_name, {})
    return str(stock.get("type", "unknown"))


def _tenure_matches_unit(tenure: str, unit_name: str) -> bool:
    cat = _category_for_unit(unit_name)
    if tenure == "Renter":
        return cat == "Rental"
    if tenure == "Owner":
        return cat == "For-Sale"
    return False


def _record_event(**kwargs) -> None:
    LEDGER_DIAG_EVENTS.append(dict(kwargs))
    HOUSING_LEDGER_HISTORY.append(dict(kwargs))


def reconcile_household_housing_labels(household_id) -> str:
    """Align household dict labels with active ledger claim (or clear if none)."""
    hh = g.HOUSEHOLDS.get(household_id)
    if hh is None:
        return "household_missing"
    claim = HOUSING_LEDGER_ACTIVE.get(household_id)
    if claim:
        hh["housing_unit_name"] = claim["housing_unit_name"]
        hh["tenure"] = claim["tenure_type"]
        return "synced_from_ledger"
    # No active claim: clear housing occupancy labels
    hh["housing_unit_name"] = None
    if hh.get("tenure") in ("Renter", "Owner"):
        hh["tenure"] = "Insecure"
    return "cleared_unclaimed_labels"


def release_housing_for_household(household_id, year: int, reason: str) -> bool:
    """Release active ledger claim for household_id. Does not use person.claimed_resources()."""
    hh = g.HOUSEHOLDS.get(household_id)
    had = household_id in HOUSING_LEDGER_ACTIVE
    claim = HOUSING_LEDGER_ACTIVE.get(household_id)

    if not had:
        if hh is not None:
            # Clear stale labels if present
            if hh.get("housing_unit_name"):
                hh["housing_unit_name"] = None
                if hh.get("tenure") in ("Renter", "Owner"):
                    hh["tenure"] = "Insecure"
        LEDGER_RELEASE_AUDIT.append({
            "year": year,
            "household_id": household_id,
            "release_reason": reason,
            "had_active_claim_before": False,
            "release_success": True,
            "active_claim_after": False,
            "household_empty_after": (hh is None) or (len(hh.get("members", []) or []) == 0),
            "notes": "no_active_claim; labels cleared if present",
        })
        _record_event(
            year=year, event_type="release", household_id=household_id,
            housing_unit_name="", housing_category="", tenure_type="",
            assignment_reason="", release_reason=reason, success=True,
            failure_reason="", notes="noop_no_active_claim",
        )
        return True

    unit = claim["housing_unit_name"]
    _ensure_unit_counter(unit)
    HOUSING_ACTIVE_CLAIMS_BY_UNIT[unit] = max(0, HOUSING_ACTIVE_CLAIMS_BY_UNIT[unit] - 1)
    claim_copy = dict(claim)
    claim_copy["released_year"] = year
    claim_copy["release_reason"] = reason
    claim_copy["active_yes_no"] = False
    del HOUSING_LEDGER_ACTIVE[household_id]

    if hh is not None:
        hh["housing_unit_name"] = None
        if hh.get("tenure") in ("Renter", "Owner"):
            hh["tenure"] = "Insecure"

    empty_after = (hh is None) or (len((hh or {}).get("members", []) or []) == 0)
    LEDGER_RELEASE_AUDIT.append({
        "year": year,
        "household_id": household_id,
        "release_reason": reason,
        "had_active_claim_before": True,
        "release_success": True,
        "active_claim_after": household_id in HOUSING_LEDGER_ACTIVE,
        "household_empty_after": empty_after,
        "notes": f"released_unit={unit}",
    })
    _record_event(
        year=year, event_type="release", household_id=household_id,
        housing_unit_name=unit, housing_category=claim_copy.get("housing_category", ""),
        tenure_type=claim_copy.get("tenure_type", ""),
        assignment_reason="", release_reason=reason, success=True,
        failure_reason="", notes="released_by_household_id",
    )
    return True


def assign_housing_to_household(
    household_id,
    unit_name: str,
    tenure_type: str,
    year: int,
    reason: str,
) -> bool:
    """Durable assign. Capacity from HOUSING_STOCK; occupancy from ledger counts."""
    hh = g.HOUSEHOLDS.get(household_id)
    if hh is None:
        _record_event(
            year=year, event_type="assign", household_id=household_id,
            housing_unit_name=unit_name, housing_category=_category_for_unit(unit_name),
            tenure_type=tenure_type, assignment_reason=reason, release_reason="",
            success=False, failure_reason="household_missing", notes="",
        )
        return False

    if unit_name not in HOUSING_STOCK:
        _record_event(
            year=year, event_type="assign", household_id=household_id,
            housing_unit_name=unit_name, housing_category="",
            tenure_type=tenure_type, assignment_reason=reason, release_reason="",
            success=False, failure_reason="unknown_unit", notes="",
        )
        return False

    # If already has claim on different unit, release first
    existing = HOUSING_LEDGER_ACTIVE.get(household_id)
    if existing:
        if existing["housing_unit_name"] == unit_name and existing["tenure_type"] == tenure_type:
            reconcile_household_housing_labels(household_id)
            _record_event(
                year=year, event_type="assign", household_id=household_id,
                housing_unit_name=unit_name, housing_category=_category_for_unit(unit_name),
                tenure_type=tenure_type, assignment_reason=reason, release_reason="",
                success=True, failure_reason="", notes="idempotent_same_claim",
            )
            return True
        release_housing_for_household(household_id, year, reason=f"reassign_before_{reason}")

    if get_housing_available_count(unit_name) <= 0:
        _record_event(
            year=year, event_type="assign", household_id=household_id,
            housing_unit_name=unit_name, housing_category=_category_for_unit(unit_name),
            tenure_type=tenure_type, assignment_reason=reason, release_reason="",
            success=False, failure_reason="capacity_full", notes="",
        )
        return False

    if not _tenure_matches_unit(tenure_type, unit_name):
        _record_event(
            year=year, event_type="assign", household_id=household_id,
            housing_unit_name=unit_name, housing_category=_category_for_unit(unit_name),
            tenure_type=tenure_type, assignment_reason=reason, release_reason="",
            success=False, failure_reason="tenure_unit_mismatch", notes="",
        )
        return False

    _ensure_unit_counter(unit_name)
    HOUSING_ACTIVE_CLAIMS_BY_UNIT[unit_name] += 1
    cat = _category_for_unit(unit_name)
    HOUSING_LEDGER_ACTIVE[household_id] = {
        "housing_unit_name": unit_name,
        "housing_category": cat,
        "tenure_type": tenure_type,
        "assigned_year": year,
        "released_year": None,
        "active_yes_no": True,
        "assignment_reason": reason,
        "release_reason": None,
        "notes": "",
    }
    hh["housing_unit_name"] = unit_name
    hh["tenure"] = tenure_type

    _record_event(
        year=year, event_type="assign", household_id=household_id,
        housing_unit_name=unit_name, housing_category=cat,
        tenure_type=tenure_type, assignment_reason=reason, release_reason="",
        success=True, failure_reason="", notes="assigned_via_ledger",
    )
    return True


def mark_household_insecure(household_id, year: int, reason: str) -> None:
    """Ensure insecure HH has no active claim and consistent labels."""
    if household_has_active_housing_claim(household_id):
        release_housing_for_household(household_id, year, reason=f"mark_insecure_{reason}")
    hh = g.HOUSEHOLDS.get(household_id)
    if hh is not None:
        hh["housing_unit_name"] = None
        hh["tenure"] = "Insecure"
    _record_event(
        year=year, event_type="mark_insecure", household_id=household_id,
        housing_unit_name="", housing_category="", tenure_type="Insecure",
        assignment_reason="", release_reason=reason, success=True,
        failure_reason="", notes="",
    )


def stock_vacancy_snapshot() -> dict[str, Any]:
    """Vacancy from durable ledger active claims (not Salabim claimers)."""
    rent_cap = rent_claimed = 0
    sale_cap = sale_claimed = 0
    for name, stock in HOUSING_STOCK.items():
        cap = int(stock["capacity"])
        claimed = get_housing_active_claim_count(name)
        if stock["type"] == "Rental":
            rent_cap += cap
            rent_claimed += claimed
        elif stock["type"] == "For-Sale":
            sale_cap += cap
            sale_claimed += claimed
    rent_avail = rent_cap - rent_claimed
    sale_avail = sale_cap - sale_claimed
    total_cap = rent_cap + sale_cap
    total_claimed = rent_claimed + sale_claimed
    total_avail = total_cap - total_claimed
    return {
        "rental_capacity": rent_cap,
        "rental_claimed": rent_claimed,
        "rental_available": rent_avail,
        "rental_vacancy_rate": (rent_avail / rent_cap) if rent_cap else 0.0,
        "for_sale_capacity": sale_cap,
        "for_sale_claimed": sale_claimed,
        "for_sale_available": sale_avail,
        "for_sale_vacancy_rate": (sale_avail / sale_cap) if sale_cap else 0.0,
        "total_housing_capacity": total_cap,
        "total_housing_claimed": total_claimed,
        "total_housing_available": total_avail,
        "overall_vacancy_rate": (total_avail / total_cap) if total_cap else 0.0,
    }


def release_empty_households(year: int) -> int:
    """Release active claims for empty households."""
    n = 0
    for hh_id, hh in list(g.HOUSEHOLDS.items()):
        if len(hh.get("members", []) or []) == 0 and household_has_active_housing_claim(hh_id):
            release_housing_for_household(hh_id, year, reason="empty_household")
            n += 1
    return n


def transfer_household_housing_claim(
    household_id,
    to_unit_name: str,
    to_tenure: str = "Owner",
    year: int = 0,
    reason: str = "renter_to_owner",
    from_tenure: str = "Renter",
) -> bool:
    """Atomic rental→owner ledger transfer with rollback on failure.

    Does not leave household claimless on failure. Does not allow dual claims.
    """
    hh = g.HOUSEHOLDS.get(household_id)
    claim = HOUSING_LEDGER_ACTIVE.get(household_id)
    had_rental = bool(
        claim
        and claim.get("tenure_type") == from_tenure
        and claim.get("housing_category") == "Rental"
    )
    target_avail_before = get_housing_available_count(to_unit_name)

    def _audit(**kwargs):
        row = {
            "year": year,
            "household_id": household_id,
            "transfer_attempted": True,
            "had_rental_claim_before": had_rental,
            "target_for_sale_available_before": target_avail_before,
            "rental_claim_released": False,
            "owner_claim_created": False,
            "had_multiple_claims_after": False,
            "had_no_claim_after": household_id not in HOUSING_LEDGER_ACTIVE,
            "transfer_success": False,
            "rollback_success": False,
            "notes": "",
        }
        row.update(kwargs)
        LEDGER_TRANSFER_AUDIT.append(row)

    if hh is None:
        _audit(notes="household_missing")
        return False
    if not had_rental:
        _audit(notes="no_active_rental_claim")
        return False
    if to_unit_name not in HOUSING_STOCK or HOUSING_STOCK[to_unit_name].get("type") != "For-Sale":
        _audit(notes="invalid_for_sale_target")
        return False
    if to_tenure != "Owner":
        _audit(notes="to_tenure_must_be_Owner")
        return False
    if target_avail_before <= 0:
        _audit(notes="for_sale_unavailable")
        return False

    old_unit = claim["housing_unit_name"]
    old_claim_snapshot = dict(claim)
    decremented_old = False
    incremented_new = False

    # Atomic swap: decrement rental, increment for-sale, replace ledger entry
    try:
        _ensure_unit_counter(old_unit)
        _ensure_unit_counter(to_unit_name)
        if get_housing_available_count(to_unit_name) <= 0:
            _audit(notes="for_sale_raced_unavailable")
            return False

        HOUSING_ACTIVE_CLAIMS_BY_UNIT[old_unit] = max(
            0, HOUSING_ACTIVE_CLAIMS_BY_UNIT[old_unit] - 1
        )
        decremented_old = True
        HOUSING_ACTIVE_CLAIMS_BY_UNIT[to_unit_name] += 1
        incremented_new = True
        HOUSING_LEDGER_ACTIVE[household_id] = {
            "housing_unit_name": to_unit_name,
            "housing_category": "For-Sale",
            "tenure_type": "Owner",
            "assigned_year": year,
            "released_year": None,
            "active_yes_no": True,
            "assignment_reason": reason,
            "release_reason": None,
            "notes": f"transferred_from_{old_unit}",
        }
        hh["housing_unit_name"] = to_unit_name
        hh["tenure"] = "Owner"

        if household_id not in HOUSING_LEDGER_ACTIVE:
            raise RuntimeError("claim_missing_after_transfer")
        if HOUSING_ACTIVE_CLAIMS_BY_UNIT[to_unit_name] > get_housing_capacity(to_unit_name):
            raise RuntimeError("overcapacity_after_transfer")

        _record_event(
            year=year, event_type="transfer", household_id=household_id,
            housing_unit_name=to_unit_name, housing_category="For-Sale",
            tenure_type="Owner", assignment_reason=reason,
            release_reason=f"released_{old_unit}", success=True,
            failure_reason="", notes=f"r2o_from_{old_unit}",
        )
        _audit(
            rental_claim_released=True,
            owner_claim_created=True,
            had_multiple_claims_after=False,
            had_no_claim_after=False,
            transfer_success=True,
            rollback_success=False,
            notes="atomic_transfer_ok",
        )
        return True
    except Exception as exc:
        if incremented_new:
            HOUSING_ACTIVE_CLAIMS_BY_UNIT[to_unit_name] = max(
                0, HOUSING_ACTIVE_CLAIMS_BY_UNIT.get(to_unit_name, 0) - 1
            )
        if decremented_old:
            HOUSING_ACTIVE_CLAIMS_BY_UNIT[old_unit] = min(
                get_housing_capacity(old_unit),
                HOUSING_ACTIVE_CLAIMS_BY_UNIT.get(old_unit, 0) + 1,
            )
        HOUSING_LEDGER_ACTIVE[household_id] = old_claim_snapshot
        hh["housing_unit_name"] = old_unit
        hh["tenure"] = from_tenure
        _record_event(
            year=year, event_type="transfer", household_id=household_id,
            housing_unit_name=to_unit_name, housing_category="For-Sale",
            tenure_type="Owner", assignment_reason=reason,
            release_reason="", success=False,
            failure_reason=str(exc), notes="rollback_to_renter",
        )
        _audit(
            rental_claim_released=False,
            owner_claim_created=False,
            had_multiple_claims_after=False,
            had_no_claim_after=household_id not in HOUSING_LEDGER_ACTIVE,
            transfer_success=False,
            rollback_success=(
                household_id in HOUSING_LEDGER_ACTIVE
                and HOUSING_LEDGER_ACTIVE[household_id].get("tenure_type") == from_tenure
            ),
            notes=f"rollback:{exc}",
        )
        return False


# Initialize counters on import for fresh modules
reset_housing_ledger()
