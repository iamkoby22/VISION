# r2_validation_regression_tests.py
# R2 -- POST-PROCESSING ONLY. Implements the 7 named regression tests from the
# R2 spec Section 27, each targeting a specific error class Phase V1 found.
# Run standalone: `python r2_validation_regression_tests.py`. Writes a CSV of
# pass/fail results. Does not touch any simulation-runtime file.

import csv, os, sys
sys.path.insert(0, os.path.dirname(__file__))
from r2_validation_engine import check_compatibility, check_compatibility_with_disclosure, compute_error_metric_if_valid

RESULTS = []

def record(test_id, description, passed, detail):
    RESULTS.append({'test_id': test_id, 'description': description, 'passed': passed, 'detail': detail})
    print(f"[{'PASS' if passed else 'FAIL'}] {test_id}: {description}")

# TEST 1: employment validation cannot silently divide by total all-age
# population if the frozen observational definition is age 16+.
def test1():
    rec = check_compatibility(
        metric_id='EMPLOYMENT_RATIO', simulation_year=2023, observed_year=2023,
        simulation_geography='Johnson City', observed_geography='Johnson City',
        simulation_universe='total population (all ages)', observed_universe='civilian population 16+',
        simulation_unit='ratio', observed_unit='ratio',
        simulation_category_definition='Employed', observed_category_definition='Employed',
    )
    ok = rec['compatibility_status'] == 'INVALID_UNIVERSE'
    err = compute_error_metric_if_valid(rec, 0.5, 0.6)
    ok = ok and err is None
    record('TEST_1', "employment ratio: total-population denominator vs age-16+ observed universe must be INVALID_UNIVERSE, no APE computed", ok, rec)

# TEST 2: unemployment validation cannot run when category universe is incompatible.
def test2():
    rec = check_compatibility(
        metric_id='UNEMPLOYMENT_RATE', simulation_year=2023, observed_year=2023,
        simulation_geography='Johnson City', observed_geography='Johnson City',
        simulation_universe='total population', observed_universe='civilian labor force',
        simulation_unit='ratio', observed_unit='ratio',
        simulation_category_definition='Unemployed', observed_category_definition='Unemployed',
    )
    ok = rec['compatibility_status'] == 'INVALID_UNIVERSE'
    err = compute_error_metric_if_valid(rec, 0.02, 0.05)
    ok = ok and err is None
    record('TEST_2', "unemployment rate with incompatible universe must not run / no error score computed", ok, rec)

# TEST 3: 2023 structural validation cannot consume a 2024 simulation snapshot
# while calling it 2023 -- this is the exact defect this engine exists to catch.
def test3():
    rec = check_compatibility(
        metric_id='AGE_SEX_STRUCTURE', simulation_year=2024, observed_year=2023,
        simulation_geography='Johnson City', observed_geography='Johnson City',
        simulation_universe='total population', observed_universe='total population',
        simulation_unit='count', observed_unit='count',
        simulation_category_definition='age_band x sex', observed_category_definition='age_band x sex',
    )
    ok = rec['compatibility_status'] == 'INVALID_YEAR'
    record('TEST_3', "Year-24(->calendar 2024) snapshot compared as if it were 2023 must be INVALID_YEAR", ok, rec)
    # Also confirm the CORRECT case (calendar_year=2023 via the new CANONICAL_2023
    # snapshot) passes cleanly:
    rec_ok = check_compatibility(
        metric_id='AGE_SEX_STRUCTURE', simulation_year=2023, observed_year=2023,
        simulation_geography='Johnson City', observed_geography='Johnson City',
        simulation_universe='total population', observed_universe='total population',
        simulation_unit='count', observed_unit='count',
        simulation_category_definition='age_band x sex', observed_category_definition='age_band x sex',
    )
    ok2 = rec_ok['compatibility_status'] == 'VALID_EXACT'
    record('TEST_3b', "the new CANONICAL_2023 snapshot (simulation_year=2023) must pass as VALID_EXACT", ok2, rec_ok)

# TEST 4: household metrics cannot mix active households with all historical
# household records.
def test4():
    rec = check_compatibility(
        metric_id='HOUSEHOLD_COUNT', simulation_year=2023, observed_year=2023,
        simulation_geography='Johnson City', observed_geography='Johnson City',
        simulation_universe='all household records ever created (active+archived)',
        observed_universe='active occupied households',
        simulation_unit='count', observed_unit='count',
        simulation_category_definition='household', observed_category_definition='household',
    )
    ok = rec['compatibility_status'] == 'INVALID_UNIVERSE'
    record('TEST_4', "all-historical-records household universe vs active-only observed universe must be INVALID_UNIVERSE", ok, rec)

# TEST 5: person-level and household-level income metrics cannot be interchanged.
def test5():
    rec = check_compatibility(
        metric_id='INCOME', simulation_year=2023, observed_year=2023,
        simulation_geography='Johnson City', observed_geography='Johnson City',
        simulation_universe='persons with income>0', observed_universe='persons with income>0',
        simulation_unit='USD per person', observed_unit='USD per household',
        simulation_category_definition='income', observed_category_definition='income',
    )
    ok = rec['compatibility_status'] == 'INVALID_UNIT'
    record('TEST_5', "person-level USD/person vs household-level USD/household must be INVALID_UNIT", ok, rec)

# TEST 6: a proxy geography cannot be relabeled EXACT_OBSERVED (i.e. must not
# silently become VALID_EXACT; must go through the explicit disclosure path).
def test6():
    rec = check_compatibility(
        metric_id='MORTALITY_RATE', simulation_year=2023, observed_year=2023,
        simulation_geography='Johnson City', observed_geography='Washington County, TN (proxy for Johnson City)',
        simulation_universe='total population', observed_universe='total population',
        simulation_unit='rate per 1000', observed_unit='rate per 1000',
        simulation_category_definition='mortality', observed_category_definition='mortality',
    )
    ok = rec['compatibility_status'] == 'INVALID_GEOGRAPHY'
    # Now show the ONLY correct way to use a proxy: explicit disclosure wrapper,
    # which still requires geography to be declared EQUAL (i.e. the proxy must
    # be pre-labeled as representing the same simulation_geography by the
    # caller, with the proxy nature recorded in disclosure_note) -- it can
    # never silently become VALID_EXACT/EXACT_OBSERVED.
    rec2 = check_compatibility_with_disclosure(
        metric_id='MORTALITY_RATE', disclosure_kind='VALID_PROXY_WITH_DISCLOSURE',
        disclosure_note='Washington County, TN used as a county-fragment proxy for Johnson City; scientific_class E2 per prior lineage documentation.',
        simulation_year=2023, observed_year=2023,
        simulation_geography='Johnson City (proxy: Washington County, TN)', observed_geography='Johnson City (proxy: Washington County, TN)',
        simulation_universe='total population', observed_universe='total population',
        simulation_unit='rate per 1000', observed_unit='rate per 1000',
        simulation_category_definition='mortality', observed_category_definition='mortality',
    )
    ok2 = rec2['compatibility_status'] == 'VALID_PROXY_WITH_DISCLOSURE' and rec2['compatibility_status'] != 'VALID_EXACT'
    record('TEST_6', "undisclosed geography mismatch must be INVALID_GEOGRAPHY; a real proxy must be explicitly VALID_PROXY_WITH_DISCLOSURE, never bare VALID_EXACT", ok and ok2, {'undisclosed': rec, 'disclosed': rec2})

# TEST 7: invalid category mappings must return INVALID_CATEGORY, not an error.
def test7():
    try:
        rec = check_compatibility(
            metric_id='MARITAL_STATUS_MARRIED', simulation_year=2023, observed_year=2023,
            simulation_geography='Johnson City', observed_geography='Johnson City',
            simulation_universe='persons 15+', observed_universe='persons 15+',
            simulation_unit='count', observed_unit='count',
            simulation_category_definition="raw label 'Married' (runtime-origin only, excludes T0-origin 'Now married (except separated)')",
            observed_category_definition="ACS DP02 'Now married (except separated)'",
        )
        raised = False
    except Exception:
        raised = True
        rec = None
    ok = (not raised) and rec['compatibility_status'] == 'INVALID_CATEGORY'
    err = compute_error_metric_if_valid(rec, 100, 200) if rec else None
    ok = ok and err is None
    record('TEST_7', "mismatched category definitions must return INVALID_CATEGORY status (not raise, not silently compute an error score)", ok, rec)

def main():
    test1(); test2(); test3(); test4(); test5(); test6(); test7()
    out_path = r"C:\Users\LORD OF LORDS\Desktop\paper_mastercode_fable_simulation_v1_1\RESSEARCH\25_PHASE_R2_OBSERVABILITY_VALIDATION\21_r2_validation_regression_test_results.csv"
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['test_id', 'description', 'passed', 'detail'])
        for r in RESULTS:
            w.writerow([r['test_id'], r['description'], r['passed'], str(r['detail'])])
    n_pass = sum(1 for r in RESULTS if r['passed'])
    print(f"\n{n_pass}/{len(RESULTS)} regression tests passed. Written to {out_path}")
    return 0 if n_pass == len(RESULTS) else 1

if __name__ == '__main__':
    sys.exit(main())
