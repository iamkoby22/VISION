#!/usr/bin/env python
"""Compute a path-level diff between two JSON-safe config snapshots."""
from __future__ import annotations

from typing import Any


def _walk(before: Any, after: Any, path: str, rows: list) -> None:
    if type(before) != type(after) and not (
        isinstance(before, (int, float)) and isinstance(after, (int, float))
    ):
        rows.append({"path": path, "before": before, "after": after, "change": "type_or_value"})
        return
    if isinstance(before, dict) and isinstance(after, dict):
        keys = set(before) | set(after)
        for k in sorted(keys, key=str):
            child = f"{path}.{k}" if path else str(k)
            if k not in before:
                rows.append({"path": child, "before": None, "after": after[k], "change": "added"})
            elif k not in after:
                rows.append({"path": child, "before": before[k], "after": None, "change": "removed"})
            else:
                _walk(before[k], after[k], child, rows)
        return
    if isinstance(before, list) and isinstance(after, list):
        if before != after:
            rows.append({"path": path, "before": before, "after": after, "change": "list_replaced"})
        return
    if before != after:
        rows.append({"path": path, "before": before, "after": after, "change": "value"})


def diff_snapshots(before: dict, after: dict) -> dict:
    rows: list = []
    _walk(before, after, "", rows)
    return {
        "n_changes": len(rows),
        "changed": bool(rows),
        "changes": rows,
    }
