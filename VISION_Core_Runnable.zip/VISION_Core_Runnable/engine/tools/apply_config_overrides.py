#!/usr/bin/env python
"""Phase 9D-CO: apply validated config overrides to mastercode02_config_and_rates.

Must be called AFTER `import mastercode02_config_and_rates as config` and BEFORE
importing consumer modules that from-import config names (agents, setup, utils,
logging, renter_to_owner).

Mechanics:
- scalars: setattr(config, key, value)
- dicts: recursive in-place update (preserve object identity for from-imported refs)
- lists: slice assignment target[:] = new_list (preserve list identity)
- IMMIGRATION_CONFIG.age_range: JSON list → tuple
"""
from __future__ import annotations

from typing import Any

from validate_config_overrides import (
    ALLOWED_TOP_LEVEL,
    SAFE_DICT_KEYS,
    SAFE_LIST_KEYS,
    SAFE_SCALAR_KEYS,
    ConfigOverrideValidationError,
    validate_config_overrides,
)


def _coerce_leaf(path: str, key: str, value: Any) -> Any:
    # age_range is a 2-tuple in the model
    if key == "age_range" and isinstance(value, list) and len(value) == 2:
        return (int(value[0]), int(value[1]))
    # INCOME_BANDS entries are lists of (lo, hi) tuples
    if isinstance(value, list) and value and all(
        isinstance(x, list) and len(x) == 2 and all(isinstance(n, (int, float)) for n in x)
        for x in value
    ):
        # Only coerce when nested under INCOME_BANDS
        if "INCOME_BANDS" in path:
            return [(float(a), float(b)) for a, b in value]
    return value


def _inplace_update_dict(target: dict, patch: dict, path: str) -> None:
    for k, v in patch.items():
        child = f"{path}.{k}" if path else k
        if k not in target:
            # Allow adding known nested keys for partial overrides of structured tables
            if isinstance(v, dict):
                target[k] = {}
                _inplace_update_dict(target[k], v, child)
            elif isinstance(v, list):
                target[k] = list(_coerce_leaf(child, k, v) if k == "age_range" else v)
            else:
                target[k] = _coerce_leaf(child, k, v)
            continue
        cur = target[k]
        coerced = _coerce_leaf(child, k, v)
        if isinstance(cur, dict) and isinstance(coerced, dict):
            _inplace_update_dict(cur, coerced, child)
        elif isinstance(cur, list) and isinstance(coerced, list):
            cur[:] = coerced
        else:
            target[k] = coerced


# R3/ECON-003: sector-capacity RATIO from the EXISTING, currently-approved
# EMPLOYERS default in mastercode02_config_and_rates.py (Healthcare System,
# Higher Education, City & County Gov., Retail & Hospitality, Manufacturing,
# Small Businesses/Other = 12750:6750:3750:7500:3000:3750 -- confirmed present,
# unmodified, in the current source this pass). Captured here as a fixed ratio
# constant (not re-read from config_module at correction time, since by then
# the override merge below has already overwritten config_module.EMPLOYERS in
# place) -- restates values already present, unmodified, in current source;
# invents nothing new. See RESSEARCH/24_PHASE_R1_CORRECTION_CONTRACT/
# 07_r1_employer_capacity_contract.md.
DEFAULT_EMPLOYER_CAPACITY_RATIO: dict[str, float] = {
    "EMP01": 12750.0, "EMP02": 6750.0, "EMP03": 3750.0,
    "EMP04": 7500.0, "EMP05": 3000.0, "EMP06": 3750.0,
}


def _fix_flattened_employer_capacities(config_module: Any) -> bool:
    """R3/ECON-003: confirmed defect -- the calibration source
    (calibration/fable_v1_1/fable_capacity_calibration_v1_1.csv) stamps one
    identical city-aggregate capacity value ("observed workplace jobs / 0.95
    operational job capacity", computed once per city) across all 6
    EMPLOYERS.EMP0X.capacity fields, rather than providing 6 independently
    measured sector capacities. Applied verbatim by the generic override merge
    above, this destroys the ~4.25:1 sectoral ratio already approved in
    EMPLOYERS' own default values and instead grants each of the 6 sectors the
    FULL city-aggregate capacity independently (inflating total effective
    capacity 6x versus what the calibration data actually measured).

    Minimum correction: redistribute the SAME aggregate total the override
    currently produces (city-wide total employment capacity is NOT changed --
    only its distribution across sectors) in proportion to the EXISTING,
    currently-approved default ratio. No new value is estimated or downloaded;
    both the total (already applied) and the ratio (already in source) exist
    in currently-approved project data.

    Only fires if EMPLOYERS.EMP0X.capacity values are ALL IDENTICAL after the
    override merge -- the exact, confirmed defect signature. A genuinely
    differentiated override (if one is ever supplied) is left untouched, so
    this is a targeted correction of the known defect, not a blanket
    normalization of any future EMPLOYERS override.

    Returns True if the correction fired (for observability/audit purposes).
    """
    employers = getattr(config_module, "EMPLOYERS", None)
    if not isinstance(employers, dict) or not employers:
        return False
    capacities = {eid: edata.get("capacity") for eid, edata in employers.items()
                  if isinstance(edata, dict)}
    values = list(capacities.values())
    if not values or any(v is None for v in values):
        return False
    if len(set(values)) != 1:
        # Not the flattened-identical-value signature -- a genuinely
        # differentiated capacity set (e.g. the unmodified source default, or
        # a future properly-disaggregated override); do not touch it.
        return False
    if set(capacities.keys()) != set(DEFAULT_EMPLOYER_CAPACITY_RATIO.keys()):
        # Sector-ID set doesn't match the known-approved ratio's keys; do not
        # guess a mapping -- leave untouched (would require an author decision
        # if this ever occurs, not something to silently paper over).
        return False
    flattened_value = values[0]
    total = flattened_value * len(values)
    ratio_sum = sum(DEFAULT_EMPLOYER_CAPACITY_RATIO.values())
    for eid in employers:
        employers[eid]["capacity"] = round(total * (DEFAULT_EMPLOYER_CAPACITY_RATIO[eid] / ratio_sum), 2)
    return True


def apply_config_overrides(config_module: Any, overrides: dict) -> dict:
    """Apply overrides to the live config module. Returns application report."""
    validate_config_overrides(overrides)  # re-validate; raises ConfigOverrideValidationError

    applied: list[str] = []
    for key, value in overrides.items():
        if key not in ALLOWED_TOP_LEVEL:
            raise ConfigOverrideValidationError([f"{key}: not allowed"])
        if not hasattr(config_module, key):
            raise ConfigOverrideValidationError(
                [f"{key}: not present on config module (refusing to invent attributes)"])

        if key in SAFE_SCALAR_KEYS:
            setattr(config_module, key, value)
            applied.append(key)
        elif key in SAFE_DICT_KEYS:
            target = getattr(config_module, key)
            if not isinstance(target, dict) or not isinstance(value, dict):
                raise ConfigOverrideValidationError(
                    [f"{key}: expected dict override against dict target"])
            _inplace_update_dict(target, value, key)
            applied.append(key)
        elif key in SAFE_LIST_KEYS:
            target = getattr(config_module, key)
            if not isinstance(target, list) or not isinstance(value, list):
                raise ConfigOverrideValidationError(
                    [f"{key}: expected list override against list target"])
            target[:] = value
            applied.append(key)
        else:
            raise ConfigOverrideValidationError([f"{key}: unsupported class"])

    econ003_fired = False
    if "EMPLOYERS" in applied:
        econ003_fired = _fix_flattened_employer_capacities(config_module)

    return {
        "applied_keys": applied,
        "n_applied": len(applied),
        "config_overrides_applied": bool(applied),
        "econ003_capacity_redistribution_applied": econ003_fired,
    }
