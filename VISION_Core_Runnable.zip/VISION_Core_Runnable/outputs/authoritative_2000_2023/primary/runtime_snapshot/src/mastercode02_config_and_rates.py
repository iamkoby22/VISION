# mastercode02_config_and_rates.py
import numpy as np

# --- SIMULATION CONTROL ---
SIMULATION_DURATION = 5 # Reverted to original duration

# --- R11: city-specific vital-rate calibration scalars (Fable Calibration v1.1) ---
# These feed g.city_birth_rate_modifier / g.city_death_rate_modifier /
# g.city_marriage_rate_modifier at simulation start (see run_mastercode02.py
# reset_global_state()). Those globals are multiplicative hooks on
# death_prob / final_birth_prob / marriage_prob (mastercode02_agents.py),
# composed explicitly alongside a separate annual_*_modifier (ARIMA trend,
# city-agnostic) and event_*_modifier (scenario-event, default neutral).
# Default 1.0 here reproduces the exact pre-R11 baseline behavior bit-for-bit;
# only a city-scoped config-overrides draft changes them. See
# reports/mr_model_contract_resolution.md for the scientific derivation of any
# non-default value used for a given city run, and
# RESSEARCH/03_FORENSIC_AUDIT/vital_rate_gate1_report.md +
# RESSEARCH/03_FORENSIC_AUDIT/vital_rate_gate2_correction_report.md for the
# defect this naming (city_* vs. annual_*, previously both called arima_*)
# was introduced to prevent from recurring.
BIRTH_RATE_MODIFIER = 1.0
DEATH_RATE_MODIFIER = 1.0
MARRIAGE_RATE_MODIFIER = 1.0

# --- PHASE 3B: FERTILITY CALIBRATION (raw RATES['Fertility Rate'] table preserved) ---
# Median of TARGET_CBR / expected_cbr_per_1000 over Phase 3A years 1–5
# Source: runs/phase3a_fertility_forensics_20260629_184040/diagnostics/phase3a_expected_vs_actual_births.csv
TARGET_CRUDE_BIRTH_RATE_PER_1000 = 12.0
FERTILITY_PROBABILITY_SCALE = 0.16282731901148145

# --- IMMIGRATION CONFIG ---
IMMIGRATION_CONFIG = {
    'base_annual_rate': 0.005,
    'age_range': (22, 35),
    'education_distribution': {
        'high_school_completed': 0.4,
        'college_completed': 0.6
    }
}

# --- R12.4 JOHNSON CITY PEP NET-MIGRATION STRUCTURAL-SENSITIVITY EXTENSION ---
# ISOLATED EXPERIMENT ONLY. This block exists solely in this run's own
# runtime_snapshot/src copy -- the canonical corrected snapshot
# (runs/fable_v1_1/_canonical_corrected/vital_rates_91a5fc5/runtime_snapshot)
# is byte-identical to before this experiment (verified by hash in
# metadata/runtime_source_hashes.csv). Reproduced unmodified from the
# original R12.4 implementation used in
# runs/fable_v1_1/johnson_city_tn/pep_net_migration_2010_2023_seed20230101/
# (commit f4a815b7382c257e4b4dcb69b011bffe9a168fca), layered on top of the
# Gate 2 vital-rate correction -- see
# RESSEARCH/03_FORENSIC_AUDIT/vital_rate_gate2_rerun_plan.md Run 2.
#
# Scientific classification: INDEPENDENT_STRUCTURAL_MIGRATION_SENSITIVITY.
# Every value below is derived from Census PEP Vintage 2020/2023 county
# components of population change, fragment-weighted to Johnson City using
# the Washington/Carter/Sullivan population-share method already used for the
# R12.3 actuarial import -- see outputs/r12_4_pep_irs_jc_weighted_comparison_2010_2023.csv
# for full source lineage. NONE of these values were derived from, tuned
# against, or selected using the Johnson City 2023 population endpoint
# (73,337) or the baseline's own simulated result --
# endpoint_target_used_for_parameter_selection = FALSE for every entry.
JC_MIGRATION_ENDPOINT_TARGET_USED_FOR_PARAMETER_SELECTION = False

# Applied only for calendar years 2010-2023 (simulation_index 10-23, given
# T0=2000). Years 2000-2009 (simulation_index 0-9) get net_migration_extension
# = 0 -- no PEP-based adjustment is applied outside the evidenced 2010-2023
# window. Values are ROUND_HALF_UP integer person counts, exactly as recorded
# in outputs/r12_4_pep_irs_jc_weighted_comparison_2010_2023.csv.
JC_PEP_NET_MIGRATION_BY_YEAR = {
    2010: {'domestic': 248, 'international': 7},
    2011: {'domestic': 410, 'international': 68},
    2012: {'domestic': 842, 'international': 82},
    2013: {'domestic': 422, 'international': 134},
    2014: {'domestic': 244, 'international': 128},
    2015: {'domestic': 333, 'international': 209},
    2016: {'domestic': 1031, 'international': 201},
    2017: {'domestic': 431, 'international': 224},
    2018: {'domestic': 1131, 'international': 273},
    2019: {'domestic': 746, 'international': 101},
    2020: {'domestic': 320, 'international': 2},
    2021: {'domestic': 847, 'international': 45},
    2022: {'domestic': 3026, 'international': 113},
    2023: {'domestic': 2477, 'international': 195},
}

# Independently-observed migrant age-allocation distribution, recovered from
# ACS 2019-2023 5yr Table B07001 (age-by-mobility-category cross-tabulation),
# Johnson City place-level, summed across the "moved from different county
# within same state" + "moved from different state" + "moved from abroad"
# categories (the three unambiguous in-migration categories; "moved within
# same county" is excluded -- ACS cannot distinguish an intra-city move from a
# genuine county-to-city arrival, per reports/r12_4_acs_migration_rate_interpretation.md).
# This is a SINGLE fixed 2019-2023-average age shape applied uniformly to
# every simulated migration year 2010-2023 -- the underlying ACS product does
# not provide a separate age distribution per year, and this simplification is
# disclosed, not hidden. Shares sum to 1.0.
JC_MIGRATION_AGE_ALLOCATION = {
    # (min_age, max_age_inclusive): share_of_migrants
    (1, 4): 0.0409,
    (5, 17): 0.0919,
    (18, 19): 0.1585,
    (20, 24): 0.2163,
    (25, 29): 0.1113,
    (30, 34): 0.0957,
    (35, 39): 0.0424,
    (40, 44): 0.0297,
    (45, 49): 0.0233,
    (50, 54): 0.0392,
    (55, 59): 0.0299,
    (60, 64): 0.0432,
    (65, 69): 0.0236,
    (70, 74): 0.0191,
    (75, 95): 0.0350,
}

# --- FINANCIAL RESOURCE CAPACITIES ---
BANK_SAVINGS_ANNUAL_CAPACITY = 404_000_000
BANK_LOAN_ANNUAL_CAPACITY = 350_000_000
GOVERNMENT_SPENDING_ANNUAL_CAP = 200_000_000

# --- ADDED: GOVERNMENT SUPPORT CONFIG (NEEDS YOUR VALUES) ---
# This dictionary was missing, causing the import error.
# Please fill these placeholder values with your intended logic.
GOV_SUPPORT_CONFIG = {
    'single_parent_support': 1000, # Placeholder: Annual support for single parent households
    'food_stamp_per_child': 500   # Placeholder: Annual food support per child in low-income families
}

# --- ADDED: HOUSING MARKET CONFIGURATION ---
HOUSING_STOCK = {
    'Rental: Low-Income':   {'capacity': 6000, 'base_cost': 9000, 'type': 'Rental'},
    'Rental: Student':      {'capacity': 3000, 'base_cost': 11000, 'type': 'Rental'},
    'Rental: General':      {'capacity': 6575, 'base_cost': 14000, 'type': 'Rental'},
    'For-Sale: Starter':    {'capacity': 8000, 'base_value': 150000, 'type': 'For-Sale'},
    'For-Sale: Mid-Range':  {'capacity': 6000, 'base_value': 250000, 'type': 'For-Sale'},
    'For-Sale: High-End':   {'capacity': 1587, 'base_value': 400000, 'type': 'For-Sale'}
}

TENURE_PROBABILITY_MATRIX = {
    'by_age': {(15, 24): 0.871, (25, 34): 0.625, (35, 44): 0.489, (45, 54): 0.390, (55, 64): 0.312, (65, 999): 0.235},
    'by_income': {(0, 24999): 0.782, (25000, 49999): 0.551, (50000, 74999): 0.336, (75000, 99999): 0.208, (100000, 9999999): 0.135}
}

HOUSING_MARKET_TARGETS = {
    'target_rental_vacancy_rate': 0.043,
    'target_overall_vacancy_rate': 0.055,
    'target_renter_cost_burden': 0.494,
    'target_owner_cost_burden': 0.205,
    'min_down_payment': 10000
}

# --- Phase 6D: initial tenure synthesis (baseline state assignment at t0) ---
INITIAL_TENURE_SYNTHESIS_ENABLED = True
INITIAL_TENURE_SYNTHESIS_MODE = "use_existing_tenure_matrix_with_stock_constraints"
INITIAL_OWNER_ASSIGNMENT_IS_BASELINE_STATE = True

# --- Phase 6E: controlled renter-to-owner transition ---
RENTER_TO_OWNER_ENABLED = True
RENTER_TO_OWNER_ANNUAL_PROBABILITY = 0.03
RENTER_TO_OWNER_MAX_ANNUAL_RATE = 0.02
RENTER_TO_OWNER_REQUIRE_AVAILABLE_FOR_SALE = True
RENTER_TO_OWNER_REQUIRE_LEDGER_RENTAL_CLAIM = True
RENTER_TO_OWNER_MODE = "stock_constrained_affordability_aware"

# --- Original Rates and Data (Restored) ---
RATES = {
    'Death Rates': {
        'Male': {'0-4': 0.0013, '5-9': 0.0001, '10-14': 0.0002, '15-19': 0.0006, '20-24': 0.0010, '25-29': 0.0014, '30-34': 0.0018, '35-39': 0.0023, '40-44': 0.0029, '45-49': 0.0037, '50-54': 0.0053, '55-59': 0.0080, '60-64': 0.0117, '65-69': 0.0164, '70-74': 0.0238, '75-79': 0.0378, '80-84': 0.0632, '85+': 0.15},
        'Female': {'0-4': 0.0011, '5-9': 0.0001, '10-14': 0.0001, '15-19': 0.0004, '20-24': 0.0006, '25-29': 0.0008, '30-34': 0.0010, '35-39': 0.0014, '40-44': 0.0021, '45-49': 0.0028, '50-54': 0.0041, '55-59': 0.0063, '60-64': 0.0097, '65-69': 0.0139, '70-74': 0.0204, '75-79': 0.0335, '80-84': 0.0577, '85+': 0.14}
    },
    'Fertility Rate': {
        'Married': {'15-19': 0.1737, '20-24': 0.4969, '25-29': 0.4969, '30-34': 0.4969, '35-39': 0.3294, '40-44': 0.2294, '45-49': 0.0294},
        'Unmarried': {'15-19': 0.180, '20-24': 0.290, '25-29': 0.270, '30-34': 0.130, '35-39': 0.0510, '40-44': 0.0001, '45-49': 0.0}
    },
    'Employment': {
        'Employed': {'15-19': 0.2, '20-24': 0.6, '25-29': 0.75, '30-34': 0.8, '35-39': 0.8, '40-44': 0.8, '45-49': 0.78, '50-54': 0.75, '55-59': 0.7, '60-64': 0.6, '65-69': 0.2, '70-74': 0.1, '75-79': 0.05, '80-84': 0.01, '85+': 0.0}
    }
}
HISTORICAL_MACRO_DATA = {
    'Year': list(range(2000, 2024)),
    'Mortality Rate': [8.03, 8.09, 8.16, 8.08, 7.88, 7.99, 7.76, 7.6, 8.12, 7.89, 7.94, 8.07, 8.4, 8.22, 8.24, 8.44, 8.49, 8.64, 8.68, 8.7, 10.4, 10.5, 9.7, 9.2],
    'Birth Rate': [14.4, 14.1, 13.9, 14.1, 14, 14, 14.2, 14.3, 13.9, 13.5, 13, 12.7, 12.6, 12.4, 12.5, 12.4, 12.2, 11.8, 11.6, 11.4, 10.9, 11, 11.1, 11.6],
    'Employment Rate': [96.1, 95.3, 94.2, 94, 94.5, 94.9, 95.4, 95.4, 94.2, 90.7, 90.4, 91.1, 92.2, 92.6, 93.8, 94.9, 95.1, 95.6, 96.1, 96.3, 89.2, 94.6, 96.4, 96.4]
}
HISTORICAL_ECONOMIC_DATA = {
    'Year': list(range(2000, 2024)),
    'Top Tax Rate': [39.6, 39.1, 38.6, 35.0, 35.0, 35.0, 35.0, 35.0, 35.0, 35.0, 35.0, 35.0, 35.0, 39.6, 39.6, 39.6, 39.6, 39.6, 37.0, 37.0, 37.0, 37.0, 37.0, 37.0],
    'Salary Inflation': [3.7, 4.2, 3.0, 2.4, 2.4, 2.9, 3.9, 3.9, 3.4, 2.2, 1.9, 2.1, 1.9, 2.0, 2.1, 2.3, 2.6, 2.7, 2.9, 3.1, 4.6, 4.5, 4.9, 4.3],
    'Cost Inflation (CPI)': [3.4, 2.8, 1.6, 2.3, 2.7, 3.4, 3.2, 2.8, 3.8, -0.4, 1.6, 3.2, 2.1, 1.5, 1.6, 0.1, 1.3, 2.1, 2.4, 1.8, 1.2, 4.7, 8.0, 4.1],
    '30-Yr Mortgage': [8.05, 6.97, 6.54, 5.83, 5.84, 5.87, 6.41, 6.34, 6.03, 5.04, 4.69, 4.45, 3.66, 3.98, 4.17, 3.85, 3.65, 3.99, 4.54, 3.94, 3.11, 2.96, 5.34, 6.81]
}
ROAD_NETWORK_CAPACITY = {'interstate': 62000, 'highway': 38750, 'arterial': np.mean([34100, 31000, 27900])}
EMPLOYERS={'EMP01':{'name':'Healthcare System','capacity':12750}, 'EMP02':{'name':'Higher Education','capacity':6750}, 'EMP03':{'name':'City & County Gov.','capacity':3750}, 'EMP04':{'name':'Retail & Hospitality','capacity':7500}, 'EMP05':{'name':'Manufacturing','capacity':3000}, 'EMP06':{'name':'Small Businesses/Other','capacity':3750}}
EMPLOYER_PROBS=[0.35,0.18,0.1,0.2,0.08,0.09]
EDUCATION_CAPACITIES={'Nursery/Preschool':2500, 'Elementary (K-5)':5000, 'Middle (6-8)':2200, 'High School (9-12)':3200, 'University':14700, 'Community College':5500, 'masters_program':1500, 'phd_program':500}

# --- PHASE 4B: POST-HS ROUTE EXTENSION (provisional calibration; capacities unchanged) ---
# Splits prior 60% University branch into University + Community College; preserves 40% remain.
POST_HS_ROUTE_PROBS = {
    "University": 0.45,
    "Community College": 0.15,
    "Remain high_school_completed": 0.40,
}
_POST_HS_SUM = sum(POST_HS_ROUTE_PROBS.values())
if abs(_POST_HS_SUM - 1.0) > 1e-9:
    raise ValueError(f"POST_HS_ROUTE_PROBS must sum to 1.0, got {_POST_HS_SUM}")

# --- PHASE 4B: LOW-PROBABILITY DROPOUT REENTRY (provisional; age-sensitive) ---
EDUCATION_REENTRY_PROBS = {
    "high_school_dropout": {
        "base_annual_probability": 0.035,
        "target_state": "High School (9-12)",
        "notes": "Low-probability return to secondary school or equivalent pathway using existing state.",
    },
    "college_dropout": {
        "base_annual_probability": 0.030,
        "target_state": "previous_tertiary_or_fallback",
        "notes": "Low-probability college stopout reentry; return to prior tertiary route if known.",
    },
    "masters_dropout": {
        "base_annual_probability": 0.015,
        "target_state": "masters_program",
        "notes": "Very low-probability graduate stopout reentry.",
    },
}
EDUCATION_REENTRY_AGE_MULTIPLIERS = [
    {"min_age": 16, "max_age": 24, "multiplier": 1.00},
    {"min_age": 25, "max_age": 34, "multiplier": 0.45},
    {"min_age": 35, "max_age": 49, "multiplier": 0.20},
    {"min_age": 50, "max_age": 64, "multiplier": 0.05},
    {"min_age": 65, "max_age": 200, "multiplier": 0.00},
]
# Fallback when college_dropout has no last_tertiary_program
COLLEGE_REENTRY_FALLBACK_PROBS = {"Community College": 0.50, "University": 0.50}

SKILL_LEVELS=['Entry-Level / Low-Skill','Skilled Labor / Clerical','Mid-Level Professional','Senior Professional / Mgmt.']
INCOME_BANDS={'Healthcare System':[(25000,38000),(38000,55000),(55000,85000),(90000,250000)],'Higher Education':[(24000,35000),(35000,50000),(50000,75000),(80000,200000)],'City & County Gov.':[(25000,36000),(36000,52000),(52000,80000),(85000,160000)],'Retail & Hospitality':[(22000,32000),(32000,45000),(45000,70000),(70000,140000)],'Manufacturing':[(28000,40000),(40000,60000),(58000,90000),(90000,180000)],'Small Businesses/Other':[(24000,35000),(35000,58000),(50000,80000),(80000,200000)]}
PUBLIC_TRANSIT_CONFIG={'initial_buses':25,'initial_population':73440,'bus_capacity':33,'trips_per_bus_per_day':10}
# --- PHASE 5B: BUS CAPACITY UNIT RECONCILIATION (provisional; NOT fleet calibration) ---
# Daily capacity (fleet×seats×trips/day) is preserved; annual capacity is used when comparing
# to annual person-year bus demand in CommuteManager.
BUS_OPERATING_DAYS_PER_YEAR = 250
BUS_CAPACITY_UTILIZATION_FACTOR = 1.0
BUS_CAPACITY_UNIT_MODE = "annualized_from_daily"
CAR_AFFORDABILITY={'min_cost':6000,'min_household_income_threshold':30000}
COST_GRID = {
    "Food": {"1_adult": [3182, 4679, 7009, 9324], "2_adults_1_working": [5834, 7250, 9326, 11377], "2_adults_2_working": [5834, 7250, 9326, 11377]},
    "Child Care": {"1_adult": [0, 5711, 11422, 13658], "2_adults_1_working": [0, 0, 0, 0], "2_adults_2_working": [0, 5711, 11422, 13658]},
    "Medical": {"1_adult": [2406, 7000, 7054, 7112], "2_adults_1_working": [5179, 7721, 7925, 8150], "2_adults_2_working": [5179, 7721, 7925, 8150]},
    "Transportation": {"1_adult": [7054, 8163, 10283, 11832], "2_adults_1_working": [8163, 10283, 11832, 13126], "2_adults_2_working": [8163, 10283, 11832, 13126]},
    "Civic": {"1_adult": [1942, 3418, 3773, 4838], "2_adults_1_working": [3418, 3773, 4838, 5367], "2_adults_2_working": [3418, 3773, 4838, 5367]},
    "Internet & Mobile": {"1_adult": [1168, 1168, 1168, 1168], "2_adults_1_working": [1604, 1604, 1604, 1604], "2_adults_2_working": [1604, 1604, 1604, 1604]},
    "Other": {"1_adult": [2828, 5432, 5690, 6840], "2_adults_1_working": [5432, 6025, 6840, 7588], "2_adults_2_working": [5432, 6025, 6840, 7588]}
}
COMMUTATION_PURPOSE_RATES={'0-4':[0.0,0.0,0.1,0.2,0.1,0.6,0.0],'5-17':[0.0,0.6,0.1,0.15,0.05,0.1,0.0],'18-24':[0.4,0.3,0.1,0.1,0.05,0.05,0.0],'25-54':[0.6,0.05,0.15,0.05,0.05,0.1,0.0],'55-64':[0.4,0.0,0.2,0.2,0.1,0.1,0.0],'65+':[0.05,0.0,0.25,0.3,0.3,0.05,0.05]}
COMMUTATION_PURPOSES=["Work","School","Shopping","Leisure","Healthcare","Escort","Other"]