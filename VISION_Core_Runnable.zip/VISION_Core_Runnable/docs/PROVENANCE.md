# Provenance — VISION Core package

## Engine

Copied verbatim from `remediation\r6_working_copy\post_r6_1` in the source repository. Not moved, not modified.
Entry point: `engine/tools/run_mastercode02.py`.
SHA-256 for every shipped source file: `engine/ENGINE_SOURCE_SHA256_MANIFEST.json`.

## Authoritative historical output

`outputs/authoritative_2000_2023/primary/` is copied verbatim from

    runs\fable_v1_1\johnson_city_tn\corrected_vital_rates_91a5fc5_pep_seed20230101

This is the run the manuscript treats as the primary Core comparator. It ends 2023 at 69,453
persons and 35,758 active households, on the governed T0 (55,469 persons / 23,720 households),
seed 20230101, duration 24.

`outputs/authoritative_2000_2023/alternate_comparator/` is copied verbatim from

    runs\vision_core_corrected_r7\johnson_city_pep

This is the second Core PEP run at the same T0 and seed, registered as B_JC_PEP. It ends 2023 at
68,109 persons and 34,110 active households. Both are supplied because the manuscript reports
both: the choice changes the magnitudes but no comparison direction.

## What was NOT done

No authoritative run was re-executed. No engine source was edited. The only simulation executed
while building this package was the ~100-person engineering smoke test.
