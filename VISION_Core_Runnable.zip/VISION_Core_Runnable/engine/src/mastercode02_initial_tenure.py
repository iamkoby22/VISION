"""Phase 6D initial owner/renter tenure synthesis — uses existing matrix + Phase 6B ledger."""
from __future__ import annotations

import random

import mastercode02_globals as g
from mastercode02_config_and_rates import (
    HOUSING_STOCK,
    TENURE_PROBABILITY_MATRIX,
    INITIAL_OWNER_ASSIGNMENT_IS_BASELINE_STATE,
)
from mastercode02_housing_ledger import (
    assign_housing_to_household,
    mark_household_insecure,
    get_housing_available_count,
)


PHASE6D_INIT_EVENTS: list = []


def _household_income(household_data: dict) -> float:
    members = household_data.get("members", []) or []
    return float(sum(getattr(p, "annual_income", 0) or 0 for p in members))


def determine_desired_tenure(household_data: dict, *, baseline_state: bool = True) -> str:
    """Reuse TENURE_PROBABILITY_MATRIX; skip down-payment gate at init when baseline_state."""
    members = household_data.get("members", []) or []
    if not members:
        return "Insecure"
    head_age = max(p.age for p in members)
    household_income = _household_income(household_data)
    prob_from_age = 0.5
    for age_range, prob in TENURE_PROBABILITY_MATRIX["by_age"].items():
        if age_range[0] <= head_age <= age_range[1]:
            prob_from_age = prob
            break
    prob_from_income = 0.5
    for income_range, prob in TENURE_PROBABILITY_MATRIX["by_income"].items():
        if income_range[0] <= household_income <= income_range[1]:
            prob_from_income = prob
            break
    base_renter_probability = (prob_from_age * 0.6) + (prob_from_income * 0.4)
    adjusted = base_renter_probability / max(g.arima_owner_preference_modifier, 1e-9)
    final_renter_probability = max(0.0, min(1.0, adjusted))
    if random.random() < final_renter_probability:
        return "Renter"
    if baseline_state and INITIAL_OWNER_ASSIGNMENT_IS_BASELINE_STATE:
        return "Owner"
    return "Renter"


def select_unit_for_tenure(tenure: str) -> tuple[bool, str | None]:
    target_type = "Rental" if tenure == "Renter" else "For-Sale"
    available = [
        name for name, stock in HOUSING_STOCK.items()
        if stock["type"] == target_type and get_housing_available_count(name) > 0
    ]
    if available:
        return True, random.choice(available)
    return False, None


def _record_event(**kwargs) -> None:
    PHASE6D_INIT_EVENTS.append(dict(kwargs))


def place_initial_household(hh_id, hh_data: dict, year: int = 0) -> str:
    """Assign initial housing via ledger. Returns assigned tenure or Insecure."""
    members = hh_data.get("members", []) or []
    n_mem = len(members)
    if n_mem == 0:
        mark_household_insecure(hh_id, year, reason="initializer_empty_household")
        _record_event(
            year=year, household_id=hh_id, household_size=0,
            desired_tenure="Insecure", assigned_tenure="Insecure",
            housing_unit_name="", housing_category="",
            assignment_success=True, failure_reason="",
            used_existing_tenure_matrix=False,
            baseline_owner_assignment=False,
            notes="empty household; no ledger claim",
        )
        return "Insecure"

    desired = determine_desired_tenure(hh_data, baseline_state=True)
    baseline_owner = desired == "Owner"

    for attempt_tenure in (desired, "Renter" if desired == "Owner" else "Owner"):
        placed, unit = select_unit_for_tenure(attempt_tenure)
        if not placed:
            continue
        ok = assign_housing_to_household(
            hh_id, unit, attempt_tenure, year,
            reason="initializer_tenure_synthesis",
        )
        if ok:
            cat = HOUSING_STOCK[unit]["type"]
            _record_event(
                year=year, household_id=hh_id, household_size=n_mem,
                desired_tenure=desired, assigned_tenure=attempt_tenure,
                housing_unit_name=unit, housing_category=cat,
                assignment_success=True, failure_reason="",
                used_existing_tenure_matrix=True,
                baseline_owner_assignment=(attempt_tenure == "Owner" and baseline_owner),
                notes=(
                    "fallback_used" if attempt_tenure != desired else "primary_tenure_match"
                ),
            )
            return attempt_tenure

    mark_household_insecure(hh_id, year, reason="initializer_no_stock")
    _record_event(
        year=year, household_id=hh_id, household_size=n_mem,
        desired_tenure=desired, assigned_tenure="Insecure",
        housing_unit_name="", housing_category="",
        assignment_success=False, failure_reason="no_stock_for_desired_or_fallback",
        used_existing_tenure_matrix=True,
        baseline_owner_assignment=False,
        notes="stock constrained",
    )
    return "Insecure"


def synthesize_initial_housing(year: int = 0) -> None:
    """Run tenure synthesis for all households at initialization."""
    PHASE6D_INIT_EVENTS.clear()
    for hh_id, hh_data in g.HOUSEHOLDS.items():
        place_initial_household(hh_id, hh_data, year)
