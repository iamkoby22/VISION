<#
Gate 3 Run 2 -- detached Windows launcher for the Johnson City corrected
vital-rate PEP net-migration scenario (seed 20230101, source commit
91a5fc50b87c3a929615abb06b3431fbd39c959f + additive PEP extension layered
into this run's own runtime_snapshot copy only).
#>

$ErrorActionPreference = "Stop"

$RunDir = "C:\Users\LORD OF LORDS\Desktop\paper_mastercode_fable_simulation_v1_1\runs\fable_v1_1\johnson_city_tn\corrected_vital_rates_91a5fc5_pep_seed20230101"
$RuntimeSrc = Join-Path $RunDir "runtime_snapshot\src"
$RuntimeTool = Join-Path $RunDir "runtime_snapshot\tools\run_mastercode02.py"
$LogsDir = Join-Path $RunDir "logs"
$OutputsDir = Join-Path $RunDir "outputs"
$DiagDir = Join-Path $RunDir "diagnostics"
$PidFile = Join-Path $LogsDir "run2_jc_pep.pid"
$StdoutLog = Join-Path $LogsDir "run2_jc_pep.stdout.log"
$StderrLog = Join-Path $LogsDir "run2_jc_pep.stderr.log"
$T0Json = Join-Path $RunDir "inputs\t0_input.json"
$OverridesJson = Join-Path $RunDir "inputs\config_overrides_input.json"
$PythonExe = "C:\Users\LORD OF LORDS\anaconda3\python.exe"

New-Item -ItemType Directory -Force -Path $LogsDir, $OutputsDir, $DiagDir | Out-Null

$dup = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
    $_.Name -eq "python.exe" -and $_.CommandLine -match "corrected_vital_rates_91a5fc5_pep_seed20230101"
}
if ($dup) {
    Write-Host "RUN2_ALREADY_ACTIVE (found via process scan, PID=$($dup.ProcessId))" -ForegroundColor Yellow
    exit 1
}

$ArgList = @(
    "`"$RuntimeTool`"",
    "--seed", "20230101",
    "--duration", "24",
    "--output-dir", "`"$OutputsDir`"",
    "--diagnostics-dir", "`"$DiagDir`"",
    "--run-label", "corrected_vital_rates_91a5fc5_pep_seed20230101",
    "--source-dir", "`"$RuntimeSrc`"",
    "--config-overrides-json", "`"$OverridesJson`"",
    "--t0-json", "`"$T0Json`"",
    "--checkpoint-every-years", "1"
) -join " "

Write-Host "Launching Johnson City corrected vital-rate PEP scenario (detached)..." -ForegroundColor Cyan

$proc = Start-Process -FilePath $PythonExe `
    -ArgumentList $ArgList `
    -RedirectStandardOutput $StdoutLog `
    -RedirectStandardError $StderrLog `
    -WindowStyle Hidden `
    -PassThru

Start-Sleep -Seconds 2

if (-not $proc -or $proc.HasExited) {
    Write-Host "RUN2_LAUNCH_FAILED" -ForegroundColor Red
    exit 1
}

$proc.Id | Out-File -FilePath $PidFile -Encoding ascii -NoNewline

Write-Host "RUN2_ACTIVE" -ForegroundColor Green
Write-Host "PID: $($proc.Id)"
Write-Host "START_TIME: $($proc.StartTime)"
Write-Host "RUN_DIRECTORY: $RunDir"
