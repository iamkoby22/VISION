# Output dictionary

## The household counting rule — read this first

`Households` in some historical Core and VIG outputs means **total household records**, that is
active **plus archived**. `Active_Household_Count` is the canonical **active stock** where it is
implemented. These are different quantities and must never be conflated or compared across
models without checking which basis each side uses.

| File | What it is |
|---|---|
| `*_annual_summary.csv` | one row per simulated year: population, household counts on both bases, births, deaths, employment rate, average income, tenure, vacancy, cost burden, vehicles, accidents |
| `*_population_datasheet.csv` | person-level snapshot rows: age, sex, household id, marital status, education level, employment status, employer, annual income |
| `*_household_datasheet.csv` | household-level snapshot rows: type, members, tenure, housing unit, insecurity flags, income, savings, loan balance |
| `*_r2_age_sex_annual.csv` | age x sex counts by year |
| `*_r2_birth_ledger.csv` | one row per birth: newborn id, year, sex, maternal id and age, household |
| `*_r2_death_ledger.csv` | one row per death: person id, year, age at death, sex, household, employment and marital state at death |
| `*_r2_employment_annual.csv` | 16+ population, employed, unemployed, labour force, and counts by employment state |
| `*_summary_marriages.csv` | one row per marriage: both person ids, both former households, ages, new household id, year |
| `*_summary_rates.csv` | the vital-rate modifiers actually applied each year |
| `*_summary_resources.csv` | per-resource capacity, use, utilisation, refusals |
| `*_summary_trips.csv`, `*_summary_vehicle_events.csv` | transport activity |
| `*_scores_summary.csv` | economic and transport indices |

## Diagnostics

| File | What it is |
|---|---|
| `run_status.json` | status, seed, duration, T0 totals, config and T0 hashes, CLI command |
| `_checkpoint/` | non-destructive partial CSV checkpoints written every N simulated years |
| `node_call_counts.json` | VIG only: per-node invocation counts for the run |
| `*_run_completion_manifest.json` | VIG only: `SIMULATION_STATUS` and completion detail |
| `*_resource_log.csv` | VIG only: per-resource runtime log |
| `_bounded_stream/` | per-year internal consistency chunks. Very large. See the exclusion note below. |

## Provenance (written by the wrapper)

| File | What it is |
|---|---|
| `run_request.json` | the full request: years, seed, scenario, paths, return code, elapsed time |
| `environment.json` | Python version, platform, package versions, git commit |
| `source_manifest.json` | SHA-256 of every engine source file shipped in this package |
| `path_remapping.json` | VIG only: every absolute path rebound to this package |
| `preflight.json` | VIG only: the configuration invariant checks |

## A note on excluded diagnostics

`_bounded_stream/` holds per-year consistency-chunk CSVs: 27.3 GB for the VIG production run and
about 5.3 GB per sensitivity seed. They are internal consistency diagnostics, not primary
scientific outputs. They are **not** shipped in this package. Every excluded file is listed with
its size and SHA-256 in `EXCLUDED_ARTIFACT_INVENTORY.csv`, together with its path in the source
repository, so the omission is auditable and reversible.
