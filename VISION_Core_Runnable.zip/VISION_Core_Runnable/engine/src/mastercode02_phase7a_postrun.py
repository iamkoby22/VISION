"""Phase 7A post-run analysis — builds classification/reconciliation CSVs, plots, report.

Diagnostic/logging-only phase. Genuine insecure = non-empty households with no active ledger
claim; empty shells (0 members, no claim) are reported separately. Compares against Phase 6E
outputs and Phase 6F diagnostics.
"""
from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from mastercode02_phase7a_diagnostics import PHASE7A_LOG
from mastercode02_config_and_rates import HOUSING_STOCK

TOTAL_CAP = sum(int(v["capacity"]) for v in HOUSING_STOCK.values())

CLASS_ORDER = [
    "housed_nonempty", "genuine_insecure_nonempty", "empty_shell",
    "inconsistent_housed_empty", "inconsistent_insecure_with_claim", "unknown",
]


def _write(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def _safe_read(path: Path) -> pd.DataFrame:
    return pd.read_csv(path) if path.exists() else pd.DataFrame()


def run_post_analysis(run_dir: Path, phase6e_dir: Path, phase6f_dir: Path) -> bool:
    diag = run_dir / "diagnostics"
    plots = diag / "phase7a_plots"
    diag.mkdir(parents=True, exist_ok=True)
    plots.mkdir(parents=True, exist_ok=True)

    hh = pd.DataFrame(PHASE7A_LOG["households"])
    counts = pd.DataFrame(PHASE7A_LOG["status_counts"])
    stock = pd.DataFrame(PHASE7A_LOG["stock"])
    years = sorted(hh["year"].unique().tolist()) if not hh.empty else []
    stock_by_year = {int(r["year"]): r for _, r in stock.iterrows()} if not stock.empty else {}

    def stock_val(y, key, default=np.nan):
        r = stock_by_year.get(int(y))
        return float(r[key]) if (r is not None and key in r) else default

    # =========================================================================
    # F1. Household status classification by year
    # =========================================================================
    cls_rows = []
    for y in years:
        sub = hh[hh["year"] == y]
        total = len(sub)
        nonempty = int((~sub["is_empty"]).sum())
        vc = sub["classification"].value_counts().to_dict()
        for cls in CLASS_ORDER:
            c = int(vc.get(cls, 0))
            if c == 0 and cls in ("inconsistent_housed_empty", "inconsistent_insecure_with_claim", "unknown"):
                # still emit a zero row for the key invariants (transparency)
                pass
            cls_rows.append({
                "year": y,
                "household_status_classification": cls,
                "household_count": c,
                "share_of_all_households": round(c / total, 6) if total else 0.0,
                "share_of_nonempty_households": round(c / nonempty, 6) if nonempty else 0.0,
                "notes": "",
            })
    _write(pd.DataFrame(cls_rows), diag / "phase7a_household_status_classification_by_year.csv")

    # =========================================================================
    # F2. Insecure metric reconciliation
    # =========================================================================
    recon_rows = []
    for y in years:
        sub = hh[hh["year"] == y]
        total = len(sub)
        nonempty = int((~sub["is_empty"]).sum())
        genuine = int((sub["classification"] == "genuine_insecure_nonempty").sum())
        empty_shell = int((sub["classification"] == "empty_shell").sum())
        empty_with_claim = int((sub["classification"] == "inconsistent_housed_empty").sum())
        housed = int((sub["classification"] == "housed_nonempty").sum())
        old_basis = int(sub["old_insecure_label"].sum())
        recon_rows.append({
            "year": y,
            "old_basis_insecure_count": old_basis,
            "genuine_insecure_nonempty_count": genuine,
            "empty_shell_count": empty_shell,
            "empty_with_claim_count": empty_with_claim,
            "total_households": total,
            "nonempty_households": nonempty,
            "housed_nonempty_households": housed,
            "difference_old_minus_genuine": old_basis - genuine,
            "explanation": "old_basis = genuine + empty_shells (both label Insecure, no claim)"
                           if (old_basis == genuine + empty_shell) else "see components",
            "notes": "",
        })
    recon_df = pd.DataFrame(recon_rows)
    _write(recon_df, diag / "phase7a_insecure_metric_reconciliation.csv")

    # =========================================================================
    # F3. Empty household shell audit (per household per year)
    # =========================================================================
    empty_audit = hh[hh["classification"] == "empty_shell"].copy()
    if not empty_audit.empty:
        empty_audit = empty_audit[[
            "year", "household_id", "member_count", "is_empty", "old_insecure_label",
            "has_active_housing_ledger_claim", "active_housing_unit_name", "classification",
        ]].copy()
        empty_audit["created_year_if_available"] = ""
        empty_audit["became_empty_year_if_available"] = _became_empty_year(hh)
        empty_audit["notes"] = "empty shell: 0 members, no active claim"
    _write(empty_audit, diag / "phase7a_empty_household_shell_audit.csv")

    # =========================================================================
    # F4. Genuine insecure household audit (per household per year)
    # =========================================================================
    gen_audit = hh[hh["classification"] == "genuine_insecure_nonempty"].copy()
    if not gen_audit.empty:
        gen_audit = pd.DataFrame({
            "year": gen_audit["year"],
            "household_id": gen_audit["household_id"],
            "member_count": gen_audit["member_count"],
            "has_active_housing_ledger_claim": gen_audit["has_active_housing_ledger_claim"],
            "housing_unit_name": gen_audit["active_housing_unit_name"],
            "income_if_available": gen_audit["income"],
            "household_size": gen_audit["member_count"],
            "formation_reason_if_available": gen_audit["formation_reason"],
            "classification": gen_audit["classification"],
            "notes": "",
        })
    _write(gen_audit, diag / "phase7a_genuine_insecure_household_audit.csv")

    # =========================================================================
    # F5. Housing summary before/after metric
    # =========================================================================
    ba_rows = []
    for y in years:
        r = recon_df[recon_df["year"] == y].iloc[0]
        ba_rows.append({
            "year": y,
            "rental_vacancy": stock_val(y, "rental_vacancy_rate"),
            "for_sale_vacancy": stock_val(y, "for_sale_vacancy_rate"),
            "overall_vacancy": stock_val(y, "overall_vacancy_rate"),
            "renter_households": int(stock_val(y, "rental_claimed", 0)),
            "owner_households": int(stock_val(y, "for_sale_claimed", 0)),
            "old_basis_insecure": int(r["old_basis_insecure_count"]),
            "genuine_insecure": int(r["genuine_insecure_nonempty_count"]),
            "empty_shells": int(r["empty_shell_count"]),
            "total_households": int(r["total_households"]),
            "nonempty_households": int(r["nonempty_households"]),
            "notes": "renter/owner = ledger active claims (occupancy unchanged vs 6E)",
        })
    _write(pd.DataFrame(ba_rows), diag / "phase7a_housing_summary_before_after_metric.csv")

    # =========================================================================
    # G1. Phase 6E comparison  /  G2. Phase 6F metric comparison
    # =========================================================================
    cmp6e = _compare_phase6e(run_dir, phase6e_dir, recon_df, diag)
    cmp6f = _compare_phase6f(recon_df, phase6f_dir, diag)

    # =========================================================================
    # PASS checks
    # =========================================================================
    old_matches = True
    occupancy_unchanged = True
    demography_unchanged = True
    if not cmp6e.empty:
        crit = cmp6e[cmp6e["metric"].isin([
            "population", "births", "deaths", "employment_rate", "renter_households",
            "owner_households", "rental_vacancy", "for_sale_vacancy", "overall_vacancy",
            "old_basis_insecure", "avg_income", "total_cars",
        ])]
        occupancy_unchanged = bool(crit[crit["metric"].isin(
            ["renter_households", "owner_households", "rental_vacancy",
             "for_sale_vacancy", "overall_vacancy"])]["match"].all())
        demography_unchanged = bool(crit[crit["metric"].isin(
            ["population", "births", "deaths", "employment_rate", "avg_income", "total_cars"])]["match"].all())
        old_matches = bool(crit[crit["metric"] == "old_basis_insecure"]["match"].all())

    empty_no_claim = bool((recon_df["empty_with_claim_count"] == 0).all()) if not recon_df.empty else True
    genuine_lt_old = bool((recon_df["genuine_insecure_nonempty_count"] <=
                           recon_df["old_basis_insecure_count"]).all()) if not recon_df.empty else True

    passed = bool(old_matches and occupancy_unchanged and demography_unchanged and
                  empty_no_claim and genuine_lt_old)

    # =========================================================================
    # Red flags + recommendations
    # =========================================================================
    final_genuine = int(recon_df.iloc[-1]["genuine_insecure_nonempty_count"]) if not recon_df.empty else 0
    final_empty = int(recon_df.iloc[-1]["empty_shell_count"]) if not recon_df.empty else 0
    flags = pd.DataFrame([
        {"severity": "HIGH", "subsystem": "housing_supply",
         "finding": f"Genuine housing scarcity persists after metric correction (final genuine insecure={final_genuine})",
         "evidence": "phase7a_insecure_metric_reconciliation.csv",
         "consequence": "Real unmet housing demand from fixed stock + net formation",
         "recommended_fix_phase": "future_supply_or_scenarios", "should_fix_now_yes_no": "no"},
        {"severity": "MEDIUM", "subsystem": "global_state_hygiene",
         "finding": f"Empty household shells still accumulate in g.HOUSEHOLDS (final empty shells={final_empty})",
         "evidence": "phase7a_empty_household_shell_audit.csv",
         "consequence": "Households dict grows unbounded; harmless but untidy (now excluded from insecure metric)",
         "recommended_fix_phase": "phase7b_optional_pruning", "should_fix_now_yes_no": "no"},
        {"severity": "LOW", "subsystem": "ledger_consistency",
         "finding": "No empty households hold claims; no insecure-with-claim inconsistencies",
         "evidence": "phase7a_household_status_classification_by_year.csv",
         "consequence": "Classification is internally consistent",
         "recommended_fix_phase": "none", "should_fix_now_yes_no": "no"},
    ])
    _write(flags, diag / "phase7a_red_flags.csv")

    recs = pd.DataFrame([
        {"priority": 1,
         "recommendation": "Phase 7A complete: insecure metric now genuine; keep old-basis for audit",
         "type": "done", "expected_model_impact": "reporting only", "risk_level": "low",
         "files_likely_to_change": "n/a", "should_be_next_phase_yes_no": "no", "notes": ""},
        {"priority": 2,
         "recommendation": "Optional Phase 7B: safe pruning/archival of empty household shells (proven claim-free)",
         "type": "global_state_hygiene", "expected_model_impact": "smaller Households count; no occupancy change",
         "risk_level": "medium", "files_likely_to_change": "globals; agents; logging",
         "should_be_next_phase_yes_no": "maybe", "notes": "Empty shells hold no claims (safe), but changes Households column"},
        {"priority": 3,
         "recommendation": "Defer genuine-scarcity remedies (housing supply / formation calibration) to scoped phases",
         "type": "defer", "expected_model_impact": "reduces genuine insecure", "risk_level": "high",
         "files_likely_to_change": "HOUSING_STOCK; managers", "should_be_next_phase_yes_no": "no",
         "notes": "Out of current freeze"},
    ])
    _write(recs, diag / "phase7a_upgrade_recommendations.csv")

    # =========================================================================
    # Plots + report + change log
    # =========================================================================
    _make_plots(plots, recon_df, pd.DataFrame(cls_rows), stock, cmp6e, flags)
    _write_report(diag, recon_df, cmp6e, cmp6f, occupancy_unchanged, demography_unchanged,
                  old_matches, empty_no_claim, final_genuine, final_empty, passed)
    _write_change_log(diag, occupancy_unchanged, demography_unchanged)
    return passed


def _became_empty_year(hh: pd.DataFrame):
    """For each empty_shell row, the first year that household appears empty."""
    first_empty = {}
    for _, r in hh[hh["is_empty"]].sort_values("year").iterrows():
        hid = int(r["household_id"])
        if hid not in first_empty:
            first_empty[hid] = int(r["year"])
    sub = hh[hh["classification"] == "empty_shell"]
    return [first_empty.get(int(r["household_id"]), "") for _, r in sub.iterrows()]


def _compare_phase6e(run_dir: Path, phase6e_dir: Path, recon_df: pd.DataFrame, diag: Path) -> pd.DataFrame:
    a7 = _safe_read(run_dir / "outputs" / "mastercode02_output_phase7a_seed123_annual_summary.csv")
    a6 = _safe_read(phase6e_dir / "outputs" / "mastercode02_output_phase6e_seed123_annual_summary.csv")
    sc7 = _safe_read(run_dir / "outputs" / "mastercode02_output_phase7a_seed123_scores_summary.csv")
    sc6 = _safe_read(phase6e_dir / "outputs" / "mastercode02_output_phase6e_seed123_scores_summary.csv")
    r7 = _safe_read(run_dir / "outputs" / "mastercode02_output_phase7a_seed123_summary_resources.csv")
    r6 = _safe_read(phase6e_dir / "outputs" / "mastercode02_output_phase6e_seed123_summary_resources.csv")
    p7 = _safe_read(run_dir / "outputs" / "mastercode02_output_phase7a_seed123_population_datasheet.csv")
    p6 = _safe_read(phase6e_dir / "outputs" / "mastercode02_output_phase6e_seed123_population_datasheet.csv")
    stk6 = _safe_read(phase6e_dir / "diagnostics" / "phase6e_housing_stock_vacancy_audit.csv")
    stk7 = pd.DataFrame(PHASE7A_LOG["stock"])

    rows = []
    if a7.empty or a6.empty:
        return pd.DataFrame(rows)

    def res_val(df, year, name, col="waiting_or_refused"):
        if df.empty:
            return np.nan
        sub = df[(df["year"] == year) & (df["name"] == name)]
        return float(sub.iloc[0][col]) if not sub.empty else np.nan

    def fs_vac(df, year, col="for_sale_vacancy_rate"):
        if df.empty or year not in set(df["year"]):
            return np.nan
        return float(df[df["year"] == year].iloc[0][col])

    for year in sorted(a7["Year"].unique()):
        x7 = a7[a7["Year"] == year].iloc[0]
        x6 = a6[a6["Year"] == year].iloc[0]
        pop7, pop6 = float(x7["Population"]), float(x6["Population"])
        gen = int(recon_df[recon_df["year"] == year]["genuine_insecure_nonempty_count"].iloc[0]) if not recon_df.empty else np.nan
        emp = int(recon_df[recon_df["year"] == year]["empty_shell_count"].iloc[0]) if not recon_df.empty else np.nan
        pairs = [
            ("population", pop6, pop7),
            ("births", float(x6["No of births"]), float(x7["No of births"])),
            ("deaths", float(x6["No. of Deaths"]), float(x7["No. of Deaths"])),
            ("cbr_per_1000", 1000 * float(x6["No of births"]) / pop6 if pop6 else 0,
             1000 * float(x7["No of births"]) / pop7 if pop7 else 0),
            ("cdr_per_1000", 1000 * float(x6["No. of Deaths"]) / pop6 if pop6 else 0,
             1000 * float(x7["No. of Deaths"]) / pop7 if pop7 else 0),
            ("employment_rate", float(x6["Employment Rate"]), float(x7["Employment Rate"])),
            ("rental_vacancy", float(x6["Rental_Vacancy_Rate"]), float(x7["Rental_Vacancy_Rate"])),
            ("for_sale_vacancy", fs_vac(stk6, year), fs_vac(stk7, year)),
            ("overall_vacancy", float(x6["Overall_Vacancy_Rate"]), float(x7["Overall_Vacancy_Rate"])),
            ("renter_households", float(x6["Renter_Occupied_HH"]), float(x7["Renter_Occupied_HH"])),
            ("owner_households", float(x6["Owner_Occupied_HH"]), float(x7["Owner_Occupied_HH"])),
            # 6E only has old-basis; compare it to 7A's preserved old-basis column
            ("old_basis_insecure", float(x6["Housing_Insecure_HH_Count"]),
             float(x7["Housing_Insecure_HH_Count_Old_Basis"])),
            ("genuine_insecure", np.nan, float(gen)),
            ("empty_shell_count", np.nan, float(emp)),
            ("avg_income", float(x6["Avg Annual Income"]), float(x7["Avg Annual Income"])),
            ("total_cars", float(x6["Total Number of Cars"]), float(x7["Total Number of Cars"])),
            ("accidents", float(x6["Number of Accidents on road"]), float(x7["Number of Accidents on road"])),
            ("bus_refused_trips", res_val(r6, year, "Bus Service"), res_val(r7, year, "Bus Service")),
            ("university_enrolled", res_val(r6, year, "University", "in_use"), res_val(r7, year, "University", "in_use")),
            ("community_college_enrolled", res_val(r6, year, "Community College", "in_use"),
             res_val(r7, year, "Community College", "in_use")),
        ]
        if not sc6.empty and not sc7.empty and year in set(sc6["year"]) and year in set(sc7["year"]):
            e6 = sc6[sc6["year"] == year].iloc[0]
            e7 = sc7[sc7["year"] == year].iloc[0]
            pairs.append(("economic_index", float(e6["economic_index"]), float(e7["economic_index"])))
            pairs.append(("transport_index", float(e6["transport_index"]), float(e7["transport_index"])))
        for metric, v6, v7 in pairs:
            if (v6 != v6) or (v7 != v7):
                diff = np.nan
                match = "n/a_new_metric" if metric in ("genuine_insecure", "empty_shell_count") else False
            else:
                diff = float(v7) - float(v6)
                match = bool(abs(diff) < 1e-9)
            rows.append({"year": year, "metric": metric, "phase6e_value": v6,
                         "phase7a_value": v7, "absolute_diff": diff, "match": match})

    # Final-year education + working-age employment from population datasheet
    if not p7.empty and not p6.empty:
        fy = int(max(p7["year"]))
        def edu(df, level):
            return float((df[df["year"] == fy]["education_level"] == level).sum())
        def wa(df):
            w = df[(df["year"] == fy) & (df["age"] >= 18) & (df["age"] <= 64)]
            return float((w["employment_status"] == "Employed").sum()) / len(w) if len(w) else np.nan
        for metric, fn in [
            ("university_count_final", lambda d: edu(d, "University")),
            ("community_college_count_final", lambda d: edu(d, "Community College")),
            ("working_age_employment_rate_final", wa),
        ]:
            v6, v7 = fn(p6), fn(p7)
            diff = (v7 - v6) if (v6 == v6 and v7 == v7) else np.nan
            rows.append({"year": fy, "metric": metric, "phase6e_value": v6, "phase7a_value": v7,
                         "absolute_diff": diff, "match": bool(abs(diff) < 1e-9) if diff == diff else False})

    df = pd.DataFrame(rows)
    _write(df, diag / "phase7a_phase6e_comparison.csv")
    return df


def _compare_phase6f(recon_df: pd.DataFrame, phase6f_dir: Path, diag: Path) -> pd.DataFrame:
    """Confirm 7A genuine/empty/old-basis reproduce Phase 6F diagnostics exactly."""
    press = _safe_read(phase6f_dir / "phase6f_housing_stock_pressure_decomposition.csv")
    empt = _safe_read(phase6f_dir / "phase6f_empty_household_audit.csv")
    rows = []
    if recon_df.empty:
        return pd.DataFrame(rows)
    for _, r in recon_df.iterrows():
        y = int(r["year"])
        g6f = float(press[press["year"] == y]["insecure_households_end"].iloc[0]) if not press.empty and y in set(press["year"]) else np.nan
        e6f = float(empt[empt["year"] == y]["empty_households"].iloc[0]) if not empt.empty and y in set(empt["year"]) else np.nan
        for metric, v6f, v7 in [
            ("genuine_insecure", g6f, float(r["genuine_insecure_nonempty_count"])),
            ("empty_shells", e6f, float(r["empty_shell_count"])),
        ]:
            diff = (v7 - v6f) if (v6f == v6f) else np.nan
            rows.append({"year": y, "metric": metric, "phase6f_value": v6f,
                         "phase7a_value": v7, "absolute_diff": diff,
                         "match": bool(abs(diff) < 1e-9) if diff == diff else False})
    df = pd.DataFrame(rows)
    _write(df, diag / "phase7a_phase6f_metric_comparison.csv")
    return df


def _make_plots(plots, recon_df, cls_df, stock, cmp6e, flags):
    try:
        if not recon_df.empty:
            fig, ax = plt.subplots(figsize=(8, 4.5))
            ax.plot(recon_df["year"], recon_df["old_basis_insecure_count"], "-o", label="Old-basis (label)")
            ax.plot(recon_df["year"], recon_df["genuine_insecure_nonempty_count"], "-s", label="Genuine (non-empty, no claim)")
            ax.legend(); ax.set_title("Old-basis vs genuine insecure by year"); ax.set_xlabel("year")
            fig.tight_layout(); fig.savefig(plots / "01_old_vs_genuine_insecure.png"); plt.close(fig)

            fig, ax = plt.subplots(figsize=(8, 4.5))
            ax.bar(recon_df["year"], recon_df["empty_shell_count"], color="slategray")
            ax.set_title("Empty household shells by year"); ax.set_xlabel("year")
            fig.tight_layout(); fig.savefig(plots / "02_empty_shells.png"); plt.close(fig)

        if not cls_df.empty:
            piv = cls_df.pivot_table(index="year", columns="household_status_classification",
                                     values="household_count", aggfunc="sum").fillna(0)
            fig, ax = plt.subplots(figsize=(9, 4.5))
            piv.plot(kind="bar", stacked=True, ax=ax)
            ax.set_title("Household status classifications by year"); ax.legend(fontsize=7)
            fig.tight_layout(); fig.savefig(plots / "03_status_classifications.png"); plt.close(fig)

        if not recon_df.empty and not stock.empty:
            av = [float(stock[stock["year"] == y].iloc[0]["total_housing_available"])
                  if y in set(stock["year"]) else np.nan for y in recon_df["year"]]
            fig, ax = plt.subplots(figsize=(8, 4.5))
            ax.plot(recon_df["year"], recon_df["genuine_insecure_nonempty_count"], "-o", label="Genuine insecure")
            ax.plot(recon_df["year"], av, "-s", label="Available units")
            ax.legend(); ax.set_title("Genuine insecure vs available units")
            fig.tight_layout(); fig.savefig(plots / "04_genuine_vs_available.png"); plt.close(fig)

        if not cmp6e.empty:
            core = cmp6e[cmp6e["metric"].isin(
                ["population", "renter_households", "owner_households", "old_basis_insecure", "overall_vacancy"])].copy()
            core["absolute_diff"] = pd.to_numeric(core["absolute_diff"], errors="coerce")
            fig, ax = plt.subplots(figsize=(9, 4.5))
            piv = core.pivot_table(index="year", columns="metric", values="absolute_diff", aggfunc="first")
            piv.plot(ax=ax, marker="o")
            ax.axhline(0, color="gray", lw=0.8)
            ax.set_title("Phase 6E vs 7A core-output diffs (expect ~0)")
            fig.tight_layout(); fig.savefig(plots / "05_phase6e_vs_phase7a.png"); plt.close(fig)

        if not flags.empty:
            fig, ax = plt.subplots(figsize=(7, 4))
            sev = flags["severity"].value_counts()
            ax.bar(sev.index.astype(str), sev.values, color="darkorange")
            ax.set_title("Remaining red flags")
            fig.tight_layout(); fig.savefig(plots / "06_red_flags.png"); plt.close(fig)
    except Exception as exc:
        print(f"plot warning: {exc}")


def _write_report(diag, recon_df, cmp6e, cmp6f, occupancy_unchanged, demography_unchanged,
                  old_matches, empty_no_claim, final_genuine, final_empty, passed):
    def tbl(df):
        return df.to_string(index=False) if not df.empty else "(none)"
    mism6e = pd.DataFrame()
    if not cmp6e.empty:
        c = cmp6e.copy()
        c = c[~c["metric"].isin(["genuine_insecure", "empty_shell_count"])]
        mism6e = c[c["match"] != True]
    report = f"""# Phase 7A — Household Lifecycle & Genuine Insecure Metric Correction Report

**Status:** {"PASSED" if passed else "FAILED"}  
**Type:** Controlled logging/metric fix (no housing occupancy or demographic logic changed)  
**Base:** Phase 6E source-copy

## Answers

1. **What exact empty-shell artifact was found?**
   Empty household shells (0 members, no active ledger claim) were relabeled `Insecure` when
   their last member died/moved out, and were then counted by the label-only annual metric.
   Households are never deleted, so these shells accumulated and inflated insecurity.

2. **Where was old Housing_Insecure_HH_Count computed?**
   `mastercode02_logging.py`, `_log_annual_summary` — previously
   `len([h for h in g.HOUSEHOLDS.values() if h.get('tenure') == 'Insecure'])` (label-only).

3. **How is genuine insecure now defined?**
   Ledger-based classification (`classify_household_housing_status`): a household is
   `genuine_insecure_nonempty` iff it has >=1 member AND no active housing ledger claim.
   `Housing_Insecure_HH_Count` now equals this genuine count.

4. **How many empty shells exist by year?**
   {", ".join(f"y{int(r['year'])}={int(r['empty_shell_count'])}" for _, r in recon_df.iterrows())}

5. **How many genuine insecure households exist by year?**
   {", ".join(f"y{int(r['year'])}={int(r['genuine_insecure_nonempty_count'])}" for _, r in recon_df.iterrows())}

6. **How much of the old count was empty-shell inflation?**
   old_basis = genuine + empty_shells each year (see reconciliation). Final year:
   old={int(recon_df.iloc[-1]['old_basis_insecure_count'])} = genuine={final_genuine} + empty_shells={final_empty}.

7. **Did any housing occupancy/vacancy metric change?**
   No. Occupancy/vacancy unchanged vs 6E: {occupancy_unchanged}.

8. **Did any household gain or lose a housing claim because of this phase?**
   No. All changes are read-only logging/classification; the ledger was not modified.

9. **Should empty-shell pruning be implemented later?**
   Optional Phase 7B. Shells hold no claims (safe to prune) but pruning changes the
   `Households` count and is intentionally out of Phase 7A scope.

10. **Is genuine scarcity still present after correction?**
    Yes — genuine insecure grows 0 → {final_genuine} from fixed stock + net household formation.
    The metric fix removes phantom insecurity; it does not remove real scarcity.

11. **Remaining red flags?**
    Genuine scarcity (HIGH, deferred); empty-shell accumulation in dict (MEDIUM, optional 7B);
    ledger consistency clean (LOW).

## Insecure metric reconciliation
```
{tbl(recon_df)}
```

## Phase 6E comparison — non-insecure mismatches (expect none)
```
{tbl(mism6e)}
```

## Phase 6F metric comparison (genuine + empty shells should match 6F exactly)
```
{tbl(cmp6f)}
```

## Verification
- Old-basis insecure matches Phase 6E: {old_matches}
- Occupancy/vacancy unchanged: {occupancy_unchanged}
- Population/demography unchanged: {demography_unchanged}
- No empty household holds a claim: {empty_no_claim}

## Stop
Phase 7A is complete. Do NOT prune households, add supply, calibrate formation, refactor
global state, or add ML.
"""
    (diag / "phase7a_household_lifecycle_insecure_metric_fix_report.md").write_text(report, encoding="utf-8")


def _write_change_log(diag, occupancy_unchanged, demography_unchanged):
    txt = f"""# Phase 7A Change Log

| File | Type | Reason |
|------|------|--------|
| `mastercode02_household_lifecycle.py` | model-logic helper (new, read-only) | `classify_household_housing_status` + status counts (ledger-based) |
| `mastercode02_logging.py` | logging/metric | `Housing_Insecure_HH_Count` now = genuine; added genuine/empty-shell/old-basis columns; datasheet classification fields |
| `mastercode02_phase7a_diagnostics.py` | diagnostic (new) | Read-only per-year household classification snapshots |
| `mastercode02_phase7a_postrun.py` | diagnostic (new) | Reconciliation CSVs, comparisons, plots, report |
| `notebooks/run_phase7a.py` | runner (new) | Seeded run (seed 123, duration 5) |

## Exact artifact fixed
Empty household shells (0 members, no active ledger claim) were counted as `Insecure` by the
label-only annual metric. `Housing_Insecure_HH_Count` now counts only genuine insecure
(non-empty households with no active ledger claim); the old label count is preserved as
`Housing_Insecure_HH_Count_Old_Basis` / `Official_Insecure_Label_Count_Old_Basis`.

## Why this does not change housing occupancy
The classifier and metric read the Phase 6B/6E ledger and member counts; no assign/release/
transfer occurs. Occupancy/vacancy unchanged vs 6E: {occupancy_unchanged}.

## Why this does not add housing supply
No `HOUSING_STOCK` capacity or category was touched.

## Confirmation non-housing logic unchanged
No fertility/mortality/immigration/employment/education/transit/formation logic changed
(logging-only additions, no RNG draws). Demography unchanged vs 6E: {demography_unchanged}.
"""
    (diag / "phase7a_change_log.md").write_text(txt, encoding="utf-8")
