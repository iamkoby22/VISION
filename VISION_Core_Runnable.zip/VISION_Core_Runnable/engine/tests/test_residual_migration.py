"""R7.10 pre-run test suite for mastercode02_residual_migration.py.

Executes the R7.9/R7.10 25-test contract to the extent verifiable via static/unit-level checks
without launching the full salabim simulation (full-run behavioral checks -- e.g. housing capacity
never exceeded across 24 simulated years -- are additionally re-verified post-run in the R7.10
evidence package). Run with: python tests/test_residual_migration.py
"""
import csv
import hashlib
import json
import math
import sys
from pathlib import Path

SRC = Path(__file__).parent.parent / "src"
sys.path.insert(0, str(SRC))

import mastercode02_residual_migration as rm  # noqa: E402

RESULTS = []


def check(name, condition, detail=""):
    RESULTS.append((name, bool(condition), detail))
    print(f"[{'PASS' if condition else 'FAIL'}] {name}" + (f" -- {detail}" if detail else ""))


# --- 1-2: annual/cumulative residual series matches frozen files ---
r79_path = Path(__file__).parent.parent.parent.parent.parent / "RESSEARCH" / "37_PHASE_R7_9_RESIDUAL_MIGRATION_SPECIFICATION" / "02_r7_9_frozen_annual_residual_migration.csv"
r710_path = Path(__file__).parent.parent.parent.parent.parent / "RESSEARCH" / "38_PHASE_R7_10_RESIDUAL_MIGRATION_EXPERIMENT" / "02_r7_10_integerized_residual_migration.csv"
schedule = rm._load_annual_schedule()
r710_rows = list(csv.DictReader(open(r710_path)))
check("1: runtime schedule matches R7.10 integerized file (all 24 years)",
      all(schedule[int(r["calendar_year"])]["integer_residual"] == int(r["integer_residual"]) for r in r710_rows))

int_cumulative = sum(v["integer_residual"] for v in schedule.values())
check("2/3: integer cumulative residual == 28090", int_cumulative == 28090, f"got {int_cumulative}")

# --- 4: age probabilities sum to 1 (raw counts, not rounded display values) ---
age_sum = sum(p for _, _, p in rm.AGE_BINS)
check("4: age-bin probabilities sum to 1.0 +/- 1e-3 (display-rounded values)", abs(age_sum - 1.0) < 1e-3, f"sum={age_sum}")
# raw-count normalization used at runtime (rm._AGE_BIN_TOTAL) always yields an exact 1.0 draw range
check("4b: runtime age-bin draw normalizes exactly (uses raw sum as draw ceiling)", rm._AGE_BIN_TOTAL == age_sum)

# --- 5: sex probability well-formed ---
check("5: sex probability in (0,1)", 0.0 < rm.SEX_PROB_FEMALE < 1.0, f"{rm.SEX_PROB_FEMALE}")

# --- 3: domestic/international reconciliation ---
dom_intl_ok = all(
    abs(v["domestic_fraction"] + v["international_fraction"] - 1.0) < 1e-6 or v["integer_residual"] == 0
    for v in schedule.values()
)
check("3: domestic_fraction + international_fraction == 1.0 for every year", dom_intl_ok)

# --- RNG reproducibility (test 24) ---
seed_a = rm._derive_residual_seed(20230101)
seed_b = rm._derive_residual_seed(20230101)
check("24a: derived residual seed is deterministic (same base seed -> same derived seed)", seed_a == seed_b)
import random as _random
rngA = _random.Random(seed_a)
rngB = _random.Random(seed_a)
draws_a = [rngA.random() for _ in range(50)]
draws_b = [rngB.random() for _ in range(50)]
check("24b: same derived seed produces identical draw sequence", draws_a == draws_b)
seed_other = rm._derive_residual_seed(99999999)
check("24c: different base seed produces a different derived seed", seed_a != seed_other)
check("24d: derived seed != base seed (genuinely transformed, not passthrough)", seed_a != 20230101)

# --- 6/8/10: no impossible age/student/employment/education combinations (logic-level check) ---
class _FakeEnv:
    def now(self):
        return 1


mgr = rm.ResidualMigrationManager.__new__(rm.ResidualMigrationManager)
mgr.rng = _random.Random(12345)
impossible_found = []
for _ in range(20000):
    age = mgr._draw_age()
    student = mgr._draw_student(age)
    education = mgr._education_for(age, student)
    if student and age < 18:
        impossible_found.append(("student under 18", age))
    if education == "college_completed" and age < 18:
        impossible_found.append(("college_completed under 18", age))
    if education == "University" and age < 18:
        impossible_found.append(("University education under 18 non-student-path", age))
check("6/9/10: no impossible age/student/education combination across 20,000 draws", not impossible_found, str(impossible_found[:5]))

age_min = min(mgr._draw_age() for _ in range(20000))
check("F: age distribution permits ages below 22 (min drawn age < 22 over 20,000 draws)", age_min < 22, f"min={age_min}")

# --- 7: mechanism labels distinct and non-null ---
check("7/13: mechanism labels distinct", {"RESIDUAL_DOMESTIC", "RESIDUAL_INTERNATIONAL"} == {mgr._mechanism_subtype(True), mgr._mechanism_subtype(False)})

# --- config identity checks (T0, seed, ARIMA/PEP, housing, vacancy target) ---
sys.path.insert(0, str(SRC))
import mastercode02_config_and_rates as config  # noqa: E402
check("17: target_rental_vacancy_rate remains 0.043", config.HOUSING_MARKET_TARGETS["target_rental_vacancy_rate"] == 0.043)
check("15/19: PEP_STRUCTURAL_MIGRATION_ENABLED default remains False", config.PEP_STRUCTURAL_MIGRATION_ENABLED is False)
check("16 (new): RESIDUAL_MIGRATION_ENABLED default is False (extension OFF by default)", config.RESIDUAL_MIGRATION_ENABLED is False)

R6C_RUN_STATUS = Path(__file__).parent.parent.parent.parent.parent / "runs" / "vision_core_corrected_r7" / "knoxville_baseline_housing_corrected" / "diagnostics" / "run_status.json"
r6c = json.load(open(R6C_RUN_STATUS))
check("14: T0 population baseline == 173890 (from R7.6C control)", r6c["t0_population_total"] == 173890)
check("14b: T0 households baseline == 76650 (from R7.6C control)", r6c["t0_household_total"] == 76650)
check("15: seed baseline == 20230101 (from R7.6C control)", r6c["seed"] == 20230101)
check("20: housing override baseline t0_data_hash recorded", r6c["t0_data_hash"] == "45ff113dbc47b531a730b1f7f83958d928ac545be7dcb26f0665562617625e83")

# --- override diff gate (25: no 2023 endpoint reference in frozen inputs) ---
frozen_files = list((Path(__file__).parent.parent.parent.parent.parent / "RESSEARCH" / "37_PHASE_R7_9_RESIDUAL_MIGRATION_SPECIFICATION").glob("0[2-9]_*.csv"))
contains_endpoint = []
for fp in frozen_files:
    text = fp.read_text()
    if "197463" in text or "197,463" in text:
        contains_endpoint.append(fp.name)
check("25: no frozen input file references the 2023 population endpoint (197,463)", not contains_endpoint, str(contains_endpoint))

# --- data file hash (for the run manifest) ---
data_csv = SRC / "data" / "residual_migration_knoxville.csv"
data_hash = hashlib.sha256(data_csv.read_bytes()).hexdigest()
print(f"\nresidual_migration_knoxville.csv sha256: {data_hash}")

module_src = (SRC / "mastercode02_residual_migration.py").read_bytes()
module_hash = hashlib.sha256(module_src).hexdigest()
print(f"mastercode02_residual_migration.py sha256: {module_hash}")

n_pass = sum(1 for _, ok, _ in RESULTS if ok)
n_fail = sum(1 for _, ok, _ in RESULTS if not ok)
print(f"\n{n_pass} passed, {n_fail} failed out of {len(RESULTS)}")

with open(Path(__file__).parent.parent.parent.parent.parent / "RESSEARCH" / "38_PHASE_R7_10_RESIDUAL_MIGRATION_EXPERIMENT" / "03_r7_10_pre_run_test_results.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["test", "result", "detail"])
    for name, ok, detail in RESULTS:
        w.writerow([name, "PASS" if ok else "FAIL", detail])
    w.writerow(["residual_migration_knoxville.csv sha256", data_hash, ""])
    w.writerow(["mastercode02_residual_migration.py sha256", module_hash, ""])

sys.exit(0 if n_fail == 0 else 1)
