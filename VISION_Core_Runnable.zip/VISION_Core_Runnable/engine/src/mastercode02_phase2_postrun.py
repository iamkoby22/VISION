"""Phase 2 post-run analysis: baseline comparison, forensics, plots, reports."""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from mastercode02_phase2_diagnostics import PHASE2_LOG, diagnose_unused_education_routes


def write_phase2_diagnostic_csvs(diag_dir: Path) -> None:
    diag_dir.mkdir(parents=True, exist_ok=True)
    mapping = {
        "phase2_employment_metrics.csv": "employment_metrics",
        "phase2_housing_metrics.csv": "housing_metrics",
        "phase2_birth_death_metrics.csv": "birth_death_metrics",
        "phase2_resource_diagnostics.csv": "resource_diagnostics",
        "phase2_transit_diagnostics.csv": "transit_diagnostics",
        "phase2_household_logging_audit.csv": "household_logging_audit",
    }
    for filename, key in mapping.items():
        if PHASE2_LOG.get(key):
            pd.DataFrame(PHASE2_LOG[key]).to_csv(diag_dir / filename, index=False)

    unused = diagnose_unused_education_routes()
    pd.DataFrame(unused).to_csv(diag_dir / "phase2_unused_routes.csv", index=False)

    # Flatten all phase2 metrics into one file
    all_metrics = []
    for key, rows in PHASE2_LOG.items():
        for row in rows:
            r = dict(row)
            r["source_table"] = key
            all_metrics.append(r)
    if all_metrics:
        pd.DataFrame(all_metrics).to_csv(diag_dir / "phase2_metric_diagnostics.csv", index=False)


def column_forensics(out_dir: Path) -> pd.DataFrame:
    rows = []
    for csv_path in sorted(out_dir.glob("mastercode02_output_phase2_seed123_*.csv")):
        df = pd.read_csv(csv_path)
        source = csv_path.stem.replace("mastercode02_output_phase2_seed123_", "")
        for col in df.columns:
            s = df[col]
            null_pct = s.isna().mean() * 100
            nunique = s.nunique(dropna=True)
            is_const = nunique <= 1
            numeric = pd.api.types.is_numeric_dtype(s)
            mostly_missing = null_pct > 50
            suspicious = []
            if is_const and col not in ("year", "Year"):
                suspicious.append("constant")
            if mostly_missing:
                suspicious.append("mostly_missing")
            if not numeric and col.lower().endswith(("_rate", "_count", "utilization", "capacity", "in_use")):
                suspicious.append("expected_numeric")
            if numeric and s.notna().any():
                if "rate" in col.lower() or "vacancy" in col.lower() or "utilization" in col.lower():
                    if (s.min() < -0.01 or s.max() > 1.01) and "per_1000" not in col.lower():
                        suspicious.append("outside_0_1_bounds")
            rows.append({
                "source": source,
                "column": col,
                "dtype": str(s.dtype),
                "null_pct": round(null_pct, 2),
                "nunique": int(nunique),
                "is_constant": is_const,
                "mostly_missing": mostly_missing,
                "suspicious_flags": "|".join(suspicious) if suspicious else "",
            })
    return pd.DataFrame(rows)


def baseline_comparison(
    phase2_annual: pd.DataFrame,
    baseline_annual: pd.DataFrame,
    phase2_scores: pd.DataFrame,
    baseline_scores: pd.DataFrame,
) -> pd.DataFrame:
    metrics = [
        ("Population", "Population"),
        ("births", "No of births"),
        ("deaths", "No. of Deaths"),
        ("employment_rate", "Employment Rate"),
        ("rental_vacancy", "Rental_Vacancy_Rate"),
        ("overall_vacancy", "Overall_Vacancy_Rate"),
        ("housing_insecure", "Housing_Insecure_HH_Count"),
        ("avg_income", "Avg Annual Income"),
    ]
    rows = []
    for year in range(6):
        p2 = phase2_annual[phase2_annual["Year"] == year]
        bl = baseline_annual[baseline_annual["Year"] == year]
        if p2.empty or bl.empty:
            continue
        for label, col in metrics:
            v2 = float(p2.iloc[0][col])
            vb = float(bl.iloc[0][col])
            diff = v2 - vb
            rel = (diff / vb * 100) if vb != 0 else (0 if diff == 0 else np.nan)
            cause = "match" if abs(diff) < 1e-6 else "investigate"
            if abs(diff) < 1e-6:
                cause = "match"
            elif abs(rel) < 0.01:
                cause = "rounding_only"
            else:
                cause = "unintended_model_change_or_seed_mismatch"
            rows.append({
                "year": year,
                "metric": label,
                "baseline_value": vb,
                "phase2_value": v2,
                "absolute_diff": diff,
                "relative_diff_pct": rel,
                "likely_cause": cause,
            })
    for label, col in [("economic_index", "economic_index"), ("transport_index", "transport_index")]:
        for year in range(6):
            p2 = phase2_scores[phase2_scores["year"] == year]
            bl = baseline_scores[baseline_scores["year"] == year]
            if p2.empty or bl.empty:
                continue
            v2 = float(p2.iloc[0][col])
            vb = float(bl.iloc[0][col])
            diff = v2 - vb
            rel = (diff / vb * 100) if vb != 0 else 0
            cause = "match" if abs(diff) < 0.01 else "unintended_model_change_or_seed_mismatch"
            rows.append({
                "year": year,
                "metric": label,
                "baseline_value": vb,
                "phase2_value": v2,
                "absolute_diff": diff,
                "relative_diff_pct": rel,
                "likely_cause": cause,
            })
    return pd.DataFrame(rows)


def generate_plots(
    diag_dir: Path,
    comparison: pd.DataFrame,
    phase2_emp: pd.DataFrame,
    phase2_housing: pd.DataFrame,
    phase2_birth: pd.DataFrame,
    phase2_res: pd.DataFrame,
    phase2_transit: pd.DataFrame,
    baseline_annual: pd.DataFrame,
    phase2_annual: pd.DataFrame,
    baseline_scores: pd.DataFrame,
    phase2_scores: pd.DataFrame,
    hh_audit: pd.DataFrame,
) -> None:
    plot_dir = diag_dir / "phase2_plots"
    plot_dir.mkdir(parents=True, exist_ok=True)

    years = baseline_annual["Year"]
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(years, baseline_annual["Population"], "o--", label="Baseline")
    ax.plot(years, phase2_annual["Population"], "s-", label="Phase 2")
    ax.set_title("Population: Baseline vs Phase 2")
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(plot_dir / "01_population_comparison.png", dpi=150)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 5))
    w = 0.18
    for i, y in enumerate(years):
        ax.bar(y - w, baseline_annual.loc[baseline_annual["Year"] == y, "No of births"].values[0], width=w, color="C0", alpha=0.5)
        ax.bar(y, phase2_annual.loc[phase2_annual["Year"] == y, "No of births"].values[0], width=w, color="C0")
        ax.bar(y + w, baseline_annual.loc[baseline_annual["Year"] == y, "No. of Deaths"].values[0], width=w, color="C3", alpha=0.5)
        ax.bar(y + 2 * w, phase2_annual.loc[phase2_annual["Year"] == y, "No. of Deaths"].values[0], width=w, color="C3")
    ax.set_title("Births/Deaths: Baseline (faint) vs Phase 2 (solid)")
    ax.set_xlabel("Year")
    fig.tight_layout()
    fig.savefig(plot_dir / "02_births_deaths_comparison.png", dpi=150)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(phase2_birth["year"], phase2_birth["crude_birth_rate_per_1000"], "o-", label="CBR")
    ax.plot(phase2_birth["year"], phase2_birth["crude_death_rate_per_1000"], "s-", label="CDR")
    ax.set_title("Crude Birth and Death Rates (Phase 2)")
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(plot_dir / "03_crude_birth_death_rate.png", dpi=150)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(phase2_emp["year"], phase2_emp["employment_rate_total_pop"], "o-", label="Total pop")
    ax.plot(phase2_emp["year"], phase2_emp["employment_rate_working_age_18_64"], "s-", label="Working age 18-64")
    ax.set_title("Employment Rate by Denominator")
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(plot_dir / "04_employment_rates.png", dpi=150)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(phase2_housing["year"], phase2_housing["rental_vacancy_rate"], label="Rental")
    ax.plot(phase2_housing["year"], phase2_housing["forsale_vacancy_rate"], label="For-sale")
    ax.plot(phase2_housing["year"], phase2_housing["overall_vacancy_rate"], label="Overall")
    ax.set_title("Vacancy Rates (Phase 2 explicit definitions)")
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(plot_dir / "05_vacancy_rates.png", dpi=150)
    plt.close(fig)

    if not hh_audit.empty:
        fig, ax = plt.subplots(figsize=(8, 5))
        row = hh_audit.iloc[-1]
        labels = ["Baseline\n(nonempty only)", "Phase 2\n(all HH)"]
        values = [35161, int(row["expected_datasheet_rows_after_phase2_fix"])]
        ax.bar(labels, values, color=["C1", "C2"])
        ax.set_title("Household Datasheet Row Count: Before vs After Logging Fix")
        ax.set_ylabel("Rows")
        fig.tight_layout()
        fig.savefig(plot_dir / "06_household_logging_gap.png", dpi=150)
        plt.close(fig)

    agg = phase2_res.groupby(["year", "resource_group"])["utilization"].mean().reset_index()
    pivot = agg.pivot(index="resource_group", columns="year", values="utilization")
    fig, ax = plt.subplots(figsize=(10, 5))
    im = ax.imshow(pivot.values, aspect="auto", cmap="YlOrRd", vmin=0, vmax=1)
    ax.set_yticks(range(len(pivot.index)))
    ax.set_yticklabels(pivot.index)
    ax.set_xticks(range(len(pivot.columns)))
    ax.set_xticklabels(pivot.columns)
    ax.set_title("Mean Resource Utilization by Group")
    fig.colorbar(im, ax=ax)
    fig.tight_layout()
    fig.savefig(plot_dir / "07_resource_utilization_by_group.png", dpi=150)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.bar(phase2_transit["year"], phase2_transit["passengers_served"], label="Served", alpha=0.7)
    ax.bar(phase2_transit["year"], phase2_transit["passengers_refused"], bottom=phase2_transit["passengers_served"], label="Refused", alpha=0.7)
    ax.set_title("Bus Passengers Served vs Refused")
    ax.legend()
    fig.tight_layout()
    fig.savefig(plot_dir / "08_bus_served_refused.png", dpi=150)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(baseline_scores["year"], baseline_scores["economic_index"], "o--", label="Eco baseline")
    ax.plot(phase2_scores["year"], phase2_scores["economic_index"], "o-", label="Eco phase2")
    ax.plot(baseline_scores["year"], baseline_scores["transport_index"], "s--", label="Trans baseline")
    ax.plot(phase2_scores["year"], phase2_scores["transport_index"], "s-", label="Trans phase2")
    ax.set_title("Economic and Transport Index")
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(plot_dir / "09_economic_transport_index.png", dpi=150)
    plt.close(fig)


def build_red_flags(
    comparison: pd.DataFrame,
    hh_audit: pd.DataFrame,
    phase2_hh_path: Path,
    phase2_annual: pd.DataFrame,
    unused: pd.DataFrame,
) -> pd.DataFrame:
    flags = []
    mismatches = comparison[comparison["likely_cause"] == "unintended_model_change_or_seed_mismatch"]
    if len(mismatches) == 0:
        flags.append({
            "severity": "LOW", "category": "baseline_parity",
            "finding": "Core annual metrics match baseline within tolerance",
            "detail": "No material divergence detected",
        })
    else:
        for _, r in mismatches.iterrows():
            flags.append({
                "severity": "HIGH", "category": "baseline_parity",
                "finding": f"Metric {r['metric']} year {r['year']} differs",
                "detail": f"baseline={r['baseline_value']} phase2={r['phase2_value']} diff={r['absolute_diff']}",
            })

    if not hh_audit.empty:
        row = hh_audit.iloc[-1]
        hh_rows = len(pd.read_csv(phase2_hh_path)) if phase2_hh_path.exists() else 0
        gap = int(row["total_households_in_model"]) - hh_rows
        flags.append({
            "severity": "LOW" if gap == 0 else "HIGH",
            "category": "household_logging",
            "finding": f"Household datasheet rows={hh_rows}, model total={int(row['total_households_in_model'])}",
            "detail": f"Gap={gap}; empty households now logged={int(row['empty_households'])}",
        })

    flags.append({
        "severity": "HIGH", "category": "fertility",
        "finding": f"CBR year 5 = {phase2_annual.iloc[-1].get('No of births', 0) / phase2_annual.iloc[-1]['Population'] * 1000:.1f}/1000",
        "detail": "Scientific plausibility concern from Phase 1; unchanged in Phase 2",
    })
    if not unused.empty:
        flags.append({
            "severity": "MEDIUM", "category": "education_routing",
            "finding": "Community College unused",
            "detail": unused.iloc[0]["diagnosis"],
        })
    return pd.DataFrame(flags)


def build_upgrade_candidates() -> pd.DataFrame:
    return pd.DataFrame([
        {"priority": 1, "phase": 3, "area": "fertility_calibration", "rationale": "CBR still ~55/1000"},
        {"priority": 2, "phase": 3, "area": "education_routing", "rationale": "Add Community College pathway"},
        {"priority": 3, "phase": 3, "area": "transit_capacity", "rationale": "Bus refusal remains high"},
        {"priority": 4, "phase": 3, "area": "housing_metrics", "rationale": "Rental saturation definition review"},
        {"priority": 5, "phase": 3, "area": "global_state_hygiene", "rationale": "Add finance counters to globals.py"},
        {"priority": 6, "phase": 3, "area": "multi_year_population_export", "rationale": "Population datasheet still final-year only"},
    ])


def write_observability_report(
    diag_dir: Path,
    run_dir: Path,
    comparison: pd.DataFrame,
    hh_audit: pd.DataFrame,
    state_snapshot: dict,
    passed: bool,
) -> None:
    lines = [
        "# Phase 2 Observability Report",
        "",
        f"**Run:** `{run_dir.name}`",
        f"**Status:** {'PASSED' if passed else 'FAILED'}",
        "",
        "## Summary",
        "",
        "- Original code: untouched",
        "- Locked baseline run: untouched",
        "- Phase 2 source-copy: modified for logging/observability only",
        "",
        "## Household Logging Gap",
        "",
    ]
    if not hh_audit.empty:
        r = hh_audit.iloc[-1]
        lines += [
            f"- Model households: {int(r['total_households_in_model']):,}",
            f"- Empty households (now logged): {int(r['empty_households']):,}",
            f"- Baseline gap explained by skipped empty HH: {int(r['baseline_gap_empty_households_skipped']):,}",
            f"- Expected datasheet rows after fix: {int(r['expected_datasheet_rows_after_phase2_fix']):,}",
            "",
        ]
    core_match = (comparison["likely_cause"] == "match").all() if len(comparison) else False
    lines += [
        "## Baseline Comparison",
        "",
        f"Core metrics match baseline: **{'YES' if core_match else 'SEE phase2_baseline_comparison.csv'}**",
        "",
        "## State Snapshot (pre-run)",
        "",
        f"Missing attributes: {state_snapshot.get('missing_attributes', [])}",
        "",
        "## Phase 3 Recommendation Order",
        "",
        "1. Fertility calibration review",
        "2. Education routing (Community College)",
        "3. Transit capacity",
        "4. Housing metric definitions",
        "5. Global state hygiene",
        "6. Multi-year population export",
    ]
    (diag_dir / "phase2_observability_report.md").write_text("\n".join(lines), encoding="utf-8")


def run_post_analysis(
    run_dir: Path,
    baseline_run_dir: Path,
    state_snapshot: dict,
) -> bool:
    diag_dir = run_dir / "diagnostics"
    out_dir = run_dir / "outputs"
    base_out = baseline_run_dir / "outputs"

    write_phase2_diagnostic_csvs(diag_dir)

    p2_annual = pd.read_csv(out_dir / "mastercode02_output_phase2_seed123_annual_summary.csv")
    bl_annual = pd.read_csv(base_out / "mastercode02_output_baseline_seed123_annual_summary.csv")
    p2_scores = pd.read_csv(out_dir / "mastercode02_output_phase2_seed123_scores_summary.csv")
    bl_scores = pd.read_csv(base_out / "mastercode02_output_baseline_seed123_scores_summary.csv")

    comparison = baseline_comparison(p2_annual, bl_annual, p2_scores, bl_scores)
    comparison.to_csv(diag_dir / "phase2_baseline_comparison.csv", index=False)

    forensics = column_forensics(out_dir)
    forensics.to_csv(diag_dir / "phase2_column_forensics.csv", index=False)

    hh_audit = pd.read_csv(diag_dir / "phase2_household_logging_audit.csv") if (diag_dir / "phase2_household_logging_audit.csv").exists() else pd.DataFrame()
    unused = pd.read_csv(diag_dir / "phase2_unused_routes.csv") if (diag_dir / "phase2_unused_routes.csv").exists() else pd.DataFrame()

    red_flags = build_red_flags(
        comparison, hh_audit,
        out_dir / "mastercode02_output_phase2_seed123_household_datasheet.csv",
        p2_annual, unused,
    )
    red_flags.to_csv(diag_dir / "phase2_red_flags.csv", index=False)
    build_upgrade_candidates().to_csv(diag_dir / "phase2_upgrade_candidates.csv", index=False)

    generate_plots(
        diag_dir, comparison,
        pd.read_csv(diag_dir / "phase2_employment_metrics.csv"),
        pd.read_csv(diag_dir / "phase2_housing_metrics.csv"),
        pd.read_csv(diag_dir / "phase2_birth_death_metrics.csv"),
        pd.read_csv(diag_dir / "phase2_resource_diagnostics.csv"),
        pd.read_csv(diag_dir / "phase2_transit_diagnostics.csv"),
        bl_annual, p2_annual, bl_scores, p2_scores, hh_audit,
    )

    hh_gap_resolved = False
    if not hh_audit.empty:
        hh_rows = len(pd.read_csv(out_dir / "mastercode02_output_phase2_seed123_household_datasheet.csv"))
        hh_gap_resolved = hh_rows == int(hh_audit.iloc[-1]["total_households_in_model"])

    core_ok = len(comparison[comparison["likely_cause"] == "unintended_model_change_or_seed_mismatch"]) == 0
    passed = core_ok and hh_gap_resolved

    write_observability_report(diag_dir, run_dir, comparison, hh_audit, state_snapshot, passed)
    return passed
