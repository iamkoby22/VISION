"""Phase 6B housing ledger diagnostics — observation only."""
from __future__ import annotations

import mastercode02_globals as g
from mastercode02_config_and_rates import HOUSING_STOCK
from mastercode02_housing_ledger import (
    HOUSING_LEDGER_ACTIVE,
    LEDGER_DIAG_EVENTS,
    LEDGER_RELEASE_AUDIT,
    get_housing_active_claim_count,
    get_housing_capacity,
    get_housing_available_count,
    household_has_active_housing_claim,
    get_household_housing_claim,
    stock_vacancy_snapshot,
)


PHASE6B_LOG: dict = {
    "active_by_year": [],
    "consistency": [],
    "stock_vacancy": [],
    "invariants": [],
}


def snapshot_yearly_phase6b(year: int, env=None) -> None:
    snap = stock_vacancy_snapshot()
    interp = (
        "rental_full_forsale_slack"
        if snap["rental_vacancy_rate"] < 0.05 and snap["overall_vacancy_rate"] > 0.15
        else (
            "both_near_full"
            if snap["rental_vacancy_rate"] < 0.05 and snap["for_sale_vacancy_rate"] < 0.05
            else "mixed_or_slack"
        )
    )
    PHASE6B_LOG["stock_vacancy"].append({
        "year": year,
        **snap,
        "interpretation": interp,
        "notes": "vacancy from durable HOUSING_LEDGER_ACTIVE counts",
    })

    for name, stock in HOUSING_STOCK.items():
        cap = get_housing_capacity(name)
        claimed = get_housing_active_claim_count(name)
        avail = get_housing_available_count(name)
        PHASE6B_LOG["active_by_year"].append({
            "year": year,
            "housing_unit_name": name,
            "housing_category": stock["type"],
            "tenure_type": "Rental" if stock["type"] == "Rental" else "For-Sale",
            "capacity": cap,
            "active_claims": claimed,
            "available": avail,
            "utilization_rate": claimed / cap if cap else 0.0,
            "vacancy_rate": avail / cap if cap else 0.0,
            "notes": "ledger active claims",
        })

    violations = {
        "claims_gt_capacity": [],
        "multi_claim_household": [],  # impossible by dict key; check labels
        "housed_without_ledger": [],
        "ledger_without_household": [],
        "insecure_with_claim": [],
        "empty_with_claim": [],
        "renter_nonsale_mismatch": [],
        "owner_nonrental_mismatch": [],
    }

    # Unit capacity invariants
    for name in HOUSING_STOCK:
        claimed = get_housing_active_claim_count(name)
        cap = get_housing_capacity(name)
        if claimed > cap:
            violations["claims_gt_capacity"].append(name)

    # Orphan ledger claims
    for hh_id in list(HOUSING_LEDGER_ACTIVE.keys()):
        if hh_id not in g.HOUSEHOLDS:
            violations["ledger_without_household"].append(hh_id)

    for hh_id, hh in g.HOUSEHOLDS.items():
        members = hh.get("members", []) or []
        empty = len(members) == 0
        tenure = hh.get("tenure")
        unit = hh.get("housing_unit_name")
        has_claim = household_has_active_housing_claim(hh_id)
        claim = get_household_housing_claim(hh_id)
        ledger_unit = claim["housing_unit_name"] if claim else ""
        is_renter = tenure == "Renter"
        is_owner = tenure == "Owner"
        is_insecure = tenure == "Insecure"

        tenure_matches = True
        if has_claim and claim:
            cat = claim.get("housing_category")
            if is_renter and cat != "Rental":
                tenure_matches = False
                violations["renter_nonsale_mismatch"].append(hh_id)
            if is_owner and cat != "For-Sale":
                tenure_matches = False
                violations["owner_nonrental_mismatch"].append(hh_id)

        if (is_renter or is_owner) and unit and not has_claim:
            violations["housed_without_ledger"].append(hh_id)
            cstat = "housed_label_without_ledger"
        elif is_insecure and has_claim:
            violations["insecure_with_claim"].append(hh_id)
            cstat = "insecure_with_active_claim"
        elif empty and has_claim:
            violations["empty_with_claim"].append(hh_id)
            cstat = "empty_with_active_claim"
        elif has_claim and unit == ledger_unit:
            cstat = "ok"
        elif has_claim and unit != ledger_unit:
            cstat = "label_ledger_unit_mismatch"
        elif not has_claim and not unit:
            cstat = "ok_unhoused"
        else:
            cstat = "other"

        PHASE6B_LOG["consistency"].append({
            "year": year,
            "household_id": hh_id,
            "household_size": len(members),
            "is_empty": empty,
            "is_renter": is_renter,
            "is_owner": is_owner,
            "is_insecure": is_insecure,
            "housing_unit_name": unit or "",
            "has_active_ledger_claim": has_claim,
            "ledger_housing_unit_name": ledger_unit,
            "tenure_matches_unit": tenure_matches,
            "consistency_status": cstat,
            "notes": "",
        })

    inv_rows = [
        ("no_unit_overcapacity", "claims_gt_capacity", "HIGH"),
        ("no_housed_without_ledger", "housed_without_ledger", "HIGH"),
        ("no_ledger_without_household", "ledger_without_household", "HIGH"),
        ("no_insecure_with_claim", "insecure_with_claim", "MEDIUM"),
        ("no_empty_with_claim", "empty_with_claim", "HIGH"),
        ("renter_maps_to_rental", "renter_nonsale_mismatch", "MEDIUM"),
        ("owner_maps_to_forsale", "owner_nonrental_mismatch", "MEDIUM"),
    ]
    for inv_name, key, sev in inv_rows:
        ids = violations[key]
        PHASE6B_LOG["invariants"].append({
            "year": year,
            "invariant_name": inv_name,
            "pass_fail": "PASS" if len(ids) == 0 else "FAIL",
            "violation_count": len(ids),
            "example_ids": ";".join(str(x) for x in ids[:8]),
            "severity": sev,
            "notes": "",
        })
