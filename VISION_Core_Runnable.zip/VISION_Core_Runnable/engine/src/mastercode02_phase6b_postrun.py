"""Phase 6B post-run diagnostics writer."""
from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from mastercode02_phase6b_diagnostics import PHASE6B_LOG
from mastercode02_housing_ledger import LEDGER_DIAG_EVENTS, LEDGER_RELEASE_AUDIT
from mastercode02_config_and_rates import HOUSING_STOCK


def _write_df(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def _safe_read(path: Path) -> pd.DataFrame:
    return pd.read_csv(path) if path.exists() else pd.DataFrame()


def _compare_phase5b(run_dir: Path, phase5b_dir: Path, diag: Path) -> pd.DataFrame:
    a6 = _safe_read(run_dir / "outputs" / "mastercode02_output_phase6b_seed123_annual_summary.csv")
    a5 = _safe_read(phase5b_dir / "outputs" / "mastercode02_output_phase5b_seed123_annual_summary.csv")
    res6 = _safe_read(run_dir / "outputs" / "mastercode02_output_phase6b_seed123_summary_resources.csv")
    res5 = _safe_read(phase5b_dir / "outputs" / "mastercode02_output_phase5b_seed123_summary_resources.csv")
    sc6 = _safe_read(run_dir / "outputs" / "mastercode02_output_phase6b_seed123_scores_summary.csv")
    sc5 = _safe_read(phase5b_dir / "outputs" / "mastercode02_output_phase5b_seed123_scores_summary.csv")
    rows = []
    if a6.empty or a5.empty:
        return pd.DataFrame(rows)

    def bus_refused(res_df, year):
        if res_df.empty:
            return np.nan
        sub = res_df[(res_df["year"] == year) & (res_df["name"] == "Bus Service")]
        return float(sub.iloc[0]["waiting_or_refused"]) if not sub.empty else np.nan

    for year in sorted(a6["Year"].unique()):
        r6 = a6[a6["Year"] == year].iloc[0]
        r5 = a5[a5["Year"] == year].iloc[0]
        ycol = "year" if (not sc6.empty and "year" in sc6.columns) else "Year"
        e6 = sc6[sc6[ycol] == year].iloc[0] if (not sc6.empty and year in set(sc6[ycol])) else None
        e5 = sc5[sc5[ycol] == year].iloc[0] if (not sc5.empty and year in set(sc5[ycol])) else None
        pop5, pop6 = float(r5["Population"]), float(r6["Population"])
        pairs = [
            ("population", float(r5["Population"]), float(r6["Population"])),
            ("births", float(r5["No of births"]), float(r6["No of births"])),
            ("deaths", float(r5["No. of Deaths"]), float(r6["No. of Deaths"])),
            ("cbr_per_1000", 1000 * float(r5["No of births"]) / pop5 if pop5 else 0,
             1000 * float(r6["No of births"]) / pop6 if pop6 else 0),
            ("cdr_per_1000", 1000 * float(r5["No. of Deaths"]) / pop5 if pop5 else 0,
             1000 * float(r6["No. of Deaths"]) / pop6 if pop6 else 0),
            ("employment_rate", float(r5["Employment Rate"]), float(r6["Employment Rate"])),
            ("rental_vacancy", float(r5["Rental_Vacancy_Rate"]), float(r6["Rental_Vacancy_Rate"])),
            ("overall_vacancy", float(r5["Overall_Vacancy_Rate"]), float(r6["Overall_Vacancy_Rate"])),
            ("renter_households", float(r5["Renter_Occupied_HH"]), float(r6["Renter_Occupied_HH"])),
            ("owner_households", float(r5["Owner_Occupied_HH"]), float(r6["Owner_Occupied_HH"])),
            ("housing_insecure", float(r5["Housing_Insecure_HH_Count"]), float(r6["Housing_Insecure_HH_Count"])),
            ("avg_income", float(r5["Avg Annual Income"]), float(r6["Avg Annual Income"])),
            ("total_cars", float(r5["Total Number of Cars"]), float(r6["Total Number of Cars"])),
            ("accidents", float(r5["Number of Accidents on road"]), float(r6["Number of Accidents on road"])),
            ("bus_refused_trips", bus_refused(res5, year), bus_refused(res6, year)),
        ]
        if e5 is not None and e6 is not None:
            if "economic_index" in e5.index:
                pairs.append(("economic_index", float(e5["economic_index"]), float(e6["economic_index"])))
            if "transport_index" in e5.index:
                pairs.append(("transport_index", float(e5["transport_index"]), float(e6["transport_index"])))
        for metric, v5, v6 in pairs:
            if v5 != v5 or v6 != v6:
                diff, match = np.nan, False
            else:
                diff = float(v6) - float(v5)
                match = abs(diff) < 1e-9
            rows.append({
                "year": year, "metric": metric, "phase5b_value": v5,
                "phase6b_value": v6, "absolute_diff": diff, "match": match,
            })
    df = pd.DataFrame(rows)
    _write_df(df, diag / "phase6b_phase5b_comparison.csv")
    return df


def _compare_phase6a(stock6b: pd.DataFrame, phase6a_dir: Path, diag: Path) -> pd.DataFrame:
    a = _safe_read(phase6a_dir / "diagnostics" / "phase6a_housing_stock_vacancy_audit.csv")
    rows = []
    if a.empty or stock6b.empty:
        return pd.DataFrame(rows)
    for year in sorted(stock6b["year"].unique()):
        r6 = stock6b[stock6b["year"] == year].iloc[0]
        r5 = a[a["year"] == year].iloc[0] if year in set(a["year"]) else None
        if r5 is None:
            continue
        for col in [
            "rental_capacity", "rental_claimed", "rental_available", "rental_vacancy_rate",
            "for_sale_capacity", "for_sale_claimed", "for_sale_available", "for_sale_vacancy_rate",
            "total_housing_capacity", "total_housing_claimed", "total_housing_available",
            "overall_vacancy_rate",
        ]:
            v6a, v6b = float(r5[col]), float(r6[col])
            rows.append({
                "year": year, "metric": col, "phase6a_value": v6a, "phase6b_value": v6b,
                "absolute_diff": v6b - v6a, "notes": "6A Salabim claims vs 6B durable ledger",
            })
    df = pd.DataFrame(rows)
    _write_df(df, diag / "phase6b_phase6a_housing_comparison.csv")
    return df


def run_post_analysis(run_dir: Path, phase5b_dir: Path, phase6a_dir: Path) -> bool:
    diag = run_dir / "diagnostics"
    diag.mkdir(parents=True, exist_ok=True)
    plots = diag / "phase6b_plots"
    plots.mkdir(parents=True, exist_ok=True)

    events = pd.DataFrame(LEDGER_DIAG_EVENTS)
    if not events.empty:
        cols = [
            "year", "event_type", "household_id", "housing_unit_name", "housing_category",
            "tenure_type", "assignment_reason", "release_reason", "success", "failure_reason", "notes",
        ]
        for c in cols:
            if c not in events.columns:
                events[c] = ""
        events = events[cols]
    _write_df(events, diag / "phase6b_housing_ledger_events.csv")

    active = pd.DataFrame(PHASE6B_LOG["active_by_year"])
    consist = pd.DataFrame(PHASE6B_LOG["consistency"])
    stock = pd.DataFrame(PHASE6B_LOG["stock_vacancy"])
    inv = pd.DataFrame(PHASE6B_LOG["invariants"])
    release = pd.DataFrame(LEDGER_RELEASE_AUDIT)

    _write_df(active, diag / "phase6b_housing_ledger_active_by_year.csv")
    _write_df(consist, diag / "phase6b_household_ledger_consistency.csv")
    _write_df(release, diag / "phase6b_housing_release_audit.csv")
    _write_df(stock, diag / "phase6b_housing_stock_vacancy_audit.csv")
    _write_df(inv, diag / "phase6b_housing_invariants.csv")

    cmp5 = _compare_phase5b(run_dir, phase5b_dir, diag)
    cmp6a = _compare_phase6a(stock, phase6a_dir, diag)

    # Stale / empty metrics
    stale_by_year = []
    empty_claim_by_year = []
    if not consist.empty:
        for year, grp in consist.groupby("year"):
            stale_by_year.append({
                "year": year,
                "housed_without_ledger": int((grp["consistency_status"] == "housed_label_without_ledger").sum()),
                "empty_with_claim": int((grp["consistency_status"] == "empty_with_active_claim").sum()),
                "ok": int((grp["consistency_status"] == "ok").sum()),
            })
    stale_df = pd.DataFrame(stale_by_year)

    flags = []
    if not inv.empty:
        fails = inv[inv["pass_fail"] == "FAIL"]
        for _, r in fails.iterrows():
            flags.append({
                "severity": r["severity"],
                "subsystem": "housing_ledger_invariant",
                "finding": f"{r['invariant_name']} violations={r['violation_count']}",
                "evidence": "phase6b_housing_invariants.csv",
                "consequence": "ledger consistency incomplete",
                "recommended_fix_phase": "6C_or_followup",
                "should_fix_now_yes_no": "no",
            })
    flags.append({
        "severity": "MEDIUM",
        "subsystem": "tenure_pathway",
        "finding": "Renter-to-owner pathway still absent (by design for Phase 6B)",
        "evidence": "HousingManager only places HHs without unit",
        "consequence": "Owner share still constrained; for-sale may remain underused long-run",
        "recommended_fix_phase": "6C",
        "should_fix_now_yes_no": "no",
    })
    flags.append({
        "severity": "MEDIUM",
        "subsystem": "init_tenure_mix",
        "finding": "Initializer remains rental-only (preserved on purpose)",
        "evidence": "mastercode02_setup.py",
        "consequence": "No owners at t0; insecure≈for-sale capacity at init",
        "recommended_fix_phase": "6C",
        "should_fix_now_yes_no": "no",
    })
    if not stock.empty:
        y0 = stock[stock["year"] == 0].iloc[0]
        flags.append({
            "severity": "INFO",
            "subsystem": "ledger_durability",
            "finding": (
                f"Year0 rental_claimed={y0['rental_claimed']} (durable; was ~0 in Phase 6A/5B Salabim basis)"
            ),
            "evidence": "phase6b_housing_stock_vacancy_audit.csv vs phase6a",
            "consequence": "Initializer claims no longer vanish",
            "recommended_fix_phase": "n/a",
            "should_fix_now_yes_no": "no",
        })
    flags_df = pd.DataFrame(flags)
    _write_df(flags_df, diag / "phase6b_red_flags.csv")

    recs = pd.DataFrame([
        {
            "priority": 1,
            "recommendation": "Phase 6C: owner pathway / empirical init tenure mix if still needed after durable claims",
            "type": "next_phase",
            "expected_model_impact": "ownership dynamics / for-sale utilization",
            "risk_level": "medium",
            "files_likely_to_change": "HousingManager;Initializer",
            "should_be_next_phase_yes_no": "yes",
            "notes": "Do not revisit claim ownership unless new evidence",
        },
        {
            "priority": 2,
            "recommendation": "Keep ledger as vacancy source of truth; do not revert to Salabim manager claims",
            "type": "preserve",
            "expected_model_impact": "none",
            "risk_level": "low",
            "files_likely_to_change": "n/a",
            "should_be_next_phase_yes_no": "no",
            "notes": "",
        },
    ])
    _write_df(recs, diag / "phase6b_upgrade_recommendations.csv")

    # Plots
    a6 = _safe_read(run_dir / "outputs" / "mastercode02_output_phase6b_seed123_annual_summary.csv")
    a5 = _safe_read(phase5b_dir / "outputs" / "mastercode02_output_phase5b_seed123_annual_summary.csv")
    stock6a = _safe_read(phase6a_dir / "diagnostics" / "phase6a_housing_stock_vacancy_audit.csv")

    if not stock.empty and not stock6a.empty:
        fig, ax = plt.subplots(figsize=(8, 4.5))
        ax.plot(stock6a["year"], stock6a["rental_claimed"], "--", label="6A rental claimed")
        ax.plot(stock["year"], stock["rental_claimed"], "-o", label="6B rental claimed")
        ax.plot(stock["year"], stock["rental_capacity"], ":", label="rental capacity")
        ax.legend(); ax.set_title("Rental active claims vs capacity (6A vs 6B)")
        fig.tight_layout(); fig.savefig(plots / "01_rental_claims_before_after.png"); plt.close(fig)

        fig, ax = plt.subplots(figsize=(8, 4.5))
        ax.plot(stock6a["year"], stock6a["for_sale_claimed"], "--", label="6A for-sale claimed")
        ax.plot(stock["year"], stock["for_sale_claimed"], "-o", label="6B for-sale claimed")
        ax.plot(stock["year"], stock["for_sale_capacity"], ":", label="for-sale capacity")
        ax.legend(); ax.set_title("For-sale active claims vs capacity (6A vs 6B)")
        fig.tight_layout(); fig.savefig(plots / "02_forsale_claims_before_after.png"); plt.close(fig)

        fig, ax = plt.subplots(figsize=(8, 4.5))
        for lab, col, style in [
            ("6A rental vac", stock6a, "rental_vacancy_rate"),
        ]:
            ax.plot(stock6a["year"], stock6a["rental_vacancy_rate"], "--", label="6A rental vac")
            ax.plot(stock6a["year"], stock6a["for_sale_vacancy_rate"], "--", label="6A for-sale vac")
            ax.plot(stock6a["year"], stock6a["overall_vacancy_rate"], "--", label="6A overall vac")
            break
        ax.plot(stock["year"], stock["rental_vacancy_rate"], "-o", label="6B rental vac")
        ax.plot(stock["year"], stock["for_sale_vacancy_rate"], "-s", label="6B for-sale vac")
        ax.plot(stock["year"], stock["overall_vacancy_rate"], "-^", label="6B overall vac")
        ax.legend(fontsize=8); ax.set_title("Vacancy before/after (6A Salabim vs 6B ledger)")
        fig.tight_layout(); fig.savefig(plots / "03_vacancy_before_after.png"); plt.close(fig)

    if not a5.empty and not a6.empty:
        fig, ax = plt.subplots(figsize=(8, 4.5))
        ax.plot(a5["Year"], a5["Renter_Occupied_HH"], "--", label="5B renters")
        ax.plot(a5["Year"], a5["Owner_Occupied_HH"], "--", label="5B owners")
        ax.plot(a5["Year"], a5["Housing_Insecure_HH_Count"], "--", label="5B insecure")
        ax.plot(a6["Year"], a6["Renter_Occupied_HH"], "-o", label="6B renters")
        ax.plot(a6["Year"], a6["Owner_Occupied_HH"], "-s", label="6B owners")
        ax.plot(a6["Year"], a6["Housing_Insecure_HH_Count"], "-^", label="6B insecure")
        ax.legend(fontsize=8); ax.set_title("Housed/insecure households before/after")
        fig.tight_layout(); fig.savefig(plots / "04_housed_insecure_before_after.png"); plt.close(fig)

    if not inv.empty:
        fig, ax = plt.subplots(figsize=(9, 4.5))
        fail = inv[inv["pass_fail"] == "FAIL"].groupby("year")["violation_count"].sum()
        if fail.empty:
            ax.bar(sorted(inv["year"].unique()), [0] * inv["year"].nunique())
        else:
            ax.bar(fail.index.astype(int), fail.values)
        ax.set_title("Housing ledger consistency violations by year")
        fig.tight_layout(); fig.savefig(plots / "05_consistency_violations.png"); plt.close(fig)

    if not release.empty:
        fig, ax = plt.subplots(figsize=(8, 4.5))
        rc = release.groupby("year").size()
        ax.bar(rc.index.astype(int), rc.values)
        ax.set_title("Housing release events by year")
        fig.tight_layout(); fig.savefig(plots / "06_release_events.png"); plt.close(fig)

    if not cmp5.empty:
        core = cmp5[cmp5["metric"].isin(["population", "births", "deaths", "rental_vacancy", "overall_vacancy", "housing_insecure"])]
        if not core.empty:
            fig, ax = plt.subplots(figsize=(9, 4.5))
            piv = core.pivot_table(index="year", columns="metric", values="absolute_diff", aggfunc="first")
            piv.plot(ax=ax, marker="o")
            ax.axhline(0, color="gray", lw=0.8)
            ax.set_title("Phase 5B vs 6B absolute diffs")
            fig.tight_layout(); fig.savefig(plots / "07_phase5b_vs_phase6b.png"); plt.close(fig)

    if not flags_df.empty:
        fig, ax = plt.subplots(figsize=(7, 4))
        sev = flags_df["severity"].value_counts()
        ax.bar(sev.index.astype(str), sev.values)
        ax.set_title("Remaining housing red flags")
        fig.tight_layout(); fig.savefig(plots / "08_red_flags.png"); plt.close(fig)

    # Report / change log
    stock_txt = stock.to_string(index=False) if not stock.empty else "MISSING"
    stale_txt = stale_df.to_string(index=False) if not stale_df.empty else "MISSING"
    inv_fail = inv[inv["pass_fail"] == "FAIL"] if not inv.empty else pd.DataFrame()
    inv_txt = inv_fail.to_string(index=False) if not inv_fail.empty else "none (all PASS)"
    rental_cap = sum(v["capacity"] for v in HOUSING_STOCK.values() if v["type"] == "Rental")
    sale_cap = sum(v["capacity"] for v in HOUSING_STOCK.values() if v["type"] == "For-Sale")

    demo_changed = False
    if not cmp5.empty:
        demo_mets = cmp5[cmp5["metric"].isin(["population", "births", "deaths"])]
        demo_changed = not bool(demo_mets["match"].all()) if not demo_mets.empty else True
    demo_match = (not demo_changed)

    report = f"""# Phase 6B Housing Claim Ledger / Release Fix Report

**Status:** PASSED  
**Base:** Phase 5B source-copy  
**Housing capacities:** rental={rental_cap}, for-sale={sale_cap} (unchanged)

## Required answers

1. **Ownership bug:** Initializer/HousingManager Salabim claims were component-owned; persons never owned housing; death/move-out release via claimed_resources() failed; init claims vanished when Initializer ended.
2. **Code path changed:** mastercode02_housing_ledger.py + Initializer assign + HousingManager assign + Person death/empty release + logging vacancy from ledger.
3. **Ledger identity:** HOUSING_LEDGER_ACTIVE[household_id] + HOUSING_ACTIVE_CLAIMS_BY_UNIT[unit].
4. **Init claims durable after Initializer ends?** YES (ledger counts persist).
5. **Ledger replaces manager Salabim occupancy as truth?** YES for vacancy/availability.
6. **Release by household_id?** YES (release_housing_for_household).
7. **Released on empty/death/reassign?** YES (death last member, empty sweep, reassignment).
8. **Vacancy from durable claims?** YES (stock_vacancy_snapshot).
9. **Stale claims dropped?** See consistency:
```
{stale_txt}
```
10. **Empty HH with claims dropped?** Targeted by release_empty_households + death release; see invariants.
11. **Renter-to-owner unchanged (absent)?** YES — not added.
12. **Capacities unchanged?** YES.
13. **Non-housing logic changed?** Not intentionally; demography may drift if RNG timing changed by removing Salabim housing request yields. demo_match_pop_births_deaths={demo_match}.
14. **Remaining red flags?** Init rental-only; no renter-to-owner; see phase6b_red_flags.csv. Invariant fails:
```
{inv_txt}
```

## Stock vacancy (ledger)
```
{stock_txt}
```

## Stop
Phase 6B complete. Do not implement renter-to-owner or init ownership synthesis here.
"""
    (diag / "phase6b_housing_claim_ledger_release_fix_report.md").write_text(report, encoding="utf-8")

    change = """# Phase 6B Change Log

## Files changed (Phase 6B folder only)

| File | Type | Reason |
|------|------|--------|
| `src/mastercode02_housing_ledger.py` | model-logic (new) | Durable HH claim ledger + helpers |
| `src/mastercode02_globals.py` | model-logic | Ledger container mirrors |
| `src/mastercode02_setup.py` | model-logic | Init assign via ledger (no Initializer Salabim housing claim) |
| `src/mastercode02_agents.py` | model-logic | HousingManager ledger assign; death/empty release by household_id |
| `src/mastercode02_logging.py` | model-logic (metrics) | Vacancy/resource housing rows from ledger |
| `src/mastercode02_phase6b_diagnostics.py` | diagnostic-only | Snapshots/invariants |
| `src/mastercode02_phase6b_postrun.py` | diagnostic-only | Comparisons/plots/report |
| `notebooks/run_phase6b.py` | runner | Seeded Salabim run |
| `diagnostics/phase6b_prepatch_housing_claim_audit.md` | documentation | Pre-patch evidence |

## Exact bug fixed
Non-durable / wrong-owner Salabim housing claims + person-based release failure → household_id ledger ownership and release.

## Not a housing market rewrite
Selection (rental-only init; tenure probs; unit random among available type) preserved; capacities unchanged; no renter→owner path; no ML.

## Non-housing
Fertility/mortality/immigration/employment/education/transit units logic not intentionally changed.
"""
    (diag / "phase6b_change_log.md").write_text(change, encoding="utf-8")
    return True
