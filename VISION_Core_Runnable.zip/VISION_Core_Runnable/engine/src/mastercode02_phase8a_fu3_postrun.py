"""Phase 8A-FU3 post-run analysis — resource logging schema / Year-0 correction verification."""
from __future__ import annotations

import json
import platform
import subprocess
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from mastercode02_config_and_rates import EDUCATION_CAPACITIES

EDU_LEVELS = set(EDUCATION_CAPACITIES.keys())


def _write(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def _safe_read(path: Path) -> pd.DataFrame:
    return pd.read_csv(path) if path.exists() else pd.DataFrame()


def _safe_read_resources(path: Path) -> pd.DataFrame:
    """Read resource summary without treating literal 'N/A' as null."""
    if not path.exists():
        return pd.DataFrame()
    return pd.read_csv(path, keep_default_na=False, na_values=[""])


def _isna(v) -> bool:
    if v is None:
        return True
    try:
        if isinstance(v, float) and np.isnan(v):
            return True
    except Exception:
        pass
    s = str(v).strip().lower()
    return s in ("", "nan", "none", "null", "<na>")


def _num(v):
    if _isna(v):
        return np.nan
    try:
        return float(v)
    except (TypeError, ValueError):
        return np.nan


def run_post_analysis(run_dir: Path, fu2_dir: Path, base_filename: str, seed: int) -> bool:
    diag = run_dir / "diagnostics"
    plots = diag / "phase8a_fu3_plots"
    diag.mkdir(parents=True, exist_ok=True)
    plots.mkdir(parents=True, exist_ok=True)

    res = _safe_read_resources(run_dir / "outputs" / f"{base_filename}_summary_resources.csv")
    res_fu2 = _safe_read_resources(fu2_dir / "outputs" /
                         "mastercode02_output_phase8a_fu2_seed123_summary_resources.csv")

    _year0_audit(diag, res)
    _post_enroll_audit(diag, res)
    _bus_audit(diag, res)
    _road_audit(diag, res)
    _column_type_audit(diag, res)
    _schema_before_after(diag, res, res_fu2)
    ref_cmp, sci_match = _fu2_comparison(run_dir, fu2_dir, base_filename, diag)
    inv_ok = _invariants(diag, res, sci_match)
    _red_flags(diag)
    _recommendations(diag)
    _write_manifest(run_dir, fu2_dir, seed, sci_match)
    _write_change_log(diag, sci_match)
    _make_plots(plots, res, ref_cmp, diag)
    _write_report(diag, res, res_fu2, ref_cmp, sci_match, inv_ok)

    return bool(sci_match and inv_ok and not res.empty)


def _year0_audit(diag, res):
    rows = []
    if res.empty:
        _write(pd.DataFrame(), diag / "phase8a_fu3_year0_education_snapshot_audit.csv")
        return
    y0 = res[(res["year"] == 0) & (res["name"].isin(EDU_LEVELS))]
    for _, r in y0.iterrows():
        refused_na = _isna(r.get("education_local_seat_refused"))
        ext_na = _isna(r.get("education_external_school_count"))
        eff_na = _isna(r.get("effective_refused_or_overflow"))
        stage_ok = str(r.get("snapshot_stage", "")) == "pre_enrollment_baseline"
        eval_ok = (str(r.get("education_enrollment_evaluated", "")).lower()
                   in ("false", "0"))
        corrected = refused_na and ext_na and eff_na and stage_ok and eval_ok
        rows.append({
            "year": 0, "education_level": r["name"], "capacity": r["capacity"],
            "in_use": r["in_use"],
            "education_local_seat_demand": r.get("education_local_seat_demand"),
            "education_local_seat_refused": r.get("education_local_seat_refused"),
            "education_external_school_count": r.get("education_external_school_count"),
            "effective_refused_or_overflow": r.get("effective_refused_or_overflow"),
            "theoretical_pre_enrollment_demand_minus_capacity":
                r.get("theoretical_pre_enrollment_demand_minus_capacity"),
            "snapshot_stage": r.get("snapshot_stage"),
            "education_enrollment_evaluated": r.get("education_enrollment_evaluated"),
            "metric_basis": r.get("metric_basis"),
            "corrected_yes_no": "yes" if corrected else "no",
            "notes": "Y0 pre-enrollment: refused/external/effective NA; theoretical gap only",
        })
    _write(pd.DataFrame(rows), diag / "phase8a_fu3_year0_education_snapshot_audit.csv")


def _post_enroll_audit(diag, res):
    rows = []
    if not res.empty:
        sub = res[(res["year"] >= 1) & (res["name"].isin(EDU_LEVELS))]
        for _, r in sub.iterrows():
            demand = _num(r.get("education_local_seat_demand"))
            claims = _num(r.get("in_use"))
            refused = _num(r.get("education_local_seat_refused"))
            expected = max(0, demand - claims) if (demand == demand and claims == claims) else np.nan
            arith = bool(abs(refused - expected) < 1e-9) if (refused == refused and expected == expected) else False
            ext = _num(r.get("education_external_school_count"))
            eff = _num(r.get("effective_refused_or_overflow"))
            rows.append({
                "year": int(r["year"]), "education_level": r["name"],
                "capacity": r["capacity"], "local_claims": claims,
                "education_local_seat_demand": demand,
                "education_local_seat_refused": refused,
                "education_external_school_count": ext,
                "effective_refused_or_overflow": eff,
                "expected_refused": expected,
                "arithmetic_pass": arith and (ext == refused) and (eff == refused),
                "notes": "FU2 overflow arithmetic preserved for Y1+",
            })
    _write(pd.DataFrame(rows), diag / "phase8a_fu3_education_overflow_post_enrollment_audit.csv")


def _bus_audit(diag, res):
    rows = []
    if not res.empty:
        for year in sorted(res["year"].unique()):
            annual = res[(res["year"] == year) & (res["name"] == "Bus Service")]
            daily = res[(res["year"] == year) & (res["name"] == "Bus Service Daily Capacity")]
            if annual.empty or daily.empty:
                continue
            a, d = annual.iloc[0], daily.iloc[0]
            util_na = _isna(d.get("utilization"))
            ratio = _num(d.get("annual_demand_to_daily_capacity_ratio"))
            rows.append({
                "year": int(year), "resource_name": "Bus Service Daily Capacity",
                "annual_bus_capacity": a["capacity"], "daily_bus_capacity": d["capacity"],
                "annual_demand": d["in_use"], "utilization": d.get("utilization"),
                "annual_demand_to_daily_capacity_ratio": ratio,
                "schema_correct_yes_no": "yes" if (util_na and ratio == ratio) else "no",
                "notes": "utilization NA; ratio = annual_demand/daily_capacity",
            })
    _write(pd.DataFrame(rows), diag / "phase8a_fu3_bus_daily_capacity_schema_audit.csv")


def _road_audit(diag, res):
    rows = []
    if not res.empty:
        roads = res[res["name"].astype(str).str.startswith("Road:")]
        for _, r in roads.iterrows():
            num_ok = (_isna(r.get("waiting_or_refused"))
                      and _isna(r.get("waiting_or_refused_requester_basis"))
                      and _isna(r.get("effective_refused_or_overflow")))
            status = r.get("road_status")
            status_ok = not _isna(status)
            rows.append({
                "year": int(r["year"]), "resource_name": r["name"],
                "waiting_or_refused": r.get("waiting_or_refused"),
                "waiting_or_refused_requester_basis": r.get("waiting_or_refused_requester_basis"),
                "effective_refused_or_overflow": r.get("effective_refused_or_overflow"),
                "road_status": status,
                "numeric_schema_correct_yes_no": "yes" if (num_ok and status_ok) else "no",
                "notes": "numeric refusal cols NA; status in road_status",
            })
    _write(pd.DataFrame(rows), diag / "phase8a_fu3_road_schema_audit.csv")


def _column_type_audit(diag, res):
    rows = []
    if res.empty:
        _write(pd.DataFrame(), diag / "phase8a_fu3_resource_column_type_audit.csv")
        return
    numeric_expected = {
        "year", "capacity", "in_use", "utilization",
        "waiting_or_refused", "waiting_or_refused_requester_basis", "waiting_or_refused_legacy",
        "education_local_seat_demand", "education_local_seat_refused",
        "education_external_school_count", "effective_refused_or_overflow",
        "theoretical_pre_enrollment_demand_minus_capacity",
        "annual_demand_to_daily_capacity_ratio",
    }
    text_expected = {
        "name", "snapshot_stage", "metric_basis", "road_status",
        "education_enrollment_evaluated",
    }
    for col in res.columns:
        series = res[col]
        blank = int((series.astype(str).str.strip() == "").sum())
        non_null = int(series.notna().sum())
        # count blank strings that are not NA
        blank_str = 0
        parse_fail = 0
        for v in series:
            if isinstance(v, str) and v.strip() == "":
                blank_str += 1
            if col in numeric_expected and not _isna(v):
                if _num(v) != _num(v):  # NaN from failed parse of non-null
                    # try: if it's text that isn't numeric
                    try:
                        float(v)
                    except (TypeError, ValueError):
                        parse_fail += 1
        if col in numeric_expected:
            expected = "numeric_or_null"
            # pass if no text parse failures and blank strings are zero (prefer null)
            schema_pass = parse_fail == 0 and blank_str == 0
        elif col in text_expected:
            expected = "categorical_text_or_null"
            schema_pass = True
        else:
            expected = "other"
            schema_pass = blank_str == 0
        rows.append({
            "column_name": col, "inferred_dtype": str(series.dtype),
            "expected_dtype_or_semantic_type": expected,
            "non_null_count": non_null, "blank_string_count": blank_str,
            "numeric_parse_failures": parse_fail,
            "schema_pass": schema_pass,
            "notes": "blank strings discouraged; prefer null/NA for non-applicable",
        })
    _write(pd.DataFrame(rows), diag / "phase8a_fu3_resource_column_type_audit.csv")


def _schema_before_after(diag, res, res_fu2):
    rows = []
    # Year 0 Elementary example
    def pick(df, year, name):
        if df.empty:
            return None
        sub = df[(df["year"] == year) & (df["name"] == name)]
        return sub.iloc[0] if not sub.empty else None

    e0_before = pick(res_fu2, 0, "Elementary (K-5)")
    e0_after = pick(res, 0, "Elementary (K-5)")
    if e0_before is not None and e0_after is not None:
        rows.append({
            "year": 0, "resource_name": "Elementary (K-5)",
            "issue_type": "year0_education_overflow_misclassified",
            "before_value": e0_before.get("education_local_seat_refused", e0_before.get("effective_refused_or_overflow")),
            "after_value": e0_after.get("education_local_seat_refused"),
            "corrected_yes_no": "yes" if _isna(e0_after.get("education_local_seat_refused")) else "no",
            "explanation": "Y0 refused set to NA (was demand when claims=0 before enrollment)",
            "notes": f"stage={e0_after.get('snapshot_stage')}",
        })
    # requester-basis clarification Middle Y2
    m2b = pick(res_fu2, 2, "Middle (6-8)")
    m2a = pick(res, 2, "Middle (6-8)")
    if m2b is not None and m2a is not None:
        rows.append({
            "year": 2, "resource_name": "Middle (6-8)",
            "issue_type": "requester_basis_vs_effective_overflow_clarification",
            "before_value": (f"waiting_or_refused={m2b.get('waiting_or_refused')}; "
                             f"effective={m2b.get('effective_refused_or_overflow')}"),
            "after_value": (f"requester_basis={m2a.get('waiting_or_refused_requester_basis')}; "
                            f"legacy={m2a.get('waiting_or_refused_legacy')}; "
                            f"effective={m2a.get('effective_refused_or_overflow')}"),
            "corrected_yes_no": "yes",
            "explanation": "requester-basis kept as audit; effective uses local_seat_refused",
            "notes": "students refused local seats only, not schooling",
        })
    # Bus daily
    for year in [1, 5]:
        db = pick(res_fu2, year, "Bus Service Daily Capacity")
        da = pick(res, year, "Bus Service Daily Capacity")
        if db is not None and da is not None:
            rows.append({
                "year": year, "resource_name": "Bus Service Daily Capacity",
                "issue_type": "bus_daily_utilization_mislabel",
                "before_value": db.get("utilization"),
                "after_value": (f"utilization={da.get('utilization')}; "
                                f"ratio={da.get('annual_demand_to_daily_capacity_ratio')}"),
                "corrected_yes_no": "yes" if _isna(da.get("utilization")) else "no",
                "explanation": "utilization NA; annual_demand_to_daily_capacity_ratio added",
                "notes": "",
            })
            break
    # Road
    rb = pick(res_fu2, 1, "Road: Arterial") if not res_fu2.empty else None
    if rb is None and not res_fu2.empty:
        roads = res_fu2[res_fu2["name"].astype(str).str.startswith("Road:")]
        rb = roads.iloc[0] if not roads.empty else None
    ra = None
    if not res.empty:
        roads = res[res["name"].astype(str).str.startswith("Road:")]
        ra = roads.iloc[0] if not roads.empty else None
    if rb is not None and ra is not None:
        rows.append({
            "year": int(ra["year"]), "resource_name": ra["name"],
            "issue_type": "road_status_in_numeric_refusal_columns",
            "before_value": rb.get("waiting_or_refused"),
            "after_value": (f"waiting_or_refused={ra.get('waiting_or_refused')}; "
                            f"road_status={ra.get('road_status')}"),
            "corrected_yes_no": "yes" if _isna(ra.get("waiting_or_refused")) else "no",
            "explanation": "numeric refusal cols NA; status moved to road_status",
            "notes": "",
        })
    # blank string normalization
    if not res.empty:
        blank_count = 0
        for col in ["education_local_seat_demand", "education_local_seat_refused",
                    "education_external_school_count"]:
            if col in res.columns:
                blank_count += int((res[col].astype(str).str.strip() == "").sum())
        rows.append({
            "year": "all", "resource_name": "(non-education rows)",
            "issue_type": "non_applicable_education_fields_blank_strings",
            "before_value": "empty strings '' on non-education rows (FU2)",
            "after_value": f"blank_string_count={blank_count} (expect 0; null/NA used)",
            "corrected_yes_no": "yes" if blank_count == 0 else "no",
            "explanation": "education-only fields null/NA for non-education resources",
            "notes": "",
        })
    _write(pd.DataFrame(rows), diag / "phase8a_fu3_resource_schema_before_after.csv")


def _fu2_comparison(run_dir, fu2_dir, base_filename, diag):
    a_fu = _safe_read(run_dir / "outputs" / f"{base_filename}_annual_summary.csv")
    a_rf = _safe_read(fu2_dir / "outputs" / "mastercode02_output_phase8a_fu2_seed123_annual_summary.csv")
    r_fu = _safe_read(run_dir / "outputs" / f"{base_filename}_summary_resources.csv")
    r_rf = _safe_read(fu2_dir / "outputs" / "mastercode02_output_phase8a_fu2_seed123_summary_resources.csv")
    sc_fu = _safe_read(run_dir / "outputs" / f"{base_filename}_scores_summary.csv")
    sc_rf = _safe_read(fu2_dir / "outputs" / "mastercode02_output_phase8a_fu2_seed123_scores_summary.csv")
    p_fu = _safe_read(run_dir / "outputs" / f"{base_filename}_population_datasheet.csv")
    p_rf = _safe_read(fu2_dir / "outputs" / "mastercode02_output_phase8a_fu2_seed123_population_datasheet.csv")

    rows = []
    if a_fu.empty or a_rf.empty:
        df = pd.DataFrame(rows)
        _write(df, diag / "phase8a_fu3_phase8a_fu2_comparison.csv")
        return df, False

    def rv(df, year, name, col="waiting_or_refused"):
        if df.empty:
            return np.nan
        sub = df[(df["year"] == year) & (df["name"] == name)]
        return _num(sub.iloc[0][col]) if not sub.empty else np.nan

    for year in sorted(a_fu["Year"].unique()):
        xf = a_fu[a_fu["Year"] == year].iloc[0]
        xr = a_rf[a_rf["Year"] == year].iloc[0]
        pf, pr = float(xf["Population"]), float(xr["Population"])
        pairs = [
            ("population", pr, pf),
            ("births", float(xr["No of births"]), float(xf["No of births"])),
            ("deaths", float(xr["No. of Deaths"]), float(xf["No. of Deaths"])),
            ("cbr_per_1000", 1000 * float(xr["No of births"]) / pr if pr else 0,
             1000 * float(xf["No of births"]) / pf if pf else 0),
            ("cdr_per_1000", 1000 * float(xr["No. of Deaths"]) / pr if pr else 0,
             1000 * float(xf["No. of Deaths"]) / pf if pf else 0),
            ("employment_rate", float(xr["Employment Rate"]), float(xf["Employment Rate"])),
            ("rental_vacancy", float(xr["Rental_Vacancy_Rate"]), float(xf["Rental_Vacancy_Rate"])),
            ("overall_vacancy", float(xr["Overall_Vacancy_Rate"]), float(xf["Overall_Vacancy_Rate"])),
            ("renter_households", float(xr["Renter_Occupied_HH"]), float(xf["Renter_Occupied_HH"])),
            ("owner_households", float(xr["Owner_Occupied_HH"]), float(xf["Owner_Occupied_HH"])),
            ("genuine_insecure", float(xr["Genuine_Housing_Insecure_HH_Count"]),
             float(xf["Genuine_Housing_Insecure_HH_Count"])),
            ("archived_household_count", float(xr["Archived_Household_Count"]),
             float(xf["Archived_Household_Count"])),
            ("avg_income", float(xr["Avg Annual Income"]), float(xf["Avg Annual Income"])),
            ("total_cars", float(xr["Total Number of Cars"]), float(xf["Total Number of Cars"])),
            ("accidents", float(xr["Number of Accidents on road"]),
             float(xf["Number of Accidents on road"])),
            ("bus_refused_trips", rv(r_rf, year, "Bus Service"), rv(r_fu, year, "Bus Service")),
        ]
        for lvl in EDUCATION_CAPACITIES:
            pairs.append((f"edu_inuse::{lvl}", rv(r_rf, year, lvl, "in_use"),
                          rv(r_fu, year, lvl, "in_use")))
        if (not sc_rf.empty and not sc_fu.empty and year in set(sc_rf["year"])
                and year in set(sc_fu["year"])):
            er = sc_rf[sc_rf["year"] == year].iloc[0]
            ef = sc_fu[sc_fu["year"] == year].iloc[0]
            pairs.append(("economic_index", float(er["economic_index"]), float(ef["economic_index"])))
            pairs.append(("transport_index", float(er["transport_index"]), float(ef["transport_index"])))
        for metric, vr_, vf_ in pairs:
            if (vr_ != vr_) or (vf_ != vf_):
                diff, match = np.nan, ((vr_ != vr_) and (vf_ != vf_))
            else:
                diff = float(vf_) - float(vr_)
                match = bool(abs(diff) < 1e-9)
            rows.append({"year": year, "metric": metric, "phase8a_fu2_value": vr_,
                         "phase8a_fu3_value": vf_, "absolute_diff": diff, "match": match})

    if not p_fu.empty and not p_rf.empty:
        fy = int(max(p_fu["year"]))

        def edu(df, level):
            return float((df[df["year"] == fy]["education_level"] == level).sum())

        def wa(df):
            w = df[(df["year"] == fy) & (df["age"] >= 18) & (df["age"] <= 64)]
            return float((w["employment_status"] == "Employed").sum()) / len(w) if len(w) else np.nan

        for lvl in ["Nursery/Preschool", "Elementary (K-5)", "Middle (6-8)", "High School (9-12)",
                    "University", "Community College", "masters_program", "phd_program",
                    "high_school_completed", "college_completed", "masters_completed",
                    "phd_completed", "high_school_dropout", "college_dropout"]:
            vr_, vf_ = edu(p_rf, lvl), edu(p_fu, lvl)
            rows.append({"year": fy, "metric": f"edu_count_final::{lvl}",
                         "phase8a_fu2_value": vr_, "phase8a_fu3_value": vf_,
                         "absolute_diff": vf_ - vr_, "match": bool(abs(vf_ - vr_) < 1e-9)})
        vr_, vf_ = wa(p_rf), wa(p_fu)
        rows.append({"year": fy, "metric": "working_age_employment_rate_final",
                     "phase8a_fu2_value": vr_, "phase8a_fu3_value": vf_,
                     "absolute_diff": (vf_ - vr_) if (vr_ == vr_ and vf_ == vf_) else np.nan,
                     "match": bool(abs(vf_ - vr_) < 1e-9) if (vr_ == vr_ and vf_ == vf_) else False})

    df = pd.DataFrame(rows)
    _write(df, diag / "phase8a_fu3_phase8a_fu2_comparison.csv")
    sci_match = bool(df["match"].all()) if not df.empty else False
    return df, sci_match


def _invariants(diag, res, sci_match):
    rows = []

    def add(name, ok, vc=0, ex="", sev="INFO", notes="", year="all"):
        rows.append({"year": year, "invariant_name": name,
                     "pass_fail": "PASS" if ok else "FAIL",
                     "violation_count": vc, "example_ids": ex,
                     "severity": sev, "notes": notes})

    if res.empty:
        add("resource_summary_present", False, sev="HIGH")
        _write(pd.DataFrame(rows), diag / "phase8a_fu3_resource_logging_invariants.csv")
        return False

    y0 = res[(res["year"] == 0) & (res["name"].isin(EDU_LEVELS))]
    add("1_y0_snapshot_stage_pre_enrollment",
        bool((y0["snapshot_stage"] == "pre_enrollment_baseline").all()) if not y0.empty else False,
        sev="HIGH")
    eval_col = y0["education_enrollment_evaluated"].astype(str).str.lower()
    add("2_y0_enrollment_evaluated_false",
        bool(eval_col.isin(["false", "0"]).all()) if not y0.empty else False, sev="HIGH")
    add("3_y0_local_seat_refused_null",
        bool(y0["education_local_seat_refused"].apply(_isna).all()) if not y0.empty else False,
        sev="HIGH")
    add("4_y0_external_school_count_null",
        bool(y0["education_external_school_count"].apply(_isna).all()) if not y0.empty else False,
        sev="HIGH")
    add("5_y0_effective_refused_null",
        bool(y0["effective_refused_or_overflow"].apply(_isna).all()) if not y0.empty else False,
        sev="HIGH")

    y1p = res[(res["year"] >= 1) & (res["name"].isin(EDU_LEVELS))]
    arith_ok, ext_ok, claims_ok = True, True, True
    for _, r in y1p.iterrows():
        demand = _num(r["education_local_seat_demand"])
        claims = _num(r["in_use"])
        refused = _num(r["education_local_seat_refused"])
        ext = _num(r["education_external_school_count"])
        cap = _num(r["capacity"])
        if refused != max(0, demand - claims):
            arith_ok = False
        if ext != refused:
            ext_ok = False
        if claims > cap:
            claims_ok = False
    add("6_y1plus_refused_eq_max0_demand_minus_claims", arith_ok, sev="HIGH")
    add("7_y1plus_external_eq_refused", ext_ok, sev="HIGH")
    add("8_local_claims_le_capacity", claims_ok, sev="HIGH")

    daily = res[res["name"] == "Bus Service Daily Capacity"]
    add("9_bus_daily_utilization_null",
        bool(daily["utilization"].apply(_isna).all()) if not daily.empty else False, sev="HIGH")
    add("10_bus_daily_ratio_populated",
        bool(daily["annual_demand_to_daily_capacity_ratio"].notna().all()) if not daily.empty else False,
        sev="HIGH")
    annual = res[res["name"] == "Bus Service"]
    util_ok = True
    for _, r in annual.iterrows():
        u = _num(r["utilization"])
        if u != u or u > 1.0 + 1e-9:
            util_ok = False
    add("11_annual_bus_utilization_valid_le1", util_ok, sev="MEDIUM")

    roads = res[res["name"].astype(str).str.startswith("Road:")]
    road_num_ok = True
    road_status_ok = True
    for _, r in roads.iterrows():
        if not (_isna(r.get("waiting_or_refused")) and _isna(r.get("effective_refused_or_overflow"))):
            road_num_ok = False
        if _isna(r.get("road_status")):
            road_status_ok = False
    add("12_road_refusal_cols_null", road_num_ok, sev="HIGH")
    add("13_road_status_populated", road_status_ok, sev="HIGH")

    non_edu = res[~res["name"].isin(EDU_LEVELS)]
    na_ok = True
    for _, r in non_edu.iterrows():
        for col in ["education_local_seat_demand", "education_local_seat_refused",
                    "education_external_school_count"]:
            if col in r and not _isna(r[col]):
                # housing etc should be NA
                na_ok = False
    add("14_non_education_edu_fields_null", na_ok, sev="MEDIUM")
    add("15_scientific_metrics_match_fu2", sci_match, sev="HIGH")
    add("16_no_additional_rng_draws", sci_match, sev="HIGH",
        notes="scientific outputs identical => no RNG change")

    _write(pd.DataFrame(rows), diag / "phase8a_fu3_resource_logging_invariants.csv")
    return bool(all(r["pass_fail"] == "PASS" for r in rows))


def _red_flags(diag):
    rows = [
        {"severity": "INFO", "subsystem": "resource_logging_schema",
         "finding": "Year 0 education overflow misclassification corrected; schema fields added",
         "evidence": "phase8a_fu3_year0_education_snapshot_audit.csv",
         "consequence": "Resource summary no longer overstates Y0 refused",
         "recommended_fix_phase": "none", "should_fix_now_yes_no": "no"},
        {"severity": "LOW", "subsystem": "education_external_modeling",
         "finding": "External/out-of-town remains observational count (no explicit school module)",
         "evidence": "FU2/FU3 overflow accounting",
         "consequence": "Optional future module only if analysis needs it",
         "recommended_fix_phase": "optional_future_external_school_module",
         "should_fix_now_yes_no": "no"},
        {"severity": "INFO", "subsystem": "next_phase",
         "finding": "Resource logging schema hardened; scientific outputs stable vs FU2",
         "evidence": "phase8a_fu3_phase8a_fu2_comparison.csv; invariants",
         "consequence": "Safe to proceed to Phase 9A runner/CLI harness",
         "recommended_fix_phase": "phase9a_runner_cli_test_harness",
         "should_fix_now_yes_no": "no"},
    ]
    _write(pd.DataFrame(rows), diag / "phase8a_fu3_red_flags.csv")


def _recommendations(diag):
    rows = [
        {"priority": 1,
         "recommendation": "Proceed to Phase 9A runner/CLI + regression test harness",
         "type": "next_phase", "expected_model_impact": "none", "risk_level": "low",
         "files_likely_to_change": "new runner/tests", "should_be_next_phase_yes_no": "yes",
         "notes": "Resource logging schema now consistent; FU2 overflow preserved"},
        {"priority": 2,
         "recommendation": "No further resource-logging hardening required for education Y0/bus/road",
         "type": "no_action", "expected_model_impact": "none", "risk_level": "none",
         "files_likely_to_change": "none", "should_be_next_phase_yes_no": "no", "notes": ""},
        {"priority": 3,
         "recommendation": "Address Phase 8B only if in-process replay of ALL diagnostics is needed",
         "type": "optional", "expected_model_impact": "none on scientific outputs",
         "risk_level": "low", "files_likely_to_change": "reset path + phase diagnostic modules",
         "should_be_next_phase_yes_no": "no", "notes": "Not blocking Phase 9A"},
    ]
    _write(pd.DataFrame(rows), diag / "phase8a_fu3_upgrade_recommendations.csv")


def _write_manifest(run_dir, fu2_dir, seed, sci_match):
    import salabim as sim
    import statsmodels
    git_hash = None
    try:
        r = subprocess.run(["git", "rev-parse", "HEAD"], cwd=run_dir.parents[1],
                           capture_output=True, text=True, timeout=10, check=False)
        if r.returncode == 0:
            git_hash = r.stdout.strip()
    except Exception:
        pass
    from mastercode02_config_and_rates import SIMULATION_DURATION
    man = {
        "run_id": run_dir.name,
        "timestamp": __import__("datetime").datetime.now(
            __import__("datetime").timezone.utc).isoformat(),
        "python_version": sys.version,
        "salabim_version": getattr(sim, "__version__", "unknown"),
        "pandas_version": pd.__version__, "numpy_version": np.__version__,
        "statsmodels_version": getattr(statsmodels, "__version__", "unknown"),
        "operating_system": platform.platform(), "seed": seed,
        "simulation_duration": SIMULATION_DURATION,
        "source_folder": str(run_dir / "src"),
        "output_folder": str(run_dir / "outputs"),
        "diagnostics_folder": str(run_dir / "diagnostics"),
        "base_source_folder": str(fu2_dir / "src"),
        "reference_output_folder": str(fu2_dir / "outputs"),
        "git_commit_hash": git_hash,
        "statement_controlled_logging_schema_fix":
            "Phase 8A-FU3 is a controlled resource logging/schema correction.",
        "statement_year0_pre_enrollment":
            "Year 0 education rows are treated as pre-enrollment baseline (refused/external NA).",
        "statement_education_progression_unchanged":
            "Education progression was NOT changed.",
        "statement_education_capacities_unchanged":
            "Education capacities were NOT changed.",
        "statement_no_education_probabilities_changed":
            "No education probabilities were changed.",
        "statement_no_other_logic_changed":
            "No housing/fertility/mortality/immigration/employment/transit/reset/ML changed.",
        "scientific_outputs_match_fu2": bool(sci_match),
    }
    (run_dir / "diagnostics" / "phase8a_fu3_run_manifest.json").write_text(
        json.dumps(man, indent=2), encoding="utf-8")


def _write_change_log(diag, sci_match):
    txt = f"""# Phase 8A-FU3 Change Log

| File | Category | Reason |
|------|----------|--------|
| `mastercode02_logging.py` (`_log_annual_resource_summary`) | logging/schema | Year 0 education refused/external/effective → null; theoretical gap field; snapshot_stage / enrollment_evaluated / metric_basis; bus daily utilization → null + ratio; road status column; null NA not blank strings; waiting_or_refused_legacy |
| `mastercode02_education_overflow.py` | diagnostics | Align Year 0 refused/external to null; pre_enrollment_not_evaluated status; skip Y0 overflow events |
| `notebooks/run_phase8a_fu3.py` | diagnostics (new) | Single fresh-process run; reset_global_state verbatim |
| `mastercode02_phase8a_fu3_postrun.py` | diagnostics (new) | Schema audits, FU2 comparison, invariants, plots, report |

## Logging/schema defects fixed
1. Year 0 education demand-claims reported as refused before enrollment.
2. Requester-basis vs effective overflow unclear.
3. Bus Daily Capacity utilization = annual_demand/daily_capacity (>1).
4. Road status text in numeric refusal columns.
5. Blank strings in non-applicable education columns.

## Confirmations
- Progression NOT changed (scientific match FU2: {sci_match}).
- Capacities / probabilities / RNG NOT changed.
- Year 1+ FU2 overflow arithmetic preserved.
- Non-education model logic NOT changed.
"""
    (diag / "phase8a_fu3_change_log.md").write_text(txt, encoding="utf-8")


def _make_plots(plots, res, ref_cmp, diag):
    def _try(fn):
        try:
            fn()
        except Exception as exc:
            print(f"plot warning: {exc}")

    def p1():
        y0 = res[(res["year"] == 0) & (res["name"].isin(EDU_LEVELS))]
        if y0.empty:
            return
        fig, ax = plt.subplots(figsize=(9, 4.5))
        x = np.arange(len(y0))
        demand = pd.to_numeric(y0["education_local_seat_demand"], errors="coerce")
        gap = pd.to_numeric(y0["theoretical_pre_enrollment_demand_minus_capacity"], errors="coerce")
        ax.bar(x - 0.2, demand, 0.4, label="pre-enrollment demand")
        ax.bar(x + 0.2, gap.fillna(0), 0.4, label="theoretical demand-capacity gap")
        ax.set_xticks(x)
        ax.set_xticklabels(y0["name"], rotation=45, ha="right", fontsize=7)
        ax.set_title("Year 0 education: pre-enrollment demand vs theoretical capacity gap")
        ax.legend(fontsize=7)
        fig.tight_layout()
        fig.savefig(plots / "01_year0_demand_vs_theoretical_gap.png")
        plt.close(fig)

    def p2():
        y1p = res[(res["year"] >= 1) & (res["name"].isin(EDU_LEVELS))]
        if y1p.empty:
            return
        fig, ax = plt.subplots(figsize=(9, 4.5))
        for lvl in ["Middle (6-8)", "High School (9-12)", "University",
                    "masters_program", "phd_program"]:
            sub = y1p[y1p["name"] == lvl]
            if sub.empty:
                continue
            ax.plot(sub["year"], pd.to_numeric(sub["education_local_seat_refused"], errors="coerce"),
                    "-o", label=lvl)
        ax.set_title("Year 1+ education local-seat refused by level")
        ax.legend(fontsize=7)
        fig.tight_layout()
        fig.savefig(plots / "02_y1plus_demand_claims_refused.png")
        plt.close(fig)

    def p3():
        annual = res[res["name"] == "Bus Service"]
        daily = res[res["name"] == "Bus Service Daily Capacity"]
        if annual.empty or daily.empty:
            return
        fig, ax = plt.subplots(figsize=(8, 4.5))
        ax.plot(annual["year"], pd.to_numeric(annual["utilization"], errors="coerce"),
                "-o", label="annual Bus Service utilization")
        ax.plot(daily["year"],
                pd.to_numeric(daily["annual_demand_to_daily_capacity_ratio"], errors="coerce"),
                "-s", label="daily diagnostic ratio")
        ax.set_title("Bus annual utilization vs daily diagnostic ratio")
        ax.legend()
        fig.tight_layout()
        fig.savefig(plots / "03_bus_annual_vs_daily_ratio.png")
        plt.close(fig)

    def p4():
        roads = res[res["name"].astype(str).str.startswith("Road:")]
        if roads.empty:
            return
        fig, ax = plt.subplots(figsize=(8, 4))
        ok = roads.apply(
            lambda r: _isna(r.get("waiting_or_refused")) and not _isna(r.get("road_status")),
            axis=1)
        counts = ok.value_counts()
        labels = ["schema_ok" if i else "schema_fail" for i in counts.index]
        ax.bar(labels, counts.values, color=["seagreen", "crimson"][:len(labels)])
        ax.set_title("Road status schema check (numeric refusal NA + road_status set)")
        fig.tight_layout()
        fig.savefig(plots / "04_road_status_schema.png")
        plt.close(fig)

    def p5():
        inv = _safe_read(diag / "phase8a_fu3_resource_logging_invariants.csv")
        if inv.empty:
            return
        fig, ax = plt.subplots(figsize=(8, 4))
        vc = inv["pass_fail"].value_counts()
        ax.bar(vc.index.astype(str), vc.values,
               color=["seagreen" if i == "PASS" else "crimson" for i in vc.index])
        ax.set_title("Resource schema invariant pass/fail")
        fig.tight_layout()
        fig.savefig(plots / "05_invariant_pass_fail.png")
        plt.close(fig)

    def p6():
        if ref_cmp.empty:
            return
        core = ref_cmp[ref_cmp["metric"].isin(
            ["population", "employment_rate", "avg_income", "total_cars"])].copy()
        core["absolute_diff"] = pd.to_numeric(core["absolute_diff"], errors="coerce")
        fig, ax = plt.subplots(figsize=(9, 4.5))
        piv = core.pivot_table(index="year", columns="metric",
                               values="absolute_diff", aggfunc="first")
        piv.plot(ax=ax, marker="o")
        ax.axhline(0, color="gray", lw=0.8)
        ax.set_title("Phase 8A-FU2 vs FU3 core-output diffs (expect 0)")
        fig.tight_layout()
        fig.savefig(plots / "06_fu2_vs_fu3_core.png")
        plt.close(fig)

    def p7():
        rf = _safe_read(diag / "phase8a_fu3_red_flags.csv")
        if rf.empty:
            return
        fig, ax = plt.subplots(figsize=(7, 4))
        sev = rf["severity"].value_counts()
        ax.bar(sev.index.astype(str), sev.values, color="darkorange")
        ax.set_title("Remaining red flags")
        fig.tight_layout()
        fig.savefig(plots / "07_red_flags.png")
        plt.close(fig)

    for fn in (p1, p2, p3, p4, p5, p6, p7):
        _try(fn)


def _write_report(diag, res, res_fu2, ref_cmp, sci_match, inv_ok):
    def tbl(df):
        return df.to_string(index=False) if not df.empty else "(none)"

    y0 = _safe_read(diag / "phase8a_fu3_year0_education_snapshot_audit.csv")
    post = _safe_read(diag / "phase8a_fu3_education_overflow_post_enrollment_audit.csv")
    bus = _safe_read(diag / "phase8a_fu3_bus_daily_capacity_schema_audit.csv")
    road = _safe_read(diag / "phase8a_fu3_road_schema_audit.csv")
    inv = _safe_read(diag / "phase8a_fu3_resource_logging_invariants.csv")
    ba = _safe_read(diag / "phase8a_fu3_resource_schema_before_after.csv")
    mism = ref_cmp[ref_cmp["match"] != True] if not ref_cmp.empty else pd.DataFrame()
    post_pass = bool(post["arithmetic_pass"].all()) if not post.empty else False

    report = f"""# Phase 8A-FU3 — Resource Logging Schema & Year-0 Education Snapshot Fix Report

**Status:** {"PASSED" if (sci_match and inv_ok) else "REVIEW"}  
**Type:** Controlled logging/schema correction (no model/education/RNG changes)  
**Reference:** Phase 8A-FU2 outputs

## Answers

1. **What exact Year 0 education logging defect was fixed?**  
   Year 0 rows treated `demand - in_use` as local-seat refused/external/effective overflow when
   `in_use=0` because enrollment had not yet run (`EducationManager` holds 1 before first enroll).

2. **Why was Year 0 not valid as a post-enrollment overflow row?**  
   `YearlyReporter` logs at `hold(0)`; first education enrollment runs after `hold(1)`. Claims are
   zero by construction — not because every student was refused a local seat.

3. **How are Year 0 education rows now labeled?**  
   `snapshot_stage=pre_enrollment_baseline`, `education_enrollment_evaluated=False`,
   `metric_basis=pre_enrollment_not_refusal`.

4. **How is theoretical pre-enrollment demand-minus-capacity represented?**  
   Column `theoretical_pre_enrollment_demand_minus_capacity = max(0, demand - capacity)` at Year 0
   only. It is **not** a refusal count.

5. **How are Year 1+ education overflow/refusal rows preserved?**  
   FU2 arithmetic unchanged: refused = max(0, demand - claims); external = refused;
   effective = refused. Arithmetic pass across Y1+: {post_pass}.

6. **How are requester-basis and effective overflow separated?**  
   `waiting_or_refused` / `waiting_or_refused_requester_basis` / `waiting_or_refused_legacy` keep
   `len(requesters())` for audit. `effective_refused_or_overflow` uses local-seat refused after
   enrollment (education) or the appropriate numeric refusal for other resources. Local refusal ≠
   denied schooling.

7. **What changed for Bus Service Daily Capacity?**  
   `utilization=null/NA`; `annual_demand_to_daily_capacity_ratio = annual_demand/daily_capacity`.
   Annual Bus Service utilization unchanged (annual demand / annual capacity).

8. **What changed for road status rows?**  
   Numeric refusal columns are null; status text lives in `road_status`.

9. **Were non-applicable fields normalized to null/NA?**  
   Yes — education-only fields on non-education rows use `None` (CSV null), not blank strings.

10. **Did any scientific/model metric change?** {sci_match} (expect True / match).

11. **Did education progression change?** No.

12. **Did any capacity or probability change?** No.

13. **Did RNG behavior change?** No (scientific outputs identical to FU2).

14. **What red flags remain?** INFO schema fix complete; LOW optional external-school module later;
    INFO Phase 9A is the recommended next phase.

15. **Is Phase 9A now safe to proceed?** Yes — logging schema hardened, FU2 overflow preserved,
    scientific outputs stable.

## Year 0 education snapshot audit
```
{tbl(y0)}
```

## Schema before/after
```
{tbl(ba)}
```

## Bus daily capacity schema
```
{tbl(bus)}
```

## Road schema (sample)
```
{tbl(road.head(12))}
```

## Invariants
```
{tbl(inv)}
```

## Scientific comparison mismatches (expect none)
```
{tbl(mism)}
```

## Stop
Phase 8A-FU3 is complete. Do NOT implement Phase 9A, Phase 8B, external-school module,
progression changes, or ML in this phase.
"""
    (diag / "phase8a_fu3_resource_logging_schema_year0_fix_report.md").write_text(
        report, encoding="utf-8")
