# -*- coding: utf-8 -*-
"""VISION Core — portable execution wrapper.

This script does NOT implement any demographic logic. It prepares paths, validates
parameters, creates the output layout, launches the ORIGINAL frozen engine entry point
(engine/tools/run_mastercode02.py) as a subprocess, and writes provenance.

DURATION SEMANTICS (verified by direct source read, do not change without re-verifying):
    --years N  ->  engine --duration N
    The engine writes N+1 annual rows, calendar 2000 .. 2000+N.
    So N is the number of ANNUAL TRANSITIONS and N+1 is the number of checkpoints.
    MODEL_YEARS = 23  ->  calendar 2000 through 2023, 23 transitions, 24 checkpoints.
    (Cross-checked: the authoritative VIG run used duration 23 and produced 24 annual rows;
     the Core benchmark run used duration 24 and produced 25.)

Usage:
    python run_core.py --years 23 --seed 20230101 --scenario canonical --run-label example_core
    python run_core.py --years 2  --seed 314159   --scenario smoke     --run-label core_smoke_100
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import subprocess
import sys
import time

PKG = os.path.dirname(os.path.abspath(__file__))
ENGINE = os.path.join(PKG, "engine")
ENGINE_SRC = os.path.join(ENGINE, "src")
ENGINE_ENTRY = os.path.join(ENGINE, "tools", "run_mastercode02.py")
CONFIG = os.path.join(PKG, "config")
OUTPUTS = os.path.join(PKG, "outputs")

SCENARIOS = {
    # name        -> (t0 json,                               config overrides json)
    "canonical": (os.path.join(CONFIG, "canonical", "jc_year2000_t0_input.json"),
                  os.path.join(CONFIG, "canonical", "jc_config_overrides_final_2000_2023.json")),
    "baseline": (os.path.join(CONFIG, "canonical", "jc_year2000_t0_input.json"), None),
    "smoke": (os.path.join(CONFIG, "smoke", "smoke_t0_100.json"), None),
    "custom": (None, None),
}


def _resolve_scenario(name, custom_t0, custom_overrides):
    if name not in SCENARIOS:
        raise SystemExit("unknown scenario %r; choose from %s"
                         % (name, ", ".join(sorted(SCENARIOS))))
    t0, ov = SCENARIOS[name]
    if name == "custom":
        t0, ov = custom_t0, custom_overrides
    for label, p in (("t0", t0), ("config-overrides", ov)):
        if p and not os.path.isfile(p):
            raise SystemExit("scenario %r: %s file not found: %s" % (name, label, p))
    return t0, ov


def _write_json(path, payload):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, default=str)


def _package_versions():
    out = {}
    for mod in ("salabim", "numpy", "pandas", "sklearn", "xgboost", "joblib", "pyarrow"):
        try:
            m = __import__(mod)
            out[mod] = getattr(m, "__version__", "unknown")
        except Exception:
            out[mod] = None
    return out


def _git_commit():
    try:
        r = subprocess.run(["git", "rev-parse", "HEAD"], cwd=PKG, capture_output=True,
                           text=True, timeout=10)
        return r.stdout.strip() or None
    except Exception:
        return None


def main(argv=None):
    ap = argparse.ArgumentParser(description="Run VISION Core from the portable package.")
    ap.add_argument("--years", type=int, required=True,
                    help="Annual transitions. N produces N+1 annual rows, calendar 2000..2000+N.")
    ap.add_argument("--seed", type=int, required=True)
    ap.add_argument("--scenario", default="canonical", choices=sorted(SCENARIOS))
    ap.add_argument("--run-label", required=True)
    ap.add_argument("--checkpoint-every-years", type=int, default=1)
    ap.add_argument("--t0-json", default=None, help="custom scenario only")
    ap.add_argument("--config-overrides-json", default=None, help="custom scenario only")
    ap.add_argument("--events-json", default=None,
                    help="existing model scenario events (public_health/political_stability/panic)")
    ap.add_argument("--output-root", default=None,
                    help="default: <package>/outputs/user_runs")
    ap.add_argument("--force-overwrite", action="store_true")
    args = ap.parse_args(argv)

    if args.years < 1:
        raise SystemExit("--years must be >= 1")
    if not os.path.isfile(ENGINE_ENTRY):
        raise SystemExit("engine entry point missing: %s" % ENGINE_ENTRY)

    t0_json, overrides_json = _resolve_scenario(args.scenario, args.t0_json,
                                                args.config_overrides_json)

    # the engine resolves RELATIVE output paths against its own root, so always pass absolute
    root = os.path.abspath(args.output_root or os.path.join(OUTPUTS, "user_runs"))
    run_dir = os.path.join(root, args.run_label)
    if os.path.isdir(run_dir) and os.listdir(run_dir) and not args.force_overwrite:
        raise SystemExit("run directory already exists and is not empty: %s\n"
                         "pass --force-overwrite to reuse it." % run_dir)
    out_dir = os.path.join(run_dir, "outputs")
    diag_dir = os.path.join(run_dir, "diagnostics")
    log_dir = os.path.join(run_dir, "logs")
    prov_dir = os.path.join(run_dir, "provenance")
    for d in (out_dir, diag_dir, log_dir, prov_dir):
        os.makedirs(d, exist_ok=True)

    cmd = [sys.executable, ENGINE_ENTRY,
           "--seed", str(args.seed),
           "--duration", str(args.years),
           "--output-dir", out_dir,
           "--diagnostics-dir", diag_dir,
           "--run-label", args.run_label,
           "--source-dir", ENGINE_SRC,
           "--checkpoint-every-years", str(args.checkpoint_every_years),
           "--force"]
    if t0_json:
        cmd += ["--t0-json", t0_json]
    if overrides_json:
        cmd += ["--config-overrides-json", overrides_json]
    if args.events_json:
        cmd += ["--events-json", args.events_json]

    request = {
        "model": "VISION Core", "run_label": args.run_label, "scenario": args.scenario,
        "years_transitions": args.years, "expected_annual_rows": args.years + 1,
        "calendar_span": "2000..%d" % (2000 + args.years),
        "seed": args.seed, "checkpoint_every_years": args.checkpoint_every_years,
        "t0_json": t0_json, "config_overrides_json": overrides_json,
        "events_json": args.events_json,
        "engine_entry_point": ENGINE_ENTRY, "command": cmd,
        "started_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }
    _write_json(os.path.join(prov_dir, "run_request.json"), request)
    _write_json(os.path.join(prov_dir, "environment.json"), {
        "python_version": sys.version, "python_executable": sys.executable,
        "platform": platform.platform(), "packages": _package_versions(),
        "git_commit": _git_commit(), "package_root": PKG,
    })
    manifest_src = os.path.join(ENGINE, "ENGINE_SOURCE_SHA256_MANIFEST.json")
    if os.path.isfile(manifest_src):
        with open(manifest_src, encoding="utf-8") as f:
            _write_json(os.path.join(prov_dir, "source_manifest.json"), json.load(f))

    print("[run_core] scenario=%s years=%d (calendar 2000..%d) seed=%d"
          % (args.scenario, args.years, 2000 + args.years, args.seed), flush=True)
    print("[run_core] engine: %s" % ENGINE_ENTRY, flush=True)
    print("[run_core] run dir: %s" % run_dir, flush=True)

    t = time.time()
    with open(os.path.join(log_dir, "stdout.log"), "w", encoding="utf-8") as so, \
            open(os.path.join(log_dir, "stderr.log"), "w", encoding="utf-8") as se:
        rc = subprocess.call(cmd, stdout=so, stderr=se, cwd=ENGINE)
    elapsed = time.time() - t

    request.update({"finished_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                    "elapsed_seconds": round(elapsed, 2), "return_code": rc})
    _write_json(os.path.join(prov_dir, "run_request.json"), request)

    print("[run_core] return code %d in %.1f s" % (rc, elapsed), flush=True)
    if rc != 0:
        tail = ""
        p = os.path.join(log_dir, "stderr.log")
        if os.path.isfile(p):
            with open(p, encoding="utf-8", errors="replace") as f:
                tail = f.read()[-2000:]
        print("[run_core] stderr tail:\n%s" % tail, flush=True)
    return rc


if __name__ == "__main__":
    sys.exit(main())
