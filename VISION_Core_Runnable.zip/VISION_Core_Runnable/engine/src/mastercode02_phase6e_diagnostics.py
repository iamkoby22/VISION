"""Phase 6E diagnostics — observation only."""
from __future__ import annotations

import mastercode02_globals as g
from mastercode02_config_and_rates import HOUSING_STOCK
from mastercode02_housing_ledger import (
    stock_vacancy_snapshot,
    household_has_active_housing_claim,
    get_household_housing_claim,
    get_housing_active_claim_count,
    get_housing_capacity,
    get_housing_available_count,
    HOUSING_LEDGER_ACTIVE,
)


PHASE6E_LOG: dict = {
    "stock_vacancy": [],
    "consistency": [],
    "invariants": [],
}


def snapshot_yearly_phase6e(year: int, env=None) -> None:
    snap = stock_vacancy_snapshot()
    interp = (
        "stock_full"
        if snap["total_housing_available"] <= 0
        else (
            "rental_slack_forsale_tight"
            if snap["for_sale_available"] < snap["rental_available"]
            else "mixed_or_slack"
        )
    )
    PHASE6E_LOG["stock_vacancy"].append({
        "year": year, **snap,
        "interpretation": interp,
        "notes": "ledger-based vacancy",
    })

    violations = {
        "claims_gt_capacity": [],
        "housed_without_ledger": [],
        "ledger_without_household": [],
        "insecure_with_claim": [],
        "empty_with_claim": [],
        "renter_nonsale_mismatch": [],
        "owner_nonrental_mismatch": [],
        "multiple_active_claims": [],  # structural: one dict key max
    }

    for hh_id in list(HOUSING_LEDGER_ACTIVE.keys()):
        if hh_id not in g.HOUSEHOLDS:
            violations["ledger_without_household"].append(hh_id)

    for hh_id, hh in g.HOUSEHOLDS.items():
        members = hh.get("members", []) or []
        n = len(members)
        tenure = hh.get("tenure")
        unit = hh.get("housing_unit_name")
        has_claim = household_has_active_housing_claim(hh_id)
        claim = get_household_housing_claim(hh_id)
        ledger_unit = claim["housing_unit_name"] if claim else ""
        is_renter = tenure == "Renter"
        is_owner = tenure == "Owner"
        is_insecure = tenure == "Insecure"
        multi = False  # one claim per hh by design

        tenure_matches = True
        if has_claim and claim:
            cat = claim.get("housing_category")
            if is_renter and cat != "Rental":
                tenure_matches = False
                violations["renter_nonsale_mismatch"].append(hh_id)
            if is_owner and cat != "For-Sale":
                tenure_matches = False
                violations["owner_nonrental_mismatch"].append(hh_id)

        if (is_renter or is_owner) and unit and not has_claim:
            violations["housed_without_ledger"].append(hh_id)
            cstat = "housed_label_without_ledger"
        elif is_insecure and has_claim:
            violations["insecure_with_claim"].append(hh_id)
            cstat = "insecure_with_active_claim"
        elif n == 0 and has_claim:
            violations["empty_with_claim"].append(hh_id)
            cstat = "empty_with_active_claim"
        elif has_claim and unit == ledger_unit:
            cstat = "ok"
        elif not has_claim and not unit:
            cstat = "ok_unhoused"
        else:
            cstat = "other"

        PHASE6E_LOG["consistency"].append({
            "year": year,
            "household_id": hh_id,
            "household_size": n,
            "is_empty": n == 0,
            "is_renter": is_renter,
            "is_owner": is_owner,
            "is_insecure": is_insecure,
            "housing_unit_name": unit or "",
            "has_active_ledger_claim": has_claim,
            "ledger_housing_unit_name": ledger_unit,
            "tenure_matches_unit": tenure_matches,
            "multiple_active_claims": multi,
            "consistency_status": cstat,
            "notes": "",
        })

    for name in HOUSING_STOCK:
        if get_housing_active_claim_count(name) > get_housing_capacity(name):
            violations["claims_gt_capacity"].append(name)

    inv_specs = [
        ("no_unit_overcapacity", "claims_gt_capacity", "HIGH"),
        ("no_housed_without_ledger", "housed_without_ledger", "HIGH"),
        ("no_ledger_without_household", "ledger_without_household", "HIGH"),
        ("no_insecure_with_claim", "insecure_with_claim", "MEDIUM"),
        ("no_empty_with_claim", "empty_with_claim", "HIGH"),
        ("renter_maps_to_rental", "renter_nonsale_mismatch", "MEDIUM"),
        ("owner_maps_to_forsale", "owner_nonrental_mismatch", "MEDIUM"),
        ("no_multiple_active_claims", "multiple_active_claims", "HIGH"),
    ]
    for inv_name, key, sev in inv_specs:
        ids = violations[key]
        PHASE6E_LOG["invariants"].append({
            "year": year,
            "invariant_name": inv_name,
            "pass_fail": "PASS" if len(ids) == 0 else "FAIL",
            "violation_count": len(ids),
            "example_ids": ";".join(str(x) for x in ids[:8]),
            "severity": sev,
            "notes": "",
        })
