# mastercode02_logging.py
import pandas as pd
import numpy as np
import mastercode02_globals as g
import traceback
from mastercode02_config_and_rates import (SIMULATION_DURATION, ROAD_NETWORK_CAPACITY, HOUSING_STOCK)

LOG_DATA = {
    'population_datasheet': [], 'household_datasheet': [], 'annual_summary': [],
    'marriage_summary': [], 'vehicle_events': [], 'trip_summary': [], 'rates_summary': [],
    'resource_summary': [],
    'scores_summary': []
}

def _update_global_housing_metrics():
    """Calculates current housing market stats and updates global variables for feedback loops."""
    # Phase 6B: vacancy from durable household ledger (not Salabim manager/init claims)
    from mastercode02_housing_ledger import stock_vacancy_snapshot
    snap = stock_vacancy_snapshot()
    g.current_rental_vacancy_rate = snap["rental_vacancy_rate"]

    renter_households = [h for h in g.HOUSEHOLDS.values() if h.get('tenure') == 'Renter' and h.get('members')]
    if renter_households:
        burdened_renters = sum(1 for h in renter_households if h.get('is_cost_burdened', False))
        g.current_renter_cost_burden_ratio = burdened_renters / len(renter_households)
    else:
        g.current_renter_cost_burden_ratio = 0

def log_yearly_data(year, env, growth_rate):
    _update_global_housing_metrics()

    # Phase 7B: archive empty, claim-free household shells (flag-based; no hard delete).
    # Runs after all yearly releases/updates and before annual logging so counts reflect it.
    # Deaths are summed over ALL g.HOUSEHOLDS (archived included) so demography is unaffected.
    try:
        from mastercode02_household_archive import archive_empty_household_shells
        archive_empty_household_shells(year)
    except ImportError:
        pass

    if year == SIMULATION_DURATION:
        _log_population_datasheet(year)
        _log_household_datasheet(year)

    # Phase 3C fertility / marital classification metrics BEFORE birth-counter reset
    try:
        from mastercode02_phase3c_diagnostics import snapshot_yearly_fertility_metrics
        snapshot_yearly_fertility_metrics(year)
    except ImportError:
        pass

    _log_annual_summary(year, env, growth_rate)
    _log_new_summaries(year, env)
    _log_annual_resource_summary(year, env)
    _log_annual_scores(year, env)

    # Phase 2 observability collectors (reporting only)
    try:
        from mastercode02_phase2_diagnostics import collect_yearly_phase2_metrics, collect_household_logging_audit
        collect_yearly_phase2_metrics(year, env, growth_rate)
        collect_household_logging_audit(year)
    except ImportError:
        pass

    # Phase 4B education snapshots (diagnostic only)
    try:
        from mastercode02_phase4b_diagnostics import snapshot_yearly_education
        snapshot_yearly_education(year)
    except ImportError:
        pass

    # Phase 4D resource consistency snapshots (diagnostic only)
    try:
        from mastercode02_phase4d_diagnostics import snapshot_yearly_phase4d
        snapshot_yearly_phase4d(year)
    except ImportError:
        pass

    # Phase 5B transit units diagnostics (observation only)
    try:
        from mastercode02_phase5b_diagnostics import snapshot_yearly_phase5b
        snapshot_yearly_phase5b(year, env)
    except ImportError:
        pass

    # Phase 6B housing ledger forensics (observation)
    try:
        from mastercode02_phase6b_diagnostics import snapshot_yearly_phase6b
        snapshot_yearly_phase6b(year, env)
    except ImportError:
        pass

    # Phase 6D initial tenure synthesis diagnostics (observation)
    try:
        from mastercode02_phase6d_diagnostics import snapshot_yearly_phase6d
        snapshot_yearly_phase6d(year, env)
    except ImportError:
        pass

    # Phase 6E renter-to-owner diagnostics (observation)
    try:
        from mastercode02_phase6e_diagnostics import snapshot_yearly_phase6e
        snapshot_yearly_phase6e(year, env)
    except ImportError:
        pass

    # Phase 7A household lifecycle / genuine-insecure classification (observation only)
    try:
        from mastercode02_phase7a_diagnostics import snapshot_yearly_phase7a
        snapshot_yearly_phase7a(year, env)
    except ImportError:
        pass

    # Phase 7B empty household shell archival diagnostics (post-archival, observation)
    try:
        from mastercode02_phase7b_diagnostics import snapshot_yearly_phase7b
        snapshot_yearly_phase7b(year, env)
    except ImportError:
        pass


def _log_population_datasheet(year):
    # This function is from your original working version
    for p in g.POPULATION:
        LOG_DATA['population_datasheet'].append({
            'year': year, 'person_id': p.id, 'age': p.age, 'sex': p.sex,
            'household_id': p.household_id, 'marital_status': p.marital_status,
            'education_level': p.education, 'employment_status': p.employment_status,
            'employer': p.employer, 'annual_income': p.annual_income,
        })

def _log_household_datasheet(year):
    # Phase 2: log ALL households including empty (logging coverage fix only)
    # Phase 7A: add ledger-based household status classification (read-only).
    from mastercode02_household_lifecycle import (
        classify_household_housing_status, GENUINE_INSECURE, EMPTY_SHELL,
    )
    from mastercode02_housing_ledger import (
        household_has_active_housing_claim, get_household_housing_claim,
    )
    for hh_id, hh_data in g.HOUSEHOLDS.items():
        # Phase 7B: main datasheet lists ACTIVE households; archived shells go to the archive datasheet.
        if hh_data.get('archived'):
            continue
        members = hh_data.get('members', [])
        tenure = hh_data.get('tenure')
        housing_unit = hh_data.get('housing_unit_name')
        classification = classify_household_housing_status(hh_id)
        has_claim = household_has_active_housing_claim(hh_id)
        claim = get_household_housing_claim(hh_id)
        active_unit = claim.get('housing_unit_name', '') if claim else ''
        active_tenure = claim.get('tenure_type', '') if claim else ''
        LOG_DATA['household_datasheet'].append({
            'year': year,
            'household_id': hh_id,
            'active_household': not hh_data.get('archived', False),
            'is_archived': bool(hh_data.get('archived', False)),
            'household_type': hh_data.get('type'),
            'household_members': len(members),
            'is_empty': len(members) == 0,
            # Phase 7A: is_insecure now means GENUINE insecure (non-empty, no ledger claim)
            'is_insecure': classification == GENUINE_INSECURE,
            'is_insecure_old_label_basis': tenure == 'Insecure',
            'is_renter': tenure == 'Renter',
            'is_owner': tenure == 'Owner',
            'tenure': tenure,
            'tenure_missing': tenure is None or tenure == '',
            'housing_unit': housing_unit,
            'housing_unit_missing': housing_unit is None or housing_unit == '',
            'household_status_classification': classification,
            'genuine_insecure': classification == GENUINE_INSECURE,
            'empty_shell': classification == EMPTY_SHELL,
            'has_active_housing_ledger_claim': has_claim,
            'active_housing_unit_name': active_unit,
            'active_housing_tenure_type': active_tenure,
            'is_cost_burdened': hh_data.get('is_cost_burdened', False),
            'employed_in_hh': sum(1 for p in members if p.employment_status == 'Employed'),
            'household_annual_income': hh_data.get('total_income', 0),
            'required_cost_pre_tax': hh_data.get('required_cost', 0),
            'savings_balance': hh_data.get('savings_balance', 0),
            'loan_balance': hh_data.get('loan_balance', 0),
        })

def _log_annual_summary(year, env, growth_rate):
    # UPDATED to include key housing metrics
    owner_hh = [h for h in g.HOUSEHOLDS.values() if h.get('tenure') == 'Owner']
    renter_hh = [h for h in g.HOUSEHOLDS.values() if h.get('tenure') == 'Renter']
    burdened_owners = sum(1 for h in owner_hh if h.get('is_cost_burdened'))
    
    from mastercode02_housing_ledger import stock_vacancy_snapshot
    snap = stock_vacancy_snapshot()

    # Phase 7A: ledger-based household lifecycle classification (read-only).
    # Genuine insecure = non-empty households with no active housing ledger claim.
    # Empty shells (0 members, no claim) are NOT genuine insecurity.
    from mastercode02_household_lifecycle import household_status_counts, old_basis_insecure_count
    status_counts = household_status_counts()
    genuine_insecure = status_counts['genuine_insecure_nonempty']
    empty_shells = status_counts['empty_shell']
    empty_with_claim = status_counts['inconsistent_housed_empty']
    old_basis_insecure = old_basis_insecure_count()

    # Phase 7B: active vs archived household bookkeeping (flag-based archival).
    from mastercode02_household_archive import (
        active_household_count, archived_household_count, count_active_empty_shells,
        ARCHIVE_YEARLY,
    )
    active_hh = active_household_count()
    archived_hh = archived_household_count()
    active_empty_shells = count_active_empty_shells()
    archived_this_year = 0
    if ARCHIVE_YEARLY:
        last = ARCHIVE_YEARLY[-1]
        if int(last.get('year', -1)) == int(year):
            archived_this_year = int(last.get('archived_this_year', 0))
    total_records_old_basis = len(g.HOUSEHOLDS)

    all_incomes = [p.annual_income for p in g.POPULATION if p.annual_income > 0]
    
    summary_dict = {
        'Year': year, 'Population': len(g.POPULATION), 'Households': len(g.HOUSEHOLDS),
        'Population Growth rate': growth_rate,
        'No of births': sum(h.get('births', 0) for h in g.HOUSEHOLDS.values()),
        'No. of Deaths': sum(h.get('deaths', 0) for h in g.HOUSEHOLDS.values()),
        'Employment Rate': sum(1 for p in g.POPULATION if p.employment_status == 'Employed') / len(g.POPULATION) if g.POPULATION else 0,
        'Avg Annual Income': np.mean(all_incomes or [0]),
        'Owner_Occupied_HH': len(owner_hh), 'Renter_Occupied_HH': len(renter_hh),
        'Rental_Vacancy_Rate': snap['rental_vacancy_rate'],
        'Overall_Vacancy_Rate': snap['overall_vacancy_rate'],
        'Owner_Cost_Burden_Rate': burdened_owners / len(owner_hh) if owner_hh else 0,
        'Renter_Cost_Burden_Rate': g.current_renter_cost_burden_ratio,
        # Phase 7A: official insecure metric now means GENUINE non-empty insecure households.
        'Housing_Insecure_HH_Count': genuine_insecure,
        'Genuine_Housing_Insecure_HH_Count': genuine_insecure,
        # Phase 7B: empty shells are now archived; count remaining ACTIVE (non-archived) shells.
        'Empty_Household_Shell_Count': active_empty_shells,
        'Empty_Household_Shell_Count_Total': empty_shells,
        'Empty_Household_With_Claim_Count': empty_with_claim,
        # Phase 7B: active vs archived household bookkeeping (no hard delete).
        'Active_Household_Count': active_hh,
        'Archived_Household_Count': archived_hh,
        'Archived_This_Year': archived_this_year,
        'Total_Household_Records_Old_Basis': total_records_old_basis,
        # Preserve the pre-Phase-7A label-only count for before/after audit.
        'Housing_Insecure_HH_Count_Old_Basis': old_basis_insecure,
        'Official_Insecure_Label_Count_Old_Basis': old_basis_insecure,
        'Total Number of Cars': sum(len(p.cars) for p in g.POPULATION),
        'Number of Accidents on road': g.ANNUAL_SUMMARY_DATA.get('num_accidents', 0),
        'Cost Inflation rate': env.cpi_inflation
    }
    LOG_DATA['annual_summary'].append(summary_dict)
    
    for hh in g.HOUSEHOLDS.values(): hh['births'] = 0; hh['deaths'] = 0

def _log_new_summaries(year, env):
    LOG_DATA['marriage_summary'].extend(g.MARRIAGES); g.MARRIAGES.clear()
    LOG_DATA['vehicle_events'].extend(g.VEHICLE_EVENTS); g.VEHICLE_EVENTS.clear()
    if g.TRIP_SUMMARY:
        df = pd.DataFrame(g.TRIP_SUMMARY); purpose_counts = df.groupby('purpose').size().reset_index(name='count'); purpose_counts['year'] = year
        LOG_DATA['trip_summary'].append(purpose_counts)
    g.TRIP_SUMMARY.clear()
    # Gate 2 decision-node provenance: record city/annual/event components and
    # the composed effective multiplier separately for death, birth, and
    # marriage, every year -- so any future regression of the Gate 1 defect
    # (a manager silently overwriting a city_* modifier) is directly visible
    # in the run's own output, not just inferable from code inspection.
    LOG_DATA['rates_summary'].append({
        'year': year,
        'city_death_rate_mod': g.city_death_rate_modifier,
        'annual_death_rate_mod': g.annual_death_rate_modifier,
        'event_death_rate_mod': g.event_death_rate_modifier,
        'effective_death_multiplier': g.city_death_rate_modifier * g.annual_death_rate_modifier * g.event_death_rate_modifier,
        'city_birth_rate_mod': g.city_birth_rate_modifier,
        'annual_birth_rate_mod': g.annual_birth_rate_modifier,
        'event_birth_rate_mod': g.event_birth_rate_modifier,
        'effective_birth_multiplier': g.city_birth_rate_modifier * g.annual_birth_rate_modifier * g.event_birth_rate_modifier,
        'city_marriage_rate_mod': g.city_marriage_rate_modifier,
        'annual_marriage_rate_mod': g.annual_marriage_rate_modifier,
        'effective_marriage_multiplier': g.city_marriage_rate_modifier * g.annual_marriage_rate_modifier,
        'tax_rate': env.tax_rate, 'salary_inflation': env.salary_inflation, 'cpi_inflation': env.cpi_inflation })

def _log_annual_resource_summary(year, env):
    from mastercode02_housing_ledger import get_housing_active_claim_count, get_housing_capacity
    # Phase 8A-FU2: education local-seat demand = count of persons currently in each level.
    # Phase 8A-FU3: Year 0 is pre-enrollment (EducationManager holds 1 before first enroll);
    # refuse/overflow NA at Y0; schema fields for stage/basis; null NA not blank strings;
    # bus daily ratio separate from utilization; road status not in numeric refusal cols.
    # Read-only (no RNG). Model enrollment/progression unchanged.
    edu_demand = {}
    for p in g.POPULATION:
        edu = p.education
        if edu in g.EDUCATION_RESOURCE:
            edu_demand[edu] = edu_demand.get(edu, 0) + 1
    # Year 0 resource log runs at hold(0) before EducationManager's first enrollment (hold(1)).
    pre_enrollment = (int(year) == 0)

    def _na_edu_fields():
        return {
            'education_local_seat_demand': None,
            'education_local_seat_refused': None,
            'education_external_school_count': None,
            'theoretical_pre_enrollment_demand_minus_capacity': None,
            'education_enrollment_evaluated': None,
        }

    # Education / employer still Salabim; housing occupancy from durable ledger
    for res_dict in [g.EDUCATION_RESOURCE, g.EMPLOYER_RESOURCE]:
        is_education = res_dict is g.EDUCATION_RESOURCE
        for name, res in res_dict.items():
            requester_basis = len(res.requesters())
            in_use = res.claimed_quantity()
            cap = res.capacity()
            util = in_use / cap if cap > 0 else 0
            row = {
                'year': year, 'name': name, 'capacity': cap, 'in_use': in_use,
                # Legacy column: requester-queue length (structurally 0 for education; audit only)
                'waiting_or_refused': requester_basis,
                'waiting_or_refused_requester_basis': requester_basis,
                'waiting_or_refused_legacy': requester_basis,
                'utilization': util,
                'road_status': None,
                'annual_demand_to_daily_capacity_ratio': None,
            }
            if is_education:
                demand = edu_demand.get(name, 0)
                theoretical_gap = max(0, demand - int(cap)) if cap is not None else None
                row['education_local_seat_demand'] = demand
                row['theoretical_pre_enrollment_demand_minus_capacity'] = (
                    theoretical_gap if pre_enrollment else None)
                if pre_enrollment:
                    row['snapshot_stage'] = 'pre_enrollment_baseline'
                    row['education_enrollment_evaluated'] = False
                    row['metric_basis'] = 'pre_enrollment_not_refusal'
                    row['education_local_seat_refused'] = None
                    row['education_external_school_count'] = None
                    row['effective_refused_or_overflow'] = None
                else:
                    refused = max(0, demand - in_use)
                    row['snapshot_stage'] = 'post_annual_enrollment'
                    row['education_enrollment_evaluated'] = True
                    row['metric_basis'] = 'local_seat_claims_vs_demand'
                    row['education_local_seat_refused'] = refused
                    row['education_external_school_count'] = refused
                    row['effective_refused_or_overflow'] = refused
            else:
                row.update(_na_edu_fields())
                row['snapshot_stage'] = 'annual_resource_snapshot'
                row['metric_basis'] = 'employer_salabim_requester_basis'
                row['effective_refused_or_overflow'] = requester_basis
            LOG_DATA['resource_summary'].append(row)
    for name in HOUSING_STOCK:
        cap = get_housing_capacity(name)
        claimed = get_housing_active_claim_count(name)
        LOG_DATA['resource_summary'].append({
            'year': year, 'name': name, 'capacity': cap, 'in_use': claimed,
            'waiting_or_refused': 0,
            'utilization': claimed / cap if cap > 0 else 0,
            'waiting_or_refused_requester_basis': 0,
            'waiting_or_refused_legacy': 0,
            'effective_refused_or_overflow': 0,
            'snapshot_stage': 'annual_resource_snapshot',
            'metric_basis': 'housing_ledger_occupancy',
            'road_status': None,
            'annual_demand_to_daily_capacity_ratio': None,
            **_na_edu_fields(),
        })

    bus_daily = getattr(env, 'bus_daily_capacity', None)
    bus_annual = getattr(env, 'bus_annual_capacity', None)
    bus_capacity = bus_annual if bus_annual is not None else getattr(env, 'total_bus_capacity', 0)
    bus_served = getattr(env, 'bus_passengers_served', 0)
    bus_refused = getattr(env, 'bus_passengers_refused', 0)
    LOG_DATA['resource_summary'].append({
        'year': year, 'name': 'Bus Service', 'capacity': bus_capacity, 'in_use': bus_served,
        'waiting_or_refused': bus_refused,
        'utilization': bus_served / bus_capacity if bus_capacity > 0 else 0,
        'waiting_or_refused_requester_basis': bus_refused,
        'waiting_or_refused_legacy': bus_refused,
        'effective_refused_or_overflow': bus_refused,
        'snapshot_stage': 'annual_resource_snapshot',
        'metric_basis': 'bus_annualized_capacity',
        'road_status': None,
        'annual_demand_to_daily_capacity_ratio': None,
        **_na_edu_fields(),
    })
    if bus_daily is not None:
        daily_ratio = (bus_served / bus_daily) if bus_daily > 0 else None
        LOG_DATA['resource_summary'].append({
            'year': year, 'name': 'Bus Service Daily Capacity', 'capacity': bus_daily,
            'in_use': bus_served, 'waiting_or_refused': bus_refused,
            # Phase 8A-FU3: do NOT write annual_demand/daily_capacity as utilization
            'utilization': None,
            'waiting_or_refused_requester_basis': bus_refused,
            'waiting_or_refused_legacy': bus_refused,
            'effective_refused_or_overflow': bus_refused,
            'snapshot_stage': 'annual_resource_snapshot',
            'metric_basis': 'daily_capacity_diagnostic_not_annual_resource_utilization',
            'road_status': None,
            'annual_demand_to_daily_capacity_ratio': daily_ratio,
            **_na_edu_fields(),
        })

    total_cars = sum(len(p.cars) for p in g.POPULATION)
    traffic_statuses = g.ANNUAL_SUMMARY_DATA.get('traffic_status', {})
    for road_type, capacity in ROAD_NETWORK_CAPACITY.items():
        status = traffic_statuses.get(road_type, 'Unavailable')
        LOG_DATA['resource_summary'].append({
            'year': year, 'name': f'Road: {road_type}', 'capacity': capacity,
            'in_use': total_cars,
            # Phase 8A-FU3: numeric refusal columns null; status in road_status
            'waiting_or_refused': None,
            'waiting_or_refused_requester_basis': None,
            'waiting_or_refused_legacy': None,
            'effective_refused_or_overflow': None,
            'utilization': total_cars / capacity if capacity > 0 else 0,
            'snapshot_stage': 'annual_resource_snapshot',
            'metric_basis': 'road_status_not_refusal_count',
            'road_status': status,
            'annual_demand_to_daily_capacity_ratio': None,
            **_na_edu_fields(),
        })

    g.annual_savings_accepted = 0; g.annual_loans_disbursed = 0; g.annual_gov_support_disbursed = 0
    g.refused_log = {'savings': 0, 'loans': 0, 'gov_support': 0}

def _log_annual_scores(year, env):
    # This is from your original working code
    def normalize(value, min_val, max_val, lower_is_better=False):
        if lower_is_better: value, min_val, max_val = -value, -max_val, -min_val
        if (max_val - min_val) == 0: return 0.5
        return max(0, min(1, (value - min_val) / (max_val - min_val)))
    
    summary = LOG_DATA['annual_summary'][-1]
    households = list(g.HOUSEHOLDS.values())
    net_incomes = [(h.get('total_income', 0) - h.get('taxes_cum', 0) - h.get('required_cost', 0)) for h in households if h.get('members')]
    
    norm_inflation = normalize(summary.get('Cost Inflation rate', 0.03), 0.0, 0.15, lower_is_better=True)
    norm_employment = normalize(summary['Employment Rate'], 0.85, 1.0)
    norm_net_income = normalize(np.median(net_incomes) if net_incomes else 0, -50000, 20000)
    
    eco_index = (norm_inflation * 0.3 + norm_employment * 0.4 + norm_net_income * 0.3) * 100
    g.latest_economic_index = eco_index
    
    total_cars = summary['Total Number of Cars']
    norm_congestion = normalize(total_cars / sum(ROAD_NETWORK_CAPACITY.values()), 0.2, 1.0, lower_is_better=True)
    norm_accidents = normalize(summary['Number of Accidents on road'], 50, 500, lower_is_better=True)
    
    trans_index = (norm_congestion * 0.7 + norm_accidents * 0.3) * 100
    
    LOG_DATA['scores_summary'].append({'year': year, 'economic_index': eco_index, 'transport_index': trans_index})

def write_and_close_csv_logs(base_filename, env):
    print(f"\n--- Writing final logs to CSV files with base name: {base_filename} ---")
    try:
        float_format = '%.4f'
        if LOG_DATA['population_datasheet']: pd.DataFrame(LOG_DATA['population_datasheet']).to_csv(f"{base_filename}_population_datasheet.csv", index=False, float_format=float_format)
        if LOG_DATA['household_datasheet']: pd.DataFrame(LOG_DATA['household_datasheet']).to_csv(f"{base_filename}_household_datasheet.csv", index=False, float_format=float_format)
        pd.DataFrame(LOG_DATA['annual_summary']).to_csv(f"{base_filename}_annual_summary.csv", index=False, float_format=float_format)
        if LOG_DATA['marriage_summary']: pd.DataFrame(LOG_DATA['marriage_summary']).to_csv(f"{base_filename}_summary_marriages.csv", index=False)
        if LOG_DATA['vehicle_events']: pd.DataFrame(LOG_DATA['vehicle_events']).to_csv(f"{base_filename}_summary_vehicle_events.csv", index=False)
        if LOG_DATA['trip_summary']: pd.concat(LOG_DATA['trip_summary']).to_csv(f"{base_filename}_summary_trips.csv", index=False)
        if LOG_DATA['rates_summary']: pd.DataFrame(LOG_DATA['rates_summary']).to_csv(f"{base_filename}_summary_rates.csv", index=False, float_format=float_format)
        if LOG_DATA['resource_summary']: pd.DataFrame(LOG_DATA['resource_summary']).to_csv(f"{base_filename}_summary_resources.csv", index=False, float_format=float_format)
        if LOG_DATA['scores_summary']: pd.DataFrame(LOG_DATA['scores_summary']).to_csv(f"{base_filename}_scores_summary.csv", index=False, float_format=float_format)
        print("...All CSV log files saved successfully.")
    except Exception:
        print("\n--- A CRITICAL ERROR OCCURRED DURING CSV FILE WRITING ---"); traceback.print_exc()