# mastercode02_heartbeat.py
"""R11.1 Phase 6 -- heartbeat, progress monitor, and safe-checkpoint infrastructure.

Purely additive observability: every function here only *reads* globals that
already exist (`mastercode02_globals`, `mastercode02_logging.LOG_DATA`) and
writes to paths the caller supplies. Nothing here mutates simulation state,
consumes RNG, or changes what `write_and_close_csv_logs()` produces at the
real end of a run -- `write_year_checkpoint()` calls that exact same function
against a separate checkpoint directory, and `LOG_DATA`'s lists are only
appended to elsewhere (never cleared) between calls, so re-reading them here
is side-effect-free and can be called any number of times.

Intended use (wired in `tools/run_mastercode02.py`): a `HeartbeatWriter`
instance writes `diagnostics_dir/heartbeat.json` at year boundaries so a
long Atlanta-scale run's liveness/progress can be polled externally without
touching the running process; `write_year_checkpoint()` writes a
non-destructive partial CSV dump every N simulated years so an interrupted
long run still leaves a readable up-to-year-N snapshot on disk.
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

import mastercode02_globals as g


def _atomic_write_json(path, payload: dict) -> None:
    """Write JSON via a temp file + os.replace so a concurrent reader never
    observes a partially written / truncated file."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_name(path.name + ".tmp")
    tmp_path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
    os.replace(tmp_path, path)


def _rss_mb(pid: int):
    try:
        import psutil
        return round(psutil.Process(pid).memory_info().rss / (1024 * 1024), 2)
    except Exception:
        return None


class HeartbeatWriter:
    """Writes a small heartbeat JSON file at process start, each simulated
    year boundary, and at run completion/failure.

    A stale `updated_at_unix` (checked externally, e.g. `now - updated_at_unix
    > some threshold` while `status == "RUNNING"`) is itself a hang signal,
    even for the single long `env.run(till=0)` Initializer call this module
    cannot instrument internally without touching shared `mastercode02_setup.py`
    (out of scope for this phase; see Phase 6 report's stated limitation).
    """

    def __init__(self, heartbeat_path, run_label: str, seed: int, duration):
        self.path = Path(heartbeat_path)
        self.run_label = run_label
        self.seed = seed
        self.duration = duration
        self.pid = os.getpid()
        self.start_time = time.time()
        self._last_update = self.start_time

    def write(self, status: str, year=None, note: str = "") -> dict:
        now = time.time()
        payload = {
            "run_label": self.run_label,
            "seed": self.seed,
            "duration": self.duration,
            "pid": self.pid,
            "status": status,
            "current_year": year,
            "population": len(g.POPULATION),
            "households": len(g.HOUSEHOLDS),
            "elapsed_seconds": round(now - self.start_time, 3),
            "seconds_since_last_update": round(now - self._last_update, 3),
            "rss_mb": _rss_mb(self.pid),
            "note": note,
            "updated_at_unix": now,
        }
        if year is not None and self.duration:
            fraction = min(1.0, max(0.0, year / self.duration))
            payload["progress_fraction"] = round(fraction, 4)
            if year > 0:
                per_year = (now - self.start_time) / year
                remaining_years = max(0, self.duration - year)
                payload["estimated_seconds_remaining"] = round(per_year * remaining_years, 1)
        _atomic_write_json(self.path, payload)
        self._last_update = now
        return payload


def write_year_checkpoint(checkpoint_dir, base_filename: str, env, year: int) -> dict:
    """Non-destructive partial dump of everything accumulated in `LOG_DATA`
    so far (through `year`, inclusive) to `checkpoint_dir`.

    Does not touch the run's real output directory and does not clear or
    otherwise mutate `LOG_DATA` -- the real, end-of-run
    `write_and_close_csv_logs()` call in the caller is completely unaffected
    and still produces byte-identical final output regardless of how many
    times (or how often) this checkpoint function was called during the run.
    """
    from mastercode02_logging import write_and_close_csv_logs

    checkpoint_dir = Path(checkpoint_dir)
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    prev_cwd = os.getcwd()
    os.chdir(checkpoint_dir)
    try:
        write_and_close_csv_logs(base_filename, env)
    finally:
        os.chdir(prev_cwd)
    meta = {
        "last_checkpointed_year": year,
        "checkpoint_dir": str(checkpoint_dir),
        "base_filename": base_filename,
        "population": len(g.POPULATION),
        "households": len(g.HOUSEHOLDS),
        "written_at_unix": time.time(),
    }
    _atomic_write_json(checkpoint_dir / f"{base_filename}_checkpoint_meta.json", meta)
    return meta
