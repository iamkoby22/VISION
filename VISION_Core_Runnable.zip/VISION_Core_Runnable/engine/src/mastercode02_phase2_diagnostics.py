"""Phase 2 observability collectors — reporting only, no model logic changes."""
from __future__ import annotations

import mastercode02_globals as g

PHASE2_LOG: dict[str, list] = {
    "employment_metrics": [],
    "housing_metrics": [],
    "birth_death_metrics": [],
    "resource_diagnostics": [],
    "transit_diagnostics": [],
    "household_logging_audit": [],
}

EDUCATION_RESOURCES = {
    "Nursery/Preschool", "Elementary (K-5)", "Middle (6-8)", "High School (9-12)",
    "University", "Community College", "masters_program", "phd_program",
}
EMPLOYER_PREFIX = "EMP"
HOUSING_RENTAL = {"Rental: Low-Income", "Rental: Student", "Rental: General"}
HOUSING_FORSALE = {"For-Sale: Starter", "For-Sale: Mid-Range", "For-Sale: High-End"}


def _resource_group(name: str) -> str:
    if name in EDUCATION_RESOURCES:
        return "education"
    if name.startswith(EMPLOYER_PREFIX):
        return "employer"
    if name in HOUSING_RENTAL | HOUSING_FORSALE:
        return "housing"
    if name == "Bus Service":
        return "transit"
    if name.startswith("Road:"):
        return "roads"
    return "other"


def collect_yearly_phase2_metrics(year: int, env, growth_rate: float) -> None:
    """Called from log_yearly_data after core logging. Read-only on model state."""
    pop_n = len(g.POPULATION)
    emp_total = sum(1 for p in g.POPULATION if p.employment_status == "Employed")
    wa = [p for p in g.POPULATION if 18 <= p.age < 65]
    emp_wa = sum(1 for p in wa if p.employment_status == "Employed")
    emp_rate_total = emp_total / pop_n if pop_n else 0.0
    emp_rate_wa = emp_wa / len(wa) if wa else 0.0

    PHASE2_LOG["employment_metrics"].append({
        "year": year,
        "population": pop_n,
        "employed_total": emp_total,
        "employment_rate_total_pop": round(emp_rate_total, 6),
        "working_age_population_18_64": len(wa),
        "employed_working_age": emp_wa,
        "employment_rate_working_age_18_64": round(emp_rate_wa, 6),
    })

    # Housing stock from resources
    rental_cap = rental_occ = 0
    forsale_cap = forsale_occ = 0
    for name, res in g.HOUSING_RESOURCE.items():
        cap = res.capacity()
        occ = res.claimed_quantity()
        if name in HOUSING_RENTAL:
            rental_cap += cap
            rental_occ += occ
        elif name in HOUSING_FORSALE:
            forsale_cap += cap
            forsale_occ += occ
    total_cap = rental_cap + forsale_cap
    total_occ = rental_occ + forsale_occ
    rental_vac = (rental_cap - rental_occ) / rental_cap if rental_cap else 0.0
    forsale_vac = (forsale_cap - forsale_occ) / forsale_cap if forsale_cap else 0.0
    overall_vac = (total_cap - total_occ) / total_cap if total_cap else 0.0

    hh_all = list(g.HOUSEHOLDS.values())
    insecure = sum(1 for h in hh_all if h.get("tenure") == "Insecure")
    renter = sum(1 for h in hh_all if h.get("tenure") == "Renter")
    owner = sum(1 for h in hh_all if h.get("tenure") == "Owner")
    empty = sum(1 for h in hh_all if not h.get("members"))
    tenure_missing = sum(1 for h in hh_all if not h.get("tenure"))
    unit_missing = sum(1 for h in hh_all if not h.get("housing_unit_name"))

    PHASE2_LOG["housing_metrics"].append({
        "year": year,
        "rental_units_total": rental_cap,
        "rental_units_occupied": rental_occ,
        "rental_vacancy_rate": round(rental_vac, 6),
        "forsale_units_total": forsale_cap,
        "forsale_units_occupied": forsale_occ,
        "forsale_vacancy_rate": round(forsale_vac, 6),
        "total_housing_units": total_cap,
        "total_occupied_housing_units": total_occ,
        "overall_vacancy_rate": round(overall_vac, 6),
        "insecure_household_count": insecure,
        "renter_household_count": renter,
        "owner_household_count": owner,
        "empty_household_count": empty,
        "households_tenure_missing": tenure_missing,
        "households_housing_unit_missing": unit_missing,
        "total_households_in_model": len(hh_all),
    })

    births = sum(h.get("births", 0) for h in hh_all)
    deaths = sum(h.get("deaths", 0) for h in hh_all)
    fert_females = [p for p in g.POPULATION if p.sex == "Female" and 15 <= p.age <= 49]
    cbr = (births / pop_n * 1000) if pop_n else 0.0
    cdr = (deaths / pop_n * 1000) if pop_n else 0.0
    bpf = (births / len(fert_females)) if fert_females else 0.0

    PHASE2_LOG["birth_death_metrics"].append({
        "year": year,
        "population_end_of_year": pop_n,
        "birth_count": births,
        "death_count": deaths,
        "crude_birth_rate_per_1000": round(cbr, 4),
        "crude_death_rate_per_1000": round(cdr, 4),
        "fertility_age_female_count_15_49": len(fert_females),
        "births_per_fertility_age_female": round(bpf, 6),
        "population_growth_rate": growth_rate,
    })

    # Resources
    for res_dict in [g.EDUCATION_RESOURCE, g.EMPLOYER_RESOURCE, g.HOUSING_RESOURCE]:
        for name, res in res_dict.items():
            cap = res.capacity()
            in_use = res.claimed_quantity()
            waiting = len(res.requesters())
            util = in_use / cap if cap > 0 else 0.0
            PHASE2_LOG["resource_diagnostics"].append({
                "year": year,
                "name": name,
                "resource_group": _resource_group(name),
                "capacity": cap,
                "in_use": in_use,
                "waiting_or_refused": waiting,
                "utilization": round(util, 6),
                "saturation_flag": util >= 0.95,
            })

    bus_cap = getattr(env, "total_bus_capacity", 0)
    bus_served = getattr(env, "bus_passengers_served", 0)
    bus_refused = getattr(env, "bus_passengers_refused", 0)
    refusal_rate = bus_refused / (bus_served + bus_refused) if (bus_served + bus_refused) else 0.0
    PHASE2_LOG["resource_diagnostics"].append({
        "year": year, "name": "Bus Service", "resource_group": "transit",
        "capacity": bus_cap, "in_use": bus_served, "waiting_or_refused": bus_refused,
        "utilization": round(bus_served / bus_cap, 6) if bus_cap else 0.0,
        "saturation_flag": (bus_served / bus_cap >= 0.95) if bus_cap else False,
    })
    PHASE2_LOG["transit_diagnostics"].append({
        "year": year,
        "bus_capacity": bus_cap,
        "passengers_served": bus_served,
        "passengers_refused": bus_refused,
        "refusal_rate": round(refusal_rate, 6),
        "capacity_saturated": (bus_cap > 0 and bus_served >= bus_cap),
    })

    from mastercode02_config_and_rates import ROAD_NETWORK_CAPACITY
    total_cars = sum(len(p.cars) for p in g.POPULATION)
    for road_type, cap in ROAD_NETWORK_CAPACITY.items():
        util = total_cars / cap if cap else 0.0
        PHASE2_LOG["resource_diagnostics"].append({
            "year": year, "name": f"Road: {road_type}", "resource_group": "roads",
            "capacity": cap, "in_use": total_cars, "waiting_or_refused": 0,
            "utilization": round(util, 6), "saturation_flag": util >= 0.95,
        })


def collect_household_logging_audit(year: int) -> None:
    """Audit household logging coverage at final export year."""
    if year != __import__("mastercode02_config_and_rates", fromlist=["SIMULATION_DURATION"]).SIMULATION_DURATION:
        return
    total = len(g.HOUSEHOLDS)
    empty = sum(1 for h in g.HOUSEHOLDS.values() if not h.get("members"))
    nonempty = total - empty
    insecure = sum(1 for h in g.HOUSEHOLDS.values() if h.get("tenure") == "Insecure")
    renter = sum(1 for h in g.HOUSEHOLDS.values() if h.get("tenure") == "Renter")
    owner = sum(1 for h in g.HOUSEHOLDS.values() if h.get("tenure") == "Owner")
    tenure_miss = sum(1 for h in g.HOUSEHOLDS.values() if not h.get("tenure"))
    unit_miss = sum(1 for h in g.HOUSEHOLDS.values() if not h.get("housing_unit_name"))

    PHASE2_LOG["household_logging_audit"].append({
        "year": year,
        "total_households_in_model": total,
        "nonempty_households": nonempty,
        "empty_households": empty,
        "insecure_households": insecure,
        "renter_households": renter,
        "owner_households": owner,
        "tenure_missing": tenure_miss,
        "housing_unit_missing": unit_miss,
        "expected_datasheet_rows_after_phase2_fix": total,
        "baseline_gap_empty_households_skipped": empty,
    })


def diagnose_unused_education_routes() -> list[dict]:
    """Community College route diagnosis from final population state."""
    cc_agents = sum(1 for p in g.POPULATION if p.education == "Community College")
    cc_resource = g.EDUCATION_RESOURCE.get("Community College")
    cc_util = 0.0
    if cc_resource and cc_resource.capacity() > 0:
        cc_util = cc_resource.claimed_quantity() / cc_resource.capacity()

    progression_reaches_cc = False
    # Education progression in Person.update_education_cyclical goes HS -> University directly
    progression_note = (
        "high_school_completed routes to University (60% prob) or skips; "
        "Community College is never assigned in update_education_cyclical"
    )

    return [{
        "resource": "Community College",
        "agents_with_education_community_college": cc_agents,
        "resource_utilization_final": round(cc_util, 6),
        "progression_can_reach_community_college": progression_reaches_cc,
        "diagnosis": progression_note,
        "recommendation": "Phase 3 model-logic review only; do not fix in Phase 2",
    }]
