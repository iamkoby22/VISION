"""R7.10: RESIDUAL_EMPIRICAL_MIGRATION mechanism.

Implements the frozen R7.9 specification (RESSEARCH/37_PHASE_R7_9_RESIDUAL_MIGRATION_SPECIFICATION/)
per its R7.10 integerization (RESSEARCH/38_PHASE_R7_10_RESIDUAL_MIGRATION_EXPERIMENT/
02_r7_10_integerized_residual_migration.csv). Additive to, and independent of, the existing
ImmigrationManager -- that component and every other existing mechanism are unmodified. Default
OFF via config.RESIDUAL_MIGRATION_ENABLED; when OFF this module is never instantiated and has zero
effect on model behavior.

RNG: age/sex/household-type/student/domestic-international/marital-pairing draws use a dedicated
`residual_rng` instance (random.Random), isolated from the shared global `random` module the
endogenous mechanisms depend on. DISCLOSED EXCEPTION (see R7.10 file 05): employment-status
resolution reuses `_resolve_entrant_employment_status`/`assign_marital_status` VERBATIM per the
R7.9/R7.10 "do not alter employment logic" instruction; both are hardwired to the shared global
`random` module and are NOT modified here, so residual-migrant employment/marital-fallback draws
consume a small number of draws from the global stream (deterministic and reproducible given the
fixed base seed, but not isolated from it). This is documented, not silent.
"""
from __future__ import annotations

import csv
import hashlib
import random
from pathlib import Path

import salabim as sim

import mastercode02_globals as g
from mastercode02_agents import (
    Person,
    _resolve_entrant_employment_status,
    _r2_log_migration,
)
from mastercode02_generator import assign_marital_status

DATA_PATH = Path(__file__).parent / "data" / "residual_migration_knoxville.csv"

# Frozen R7.9 file 04 (ACS B07001, Knoxville city, EXACT_CITY_OBSERVATION). (low, high, probability)
AGE_BINS = [
    (1, 4, 0.0267), (5, 17, 0.0551), (18, 19, 0.2169), (20, 24, 0.2560), (25, 29, 0.1246),
    (30, 34, 0.0820), (35, 39, 0.0296), (40, 44, 0.0253), (45, 49, 0.0316), (50, 54, 0.0451),
    (55, 59, 0.0351), (60, 64, 0.0154), (65, 69, 0.0247), (70, 74, 0.0199), (75, 120, 0.0118),
]
_AGE_BIN_TOTAL = sum(p for _, _, p in AGE_BINS)  # normalize against the raw sum, not display rounding

# Frozen R7.9 file 05 (ACS S0701, Knoxville city, EXACT_CITY_OBSERVATION).
SEX_PROB_FEMALE = 0.5094

# Frozen R7.9 file 06: MODEL_ASSUMPTION student probabilities.
STUDENT_PROB_18_24 = 0.65
STUDENT_PROB_25_29 = 0.15

# Frozen R7.9 file 07: VISION's own T0 household-type shares (mastercode02_generator.py DATA),
# collapsed to the two implemented outcomes (married-couple pairing vs. single Nonfamily); the
# male/female-no-spouse-family share (12.62%) falls back to Nonfamily per the frozen design.
HOUSEHOLD_PAIR_PROB = 11825.0 / 31162.0  # 0.3795


def _derive_residual_seed(base_seed: int) -> int:
    """Frozen R7.9 file 10 / R7.10 Section N derivation procedure. Not outcome-dependent."""
    digest = hashlib.sha256(f"R7_9_RESIDUAL_MIGRATION::{base_seed}".encode()).hexdigest()
    return int(digest, 16) % (2 ** 32)


def _load_annual_schedule():
    schedule = {}
    with open(DATA_PATH, newline="") as f:
        for row in csv.DictReader(f):
            schedule[int(row["calendar_year"])] = dict(
                integer_residual=int(row["integer_residual"]),
                domestic_fraction=float(row["domestic_fraction"]),
                international_fraction=float(row["international_fraction"]),
            )
    return schedule


class ResidualMigrationManager(sim.Component):
    def __init__(self, env, base_seed):
        super().__init__(env=env)
        self.schedule = _load_annual_schedule()
        self.rng = random.Random(_derive_residual_seed(base_seed))

    def process(self):
        while True:
            yield self.hold(1)
            year = int(self.env.now())
            calendar_year = 2000 + year
            entry = self.schedule.get(calendar_year)
            if not entry or entry["integer_residual"] <= 0:
                continue
            n = entry["integer_residual"]
            print(f"ResidualMigrationManager: Adding {n} residual empirical migrants this year.")
            self._add_residual_migrants(n, year, entry["domestic_fraction"])

    # --- draws (dedicated residual_rng only) ---

    def _draw_age(self) -> int:
        r = self.rng.random() * _AGE_BIN_TOTAL
        cum = 0.0
        for lo, hi, p in AGE_BINS:
            cum += p
            if r <= cum:
                return self.rng.randint(lo, hi)
        lo, hi, _ = AGE_BINS[-1]
        return self.rng.randint(lo, hi)

    def _draw_sex(self) -> str:
        return "Female" if self.rng.random() < SEX_PROB_FEMALE else "Male"

    def _draw_student(self, age: int) -> bool:
        if 18 <= age <= 24:
            return self.rng.random() < STUDENT_PROB_18_24
        if 25 <= age <= 29:
            return self.rng.random() < STUDENT_PROB_25_29
        return False

    def _draw_is_domestic(self, domestic_fraction: float) -> bool:
        return self.rng.random() < domestic_fraction

    def _draw_wants_pairing(self, age: int) -> bool:
        return age >= 18 and self.rng.random() < HOUSEHOLD_PAIR_PROB

    # --- construction ---

    def _education_for(self, age: int, student: bool) -> str:
        if student and age >= 18:
            return "University"
        if age < 2:
            return "None"
        if age < 5:
            return "Nursery/Preschool"
        if age < 11:
            return "Elementary (K-5)"
        if age < 14:
            return "Middle (6-8)"
        if age < 18:
            return "High School (9-12)"
        # Frozen R7.9/existing ImmigrationManager education_distribution -- reused verbatim,
        # drawn on the isolated residual_rng (this distribution is not RNG-hardwired elsewhere).
        return self.rng.choices(
            ["high_school_completed", "college_completed"], weights=[0.4, 0.6], k=1
        )[0]

    def _add_residual_migrants(self, n: int, year: int, domestic_fraction: float):
        pairing_pool = []
        singles = []
        for _ in range(n):
            age = self._draw_age()
            sex = self._draw_sex()
            student = self._draw_student(age)
            is_domestic = self._draw_is_domestic(domestic_fraction)
            entry = dict(age=age, sex=sex, student=student, is_domestic=is_domestic)
            if self._draw_wants_pairing(age):
                pairing_pool.append(entry)
            else:
                singles.append(entry)

        pairs = []
        while len(pairing_pool) >= 2:
            a = pairing_pool.pop()
            b = min(pairing_pool, key=lambda x: abs(x["age"] - a["age"]))
            pairing_pool.remove(b)
            pairs.append((a, b))
        # odd one out (or any entry that could not be paired) falls back to a single household --
        # count invariant: every residual migrant still becomes exactly one Person, never zero,
        # never fabricated.
        singles.extend(pairing_pool)

        for entry in singles:
            self._create_single_migrant(entry, year)
        for a, b in pairs:
            self._create_couple_household(a, b, year)

    def _mechanism_subtype(self, is_domestic: bool) -> str:
        return "RESIDUAL_DOMESTIC" if is_domestic else "RESIDUAL_INTERNATIONAL"

    def _new_person(self, age, sex, education, employment_status, marital_status):
        initial_data = {
            "id": g.next_person_id(), "age": age, "sex": sex, "education": education,
            "employment": employment_status, "household_id": None,
            "marital_status": marital_status,
        }
        return Person(self.env, initial_data, g.POPULATION)

    def _create_single_migrant(self, entry, year):
        age, sex = entry["age"], entry["sex"]
        education = self._education_for(age, entry["student"])
        # DISCLOSED EXCEPTION (module docstring): global-random-module helper, reused verbatim.
        employment_status, candidate_employer = _resolve_entrant_employment_status(age)
        marital_status = "Never married" if age < 15 else assign_marital_status(age, sex)
        new_person = self._new_person(age, sex, education, employment_status, marital_status)
        if candidate_employer:
            new_person.employer = candidate_employer
            new_person._assign_skill_and_income()
        new_hh_id = g.next_household_id()
        g.HOUSEHOLDS[new_hh_id] = {
            "id": new_hh_id, "type": "Nonfamily household", "members": [new_person],
            "total_income": 0, "savings_balance": self.rng.uniform(5000, 20000),
        }
        new_person.household_id = new_hh_id
        new_person.activate()
        _r2_log_migration(
            simulation_year=year, person_id=new_person.id, direction="IN",
            migration_mechanism="RESIDUAL_EMPIRICAL_MIGRATION", age=age, sex=sex,
            household_id=new_hh_id, employment_state=new_person.employment_status,
            mechanism_subtype=self._mechanism_subtype(entry["is_domestic"]),
        )

    def _create_couple_household(self, a, b, year):
        # Deterministic sex-consistency fix (R7.9 file 07): if both draws landed the same sex,
        # flip the second member's sex deterministically (not re-drawn) to form a Male+Female pair,
        # matching the existing MarriageManager household-type convention exactly.
        if a["sex"] == b["sex"]:
            b = dict(b)
            b["sex"] = "Female" if a["sex"] == "Male" else "Male"

        new_hh_id = g.next_household_id()
        members = []
        for entry in (a, b):
            age, sex = entry["age"], entry["sex"]
            education = self._education_for(age, entry["student"])
            employment_status, candidate_employer = _resolve_entrant_employment_status(age)
            new_person = self._new_person(age, sex, education, employment_status, "Married")
            if candidate_employer:
                new_person.employer = candidate_employer
                new_person._assign_skill_and_income()
            new_person.household_id = new_hh_id
            members.append((new_person, entry))

        male = next(p for p, e in members if p.sex == "Male")
        female = next(p for p, e in members if p.sex == "Female")
        g.HOUSEHOLDS[new_hh_id] = {
            "id": new_hh_id, "type": "Married-couple family household",
            "members": [male, female], "births": 0, "deaths": 0, "marriages": 1,
        }
        for new_person, entry in members:
            new_person.activate()
            _r2_log_migration(
                simulation_year=year, person_id=new_person.id, direction="IN",
                migration_mechanism="RESIDUAL_EMPIRICAL_MIGRATION", age=new_person.age,
                sex=new_person.sex, household_id=new_hh_id,
                employment_state=new_person.employment_status,
                mechanism_subtype=self._mechanism_subtype(entry["is_domestic"]),
            )
