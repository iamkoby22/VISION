# mastercode02_agents.py
import salabim as sim, pandas as pd, warnings, random
from copy import deepcopy
from statsmodels.tsa.arima.model import ARIMA
import numpy as np
from mastercode02_config_and_rates import (HISTORICAL_MACRO_DATA, HISTORICAL_ECONOMIC_DATA,
                                             INCOME_BANDS, SKILL_LEVELS, CAR_AFFORDABILITY,
                                             PUBLIC_TRANSIT_CONFIG, ROAD_NETWORK_CAPACITY,
                                             EMPLOYERS, TENURE_PROBABILITY_MATRIX, GOV_SUPPORT_CONFIG,
                                             COMMUTATION_PURPOSE_RATES, COMMUTATION_PURPOSES,
                                             SIMULATION_DURATION, IMMIGRATION_CONFIG, HOUSING_STOCK,
                                             BANK_LOAN_ANNUAL_CAPACITY, BANK_SAVINGS_ANNUAL_CAPACITY,
                                             GOVERNMENT_SPENDING_ANNUAL_CAP, HOUSING_MARKET_TARGETS, RATES,
                                             FERTILITY_PROBABILITY_SCALE,
                                             POST_HS_ROUTE_PROBS, EDUCATION_REENTRY_PROBS,
                                             EDUCATION_REENTRY_AGE_MULTIPLIERS, COLLEGE_REENTRY_FALLBACK_PROBS,
                                             BUS_OPERATING_DAYS_PER_YEAR, BUS_CAPACITY_UTILIZATION_FACTOR,
                                             BUS_CAPACITY_UNIT_MODE,
                                             JC_PEP_NET_MIGRATION_BY_YEAR, JC_MIGRATION_AGE_ALLOCATION)
import mastercode02_globals as g
from mastercode02_utils import compute_household_cost, is_married_status

warnings.filterwarnings("ignore")

def log_vehicle_event(year, event_type, car_id, details):
    g.VEHICLE_EVENTS.append({'year': year, 'event': event_type, 'car_id': car_id, 'details': details})


# --- Phase 4D: minimal education-resource release helpers (claimed-resource based) ---
def is_education_resource(resource) -> bool:
    """True iff resource is one of the EDUCATION_RESOURCE values (not housing/employer/etc.)."""
    try:
        return resource in g.EDUCATION_RESOURCE.values()
    except Exception:
        return False


def get_claimed_education_resources(person):
    """Return list of (resource_name, resource_obj) for education seats this person currently claims."""
    out = []
    try:
        claimed = person.claimed_resources()
    except Exception:
        return out
    for name, res in g.EDUCATION_RESOURCE.items():
        try:
            if res in claimed:
                out.append((name, res))
        except Exception:
            continue
    return out


def release_claimed_education_resources(person, reason: str, year=None):
    """
    Release only education resources from person.claimed_resources().
    Does not touch employer, housing, or other resources.
    """
    if year is None:
        try:
            year = int(person.env.now())
        except Exception:
            year = -1
    released_names = []
    for name, res in get_claimed_education_resources(person):
        success = False
        err = ""
        try:
            if is_education_resource(res) and res in person.claimed_resources():
                person.release(res)
                success = res not in person.claimed_resources()
                if success:
                    released_names.append(name)
        except Exception as exc:
            err = str(exc)
            success = False
        try:
            from mastercode02_phase4d_diagnostics import record_education_release
            record_education_release(
                year=year,
                person_id=getattr(person, "id", None),
                current_education=getattr(person, "education", None),
                resource_name=name,
                release_reason=reason,
                release_attempted=True,
                release_success=success,
                error_message=err,
                notes="Phase 4D claim-based education release only",
            )
        except ImportError:
            pass
    return released_names

class Person(sim.Component):
    def __init__(self, env, initial_data, population_list):
        super().__init__(env=env)
        self.id = initial_data['id']; self.age = initial_data['age']; self.sex = initial_data['sex']
        self.education = initial_data['education']; self.employment_status = initial_data['employment']
        self.employer = None; self.household_id = initial_data['household_id']
        self.marital_status = initial_data.get('marital_status', 'Single'); self.year_in_level = 0
        self.skill_level = None; self.annual_income = 0; self.gov_support_cum = 0; self.cars = []
        self.use_bus = False; self.accident_involvement = False; self.commute_purpose = "Other"
        self.layoff_status = False; self.is_in_jc_school = False; self.years_married = None
        self.last_tertiary_program = None  # Phase 4B: track University vs Community College for college reentry
        self.start_age_nursery = random.choice([2, 3]); self.start_age_elementary = self.start_age_nursery + 2
        self.start_age_middle = self.start_age_elementary + 5; self.start_age_high_school = self.start_age_middle + 3
        self.start_age_college = self.start_age_high_school + 4; self.start_age_masters = self.start_age_college + 4
        self.start_age_phd = self.start_age_masters + 2
        if self.education in ['Nursery/Preschool', 'Elementary (K-5)', 'Middle (6-8)', 'High School (9-12)', 'University']:
            start_ages = {'Nursery/Preschool': self.start_age_nursery, 'Elementary (K-5)': self.start_age_elementary, 'Middle (6-8)': self.start_age_middle, 'High School (9-12)': self.start_age_high_school, 'University': self.start_age_college}
            self.year_in_level = max(1, int(self.age - start_ages.get(self.education, self.age) + 1))
        if self.education == 'University':
            self.last_tertiary_program = 'University'
        population_list.append(self)
        self.passivate()

    def process(self):
        if self.employer and self.employer in g.EMPLOYER_RESOURCE:
            yield self.request(g.EMPLOYER_RESOURCE[self.employer])
        
        while True:
            # Gate 2: explicit 3-way composition (base schedule x city calibration x
            # annual ARIMA trend x event modifier) -- was previously base x
            # arima_death_rate_modifier x event, where arima_death_rate_modifier
            # silently held the ANNUAL trend value, never the city-specific one.
            death_prob = RATES['Death Rates'][self.sex].get(self.get_age_group(), 0) * g.city_death_rate_modifier * g.annual_death_rate_modifier * g.event_death_rate_modifier
            # Ticket 10: a probability can never be negative or exceed 1, regardless of
            # what upstream modifiers compute (mirrors the existing final_birth_prob clamp
            # below, which already guards the fertility side against the same class of
            # out-of-range modifier product).
            death_prob = max(0.0, min(death_prob, 1.0))
            if random.random() < death_prob:
                self.die(); break

            yield self.hold(1)
            self.age += 1
            if self.years_married is not None:
                self.years_married += 1

            self.update_education_cyclical()
            yield from self.update_employment_status()

            if self.sex == 'Female' and 15 <= self.age < 50:
                fertility_marital_key = 'Married' if is_married_status(self.marital_status) else 'Unmarried'
                base_birth_prob = RATES['Fertility Rate'][fertility_marital_key].get(self.get_age_group(), 0)
                # Gate 2: explicit composition, same correction as death_prob above.
                final_birth_prob = base_birth_prob * g.city_birth_rate_modifier * g.annual_birth_rate_modifier * g.event_birth_rate_modifier
                marriage_mult = 1.0
                if self.years_married is not None and self.years_married <= 10:
                    marriage_mult = 1.5
                    final_birth_prob *= marriage_mult
                # Phase 3B: apply reversible fertility calibration scale after all multipliers
                final_birth_prob = final_birth_prob * FERTILITY_PROBABILITY_SCALE
                final_birth_prob = max(0.0, min(final_birth_prob, 1.0))
                if random.random() < final_birth_prob:
                    self._last_birth_prob_info = {
                        'base_birth_prob': base_birth_prob,
                        'city_modifier': g.city_birth_rate_modifier,
                        'annual_modifier': g.annual_birth_rate_modifier,
                        'event_modifier': g.event_birth_rate_modifier,
                        'marriage_multiplier': marriage_mult,
                        'marriage_multiplier_applied': marriage_mult > 1.0,
                        'fertility_scale': FERTILITY_PROBABILITY_SCALE,
                        'final_scaled_birth_prob': final_birth_prob,
                        'age_group': self.get_age_group(),
                        'raw_marital_status': self.marital_status,
                        'classified_as_married': is_married_status(self.marital_status),
                        'fertility_table_used': fertility_marital_key,
                    }
                    self.give_birth(g.HOUSEHOLDS, g.POPULATION)
            
            self._update_income_annually()
            self._manage_car_lifecycle()
            self._decide_on_car_purchase()
            self._update_commute_details()

            household = g.HOUSEHOLDS.get(self.household_id)
            if 22 <= self.age <= 30 and self.marital_status == 'Never married' and household and 'family' in household.get('type', ''):
                prob_to_move_out = 0.10 * (g.current_rental_vacancy_rate / HOUSING_MARKET_TARGETS['target_rental_vacancy_rate'])
                if random.random() < prob_to_move_out:
                    # Leave parental HH; release parental housing only if HH becomes empty
                    hh_id = self.household_id
                    household['members'].remove(self)
                    self.household_id = None
                    if hh_id is not None and len(household.get('members', [])) == 0:
                        from mastercode02_housing_ledger import release_housing_for_household
                        release_housing_for_household(hh_id, int(self.env.now()), reason='move_out_empty_household')
    
    def die(self):
        current_year = int(self.env.now())
        # Phase 4D: release any claimed education seats (not lookup-by-current-education)
        before_edu_claims = [n for n, _ in get_claimed_education_resources(self)]
        released_edu = release_claimed_education_resources(self, "death", current_year)
        after_edu_claims = [n for n, _ in get_claimed_education_resources(self)]
        try:
            from mastercode02_phase4d_diagnostics import record_death_education_release
            record_death_education_release(
                year=current_year,
                deceased_person_id=self.id,
                education_at_death=self.education,
                education_resources_claimed_before_death=";".join(before_edu_claims),
                education_resources_released_on_death=";".join(released_edu),
                unreleased_education_resources_after_death=";".join(after_edu_claims),
            )
        except ImportError:
            pass
        
        household = g.HOUSEHOLDS.get(self.household_id)
        hh_id_for_housing = self.household_id
        was_last_member = bool(household and len(household.get('members', [])) == 1)

        if self.cars and household:
            other_adults = [p for p in household['members'] if p is not self and p.age >= 18]
            if other_adults:
                heir = max(other_adults, key=lambda p: p.age)
                heir.cars.extend(self.cars)
                log_vehicle_event(current_year, 'Inheritance', ','.join([c['id'] for c in self.cars]), f"Owner {self.id} died, cars inherited by {heir.id}")
            else:
                for car in self.cars: log_vehicle_event(current_year, 'Retirement', car['id'], f"Owner {self.id} died, no heir.")
        
        if self.employer and self.employer in g.EMPLOYER_RESOURCE and g.EMPLOYER_RESOURCE[self.employer] in self.claimed_resources():
            self.release(g.EMPLOYER_RESOURCE[self.employer])
        
        if household and self in household['members']:
            household['deaths'] = household.get('deaths', 0) + 1
            household['members'].remove(self)
            # Phase 6B: release durable housing claim by household_id when HH becomes empty
            if was_last_member and hh_id_for_housing is not None:
                from mastercode02_housing_ledger import release_housing_for_household
                release_housing_for_household(hh_id_for_housing, current_year, reason='death_empty_household')
            
        if self in g.POPULATION:
            g.POPULATION.remove(self)
            
        self.cancel()

    def _manage_car_lifecycle(self):
        if not self.cars: return
        current_year = int(self.env.now())
        for car in self.cars[:]:
            car['age'] = car.get('age', 0) + 1
            if car['age'] > 10:
                self.cars.remove(car)
                log_vehicle_event(current_year, 'Retirement', car['id'], f"Car retired by {self.id}")

    def _decide_on_car_purchase(self):
        if self.age < 18 or self.cars: return
        household = g.HOUSEHOLDS.get(self.household_id)
        if not household: return
        if household.get('total_income', 0) > CAR_AFFORDABILITY['min_household_income_threshold']:
            prob = 0.10
            if self.employment_status == 'Employed': prob = 0.30
            if random.random() < prob:
                new_car_id = g.next_car_id()
                self.cars.append({'id': new_car_id, 'age': 0})
                log_vehicle_event(int(self.env.now()), 'Purchase', new_car_id, f"Purchased by {self.id}")

    def _assign_skill_and_income(self):
        if self.employment_status != 'Employed' or not self.employer:
            self.skill_level = None; self.annual_income = 0
            return
        if self.education in ['masters_completed', 'phd_completed']: self.skill_level = SKILL_LEVELS[3]
        elif self.education == 'college_completed': self.skill_level = SKILL_LEVELS[2]
        elif self.education in ['high_school_completed', 'college_dropout']: self.skill_level = SKILL_LEVELS[1]
        else: self.skill_level = SKILL_LEVELS[0]
        employer_data = EMPLOYERS.get(self.employer)
        if not employer_data:
            self.annual_income = 0
            return
        employer_name = employer_data['name']
        skill_index = SKILL_LEVELS.index(self.skill_level); income_range = INCOME_BANDS[employer_name][skill_index]
        base_income = random.uniform(income_range[0], income_range[1])
        self.annual_income = base_income * g.event_income_modifier

    def _update_income_annually(self):
        if self.annual_income > 0:
            self.annual_income *= (1 + self.env.salary_inflation)

    def _update_commute_details(self):
        age_group = '0-4' if self.age <= 4 else '5-17' if self.age <= 17 else '18-24' if self.age <= 24 else '25-54' if self.age <= 54 else '55-64' if self.age <= 64 else '65+'
        weights = COMMUTATION_PURPOSE_RATES[age_group]
        self.commute_purpose = random.choices(COMMUTATION_PURPOSES, weights=weights, k=1)[0]
        g.TRIP_SUMMARY.append({'year': int(self.env.now()), 'purpose': self.commute_purpose})
        if self.cars:
            self.use_bus = False

    def update_employment_status(self):
        if self.employment_status == 'Employed' and random.random() < 0.05:
            self.layoff_status = True; self.employment_status = 'Unemployed'
            if self.employer and self.employer in g.EMPLOYER_RESOURCE and g.EMPLOYER_RESOURCE[self.employer] in self.claimed_resources():
                yield self.release(g.EMPLOYER_RESOURCE[self.employer])
            self.employer = None; self._assign_skill_and_income()
        if self.employment_status in ['Not in Labor Force', 'Unemployed'] and 18 <= self.age < 65:
            job_chance = RATES['Employment']['Employed'].get(self.get_age_group(), 0) * g.event_employment_rate_modifier
            if random.random() < job_chance:
                available = {n: r for n, r in g.EMPLOYER_RESOURCE.items() if r.available_quantity() > 0}
                if available:
                    chosen = random.choice(list(available.keys())); yield self.request(g.EMPLOYER_RESOURCE[chosen])
                    self.employment_status = 'Employed'; self.employer = chosen; self._assign_skill_and_income()

    def get_age_group(self):
        if self.age <= 4: return '0-4'
        if self.age <= 9: return '5-9'
        if self.age <= 14: return '10-14'
        if self.age <= 19: return '15-19'
        if self.age <= 24: return '20-24'
        if self.age <= 29: return '25-29'
        if self.age <= 34: return '30-34'
        if self.age <= 39: return '35-39'
        if self.age <= 44: return '40-44'
        if self.age <= 49: return '45-49'
        if self.age <= 54: return '50-54'
        if self.age <= 59: return '55-59'
        if self.age <= 64: return '60-64'
        if self.age <= 69: return '65-69'
        if self.age <= 74: return '70-74'
        if self.age <= 79: return '75-79'
        if self.age <= 84: return '80-84'
        return '85+'

    def give_birth(self, households, population_list):
        new_id = g.next_person_id()
        initial_data = {'id': new_id, 'age': 0, 'sex': random.choice(['Male', 'Female']), 'education': 'too_young', 'employment': 'Too Young', 'household_id': self.household_id, 'marital_status': 'Never married'}
        new_person = Person(self.env, initial_data, population_list)
        if self.household_id in households:
            households[self.household_id]['members'].append(new_person)
            households[self.household_id]['births'] = households[self.household_id].get('births', 0) + 1
        new_person.activate()
        try:
            from mastercode02_phase3c_diagnostics import record_birth_trace
            info = getattr(self, '_last_birth_prob_info', None)
            if info is not None:
                record_birth_trace(self, info, new_id, int(self.env.now()))
                self._last_birth_prob_info = None
        except ImportError:
            pass

    def _education_reentry_age_multiplier(self):
        for band in EDUCATION_REENTRY_AGE_MULTIPLIERS:
            if band["min_age"] <= self.age <= band["max_age"]:
                return float(band["multiplier"])
        return 0.0

    def _try_dropout_reentry(self):
        """Phase 4B: low-probability reentry into existing education states only."""
        dropout_state = self.education
        cfg = EDUCATION_REENTRY_PROBS.get(dropout_state)
        if cfg is None:
            try:
                from mastercode02_phase4b_diagnostics import record_unsupported_dropout
                record_unsupported_dropout(self, dropout_state)
            except ImportError:
                pass
            return False
        base_p = float(cfg["base_annual_probability"])
        age_mult = self._education_reentry_age_multiplier()
        final_p = max(0.0, min(1.0, base_p * age_mult))
        draw = random.random()
        year = int(self.env.now()) if self.env is not None else -1
        target = None
        if draw < final_p:
            if dropout_state == "high_school_dropout":
                target = "High School (9-12)"
            elif dropout_state == "masters_dropout":
                target = "masters_program"
            elif dropout_state == "college_dropout":
                prior = getattr(self, "last_tertiary_program", None)
                if prior in ("University", "Community College"):
                    target = prior
                else:
                    # fallback 50/50 Community College / University
                    target = "Community College" if random.random() < COLLEGE_REENTRY_FALLBACK_PROBS["Community College"] else "University"
            if target is not None:
                self.education = target
                self.year_in_level = 1
                if target in ("University", "Community College"):
                    self.last_tertiary_program = target
        try:
            from mastercode02_phase4b_diagnostics import record_reentry_event
            record_reentry_event(
                year=year, person=self, dropout_state=dropout_state, target_state=target or "",
                base_probability=base_p, age_multiplier=age_mult, final_probability=final_p,
                random_draw=draw, successful=(target is not None and draw < final_p),
            )
        except ImportError:
            pass
        return target is not None and draw < final_p

    def update_education_cyclical(self):
        # Phase 4B extension: rare dropout reentry (existing dropout states were terminal)
        if self.education in ("high_school_dropout", "college_dropout", "masters_dropout"):
            self._try_dropout_reentry()
            return
        if self.education in ['High School (9-12)', 'University', 'Community College'] and random.random() < g.event_dropout_prob:
            if self.education == 'High School (9-12)':
                self.education = 'high_school_dropout'
            else:
                self.last_tertiary_program = self.education
                self.education = 'college_dropout'
            self.year_in_level = 0
            return
        current_level = self.education
        if self.education in ['Nursery/Preschool', 'Elementary (K-5)', 'Middle (6-8)', 'High School (9-12)', 'University', 'Community College', 'masters_program', 'phd_program']:
            self.year_in_level += 1
        if self.age == self.start_age_nursery and current_level == 'too_young': self.education = 'Nursery/Preschool'; self.year_in_level = 1
        elif self.year_in_level > 2 and current_level == 'Nursery/Preschool': self.education = 'Elementary (K-5)'; self.year_in_level = 1
        elif self.year_in_level > 5 and current_level == 'Elementary (K-5)': self.education = 'Middle (6-8)'; self.year_in_level = 1
        elif self.year_in_level > 3 and current_level == 'Middle (6-8)': self.education = 'High School (9-12)'; self.year_in_level = 1
        elif self.year_in_level > 4 and current_level == 'High School (9-12)': self.education = 'high_school_completed' if random.random() < 0.95 else 'high_school_dropout'; self.year_in_level = 0
        elif self.education == 'high_school_completed' and self.age >= self.start_age_college:
            # Phase 4B: extend post-HS branch only (prior: 60% University / 40% remain)
            r = random.random()
            u = POST_HS_ROUTE_PROBS["University"]
            cc = POST_HS_ROUTE_PROBS["Community College"]
            if r < u:
                self.education = "University"
                self.last_tertiary_program = "University"
                self.year_in_level = 1
            elif r < u + cc:
                self.education = "Community College"
                self.last_tertiary_program = "Community College"
                self.year_in_level = 1
            # else: remain high_school_completed
            try:
                from mastercode02_phase4b_diagnostics import record_post_hs_route
                record_post_hs_route(self, r, u, cc)
            except ImportError:
                pass
        elif self.year_in_level > 4 and current_level == 'University':
            self.last_tertiary_program = getattr(self, "last_tertiary_program", None) or "University"
            self.education = 'college_completed' if random.random() < 0.75 else 'college_dropout'; self.year_in_level = 0
        elif self.year_in_level > 4 and current_level == 'Community College':
            # Phase 4B: reuse University tertiary outcome pattern (same 75%/25%); outcomes college_completed/college_dropout
            self.last_tertiary_program = getattr(self, "last_tertiary_program", None) or "Community College"
            self.education = 'college_completed' if random.random() < 0.75 else 'college_dropout'; self.year_in_level = 0
        elif self.education == 'college_completed' and self.age >= self.start_age_masters:
            if random.random() < 0.10: self.education = 'masters_program'; self.year_in_level = 1
        elif self.year_in_level > 2 and current_level == 'masters_program': self.education = 'masters_completed' if random.random() < 0.90 else 'masters_dropout'; self.year_in_level = 0
        elif self.education == 'masters_completed' and self.age >= self.start_age_phd:
             if random.random() < 0.05: self.education = 'phd_program'; self.year_in_level = 1
        elif self.year_in_level > 4 and current_level == 'phd_program': self.education = 'phd_completed'; self.year_in_level = 0

class EducationManager(sim.Component):
    def process(self):
        while True:
            yield self.hold(1)
            year = int(self.env.now())
            # Phase 4D: release by claimed education resources (not current-education key lookup)
            all_students = [p for p in g.POPULATION if p.is_in_jc_school]
            for student in all_students:
                release_claimed_education_resources(student, "annual_jc_school_sync", year)
                student.is_in_jc_school = False
            # Safety: clear any leftover mismatched/stale education seats
            for person in g.POPULATION:
                claimed_edu = get_claimed_education_resources(person)
                if not claimed_edu:
                    continue
                mismatched = any(name != person.education for name, _ in claimed_edu)
                left_enrollment = person.education not in g.EDUCATION_RESOURCE
                if mismatched or left_enrollment:
                    release_claimed_education_resources(person, "stale_mismatched_claim_cleanup", year)
            for level_name, resource in g.EDUCATION_RESOURCE.items():
                eligible_students = [p for p in g.POPULATION if p.education == level_name]
                random.shuffle(eligible_students)
                available_seats = int(resource.capacity())
                enrolled_count = 0
                for student in eligible_students:
                    if enrolled_count < available_seats:
                        student.request(resource)
                        student.is_in_jc_school = True
                        enrolled_count += 1
                        # Phase 8A-FU2: observational only (no RNG, no progression effect)
                        student.education_local_seat_status = "local_claimed"
                    else:
                        student.is_in_jc_school = False
                        # Phase 8A-FU2: excess eligible student refused a LOCAL seat -> external/out-of-town.
                        # Observational label only; progression is seat-independent (see update_education_cyclical).
                        student.education_local_seat_status = "external_overflow"

def compute_scenario_event_modifiers(events, current_year):
    """Ticket 12: pure computation of one simulated year's event modifiers, factored
    out of ScenarioManager.process() so the interaction logic is unit-testable
    without a full salabim environment, and so there is exactly one implementation
    shared by the real simulation and the regression tests.

    Every modifier below except two is combined via commutative multiplication
    (`*=`), which is already correctly order-independent for any number of active
    events, same-type or cross-type (unchanged from the original approved source).

    Two fields were plain assignments (`=`) in the original source — a genuine,
    order-dependent last-write-wins defect, not an intentional design choice (no
    project evidence anywhere assigns meaning to "whichever event happens to be
    later in the list wins"; the original interactive driver script could produce
    at most one event per type and never exercised this interaction at all):

    - event_gov_cap_modifier: both panic (-> infinity) and political_stability
      (-> 1.5) unconditionally overwrote it. Fixed to `max(...)` — the most
      permissive (largest) cap among all currently active overrides always wins,
      regardless of declaration order. This is the natural, non-arbitrary
      aggregation for a "cap" (ceiling) quantity — not a choice between the two
      event TYPES, just consistent semantics for what a ceiling means when more
      than one override is in effect. For the single-event-active case (the only
      case any prior ticket's tests, or the original driver script, ever
      exercised) this is bit-for-bit identical to the old behavior:
      max(1.0, 1.5) == 1.5, max(1.0, inf) == inf.
    - event_dropout_prob: panic alone overwrote it (`= 0.05*level`); two
      simultaneously active panic events silently discarded all but the last
      one's contribution, unlike every other panic-driven quantity in the same
      formula (deaths/employment/income/inflation/gov_support), which already
      compound correctly. Fixed to accumulate additively across all active panic
      events, then clamp to [0, 1] once — consistent with the "more simultaneous
      panic exposure compounds" pattern already established by panic's other five
      fields, rather than an arbitrary new cross-type precedence rule. For a
      single active panic event this is identical to the old behavior:
      min(1.0, 0.0 + 0.05*level) == 0.05*level for panic's full domain [0, 10].
    """
    birth = death = employment = inflation = income = gov_support = 1.0
    gov_cap = 1.0
    dropout_raw = 0.0
    housing = 1.0  # INTERNAL_MODIFIER_NOT_EVENT — no event type sets this (unchanged)
    for event in events:
        if event['enabled'] and event['start_year'] <= current_year < event['end_year']:
            level = event['level']
            if event['type'] == 'public_health':
                birth *= (1 + 0.1 * level); death *= (1 - 0.1 * level)
                employment *= (1 + 0.05 * level)
            elif event['type'] == 'political_stability':
                inflation *= (1 - 0.05 * level); employment *= (1 + 0.05 * level)
                gov_cap = max(gov_cap, 1.5); income *= (1 + 0.05 * level)
                gov_support *= (1 + 0.1 * level)
            elif event['type'] == 'panic':
                death *= (1 + 0.5 * level); employment *= (1 - 0.1 * level)
                income *= (1 - 0.1 * level); dropout_raw += 0.05 * level
                inflation *= (1 + 0.1 * level); gov_cap = max(gov_cap, float('inf'))
                gov_support *= (1 + 0.2 * level)
    return {
        'event_birth_rate_modifier': birth, 'event_death_rate_modifier': death,
        'event_employment_rate_modifier': employment, 'event_inflation_modifier': inflation,
        'event_income_modifier': income, 'event_gov_support_modifier': gov_support,
        'event_gov_cap_modifier': gov_cap, 'event_dropout_prob': min(1.0, dropout_raw),
        'event_housing_cost_modifier': housing,
    }


class ScenarioManager(sim.Component):
    def __init__(self, env, events):
        super().__init__(env=env)
        self.events = events
    def process(self):
        while True:
            current_year = int(self.env.now())
            for name, value in compute_scenario_event_modifiers(self.events, current_year).items():
                setattr(g, name, value)
            yield self.hold(1)


class WorldManager(sim.Component):
    def __init__(self, env):
        super().__init__(env=env); self.forecasts = {}
        # Gate 2 correction: this class must reset the ANNUAL trend modifiers
        # only. It must NEVER touch city_death_rate_modifier /
        # city_birth_rate_modifier / city_marriage_rate_modifier -- those are
        # set once by reset_global_state() from the approved config override
        # and belong exclusively to it. (This unconditional reset previously
        # used the arima_*_modifier names, which the R11 city-calibration
        # feature also wrote to -- the exact collision Gate 1 root-caused.)
        g.annual_death_rate_modifier = 1.0; g.annual_birth_rate_modifier = 1.0
        g.annual_marriage_rate_modifier = 1.0  # stays 1.0 always -- see process() below
        g.arima_owner_preference_modifier = 1.0
        self._train_models()
    def _train_models(self):
        df_macro = pd.DataFrame(HISTORICAL_MACRO_DATA); df_macro.set_index('Year', inplace=True)
        df_econ = pd.DataFrame(HISTORICAL_ECONOMIC_DATA); df_econ.set_index('Year', inplace=True)
        for column in ['Mortality Rate', 'Birth Rate', 'Employment Rate']:
            try:
                model = ARIMA(df_macro[column], order=(1, 1, 1)).fit()
                pred = model.get_forecast(steps=SIMULATION_DURATION + 1)
                self.forecasts[column] = {'mean': pred.predicted_mean,'stderr': pred.se_mean,'base_value': df_macro[column].iloc[-1]}
            except Exception as e: print(f"ARIMA training failed for {column}: {e}")
        try:
            model = ARIMA(df_econ['30-Yr Mortgage'], order=(1, 1, 1)).fit()
            pred = model.get_forecast(steps=SIMULATION_DURATION + 1)
            self.forecasts['30-Yr Mortgage'] = {'mean': pred.predicted_mean, 'stderr': pred.se_mean, 'base_value': df_econ['30-Yr Mortgage'].mean()}
        except Exception as e: print(f"ARIMA training failed for 30-Yr Mortgage: {e}")
    def process(self):
        while True:
            yield self.hold(1)
            year = int(self.env.now())
            if year >= SIMULATION_DURATION: break
            try:
                # Gate 2 correction: the ('Employment Rate', 'arima_marriage_rate_modifier')
                # entry was REMOVED here. It accidentally used the Employment Rate
                # ARIMA forecast as a stand-in "marriage ARIMA" series -- no
                # marriage-rate historical series exists in HISTORICAL_MACRO_DATA,
                # and no new one was invented (see Gate 2 report Section 3).
                # annual_marriage_rate_modifier is therefore never reassigned
                # after __init__ and stays at its neutral 1.0 default for the
                # entire run -- an explicit, documented no-op, not a silent gap.
                for rate_name, g_modifier_name in [('Mortality Rate', 'annual_death_rate_modifier'),('Birth Rate', 'annual_birth_rate_modifier')]:
                    forecast_data = self.forecasts[rate_name]
                    mean = forecast_data['mean'].iloc[year]; stderr = forecast_data['stderr'].iloc[year]
                    stochastic_forecast = np.random.normal(loc=mean, scale=stderr)
                    scaling_factor = stochastic_forecast / forecast_data['base_value'] if forecast_data['base_value'] != 0 else 1
                    setattr(g, g_modifier_name, scaling_factor)
                forecast_data = self.forecasts['30-Yr Mortgage']
                mean = forecast_data['mean'].iloc[year]; stderr = forecast_data['stderr'].iloc[year]
                stochastic_forecast = np.random.normal(loc=mean, scale=stderr)
                g.arima_owner_preference_modifier = forecast_data['base_value'] / stochastic_forecast if stochastic_forecast > 0 else 1.0
            except Exception as e: print(f"Error in WorldManager process: {e}")

class EconomicManager(sim.Component):
    def __init__(self, env):
        super().__init__(env=env); self.forecasts = {}; self._train_models(); self.update_env_rates(0)
    def _train_models(self):
        df = pd.DataFrame(HISTORICAL_ECONOMIC_DATA); df.set_index('Year', inplace=True)
        for column in ['Top Tax Rate', 'Salary Inflation', 'Cost Inflation (CPI)', '30-Yr Mortgage']:
            try:
                model = ARIMA(df[column], order=(1, 1, 1)).fit()
                pred = model.get_forecast(steps=SIMULATION_DURATION + 1)
                self.forecasts[column] = {'mean': pred.predicted_mean, 'stderr': pred.se_mean}
            except Exception as e: print(f"ARIMA training failed for {column}: {e}")
    def update_env_rates(self, year):
        for rate_name, env_var in [('Top Tax Rate', 'tax_rate'), ('Salary Inflation', 'salary_inflation'), ('Cost Inflation (CPI)', 'cpi_inflation'), ('30-Yr Mortgage', 'mortgage_rate')]:
            forecast_data = self.forecasts[rate_name]; mean = forecast_data['mean'].iloc[year]; stderr = forecast_data['stderr'].iloc[year]
            stochastic_forecast = np.random.normal(loc=mean, scale=stderr); base_rate = stochastic_forecast / 100
            if env_var == 'cpi_inflation': base_rate *= g.event_inflation_modifier
            setattr(self.env, env_var, base_rate)
    def process(self):
        while True:
            yield self.hold(1); year = int(self.env.now())
            if year >= SIMULATION_DURATION: break
            try: self.update_env_rates(year)
            except Exception as e: print(f"Error in EconomicManager process: {e}")

class HouseholdFinanceManager(sim.Component):
    def process(self):
        while True:
            yield self.hold(1)
            for hh_id, hh_data in g.HOUSEHOLDS.items():
                members = hh_data.get('members', [])
                if not members: continue
                total_income = sum(p.annual_income for p in members)
                cpi_multiplier = 1 + self.env.cpi_inflation
                required_cost = compute_household_cost(hh_data, cpi_multiplier, self.env.mortgage_rate)
                taxes = total_income * self.env.tax_rate
                net_income_minus_cost = (total_income - taxes) - required_cost
                savings = hh_data.get('savings_balance', 0); loans = hh_data.get('loan_balance', 0); loan_repaid = hh_data.get('loan_repaid_cum', 0)
                if net_income_minus_cost > 0:
                    repayment = min(net_income_minus_cost, loans)
                    if repayment > 0: loans -= repayment; loan_repaid += repayment; net_income_minus_cost -= repayment
                    if g.annual_savings_accepted + net_income_minus_cost <= BANK_SAVINGS_ANNUAL_CAPACITY:
                        g.annual_savings_accepted += net_income_minus_cost
                        savings += net_income_minus_cost
                    else:
                        g.refused_log['savings'] += 1
                else:
                    deficit = abs(net_income_minus_cost)
                    if g.annual_loans_disbursed + deficit <= BANK_LOAN_ANNUAL_CAPACITY:
                        g.annual_loans_disbursed += deficit
                        loans += deficit
                    else:
                        g.refused_log['loans'] += 1
                hh_data.update({'total_income': total_income, 'required_cost': required_cost, 'savings_balance': savings, 'loan_balance': loans, 'loan_repaid_cum': loan_repaid, 'taxes_cum': hh_data.get('taxes_cum', 0) + taxes})

class PublicTransitManager(sim.Component):
    def process(self):
        ratio = PUBLIC_TRANSIT_CONFIG['initial_buses'] / 73440
        while True:
            current_pop = len(g.POPULATION); self.env.bus_fleet_size = int(np.ceil(current_pop * ratio))
            # Preserve daily capacity; Phase 5B adds annualized capacity for annual demand comparison
            daily_capacity = self.env.bus_fleet_size * PUBLIC_TRANSIT_CONFIG['bus_capacity'] * PUBLIC_TRANSIT_CONFIG['trips_per_bus_per_day']
            annual_capacity = daily_capacity * BUS_OPERATING_DAYS_PER_YEAR * BUS_CAPACITY_UTILIZATION_FACTOR
            self.env.bus_daily_capacity = daily_capacity
            self.env.bus_annual_capacity = annual_capacity
            self.env.bus_operating_days_per_year = BUS_OPERATING_DAYS_PER_YEAR
            self.env.bus_capacity_utilization_factor = BUS_CAPACITY_UTILIZATION_FACTOR
            self.env.bus_capacity_unit_mode = BUS_CAPACITY_UNIT_MODE
            # CommuteManager / logging historically read total_bus_capacity — use annual for unit-matched demand
            self.env.total_bus_capacity = annual_capacity
            yield self.hold(1)

class CommuteManager(sim.Component):
    def process(self):
        while True:
            yield self.hold(1)
            bus_demand = sum(1 for p in g.POPULATION if not p.cars and p.commute_purpose in ['Work', 'School'])
            # Phase 5B: compare annual demand to annual capacity (not daily-scale scalar)
            bus_capacity = getattr(self.env, 'bus_annual_capacity', getattr(self.env, 'total_bus_capacity', 0))
            service_ratio = min(1.0, bus_capacity / bus_demand if bus_demand > 0 else 1.0)
            served_passengers = int(bus_demand * service_ratio)
            self.env.bus_passengers_served = served_passengers; self.env.bus_passengers_refused = bus_demand - served_passengers
            self.env.bus_annual_demand = bus_demand
            for p in g.POPULATION:
                if not p.cars and p.commute_purpose in ['Work', 'School']: p.use_bus = True if random.random() < service_ratio else False
                else: p.use_bus = False

class GovernmentManager(sim.Component):
    def process(self):
        while True:
            yield self.hold(1)
            current_gov_cap = GOVERNMENT_SPENDING_ANNUAL_CAP * g.event_gov_cap_modifier
            for hh_id, hh_data in g.HOUSEHOLDS.items():
                members = hh_data.get('members', []); adults = [p for p in members if p.age >= 18]; children = [p for p in members if p.age < 18]
                if not members: continue
                if len(adults) == 1 and len(children) > 0:
                    support_amount = GOV_SUPPORT_CONFIG['single_parent_support'] * g.event_gov_support_modifier
                    if g.annual_gov_support_disbursed + support_amount <= current_gov_cap: g.annual_gov_support_disbursed += support_amount; adults[0].gov_support_cum += support_amount
                    else: g.refused_log['gov_support'] += 1
                if len(children) > 0 and hh_data.get('total_income', 0) > 0 and hh_data.get('total_income', 0) < hh_data.get('required_cost', 0) * 1.25:
                    support_per_adult = (len(children) * GOV_SUPPORT_CONFIG['food_stamp_per_child'] * g.event_gov_support_modifier) / len(adults) if adults else 0
                    for adult in adults:
                        if g.annual_gov_support_disbursed + support_per_adult <= current_gov_cap: g.annual_gov_support_disbursed += support_per_adult; adult.gov_support_cum += support_per_adult
                        else: g.refused_log['gov_support'] += 1

class MarriageManager(sim.Component):
    def __init__(self, env, households, population, marriages):
        super().__init__(env=env); self.households = households; self.population = population; self.marriages = marriages
    def process(self):
        while True:
            yield self.hold(1)
            eligible_males = [p for p in self.population if not p.ispassive() and p.sex == 'Male' and p.age >= 22 and p.marital_status == 'Never married']
            random.shuffle(eligible_males)
            # R11.1 Phase 5: eligible_females was rebuilt via a full O(P) scan of
            # self.population for every marrying male (up to O(len(eligible_males))
            # times per year -> O(P^2)/year at scale; confirmed via cProfile,
            # 716.6s of self-time over 3 profiled Knoxville years). Pre-filter once
            # per year into eligible_females_pool, then age-window-filter that
            # (much smaller, never-married-only) pool per male. A married female is
            # removed from the pool immediately so it always reflects exactly the
            # same live marital_status a fresh full-population scan would have seen
            # at that point in the loop -- same set, same relative (population)
            # order, so random.choice() selects identically to before for a fixed
            # seed (see tests/test_r11_1_marriage_manager_pool.py).
            eligible_females_pool = [p for p in self.population if not p.ispassive() and p.sex == 'Female' and p.marital_status == 'Never married']
            for male in eligible_males:
                # Gate 2: explicit composition (city calibration x annual [neutral]).
                marriage_prob = 0.40 * g.city_marriage_rate_modifier * g.annual_marriage_rate_modifier
                if random.random() < marriage_prob:
                    eligible_females = [p for p in eligible_females_pool if abs(p.age - male.age) <= 5]
                    if eligible_females:
                        female = random.choice(eligible_females); new_hh_id = g.next_household_id()
                        self.form_new_household(male, female, new_hh_id)
                        male.marital_status = 'Married'; female.marital_status = 'Married'
                        eligible_females_pool.remove(female)
    def form_new_household(self, person1, person2, new_hh_id):
        male, female = (person1, person2) if person1.sex == 'Male' else (person2, person1)
        male.years_married = 0; female.years_married = 0
        man_former_hh, woman_former_hh = male.household_id, female.household_id
        if man_former_hh in g.HOUSEHOLDS and male in g.HOUSEHOLDS[man_former_hh]['members']: g.HOUSEHOLDS[man_former_hh]['members'].remove(male)
        if woman_former_hh in g.HOUSEHOLDS and female in g.HOUSEHOLDS[woman_former_hh]['members']: g.HOUSEHOLDS[woman_former_hh]['members'].remove(female)
        g.HOUSEHOLDS[new_hh_id] = {'id': new_hh_id, 'type': 'Married-couple family household', 'members': [male, female], 'births': 0, 'deaths': 0, 'marriages': 1}
        male.household_id = new_hh_id; female.household_id = new_hh_id
        marriage_id = f"M_{int(self.env.now())}_{g.next_marriage_id()}"
        g.MARRIAGES.append({'marriage_id': marriage_id, 'man_id': male.id, 'man_former_hh': man_former_hh, 'man_age': male.age, 'woman_id': female.id, 'woman_former_hh': woman_former_hh, 'woman_age': female.age, 'new_hh_id': new_hh_id, 'year_of_marriage': int(self.env.now())})

class TrafficManager(sim.Component):
    def process(self):
        while True:
            yield self.hold(1); car_commuters = sum(len(p.cars) for p in g.POPULATION if not p.ispassive())
            total_wait_time = 0; status = {}
            for road_type, capacity in ROAD_NETWORK_CAPACITY.items():
                load_factor = car_commuters / capacity if capacity > 0 else 0; road_wait_time = 0
                if load_factor < 0.7: status[road_type] = 'Normal'
                elif load_factor < 1.0: status[road_type] = 'Congested'; road_wait_time = (load_factor - 0.7) * 30
                else: status[road_type] = 'Gridlock'; road_wait_time = 9 + (load_factor - 1.0) * 60
                total_wait_time += road_wait_time
            g.ANNUAL_SUMMARY_DATA['traffic_status'] = status; g.ANNUAL_SUMMARY_DATA['avg_wait_time'] = total_wait_time / 3 if len(ROAD_NETWORK_CAPACITY) > 0 else 0
            accident_prob = 0.005
            if status.get('interstate') == 'Gridlock' or status.get('highway') == 'Gridlock': accident_prob = 0.015
            num_accidents = 0
            for p in g.POPULATION:
                if p.cars and random.random() < accident_prob: p.accident_involvement = True; num_accidents += 1
                else: p.accident_involvement = False
            g.ANNUAL_SUMMARY_DATA['num_accidents'] = num_accidents

class ImmigrationManager(sim.Component):
    def process(self):
        while True:
            yield self.hold(1)
            base_immigrants = int(len(g.POPULATION) * IMMIGRATION_CONFIG['base_annual_rate'])
            economic_multiplier = max(0, g.latest_economic_index / 50.0)
            vacancy_pressure = g.current_rental_vacancy_rate / HOUSING_MARKET_TARGETS['target_rental_vacancy_rate']
            housing_availability_multiplier = min(1.5, vacancy_pressure)
            num_to_add = int(base_immigrants * economic_multiplier * housing_availability_multiplier)

            if num_to_add > 0: print(f"ImmigrationManager: Adding {num_to_add} new agents this year.")
            try:
                from mastercode02_phase3c_diagnostics import record_immigration
                record_immigration(int(self.env.now()), num_to_add)
            except ImportError:
                pass
            for _ in range(num_to_add):
                age = random.randint(*IMMIGRATION_CONFIG['age_range'])
                education_levels = list(IMMIGRATION_CONFIG['education_distribution'].keys()); weights = list(IMMIGRATION_CONFIG['education_distribution'].values())
                education = random.choices(education_levels, weights=weights, k=1)[0]
                initial_data = {'id': g.next_person_id(),'age': age,'sex': random.choice(['Male', 'Female']),'education': education,'employment': 'Unemployed','household_id': None,'marital_status': 'Never married'}
                new_person = Person(self.env, initial_data, g.POPULATION)
                new_hh_id = g.next_household_id()
                new_hh_data = {'id': new_hh_id, 'type': 'Nonfamily household', 'members': [new_person], 'total_income': 0, 'savings_balance': random.uniform(5000, 20000)}
                g.HOUSEHOLDS[new_hh_id] = new_hh_data
                new_person.household_id = new_hh_id; new_person.activate()

# --- R12.4 ISOLATED EXPERIMENT: PEP-based Johnson City net-migration
# structural sensitivity. Exists only in this run's own runtime_snapshot/src
# copy; the canonical corrected snapshot is untouched. See
# reports/r12_4_m1_event_order.md and reports/r12_4_m1_pep_implementation.md
# for the full documented contract. Reproduced unmodified from the original
# R12.4 implementation, layered on top of the Gate 2 vital-rate correction.
PEP_MIGRATION_LOG: list = []


def _sample_migration_age() -> int:
    """Draw an age from the ACS B07001-derived Johnson City migrant age
    distribution (JC_MIGRATION_AGE_ALLOCATION). Bucket chosen by its observed
    share; age uniform within the chosen bucket, matching the existing
    ImmigrationManager's use of random.randint for within-range sampling."""
    buckets = list(JC_MIGRATION_AGE_ALLOCATION.keys())
    shares = list(JC_MIGRATION_AGE_ALLOCATION.values())
    lo, hi = random.choices(buckets, weights=shares, k=1)[0]
    return random.randint(lo, hi)


class PEPNetMigrationExtension(sim.Component):
    """Independently-sourced Johnson City net-migration structural
    sensitivity, calendar years 2010-2023 only (simulation_index 10-23).
    Scientific classification: INDEPENDENT_STRUCTURAL_MIGRATION_SENSITIVITY.

    Every count is read directly from JC_PEP_NET_MIGRATION_BY_YEAR
    (mastercode02_config_and_rates.py), itself built from Census PEP
    components of population change, fragment-weighted to Johnson City --
    never from the 2023 population endpoint, never tuned. Age is drawn from
    JC_MIGRATION_AGE_ALLOCATION (ACS B07001). All other entrant-construction
    fields (sex 50/50, education distribution, employment='Unemployed',
    marital_status='Never married', new one-person Nonfamily household) reuse
    the existing ImmigrationManager convention unchanged, per instruction to
    use the accepted entrant-construction behavior where compatible -- this
    experiment does not introduce a second, incompatible migrant generator.

    All PEP annual values for 2010-2023 are non-negative (verified,
    outputs/r12_4_pep_irs_jc_weighted_comparison_2010_2023.csv) -- this class
    therefore implements ONLY the positive-migration path. No
    Person.die()-adjacent or out-migration removal logic exists here; that is
    explicitly deferred to the separate IRS sensitivity scenario, which is the
    only one of the two approved scenarios with a negative year."""

    def process(self):
        while True:
            yield self.hold(1)
            # calendar_year = 2000 + simulation_index, per the code-verified
            # T0=2000 anchor (outputs/r12_1_simulation_calendar_crosswalk.csv).
            # self.env.now() returns the simulation_index (0-24), NOT the
            # calendar year directly -- must offset before dict lookup.
            simulation_index = int(self.env.now())
            year = 2000 + simulation_index
            entry = JC_PEP_NET_MIGRATION_BY_YEAR.get(year)
            if not entry:
                # Years 2000-2009 and any year outside the evidenced 2010-2023
                # window: net_migration_extension = 0, no adjustment applied.
                continue

            domestic_n = int(entry['domestic'])
            international_n = int(entry['international'])
            total_n = domestic_n + international_n

            if total_n > 0:
                print(f"PEPNetMigrationExtension: Adding {domestic_n} domestic + {international_n} international "
                      f"= {total_n} net migrants for year {year} (INDEPENDENT_STRUCTURAL_MIGRATION_SENSITIVITY).")

            year_log = {
                "year": year, "simulation_index": simulation_index,
                "domestic_target": domestic_n, "international_target": international_n,
                "total_target": total_n, "domestic_created": 0, "international_created": 0,
                "person_ids": [],
            }

            for origin_label, n in (("DOMESTIC", domestic_n), ("INTERNATIONAL", international_n)):
                for _ in range(n):
                    age = _sample_migration_age()
                    education_levels = list(IMMIGRATION_CONFIG['education_distribution'].keys())
                    weights = list(IMMIGRATION_CONFIG['education_distribution'].values())
                    education = random.choices(education_levels, weights=weights, k=1)[0]
                    initial_data = {
                        'id': g.next_person_id(), 'age': age, 'sex': random.choice(['Male', 'Female']),
                        'education': education, 'employment': 'Unemployed', 'household_id': None,
                        'marital_status': 'Never married',
                    }
                    new_person = Person(self.env, initial_data, g.POPULATION)
                    # Additive-only tags on the new person instance -- does not alter
                    # the Person class definition or any other person's attributes.
                    new_person.migration_event_type = "PEP_NET_MIGRATION_EXTENSION"
                    new_person.migration_origin = origin_label
                    new_person.migration_year = year
                    new_hh_id = g.next_household_id()
                    new_hh_data = {
                        'id': new_hh_id, 'type': 'Nonfamily household', 'members': [new_person],
                        'total_income': 0, 'savings_balance': random.uniform(5000, 20000),
                    }
                    g.HOUSEHOLDS[new_hh_id] = new_hh_data
                    new_person.household_id = new_hh_id
                    new_person.activate()

                    year_log["person_ids"].append(new_person.id)
                    if origin_label == "DOMESTIC":
                        year_log["domestic_created"] += 1
                    else:
                        year_log["international_created"] += 1

            PEP_MIGRATION_LOG.append(year_log)

class HousingManager(sim.Component):
    def process(self):
        from mastercode02_housing_ledger import (
            assign_housing_to_household,
            mark_household_insecure,
            release_empty_households,
            household_has_active_housing_claim,
        )
        from mastercode02_renter_to_owner import process_renter_to_owner
        from mastercode02_config_and_rates import RENTER_TO_OWNER_ENABLED
        while True:
            yield self.hold(1)
            year = int(self.env.now())
            release_empty_households(year)

            # Phase 6E: controlled renter-to-owner (stock/affordability/probability capped)
            # Runs after finance managers typically update income/savings (creation order).
            if RENTER_TO_OWNER_ENABLED:
                process_renter_to_owner(year)

            unplaced_households = [
                hh for hh in g.HOUSEHOLDS.values()
                if (not hh.get('housing_unit_name')) and (not household_has_active_housing_claim(hh.get('id')))
            ]
            for hh_data in unplaced_households:
                if not hh_data.get('members'):
                    continue

                tenure = self._determine_tenure(hh_data)
                hh_id = hh_data.get('id')

                placed, chosen_unit = self._select_unit(hh_data, tenure)
                if placed:
                    ok = assign_housing_to_household(hh_id, chosen_unit, tenure, year, reason='housing_manager_primary')
                    if ok:
                        self._apply_owner_finance(hh_data, tenure, chosen_unit)
                    else:
                        mark_household_insecure(hh_id, year, reason='assign_failed_primary')
                    continue

                alt_tenure = 'Renter' if tenure == 'Owner' else 'Owner'
                placed, chosen_unit = self._select_unit(hh_data, alt_tenure)
                if placed:
                    ok = assign_housing_to_household(hh_id, chosen_unit, alt_tenure, year, reason='housing_manager_fallback')
                    if ok:
                        self._apply_owner_finance(hh_data, alt_tenure, chosen_unit)
                    else:
                        mark_household_insecure(hh_id, year, reason='assign_failed_fallback')
                else:
                    mark_household_insecure(hh_id, year, reason='no_unit_available')

    def _determine_tenure(self, household_data):
        head_of_household_age = max(p.age for p in household_data['members'])
        household_income = household_data.get('total_income', 0)
        prob_from_age = 0.5
        for age_range, prob in TENURE_PROBABILITY_MATRIX['by_age'].items():
            if age_range[0] <= head_of_household_age <= age_range[1]:
                prob_from_age = prob; break
        prob_from_income = 0.5
        for income_range, prob in TENURE_PROBABILITY_MATRIX['by_income'].items():
            if income_range[0] <= household_income <= income_range[1]:
                prob_from_income = prob; break
        base_renter_probability = (prob_from_age * 0.6) + (prob_from_income * 0.4)
        adjusted_renter_probability = base_renter_probability / g.arima_owner_preference_modifier
        final_renter_probability = max(0, min(1, adjusted_renter_probability))
        if random.random() < final_renter_probability:
            return 'Renter'
        else:
            if household_data.get('savings_balance', 0) < HOUSING_MARKET_TARGETS['min_down_payment']:
                return 'Renter'
            return 'Owner'

    def _select_unit(self, hh_data, tenure):
        from mastercode02_housing_ledger import get_housing_available_count
        target_type = 'Rental' if tenure == 'Renter' else 'For-Sale'
        available_units = [
            name for name, stock in HOUSING_STOCK.items()
            if stock['type'] == target_type and get_housing_available_count(name) > 0
        ]
        if available_units:
            return True, random.choice(available_units)
        return False, None

    def _apply_owner_finance(self, hh_data, tenure, chosen_unit):
        if tenure != 'Owner':
            return
        home_value = HOUSING_STOCK[chosen_unit]['base_value']
        down_payment = min(hh_data.get('savings_balance', 0), home_value * 0.2)
        hh_data['savings_balance'] = hh_data.get('savings_balance', 0) - down_payment
        hh_data['loan_balance'] = hh_data.get('loan_balance', 0) + (home_value - down_payment)
