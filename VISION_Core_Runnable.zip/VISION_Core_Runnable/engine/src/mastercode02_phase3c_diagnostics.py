"""Phase 3C marital classification diagnostics."""
from __future__ import annotations

from collections import Counter

import mastercode02_globals as g
from mastercode02_config_and_rates import RATES, FERTILITY_PROBABILITY_SCALE, TARGET_CRUDE_BIRTH_RATE_PER_1000
from mastercode02_utils import is_married_status

PHASE3C_LOG: dict[str, list] = {
    "birth_trace": [],
    "immigration_by_year": [],
    "fertility_metrics": [],
    "status_counts_by_year": [],
}


def fertility_marital_key(status) -> str:
    return "Married" if is_married_status(status) else "Unmarried"


def _expected_probs(woman) -> tuple[float, float, bool, str]:
    """Return (expected_scaled_married_table, expected_scaled_unmarried_table contribution based on key, marriage_applied, key)."""
    ag = woman.get_age_group()
    key = fertility_marital_key(woman.marital_status)
    base = RATES["Fertility Rate"][key].get(ag, 0.0)
    raw = base * g.city_birth_rate_modifier * g.annual_birth_rate_modifier * g.event_birth_rate_modifier  # Gate 2
    marriage_applied = False
    if woman.years_married is not None and woman.years_married <= 10:
        raw *= 1.5
        marriage_applied = True
    scaled = max(0.0, min(raw * FERTILITY_PROBABILITY_SCALE, 1.0))
    return scaled, marriage_applied, key


def record_birth_trace(mother, info: dict, newborn_id: int, year: int) -> None:
    PHASE3C_LOG["birth_trace"].append({
        "year": year,
        "mother_id": mother.id,
        "mother_age": mother.age,
        "mother_age_group": info.get("age_group"),
        "raw_marital_status": info.get("raw_marital_status", mother.marital_status),
        "classified_as_married": info.get("classified_as_married", is_married_status(mother.marital_status)),
        "fertility_table_used": info.get("fertility_table_used"),
        "years_married": mother.years_married,
        "base_birth_probability": info.get("base_birth_prob"),
        "arima_modifier": info.get("arima_modifier"),
        "event_modifier": info.get("event_modifier"),
        "marriage_multiplier_applied": info.get("marriage_multiplier_applied"),
        "fertility_scale": info.get("fertility_scale"),
        "final_scaled_birth_probability": info.get("final_scaled_birth_prob"),
        "household_id": mother.household_id,
        "newborn_id": newborn_id,
    })


def record_immigration(year: int, count: int) -> None:
    PHASE3C_LOG["immigration_by_year"].append({"year": year, "immigration_count": count})


def snapshot_yearly_fertility_metrics(year: int) -> None:
    pop_n = len(g.POPULATION)
    fertile = [p for p in g.POPULATION if p.sex == "Female" and 15 <= p.age < 50]
    married_fertile = [p for p in fertile if is_married_status(p.marital_status)]
    unmarried_fertile = [p for p in fertile if not is_married_status(p.marital_status)]

    expected_married = 0.0
    expected_unmarried = 0.0
    marriage_mult_women = 0
    for p in fertile:
        scaled, applied, key = _expected_probs(p)
        if key == "Married":
            expected_married += scaled
        else:
            expected_unmarried += scaled
        if applied:
            marriage_mult_women += 1

    actual_births = sum(h.get("births", 0) for h in g.HOUSEHOLDS.values())
    deaths = sum(h.get("deaths", 0) for h in g.HOUSEHOLDS.values())
    PHASE3C_LOG["fertility_metrics"].append({
        "year": year,
        "population": pop_n,
        "births": actual_births,
        "deaths": deaths,
        "cbr_per_1000": round(actual_births / pop_n * 1000, 4) if pop_n else 0.0,
        "cdr_per_1000": round(deaths / pop_n * 1000, 4) if pop_n else 0.0,
        "fertile_female_count": len(fertile),
        "married_fertile_female_count": len(married_fertile),
        "unmarried_fertile_female_count": len(unmarried_fertile),
        "expected_births_married_table": round(expected_married, 4),
        "expected_births_unmarried_table": round(expected_unmarried, 4),
        "expected_births_total": round(expected_married + expected_unmarried, 4),
        "actual_births": actual_births,
        "fertility_scale": FERTILITY_PROBABILITY_SCALE,
        "target_cbr_per_1000": TARGET_CRUDE_BIRTH_RATE_PER_1000,
        "women_with_marriage_multiplier": marriage_mult_women,
    })

    # Status census for audit (all persons)
    counts = Counter()
    for p in g.POPULATION:
        counts[str(p.marital_status) if p.marital_status is not None else "<None>"] += 1
    for status, cnt in counts.items():
        PHASE3C_LOG["status_counts_by_year"].append({
            "year": year,
            "raw_status": status,
            "count": cnt,
        })
