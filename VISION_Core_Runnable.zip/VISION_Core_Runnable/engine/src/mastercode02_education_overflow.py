"""Phase 8A-FU2 education overflow / local-seat refusal accounting (observational only).

Pure observer: no RNG draws, no progression control, no capacity change. Captured once per year
AFTER annual logging. Determines local vs external via ground-truth `claimed_resources()` and
computes per-level demand/claims/refused/external + per-person events + annual reconsideration.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

import mastercode02_globals as g
from mastercode02_config_and_rates import EDUCATION_CAPACITIES

LEVELS = list(EDUCATION_CAPACITIES.keys())
DROPOUT_STATES = {"high_school_dropout", "college_dropout", "masters_dropout"}

EDU_OVERFLOW_LOG: dict = {
    "summary": [],     # per year per level aggregate
    "events": [],      # per-person overflow / status-change events
    "invariants": [],  # per year invariant checks
}

_prev_status: dict = {}      # person_id -> previous-year local seat status
_prev_education: dict = {}    # person_id -> previous-year education

# R11.1 Phase 4: the "events" list is the only unbounded-growth container here
# (one entry per external-overflow/status-change person per year; over a 24-year
# run this reached 120-400MB in memory for Johnson City/Knoxville). When a
# spill_dir is configured, events are periodically flushed to disk in chunks
# instead of retained in memory for the full run, and dump_overflow_log()
# stream-merges them back at the end. Byte-for-byte identical final JSON to the
# pure in-memory path (see tests/test_r11_1_education_overflow_streaming.py).
# When spill_dir is None (default), behavior is unchanged from before R11.1.
_SPILL_DIR: Path | None = None
_SPILL_CHUNK_SIZE = 50_000
_spill_chunk_paths: list = []


def reset_education_overflow(spill_dir=None) -> None:
    global _SPILL_DIR, _spill_chunk_paths
    EDU_OVERFLOW_LOG["summary"].clear()
    EDU_OVERFLOW_LOG["events"].clear()
    EDU_OVERFLOW_LOG["invariants"].clear()
    _prev_status.clear()
    _prev_education.clear()
    _SPILL_DIR = None
    _spill_chunk_paths = []
    if spill_dir is not None:
        spill_path = Path(spill_dir)
        spill_path.mkdir(parents=True, exist_ok=True)
        for stale in spill_path.glob("events_chunk_*.jsonl"):
            stale.unlink()
        _SPILL_DIR = spill_path


def _maybe_spill_events() -> None:
    """Flush EDU_OVERFLOW_LOG['events'] to a spill chunk once it crosses the
    chunk-size threshold, if streaming is configured. No-op otherwise (default,
    pre-R11.1 behavior: events accumulate purely in memory)."""
    if _SPILL_DIR is None:
        return
    if len(EDU_OVERFLOW_LOG["events"]) < _SPILL_CHUNK_SIZE:
        return
    chunk_path = _SPILL_DIR / f"events_chunk_{len(_spill_chunk_paths):06d}.jsonl"
    with open(chunk_path, "w", encoding="utf-8") as f:
        for ev in EDU_OVERFLOW_LOG["events"]:
            f.write(json.dumps(ev))
            f.write("\n")
    _spill_chunk_paths.append(chunk_path)
    EDU_OVERFLOW_LOG["events"].clear()


def dump_overflow_log(path) -> None:
    """Write EDU_OVERFLOW_LOG to `path`. When events were spilled to disk during
    the run (streaming mode), stream-merges spill chunks + any remaining
    in-memory events back into the same {"summary": [...], "events": [...],
    "invariants": [...]} shape `json.dump(EDU_OVERFLOW_LOG, f)` always produced
    -- byte-identical key order and default (no-indent) separators -- without
    ever holding the full events list in memory at once."""
    with open(path, "w", encoding="utf-8") as f:
        if not _spill_chunk_paths:
            json.dump(EDU_OVERFLOW_LOG, f)
            return
        f.write('{"summary": ')
        json.dump(EDU_OVERFLOW_LOG["summary"], f)
        f.write(', "events": [')
        first = True
        for chunk_path in _spill_chunk_paths:
            with open(chunk_path, "r", encoding="utf-8") as cf:
                for line in cf:
                    line = line.rstrip("\n")
                    if not line:
                        continue
                    if not first:
                        f.write(", ")
                    f.write(line)
                    first = False
        for ev in EDU_OVERFLOW_LOG["events"]:
            if not first:
                f.write(", ")
            f.write(json.dumps(ev))
            first = False
        f.write('], "invariants": ')
        json.dump(EDU_OVERFLOW_LOG["invariants"], f)
        f.write('}')
    for chunk_path in _spill_chunk_paths:
        try:
            os.remove(chunk_path)
        except OSError:
            pass


def load_overflow_log(path) -> None:
    import json
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    for k in ("summary", "events", "invariants"):
        EDU_OVERFLOW_LOG[k].clear()
        EDU_OVERFLOW_LOG[k].extend(data.get(k, []))


def _has_seat(person, res) -> bool:
    try:
        return res in person.claimed_resources()
    except Exception:
        return False


def snapshot_year(year: int, env=None) -> None:
    # ground-truth current status per person (local_claimed / external_overflow / not_applicable)
    cur_status: dict = {}
    cur_education: dict = {}
    level_members: dict = {lvl: [] for lvl in LEVELS}
    for p in g.POPULATION:
        pid = getattr(p, "id", None)
        if pid is None:
            continue
        edu = p.education
        cur_education[pid] = edu
        if edu in EDUCATION_CAPACITIES:
            res = g.EDUCATION_RESOURCE.get(edu)
            if int(year) == 0:
                # Phase 8A-FU3: Year 0 is pre-enrollment; do not label as external_overflow
                status = "pre_enrollment_not_evaluated"
            else:
                status = ("local_claimed" if (res is not None and _has_seat(p, res))
                          else "external_overflow")
            cur_status[pid] = status
            level_members[edu].append((pid, p, status))
        else:
            cur_status[pid] = "not_applicable"

    inv_claims_le_cap = True
    inv_refused_formula = True
    inv_demand_split = True
    inv_external_eq_refused = True

    for lvl in LEVELS:
        res = g.EDUCATION_RESOURCE.get(lvl)
        capacity = int(res.capacity()) if res is not None else int(EDUCATION_CAPACITIES.get(lvl, 0))
        try:
            claims = int(res.claimed_quantity()) if res is not None else 0
        except Exception:
            claims = 0
        members = level_members[lvl]
        demand = len(members)
        # Phase 8A-FU3: Year 0 is pre-enrollment; do not treat demand-claims as refusal.
        pre_enrollment = (int(year) == 0)
        if pre_enrollment:
            refused = None
            external = None
            theoretical_gap = max(0, demand - capacity)
        else:
            refused = max(0, demand - claims)
            external = sum(1 for _, _, s in members if s == "external_overflow")
            theoretical_gap = None

        # reconsideration: everyone in the level is re-evaluated annually
        reconsidered = 0 if pre_enrollment else demand
        received_local_after_external = 0
        lost_local_seat = 0
        progression_continued_count = 0
        progressed_out = 0
        dropped_out = 0
        remained = 0

        if not pre_enrollment:
            for pid, person, status in members:
                prev_s = _prev_status.get(pid, "not_applicable")
                if prev_s == "external_overflow" and status == "local_claimed":
                    received_local_after_external += 1
                if prev_s == "local_claimed" and status == "external_overflow":
                    lost_local_seat += 1

        # progression flows for persons who were in this level last year
        for pid, prev_edu in _prev_education.items():
            if prev_edu != lvl:
                continue
            now = cur_education.get(pid)
            if now is None:
                continue
            if now == lvl:
                remained += 1
            elif now in DROPOUT_STATES:
                dropped_out += 1
            else:
                progressed_out += 1

        # progression_continued: external students this year (seat-independent; FU1)
        if not pre_enrollment:
            for pid, person, status in members:
                if status == "external_overflow":
                    progression_continued_count += 1

        local_share = (claims / demand) if demand else 0.0
        overflow_share = (refused / demand) if (demand and refused is not None) else None

        EDU_OVERFLOW_LOG["summary"].append({
            "year": year, "education_level": lvl, "local_seat_capacity": capacity,
            "local_seat_demand": demand, "local_seat_claims": claims,
            "local_seat_refused": refused, "external_school_count": external,
            "theoretical_pre_enrollment_demand_minus_capacity": theoretical_gap,
            "snapshot_stage": ("pre_enrollment_baseline" if pre_enrollment
                               else "post_annual_enrollment"),
            "education_enrollment_evaluated": (False if pre_enrollment else True),
            "local_claim_share": round(local_share, 6),
            "overflow_share": (round(overflow_share, 6) if overflow_share is not None else None),
            "reconsidered_count": reconsidered,
            "received_local_after_external": received_local_after_external,
            "lost_local_seat_this_year": lost_local_seat,
            "progression_continued_count": progression_continued_count,
            "progressed_out_of_level": progressed_out,
            "dropped_out_of_level": dropped_out,
            "remained_in_level": remained,
            "notes": ("Year 0 pre-enrollment: refused/external NA; theoretical gap only"
                      if pre_enrollment else
                      "external_school_count = refused local seats (out-of-town, observational)"),
        })

        # invariants (Year 0: only claims<=cap; skip refused formulas)
        if claims > capacity:
            inv_claims_le_cap = False
        if not pre_enrollment:
            if refused != max(0, demand - claims):
                inv_refused_formula = False
            if demand != claims + refused:
                inv_demand_split = False
            if external != refused:
                inv_external_eq_refused = False

        # per-person events: overflow students + status-change (Year 1+ only)
        if not pre_enrollment:
            for pid, person, status in members:
                prev_s = _prev_status.get(pid, "not_applicable")
                changed = (prev_s != status)
                if status != "external_overflow" and not changed:
                    continue
                prev_edu = _prev_education.get(pid)
                cur_edu = cur_education.get(pid)
                EDU_OVERFLOW_LOG["events"].append({
                    "year": year, "person_id": pid, "education_level": lvl,
                    "previous_local_seat_status": prev_s, "current_local_seat_status": status,
                    "local_seat_claimed": 1 if status == "local_claimed" else 0,
                    "local_seat_refused": 1 if status == "external_overflow" else 0,
                    "external_school": status == "external_overflow",
                    "reconsidered_this_year": True,
                    "received_local_after_external": bool(
                        prev_s == "external_overflow" and status == "local_claimed"),
                    "lost_local_seat_this_year": bool(
                        prev_s == "local_claimed" and status == "external_overflow"),
                    "progression_continued": bool(
                        prev_edu is None or prev_edu != cur_edu
                        or status in ("local_claimed", "external_overflow")),
                    "education_state_after_progression": cur_edu,
                    "notes": "seat-independent progression; external=refused local seat",
                })

    EDU_OVERFLOW_LOG["invariants"].append({
        "year": year, "inv_claims_le_capacity": inv_claims_le_cap,
        "inv_refused_formula": inv_refused_formula, "inv_demand_split": inv_demand_split,
        "inv_external_eq_refused": inv_external_eq_refused,
    })

    _prev_status.clear(); _prev_status.update(cur_status)
    _prev_education.clear(); _prev_education.update(cur_education)

    _maybe_spill_events()
