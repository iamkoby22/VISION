"""Phase 4B education diagnostics — wrap hooks + yearly snapshots (observation only around model changes)."""
from __future__ import annotations

from collections import defaultdict

import mastercode02_globals as g

PHASE4B_LOG: dict = {
    "transition_events": [],
    "education_counts_by_year": [],
    "resource_snapshots": [],
    "reentry_events": [],
    "post_hs_routes": [],
    "unsupported_dropouts": [],
    "_hs_exit_raw": [],
}


def wrap_update_education_cyclical(PersonClass) -> None:
    """Wrap to log transitions without changing outcomes of the (already extended) function."""
    original = PersonClass.update_education_cyclical

    def wrapped(self):
        before = self.education
        age_before = self.age
        year = int(self.env.now()) if hasattr(self, "env") and self.env is not None else -1
        original(self)
        after = self.education
        if before != after:
            ttype = _classify_transition(before, after)
            PHASE4B_LOG["transition_events"].append({
                "year": year,
                "person_id": self.id,
                "age": age_before,
                "sex": self.sex,
                "before_education": before,
                "after_education": after,
                "transition_type": ttype,
                "route_draw_if_available": "",
                "route_probability_used": "",
                "age_multiplier_used": "",
                "final_probability_used": "",
                "resource_requested": after if after in g.EDUCATION_RESOURCE else "",
                "resource_granted": "",
                "blocked_reason": "",
                "notes": "hook around update_education_cyclical (Phase 4B model changes are inside original)",
            })
            if before == "High School (9-12)" and after in ("high_school_completed", "high_school_dropout"):
                PHASE4B_LOG["_hs_exit_raw"].append({"year": year, "outcome": after, "person_id": self.id})
            if before == "high_school_completed" and after == "University":
                PHASE4B_LOG["_hs_exit_raw"].append({"year": year, "outcome": "went_to_university", "person_id": self.id})
            if before == "high_school_completed" and after == "Community College":
                PHASE4B_LOG["_hs_exit_raw"].append({"year": year, "outcome": "went_to_community_college", "person_id": self.id})
            if "dropout" in str(before) and after in g.EDUCATION_RESOURCE:
                PHASE4B_LOG["_hs_exit_raw"]  # no-op; reentry logged separately

    PersonClass.update_education_cyclical = wrapped


def _classify_transition(before: str, after: str) -> str:
    if "dropout" in str(before) and after not in str(before):
        return "dropout_reentry"
    if "dropout" in str(after):
        return "dropout"
    if "completed" in str(after):
        return "completion"
    if after in g.EDUCATION_RESOURCE:
        return "enrollment_level_change"
    return "state_change"


def record_reentry_event(*, year, person, dropout_state, target_state, base_probability,
                         age_multiplier, final_probability, random_draw, successful):
    PHASE4B_LOG["reentry_events"].append({
        "year": year,
        "person_id": person.id,
        "age": person.age,
        "sex": person.sex,
        "dropout_state": dropout_state,
        "target_state": target_state,
        "last_tertiary_program": getattr(person, "last_tertiary_program", None) or "",
        "base_probability": base_probability,
        "age_multiplier": age_multiplier,
        "final_probability": final_probability,
        "random_draw": random_draw,
        "successful_reentry": bool(successful),
        "notes": "diagnostic record of model reentry draw",
    })


def record_post_hs_route(person, r, u_prob, cc_prob):
    year = int(person.env.now()) if person.env is not None else -1
    if r < u_prob:
        outcome = "University"
    elif r < u_prob + cc_prob:
        outcome = "Community College"
    else:
        outcome = "Remain high_school_completed"
    PHASE4B_LOG["post_hs_routes"].append({
        "year": year,
        "person_id": person.id,
        "age": person.age,
        "draw": r,
        "outcome": outcome,
        "u_prob": u_prob,
        "cc_prob": cc_prob,
    })
    if outcome == "Remain high_school_completed":
        PHASE4B_LOG["_hs_exit_raw"].append({
            "year": year, "outcome": "remained_high_school_completed", "person_id": person.id,
        })


def record_unsupported_dropout(person, dropout_state):
    PHASE4B_LOG["unsupported_dropouts"].append({
        "year": int(person.env.now()) if person.env is not None else -1,
        "person_id": person.id,
        "dropout_state": dropout_state,
        "notes": "unsupported dropout state; logged not forced",
    })


def snapshot_yearly_education(year: int) -> None:
    pop = list(g.POPULATION)
    pop_n = len(pop) or 1
    by_edu = defaultdict(list)
    for p in pop:
        by_edu[str(p.education)].append(p)

    for edu, agents in by_edu.items():
        ages = [a.age for a in agents]
        emp = sum(1 for a in agents if a.employment_status == "Employed")
        unemp = sum(1 for a in agents if a.employment_status == "Unemployed")
        PHASE4B_LOG["education_counts_by_year"].append({
            "year": year,
            "education_state": edu,
            "agent_count": len(agents),
            "share_of_population": len(agents) / pop_n,
            "age_min": min(ages) if ages else "",
            "age_max": max(ages) if ages else "",
            "mean_age": float(sum(ages) / len(ages)) if ages else "",
            "employed_count": emp,
            "unemployed_count": unemp,
        })

    snap = {"year": year}
    for name, res in g.EDUCATION_RESOURCE.items():
        try:
            claimed = int(res.claimed_quantity())
        except Exception:
            claimed = 0
        try:
            cap = int(res.capacity())
        except Exception:
            cap = 0
        snap[name] = {"capacity": cap, "claimed": claimed, "available": max(0, cap - claimed)}
    PHASE4B_LOG["resource_snapshots"].append(snap)
