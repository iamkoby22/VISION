#!/usr/bin/env python
"""Phase 9E-T0: canonical snapshot + hash of t=0 generator data blocks."""
from __future__ import annotations

import hashlib
import json

T0_BLOCKS = ("demographics", "households", "employment", "marital_status")


def snapshot_t0(data):
    """Return an ordered dict of the four canonical t=0 blocks present in DATA."""
    return {block: data[block] for block in T0_BLOCKS if block in data}


def canonical_json(blocks):
    """Deterministic canonical JSON string (sorted keys, no whitespace)."""
    return json.dumps(blocks, sort_keys=True, separators=(",", ":"))


def t0_hash(blocks):
    """SHA-256 over the canonical JSON of the t=0 blocks."""
    return hashlib.sha256(canonical_json(blocks).encode("utf-8")).hexdigest()
