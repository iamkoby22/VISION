#!/usr/bin/env python
"""Serialize a JSON-safe snapshot of overridable config groups from the config module."""
from __future__ import annotations

import hashlib
import json
from typing import Any

from validate_config_overrides import ALLOWED_TOP_LEVEL


def _jsonable(obj: Any) -> Any:
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if isinstance(k, tuple):
                # Should never appear for allowed groups; skip with string key if it does
                key = json.dumps(list(k))
            else:
                key = str(k)
            out[key] = _jsonable(v)
        return out
    if isinstance(obj, (list, tuple)):
        return [_jsonable(x) for x in obj]
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    return str(obj)


def snapshot_config(config_module: Any, keys=None) -> dict:
    keys = list(keys) if keys is not None else sorted(ALLOWED_TOP_LEVEL)
    snap = {}
    for key in keys:
        if hasattr(config_module, key):
            snap[key] = _jsonable(getattr(config_module, key))
    return snap


def snapshot_hash(snap: dict) -> str:
    blob = json.dumps(snap, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()
