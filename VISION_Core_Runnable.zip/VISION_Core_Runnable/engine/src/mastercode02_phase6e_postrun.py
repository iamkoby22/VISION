"""Phase 6E post-run analysis."""
from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from mastercode02_phase6e_diagnostics import PHASE6E_LOG
from mastercode02_renter_to_owner import PHASE6E_R2O_EVENTS, PHASE6E_R2O_SUMMARY
from mastercode02_housing_ledger import LEDGER_TRANSFER_AUDIT


def _write_df(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def _safe_read(path: Path) -> pd.DataFrame:
    return pd.read_csv(path) if path.exists() else pd.DataFrame()


def _compare_phase6d(run_dir: Path, phase6d_dir: Path, diag: Path) -> pd.DataFrame:
    a6e = _safe_read(run_dir / "outputs" / "mastercode02_output_phase6e_seed123_annual_summary.csv")
    a6d = _safe_read(phase6d_dir / "outputs" / "mastercode02_output_phase6d_seed123_annual_summary.csv")
    res6e = _safe_read(run_dir / "outputs" / "mastercode02_output_phase6e_seed123_summary_resources.csv")
    res6d = _safe_read(phase6d_dir / "outputs" / "mastercode02_output_phase6d_seed123_summary_resources.csv")
    sc6e = _safe_read(run_dir / "outputs" / "mastercode02_output_phase6e_seed123_scores_summary.csv")
    sc6d = _safe_read(phase6d_dir / "outputs" / "mastercode02_output_phase6d_seed123_scores_summary.csv")
    stock6e = pd.DataFrame(PHASE6E_LOG["stock_vacancy"])
    stock6d = _safe_read(phase6d_dir / "diagnostics" / "phase6d_housing_stock_vacancy_audit.csv")
    r2o = pd.DataFrame(PHASE6E_R2O_SUMMARY)
    rows = []
    if a6e.empty or a6d.empty:
        return pd.DataFrame(rows)

    def bus_refused(res_df, year):
        if res_df.empty:
            return np.nan
        sub = res_df[(res_df["year"] == year) & (res_df["name"] == "Bus Service")]
        return float(sub.iloc[0]["waiting_or_refused"]) if not sub.empty else np.nan

    for year in sorted(a6e["Year"].unique()):
        r6 = a6e[a6e["Year"] == year].iloc[0]
        r5 = a6d[a6d["Year"] == year].iloc[0]
        ycol = "year" if (not sc6e.empty and "year" in sc6e.columns) else "Year"
        e6 = sc6e[sc6e[ycol] == year].iloc[0] if (not sc6e.empty and year in set(sc6e[ycol])) else None
        e5 = sc6d[sc6d[ycol] == year].iloc[0] if (not sc6d.empty and year in set(sc6d[ycol])) else None
        pop5, pop6 = float(r5["Population"]), float(r6["Population"])
        fs6d = fs6e = np.nan
        if not stock6d.empty and year in set(stock6d["year"]):
            fs6d = float(stock6d[stock6d["year"] == year].iloc[0]["for_sale_vacancy_rate"])
        if not stock6e.empty and year in set(stock6e["year"]):
            fs6e = float(stock6e[stock6e["year"] == year].iloc[0]["for_sale_vacancy_rate"])
        r2o_succ = 0
        rental_freed = 0
        if not r2o.empty and year in set(r2o["year"]):
            row = r2o[r2o["year"] == year].iloc[0]
            r2o_succ = float(row["successful_transitions"])
            rental_freed = float(row["rental_units_freed"])

        pairs = [
            ("population", float(r5["Population"]), float(r6["Population"])),
            ("births", float(r5["No of births"]), float(r6["No of births"])),
            ("deaths", float(r5["No. of Deaths"]), float(r6["No. of Deaths"])),
            ("cbr_per_1000", 1000 * float(r5["No of births"]) / pop5 if pop5 else 0,
             1000 * float(r6["No of births"]) / pop6 if pop6 else 0),
            ("cdr_per_1000", 1000 * float(r5["No. of Deaths"]) / pop5 if pop5 else 0,
             1000 * float(r6["No. of Deaths"]) / pop6 if pop6 else 0),
            ("employment_rate", float(r5["Employment Rate"]), float(r6["Employment Rate"])),
            ("rental_vacancy", float(r5["Rental_Vacancy_Rate"]), float(r6["Rental_Vacancy_Rate"])),
            ("for_sale_vacancy", fs6d, fs6e),
            ("overall_vacancy", float(r5["Overall_Vacancy_Rate"]), float(r6["Overall_Vacancy_Rate"])),
            ("renter_households", float(r5["Renter_Occupied_HH"]), float(r6["Renter_Occupied_HH"])),
            ("owner_households", float(r5["Owner_Occupied_HH"]), float(r6["Owner_Occupied_HH"])),
            ("housing_insecure", float(r5["Housing_Insecure_HH_Count"]), float(r6["Housing_Insecure_HH_Count"])),
            ("avg_income", float(r5["Avg Annual Income"]), float(r6["Avg Annual Income"])),
            ("total_cars", float(r5["Total Number of Cars"]), float(r6["Total Number of Cars"])),
            ("accidents", float(r5["Number of Accidents on road"]), float(r6["Number of Accidents on road"])),
            ("bus_refused_trips", bus_refused(res6d, year), bus_refused(res6e, year)),
            ("renter_to_owner_successes", 0.0, r2o_succ),
            ("rental_units_freed", 0.0, rental_freed),
        ]
        if e5 is not None and e6 is not None:
            if "economic_index" in e5.index:
                pairs.append(("economic_index", float(e5["economic_index"]), float(e6["economic_index"])))
            if "transport_index" in e5.index:
                pairs.append(("transport_index", float(e5["transport_index"]), float(e6["transport_index"])))
        for metric, v5, v6 in pairs:
            if v5 != v5 or v6 != v6:
                diff, match = np.nan, False
            else:
                diff = float(v6) - float(v5)
                match = abs(diff) < 1e-9
            rows.append({
                "year": year, "metric": metric, "phase6d_value": v5,
                "phase6e_value": v6, "absolute_diff": diff, "match": match,
            })
    df = pd.DataFrame(rows)
    _write_df(df, diag / "phase6e_phase6d_comparison.csv")
    return df


def run_post_analysis(run_dir: Path, phase6d_dir: Path) -> bool:
    diag = run_dir / "diagnostics"
    plots = diag / "phase6e_plots"
    diag.mkdir(parents=True, exist_ok=True)
    plots.mkdir(parents=True, exist_ok=True)

    events = pd.DataFrame(PHASE6E_R2O_EVENTS)
    summary = pd.DataFrame(PHASE6E_R2O_SUMMARY)
    transfer = pd.DataFrame(LEDGER_TRANSFER_AUDIT)
    stock = pd.DataFrame(PHASE6E_LOG["stock_vacancy"])
    consist = pd.DataFrame(PHASE6E_LOG["consistency"])
    inv = pd.DataFrame(PHASE6E_LOG["invariants"])

    _write_df(events, diag / "phase6e_renter_to_owner_events.csv")
    _write_df(summary, diag / "phase6e_renter_to_owner_summary_by_year.csv")
    _write_df(transfer, diag / "phase6e_housing_ledger_transfer_audit.csv")
    _write_df(stock, diag / "phase6e_housing_stock_vacancy_audit.csv")
    _write_df(consist, diag / "phase6e_household_ledger_consistency.csv")
    _write_df(inv, diag / "phase6e_housing_invariants.csv")

    cmp = _compare_phase6d(run_dir, phase6d_dir, diag)

    inv_pass = bool((inv["pass_fail"] == "PASS").all()) if not inv.empty else False
    claimless_fail = False
    multi_fail = False
    if not transfer.empty:
        claimless_fail = bool(
            ((transfer["transfer_success"] == False) & (transfer["had_no_claim_after"] == True)).any()
        )
        multi_fail = bool((transfer["had_multiple_claims_after"] == True).any())
    if not consist.empty:
        multi_fail = multi_fail or bool((consist["multiple_active_claims"] == True).any())

    total_succ = int(summary["successful_transitions"].sum()) if not summary.empty else 0
    total_att = int(summary["attempted_transitions"].sum()) if not summary.empty else 0
    eligible_any = int(summary["eligible_renter_count"].sum()) if not summary.empty else 0

    # Pass: path implemented + invariants + no unsafe transfers; zero successes OK if stock-limited
    passed = inv_pass and (not claimless_fail) and (not multi_fail)

    flags = []
    if not inv_pass:
        flags.append({"severity": "HIGH", "subsystem": "ledger", "finding": "Invariant failures",
                      "evidence": "phase6e_housing_invariants.csv", "consequence": "consistency risk",
                      "recommended_fix_phase": "6E", "should_fix_now_yes_no": "yes"})
    if claimless_fail:
        flags.append({"severity": "CRITICAL", "subsystem": "transfer", "finding": "Failed transfer left claimless HH",
                      "evidence": "phase6e_housing_ledger_transfer_audit.csv", "consequence": "unsafe",
                      "recommended_fix_phase": "6E", "should_fix_now_yes_no": "yes"})
    if total_succ == 0:
        flags.append({"severity": "INFO", "subsystem": "r2o", "finding": "Zero successful R2O (likely stock-limited after 6D init)",
                      "evidence": "phase6e_renter_to_owner_summary_by_year.csv",
                      "consequence": "Path exists; for-sale near-full at t0",
                      "recommended_fix_phase": "optional_later", "should_fix_now_yes_no": "no"})
    flags.extend([
        {"severity": "MEDIUM", "subsystem": "stock", "finding": "For-sale nearly full after Phase 6D init limits R2O",
         "evidence": "stock vacancy + R2O blocked_no_for_sale_stock",
         "consequence": "Few/no ownership mobility without stock churn/expansion",
         "recommended_fix_phase": "later", "should_fix_now_yes_no": "no"},
        {"severity": "MEDIUM", "subsystem": "insecure", "finding": "Insecure may still grow when total stock full",
         "evidence": "annual summary", "consequence": "Not solved by R2O alone",
         "recommended_fix_phase": "later", "should_fix_now_yes_no": "no"},
    ])
    flags_df = pd.DataFrame(flags)
    _write_df(flags_df, diag / "phase6e_red_flags.csv")

    recs = pd.DataFrame([
        {"priority": 1, "recommendation": "Stop after Phase 6E; next subsystem or housing stock/churn forensics later",
         "type": "stop", "expected_model_impact": "none", "risk_level": "low",
         "files_likely_to_change": "n/a", "should_be_next_phase_yes_no": "no",
         "notes": "Do not expand stock or tune R2O probs now"},
        {"priority": 2, "recommendation": "Optional later: rental churn / construction if insecure growth is priority",
         "type": "deferred", "expected_model_impact": "housing supply", "risk_level": "high",
         "files_likely_to_change": "HousingManager; stock config", "should_be_next_phase_yes_no": "no",
         "notes": "Out of Phase 6E scope"},
    ])
    _write_df(recs, diag / "phase6e_upgrade_recommendations.csv")

    # Plots
    ann6d = _safe_read(phase6d_dir / "outputs" / "mastercode02_output_phase6d_seed123_annual_summary.csv")
    ann6e = _safe_read(run_dir / "outputs" / "mastercode02_output_phase6e_seed123_annual_summary.csv")
    stock6d = _safe_read(phase6d_dir / "diagnostics" / "phase6d_housing_stock_vacancy_audit.csv")

    if not summary.empty:
        fig, ax = plt.subplots(figsize=(8, 4.5))
        ax.plot(summary["year"], summary["attempted_transitions"], "-o", label="Attempts")
        ax.plot(summary["year"], summary["successful_transitions"], "-s", label="Successes")
        ax.legend(); ax.set_title("Renter-to-owner attempts and successes")
        fig.tight_layout(); fig.savefig(plots / "01_r2o_attempts_successes.png"); plt.close(fig)

        fig, ax = plt.subplots(figsize=(9, 4.5))
        for col, lab in [
            ("blocked_no_for_sale_stock", "No for-sale"),
            ("blocked_affordability", "Affordability"),
            ("blocked_down_payment", "Down payment"),
            ("blocked_missing_finance_data", "Missing finance"),
            ("blocked_probability", "Probability"),
        ]:
            if col in summary.columns:
                ax.plot(summary["year"], summary[col], "-o", label=lab)
        ax.legend(fontsize=8); ax.set_title("Blocked R2O reasons by year")
        fig.tight_layout(); fig.savefig(plots / "02_blocked_reasons.png"); plt.close(fig)

        fig, ax = plt.subplots(figsize=(8, 4.5))
        ax.plot(summary["year"], summary["available_for_sale_start"], "-o", label="For-sale available (start)")
        ax.plot(summary["year"], summary["eligible_renter_count"], "-s", label="Eligible renters")
        ax.legend(); ax.set_title("For-sale stock vs eligible renters")
        fig.tight_layout(); fig.savefig(plots / "06_forsale_vs_eligible.png"); plt.close(fig)

    if not ann6e.empty:
        fig, ax = plt.subplots(figsize=(8, 4.5))
        ax.plot(ann6e["Year"], ann6e["Renter_Occupied_HH"], "-o", label="6E renters")
        ax.plot(ann6e["Year"], ann6e["Owner_Occupied_HH"], "-s", label="6E owners")
        ax.plot(ann6e["Year"], ann6e["Housing_Insecure_HH_Count"], "-^", label="6E insecure")
        if not ann6d.empty:
            ax.plot(ann6d["Year"], ann6d["Renter_Occupied_HH"], "--", label="6D renters")
            ax.plot(ann6d["Year"], ann6d["Owner_Occupied_HH"], "--", label="6D owners")
            ax.plot(ann6d["Year"], ann6d["Housing_Insecure_HH_Count"], "--", label="6D insecure")
        ax.legend(fontsize=7); ax.set_title("Renter/owner/insecure before vs after")
        fig.tight_layout(); fig.savefig(plots / "03_tenure_before_after.png"); plt.close(fig)

        fig, ax = plt.subplots(figsize=(8, 4.5))
        ax.plot(ann6e["Year"], ann6e["Rental_Vacancy_Rate"], "-o", label="6E rental vac")
        if not ann6d.empty:
            ax.plot(ann6d["Year"], ann6d["Rental_Vacancy_Rate"], "--", label="6D rental vac")
        ax.legend(); ax.set_title("Rental vacancy before vs after")
        fig.tight_layout(); fig.savefig(plots / "04_rental_vacancy.png"); plt.close(fig)

    if not stock.empty:
        fig, ax = plt.subplots(figsize=(8, 4.5))
        ax.plot(stock["year"], stock["for_sale_vacancy_rate"], "-o", label="6E for-sale vac")
        if not stock6d.empty:
            ax.plot(stock6d["year"], stock6d["for_sale_vacancy_rate"], "--", label="6D for-sale vac")
        ax.legend(); ax.set_title("For-sale vacancy before vs after")
        fig.tight_layout(); fig.savefig(plots / "05_forsale_vacancy.png"); plt.close(fig)

    if not transfer.empty:
        fig, ax = plt.subplots(figsize=(8, 4))
        fails = transfer[transfer["transfer_success"] == False].groupby("year").size()
        if fails.empty:
            ax.bar([0], [0])
        else:
            ax.bar(fails.index.astype(int), fails.values)
        ax.set_title("Ledger transfer failures by year")
        fig.tight_layout(); fig.savefig(plots / "07_transfer_failures.png"); plt.close(fig)

    if not cmp.empty:
        core = cmp[cmp["metric"].isin(["population", "owner_households", "renter_households", "housing_insecure", "rental_vacancy"])]
        if not core.empty:
            fig, ax = plt.subplots(figsize=(9, 4.5))
            piv = core.pivot_table(index="year", columns="metric", values="absolute_diff", aggfunc="first")
            piv.plot(ax=ax, marker="o")
            ax.axhline(0, color="gray", lw=0.8)
            ax.set_title("Phase 6D vs 6E absolute diffs")
            fig.tight_layout(); fig.savefig(plots / "08_phase6d_vs_phase6e.png"); plt.close(fig)

    if not flags_df.empty:
        fig, ax = plt.subplots(figsize=(7, 4))
        sev = flags_df["severity"].value_counts()
        ax.bar(sev.index.astype(str), sev.values)
        ax.set_title("Remaining housing red flags")
        fig.tight_layout(); fig.savefig(plots / "09_red_flags.png"); plt.close(fig)

    sum_txt = summary.to_string(index=False) if not summary.empty else ""
    stock_txt = stock.to_string(index=False) if not stock.empty else ""
    inv_fail = inv[inv["pass_fail"] == "FAIL"] if not inv.empty else pd.DataFrame()
    inv_txt = inv_fail.to_string(index=False) if not inv_fail.empty else "none (all PASS)"

    report = f"""# Phase 6E Renter-to-Owner Transition Report

**Status:** {"PASSED" if passed else "FAILED"}  
**Base:** Phase 6D source-copy

## Answers

1. **Path added:** `HousingManager` → `process_renter_to_owner` → `transfer_household_housing_claim` (atomic rental→owner ledger swap).
2. **Eligibility:** nonempty renter; active rental ledger claim; for-sale available; finance present; affordability gate.
3. **Gates:** income ≥ required_cost; ownership cost proxy ≤30% income; if savings known, savings ≥ max(min_down, 20% value).
4. **Savings reliability:** Partial — when missing, `savings_unknown_income_screen_only`.
5. **For-sale available?** See summary available_for_sale_start (often near-zero after 6D).
6. **Attempts:** {total_att}
7. **Successes:** {total_succ}
8. **Blocked mostly:** See summary blocked_* columns (expect stock and/or probability after 6D fill).
9. **Atomic transfer?** Yes — dedicated helper with rollback.
10. **Multiple claims?** {multi_fail}
11. **Claimless after fail?** {claimless_fail}
12. **Low-frequency?** p=0.03, max_rate=0.02 of renters, capped by stock.
13. **Init tenure unchanged?** Yes (Phase 6D synthesis untouched).
14. **Capacities unchanged?** Yes.
15. **Non-housing changed?** Not intentionally.
16. **Red flags:** stock-limited R2O; insecure growth when full. Invariants: {inv_txt}

## R2O summary
```
{sum_txt}
```

## Vacancy
```
{stock_txt}
```

Eligible renter evaluations (sum): {eligible_any}

## Stop
Phase 6E complete. Do not expand stock, tune probabilities, or add loans/ML.
"""
    (diag / "phase6e_renter_to_owner_transition_report.md").write_text(report, encoding="utf-8")

    change = """# Phase 6E Change Log

| File | Type | Reason |
|------|------|--------|
| `mastercode02_config_and_rates.py` | model-logic (config) | R2O parameters |
| `mastercode02_housing_ledger.py` | model-logic | `transfer_household_housing_claim` + transfer audit |
| `mastercode02_renter_to_owner.py` | model-logic (new) | Eligibility + annual capped transitions |
| `mastercode02_agents.py` | model-logic | HousingManager calls R2O |
| `mastercode02_phase6e_diagnostics.py` | diagnostic | Snapshots/invariants |
| `mastercode02_phase6e_postrun.py` | diagnostic | Comparisons/plots |
| `mastercode02_logging.py` | diagnostic hook | Phase 6E snapshot |
| `notebooks/run_phase6e.py` | runner | Seeded run |

**Path added:** Controlled renter→owner via ledger atomic transfer.

**Not** init tenure change, capacity change, market rewrite, or ML.
"""
    (diag / "phase6e_change_log.md").write_text(change, encoding="utf-8")
    return passed
