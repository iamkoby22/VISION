#!/usr/bin/env python
"""Phase 9E-T0: structural diff between two t=0 data-block snapshots.

Returns a flat mapping of dotted-path -> {"from": <base>, "to": <candidate>}
for every differing leaf/added/removed key. An empty dict means identical.
"""
from __future__ import annotations


def _walk(prefix, base, cand, out):
    if isinstance(base, dict) and isinstance(cand, dict):
        for k in base:
            p = f"{prefix}.{k}" if prefix else str(k)
            if k not in cand:
                out[p] = {"from": base[k], "to": None}
            else:
                _walk(p, base[k], cand[k], out)
        for k in cand:
            if k not in base:
                p = f"{prefix}.{k}" if prefix else str(k)
                out[p] = {"from": None, "to": cand[k]}
    else:
        if base != cand:
            out[prefix] = {"from": base, "to": cand}


def diff_t0(base_blocks, cand_blocks):
    out: dict = {}
    _walk("", base_blocks, cand_blocks, out)
    return out
