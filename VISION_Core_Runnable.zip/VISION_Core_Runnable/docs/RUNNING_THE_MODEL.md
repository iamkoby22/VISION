# Running the model

## 1. Choose how many years

`MODEL_YEARS` / `--years` is the number of **annual transitions**.

    MODEL_YEARS = N   ->   N + 1 annual rows, calendar 2000 .. 2000+N

`MODEL_YEARS = 23` therefore means calendar 2000 through 2023: **23 transitions, 24 checkpoints**.
This matches the authoritative production run. The convention was verified by reading the engine
source and by cross-checking both completed runs (the VIG production run used duration 23 and
wrote 24 annual rows; the Core benchmark used duration 24 and wrote 25).

## 2. Choose a seed

Any integer. The authoritative production seed is `20230101`. The five sensitivity seeds are
`11111111`, `22222222`, `33333333`, `44444444`, `55555555`. The smoke fixture uses `314159`.

## 3. Choose a scenario

`canonical`, `baseline`, `smoke`, or `custom`. A custom scenario supplies its own T0 and/or
config overrides through the engine's existing switches.

## 4. Run

From the notebook, or:

    python run_<model>.py --years N --seed S --scenario SC --run-label LABEL

## 5. Read the output

Start with `outputs/user_runs/<LABEL>/outputs/*_annual_summary.csv` and
`outputs/user_runs/<LABEL>/diagnostics/run_status.json`.

## If a run fails

Check `logs/stderr.log` first. For VISION Intelligence also check
`provenance/path_remapping.json` (every entry should have `"exists": true`) and
`provenance/preflight.json` (every check should be `true`).
