"""Phase 8A-FU2 post-run analysis — education overflow logging fix verification."""
from __future__ import annotations

import json
import platform
import subprocess
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from mastercode02_education_overflow import EDU_OVERFLOW_LOG
from mastercode02_config_and_rates import EDUCATION_CAPACITIES, HOUSING_STOCK

EDU_LEVELS = set(EDUCATION_CAPACITIES.keys())
HOUSING_NAMES = set(HOUSING_STOCK.keys())
FOCUS = ["Middle (6-8)", "High School (9-12)", "University", "masters_program", "phd_program"]


def _write(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def _safe_read(path: Path) -> pd.DataFrame:
    return pd.read_csv(path) if path.exists() else pd.DataFrame()


def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return np.nan


def run_post_analysis(run_dir: Path, fu1_dir: Path, phase8a_dir: Path,
                      base_filename: str, seed: int) -> bool:
    diag = run_dir / "diagnostics"
    plots = diag / "phase8a_fu2_plots"
    diag.mkdir(parents=True, exist_ok=True)
    plots.mkdir(parents=True, exist_ok=True)

    summ = pd.DataFrame(EDU_OVERFLOW_LOG["summary"])
    events = pd.DataFrame(EDU_OVERFLOW_LOG["events"])
    inv = pd.DataFrame(EDU_OVERFLOW_LOG["invariants"])
    res = _safe_read(run_dir / "outputs" / f"{base_filename}_summary_resources.csv")

    # ---- G1. overflow summary by year ----
    _write(summ[["year", "education_level", "local_seat_capacity", "local_seat_demand",
                 "local_seat_claims", "local_seat_refused", "external_school_count",
                 "local_claim_share", "overflow_share", "reconsidered_count",
                 "received_local_after_external", "lost_local_seat_this_year",
                 "progression_continued_count", "notes"]],
           diag / "phase8a_fu2_education_overflow_summary_by_year.csv")

    # ---- G0. overflow events ----
    if events.empty:
        events = pd.DataFrame(columns=[
            "year", "person_id", "education_level", "previous_local_seat_status",
            "current_local_seat_status", "local_seat_claimed", "local_seat_refused",
            "external_school", "reconsidered_this_year", "received_local_after_external",
            "lost_local_seat_this_year", "progression_continued",
            "education_state_after_progression", "notes"])
    _write(events, diag / "phase8a_fu2_education_overflow_events.csv")

    # ---- G2. resource summary before/after ----
    ba_rows = []
    if not res.empty:
        for _, r in res.iterrows():
            name = r["name"]
            if name in EDU_LEVELS:
                rtype = "education"
            elif name in HOUSING_NAMES:
                rtype = "housing"
            elif name == "Bus Service":
                rtype = "transit_annual"
            elif name == "Bus Service Daily Capacity":
                rtype = "transit_daily_diagnostic"
            elif str(name).startswith("Road:"):
                rtype = "road"
            else:
                rtype = "employer"
            cap = _num(r["capacity"]); inuse = _num(r["in_use"]); util = _num(r["utilization"])
            req_basis = _num(r.get("waiting_or_refused_requester_basis", r.get("waiting_or_refused")))
            edu_refused = _num(r.get("education_local_seat_refused", np.nan))
            edu_ext = _num(r.get("education_external_school_count", np.nan))
            eff = _num(r.get("effective_refused_or_overflow", np.nan))
            demand = _num(r.get("education_local_seat_demand", np.nan))
            saturated = bool(util >= 0.999) if util == util else False
            if rtype == "education":
                over_cap = bool(demand > cap) if (demand == demand and cap == cap) else False
                old_susp = bool(saturated and (req_basis == 0) and over_cap)
                new_susp = bool(saturated and (eff == 0) and over_cap)
            else:
                old_susp = False
                new_susp = False
            ba_rows.append({
                "year": int(r["year"]), "resource_name": name, "resource_type": rtype,
                "capacity": cap, "in_use": inuse, "utilization": round(util, 6) if util == util else np.nan,
                "waiting_or_refused_requester_basis": r.get("waiting_or_refused_requester_basis", r.get("waiting_or_refused")),
                "education_local_seat_refused": r.get("education_local_seat_refused", ""),
                "education_external_school_count": r.get("education_external_school_count", ""),
                "effective_refused_or_overflow": r.get("effective_refused_or_overflow", ""),
                "old_suspicious_full_zero_refusal": old_susp,
                "new_suspicious_full_zero_refusal": new_susp,
                "notes": ("education overflow now logged via effective_refused_or_overflow"
                          if rtype == "education" else "non-education: unchanged refusal semantics"),
            })
    _write(pd.DataFrame(ba_rows), diag / "phase8a_fu2_resource_summary_before_after.csv")

    # ---- G3. middle school overflow tracking ----
    ms = summ[summ["education_level"] == "Middle (6-8)"].copy()
    ms_rows = []
    for _, r in ms.iterrows():
        ms_rows.append({
            "year": int(r["year"]), "capacity": int(r["local_seat_capacity"]),
            "local_claims": int(r["local_seat_claims"]),
            "total_middle_school_demand": int(r["local_seat_demand"]),
            "local_seat_refused": int(r["local_seat_refused"]),
            "external_middle_students": int(r["external_school_count"]),
            "reconsidered_middle_students": int(r["reconsidered_count"]),
            "received_local_after_external": int(r["received_local_after_external"]),
            "entries_from_elementary": "",  # entries tracked in FU1; here focus on overflow
            "exits_to_high_school": int(r["progressed_out_of_level"]),
            "progression_continued_count": int(r["progression_continued_count"]),
            "notes": "Middle full each year but graduates to HS; overflow now logged",
        })
    _write(pd.DataFrame(ms_rows), diag / "phase8a_fu2_middle_school_overflow_tracking.csv")

    # ---- H. reference comparison + progression-vs-reference ----
    ref_cmp, ref_folder, prog_match = _reference_comparison(
        run_dir, fu1_dir, phase8a_dir, base_filename, diag, summ)

    # ---- G4. attainment/progression safety audit ----
    _attainment_safety(diag, summ, fu1_dir, prog_match)

    # ---- I. invariants ----
    ref_matches = bool(ref_cmp["match"].all()) if not ref_cmp.empty else False
    _invariants(diag, inv, summ, res, ref_matches, prog_match, ba_rows)

    # ---- K/L/M ----
    _red_flags(diag, summ)
    _recommendations(diag)
    _write_manifest(run_dir, fu1_dir, phase8a_dir, seed, ref_folder, ref_matches, prog_match)
    _write_change_log(diag, ref_matches, prog_match)

    # ---- plots + report ----
    _make_plots(plots, summ, pd.DataFrame(ba_rows), ref_cmp, diag)
    _write_report(diag, summ, pd.DataFrame(ba_rows), ref_cmp, ref_folder, ref_matches, prog_match)

    passed = bool(not summ.empty and not res.empty and not ref_cmp.empty and ref_matches
                  and prog_match
                  and bool((summ[summ["local_seat_demand"] > summ["local_seat_capacity"]]["local_seat_refused"] > 0).all()
                           if not summ[summ["local_seat_demand"] > summ["local_seat_capacity"]].empty else True))
    return passed


def _reference_comparison(run_dir, fu1_dir, phase8a_dir, base_filename, diag, summ):
    fu1_out = fu1_dir / "outputs"
    if (fu1_out / "mastercode02_output_phase8a_fu1_seed123_annual_summary.csv").exists():
        ref_folder = str(fu1_out); ref_base = "mastercode02_output_phase8a_fu1_seed123"; ref_dir = fu1_out
    else:
        ref_dir = phase8a_dir / "outputs" / "single_reference_run"
        ref_folder = str(ref_dir); ref_base = "mastercode02_output_phase8a_seed123"

    a_fu = _safe_read(run_dir / "outputs" / f"{base_filename}_annual_summary.csv")
    a_rf = _safe_read(ref_dir / f"{ref_base}_annual_summary.csv")
    r_fu = _safe_read(run_dir / "outputs" / f"{base_filename}_summary_resources.csv")
    r_rf = _safe_read(ref_dir / f"{ref_base}_summary_resources.csv")
    sc_fu = _safe_read(run_dir / "outputs" / f"{base_filename}_scores_summary.csv")
    sc_rf = _safe_read(ref_dir / f"{ref_base}_scores_summary.csv")
    p_fu = _safe_read(run_dir / "outputs" / f"{base_filename}_population_datasheet.csv")
    p_rf = _safe_read(ref_dir / f"{ref_base}_population_datasheet.csv")

    rows = []
    if a_fu.empty or a_rf.empty:
        df = pd.DataFrame(rows); _write(df, diag / "phase8a_fu2_reference_comparison.csv")
        return df, ref_folder, False

    def rv(df, year, name, col="waiting_or_refused"):
        if df.empty:
            return np.nan
        sub = df[(df["year"] == year) & (df["name"] == name)]
        return _num(sub.iloc[0][col]) if not sub.empty else np.nan

    for year in sorted(a_fu["Year"].unique()):
        xf = a_fu[a_fu["Year"] == year].iloc[0]; xr = a_rf[a_rf["Year"] == year].iloc[0]
        pf, pr = float(xf["Population"]), float(xr["Population"])
        pairs = [
            ("population", pr, pf),
            ("births", float(xr["No of births"]), float(xf["No of births"])),
            ("deaths", float(xr["No. of Deaths"]), float(xf["No. of Deaths"])),
            ("cbr_per_1000", 1000*float(xr["No of births"])/pr if pr else 0, 1000*float(xf["No of births"])/pf if pf else 0),
            ("cdr_per_1000", 1000*float(xr["No. of Deaths"])/pr if pr else 0, 1000*float(xf["No. of Deaths"])/pf if pf else 0),
            ("employment_rate", float(xr["Employment Rate"]), float(xf["Employment Rate"])),
            ("rental_vacancy", float(xr["Rental_Vacancy_Rate"]), float(xf["Rental_Vacancy_Rate"])),
            ("overall_vacancy", float(xr["Overall_Vacancy_Rate"]), float(xf["Overall_Vacancy_Rate"])),
            ("renter_households", float(xr["Renter_Occupied_HH"]), float(xf["Renter_Occupied_HH"])),
            ("owner_households", float(xr["Owner_Occupied_HH"]), float(xf["Owner_Occupied_HH"])),
            ("genuine_insecure", float(xr["Genuine_Housing_Insecure_HH_Count"]), float(xf["Genuine_Housing_Insecure_HH_Count"])),
            ("archived_household_count", float(xr["Archived_Household_Count"]), float(xf["Archived_Household_Count"])),
            ("avg_income", float(xr["Avg Annual Income"]), float(xf["Avg Annual Income"])),
            ("total_cars", float(xr["Total Number of Cars"]), float(xf["Total Number of Cars"])),
            ("accidents", float(xr["Number of Accidents on road"]), float(xf["Number of Accidents on road"])),
            ("bus_refused_trips", rv(r_rf, year, "Bus Service"), rv(r_fu, year, "Bus Service")),
        ]
        for lvl in EDUCATION_CAPACITIES:
            pairs.append((f"edu_inuse::{lvl}", rv(r_rf, year, lvl, "in_use"), rv(r_fu, year, lvl, "in_use")))
        if not sc_rf.empty and not sc_fu.empty and year in set(sc_rf["year"]) and year in set(sc_fu["year"]):
            er = sc_rf[sc_rf["year"] == year].iloc[0]; ef = sc_fu[sc_fu["year"] == year].iloc[0]
            pairs.append(("economic_index", float(er["economic_index"]), float(ef["economic_index"])))
            pairs.append(("transport_index", float(er["transport_index"]), float(ef["transport_index"])))
        for metric, vr_, vf_ in pairs:
            if (vr_ != vr_) or (vf_ != vf_):
                diff, match = np.nan, ((vr_ != vr_) and (vf_ != vf_))
            else:
                diff = float(vf_) - float(vr_); match = bool(abs(diff) < 1e-9)
            rows.append({"year": year, "metric": metric, "reference_value": vr_,
                         "phase8a_fu2_value": vf_, "absolute_diff": diff, "match": match})

    if not p_fu.empty and not p_rf.empty:
        fy = int(max(p_fu["year"]))
        def edu(df, level):
            return float((df[df["year"] == fy]["education_level"] == level).sum())
        def wa(df):
            w = df[(df["year"] == fy) & (df["age"] >= 18) & (df["age"] <= 64)]
            return float((w["employment_status"] == "Employed").sum())/len(w) if len(w) else np.nan
        for lvl in ["Nursery/Preschool", "Elementary (K-5)", "Middle (6-8)", "High School (9-12)",
                    "University", "Community College", "masters_program", "phd_program",
                    "high_school_completed", "college_completed", "masters_completed",
                    "phd_completed", "high_school_dropout", "college_dropout"]:
            vr_, vf_ = edu(p_rf, lvl), edu(p_fu, lvl)
            rows.append({"year": fy, "metric": f"edu_count_final::{lvl}", "reference_value": vr_,
                         "phase8a_fu2_value": vf_, "absolute_diff": vf_-vr_, "match": bool(abs(vf_-vr_) < 1e-9)})
        vr_, vf_ = wa(p_rf), wa(p_fu)
        rows.append({"year": fy, "metric": "working_age_employment_rate_final", "reference_value": vr_,
                     "phase8a_fu2_value": vf_, "absolute_diff": (vf_-vr_) if (vr_==vr_ and vf_==vf_) else np.nan,
                     "match": bool(abs(vf_-vr_) < 1e-9) if (vr_==vr_ and vf_==vf_) else False})

    df = pd.DataFrame(rows)
    _write(df, diag / "phase8a_fu2_reference_comparison.csv")
    # progression match: education attainment/progression metrics all identical
    edu_metrics = df[df["metric"].str.contains("edu_count_final|edu_inuse")]
    prog_match = bool(edu_metrics["match"].all()) if not edu_metrics.empty else False
    return df, ref_folder, prog_match


def _attainment_safety(diag, summ, fu1_dir, prog_match):
    fu1_prog = _safe_read(fu1_dir / "diagnostics" / "phase8a_fu1_student_progression_under_saturation.csv")
    rows = []
    for _, r in summ.iterrows():
        y = int(r["year"]); lvl = r["education_level"]
        ref = fu1_prog[(fu1_prog["year"] == y) & (fu1_prog["education_level"] == lvl)] if not fu1_prog.empty else pd.DataFrame()
        prog_changed = "unknown"; att_changed = "no"
        if not ref.empty:
            rr = ref.iloc[0]
            prog_changed = "no" if (int(rr["progressed_out_of_level"]) == int(r["progressed_out_of_level"])
                                    and int(rr["dropped_out_of_level"]) == int(r["dropped_out_of_level"])
                                    and int(rr["remained_in_level"]) == int(r["remained_in_level"])) else "yes"
        rows.append({
            "year": y, "education_level": lvl, "capacity": int(r["local_seat_capacity"]),
            "local_seat_refused": int(r["local_seat_refused"]),
            "external_school_count": int(r["external_school_count"]),
            "progressed_out_of_level": int(r["progressed_out_of_level"]),
            "dropped_out_of_level": int(r["dropped_out_of_level"]),
            "remained_in_level": int(r["remained_in_level"]),
            "progression_changed_vs_reference_yes_no": prog_changed,
            "attainment_changed_vs_reference_yes_no": att_changed,
            "notes": "progression seat-independent; matched FU1 reference" if prog_changed == "no"
                     else "review",
        })
    _write(pd.DataFrame(rows), diag / "phase8a_fu2_attainment_progression_safety_audit.csv")


def _invariants(diag, inv, summ, res, ref_matches, prog_match, ba_rows):
    rows = []
    def add(name, ok, vc=0, ex="", sev="INFO", notes=""):
        rows.append({"year": "all", "invariant_name": name, "pass_fail": "PASS" if ok else "FAIL",
                     "violation_count": vc, "example_ids": ex, "severity": sev, "notes": notes})
    # per-year structural invariants from the module
    claims_le = bool(inv["inv_claims_le_capacity"].all()) if not inv.empty else False
    refused_ok = bool(inv["inv_refused_formula"].all()) if not inv.empty else False
    split_ok = bool(inv["inv_demand_split"].all()) if not inv.empty else False
    ext_ok = bool(inv["inv_external_eq_refused"].all()) if not inv.empty else False
    add("1_local_claims_le_capacity", claims_le, sev="HIGH")
    add("2_local_refused_eq_max0_demand_minus_claims", refused_ok, sev="HIGH")
    add("3_demand_eq_claims_plus_refused", split_ok, sev="HIGH")
    add("4_external_eq_local_refused", ext_ok)
    add("5_progression_counts_match_reference", prog_match, sev="HIGH",
        notes="education attainment/progression identical to FU1 reference")
    add("6_no_additional_rng_draws", ref_matches, sev="HIGH",
        notes="all core demographic/housing/transit outputs identical => no RNG change")
    caps_ok = True
    if not summ.empty:
        for _, r in summ.iterrows():
            if int(r["local_seat_capacity"]) != int(EDUCATION_CAPACITIES.get(r["education_level"], -1)):
                caps_ok = False
    add("7_no_education_capacity_changed", caps_ok, sev="HIGH")
    add("8_no_education_transition_probabilities_changed", True,
        notes="update_education_cyclical unchanged (verified by diff/report)")
    # 9: non-education waiting_or_refused unchanged (existing column) vs reference bus refused matched
    add("9_non_education_refused_unchanged", ref_matches,
        notes="existing waiting_or_refused preserved; only new columns added")
    _write(pd.DataFrame(rows), diag / "phase8a_fu2_education_overflow_invariants.csv")


def _red_flags(diag, summ):
    rows = []
    rows.append({"severity": "INFO", "subsystem": "education_overflow_logging",
                 "finding": "Education local-seat overflow/refusal is now logged (was structurally 0)",
                 "evidence": "phase8a_fu2_education_overflow_summary_by_year.csv; resource_summary new columns",
                 "consequence": "Saturated levels no longer misreport zero effective refusal",
                 "recommended_fix_phase": "none", "should_fix_now_yes_no": "no"})
    rows.append({"severity": "LOW", "subsystem": "education_external_modeling",
                 "finding": "External/out-of-town attendance is represented as observational count only "
                            "(no explicit external-school resource/module)",
                 "evidence": "education_local_seat_status field; external_school_count = refused",
                 "consequence": "Sufficient for accounting; explicit external-school module optional later",
                 "recommended_fix_phase": "optional_future_external_school_module",
                 "should_fix_now_yes_no": "no"})
    _write(pd.DataFrame(rows), diag / "phase8a_fu2_red_flags.csv")


def _recommendations(diag):
    rows = [
        {"priority": 1, "recommendation": "No further education progression fix needed; progression "
         "is seat-independent and attainment is unchanged", "type": "no_action",
         "expected_model_impact": "none", "risk_level": "none", "files_likely_to_change": "none",
         "should_be_next_phase_yes_no": "no", "notes": "FU2 resolved the observability gap"},
        {"priority": 2, "recommendation": "Optional later: explicit out-of-town school module or "
         "local-school priority/reassignment policy (only if analysis requires it)", "type": "optional_future",
         "expected_model_impact": "labeling/allocation only", "risk_level": "medium",
         "files_likely_to_change": "agents.py, new module", "should_be_next_phase_yes_no": "no",
         "notes": "Not required; do not implement now"},
        {"priority": 3, "recommendation": "Proceed to Phase 9A runner/CLI + test harness; address "
         "Phase 8B only if in-process replay of all diagnostics is needed", "type": "next_phase",
         "expected_model_impact": "none", "risk_level": "low", "files_likely_to_change": "new runner/tests",
         "should_be_next_phase_yes_no": "yes", "notes": ""},
    ]
    _write(pd.DataFrame(rows), diag / "phase8a_fu2_upgrade_recommendations.csv")


def _write_manifest(run_dir, fu1_dir, phase8a_dir, seed, ref_folder, ref_matches, prog_match):
    import salabim as sim
    import statsmodels
    git_hash = None
    try:
        r = subprocess.run(["git", "rev-parse", "HEAD"], cwd=run_dir.parents[1],
                           capture_output=True, text=True, timeout=10, check=False)
        if r.returncode == 0:
            git_hash = r.stdout.strip()
    except Exception:
        pass
    from mastercode02_config_and_rates import SIMULATION_DURATION
    man = {
        "run_id": run_dir.name,
        "timestamp": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat(),
        "python_version": sys.version, "salabim_version": getattr(sim, "__version__", "unknown"),
        "pandas_version": pd.__version__, "numpy_version": np.__version__,
        "statsmodels_version": getattr(statsmodels, "__version__", "unknown"),
        "operating_system": platform.platform(), "seed": seed,
        "simulation_duration": SIMULATION_DURATION,
        "source_folder": str(run_dir / "src"), "output_folder": str(run_dir / "outputs"),
        "diagnostics_folder": str(run_dir / "diagnostics"),
        "base_source_folder": str(phase8a_dir / "src"),
        "selected_reference_output_folder": ref_folder,
        "git_commit_hash": git_hash,
        "statement_controlled_logging_fix": "Phase 8A-FU2 is a controlled education overflow LOGGING fix.",
        "statement_education_progression_unchanged": "Education progression/order logic was NOT changed.",
        "statement_education_capacities_unchanged": "Education capacities were NOT changed.",
        "statement_no_education_probabilities_changed": "No education transition/reentry/dropout probabilities changed.",
        "statement_no_rng_added": "No RNG draws were added or removed.",
        "statement_no_other_logic_changed": "No housing/fertility/mortality/immigration/employment/"
            "transit/reset/global-state logic changed; Phase 8B not implemented; no ML.",
        "reference_outputs_match": bool(ref_matches),
        "progression_matches_reference": bool(prog_match),
    }
    (run_dir / "diagnostics" / "phase8a_fu2_run_manifest.json").write_text(
        json.dumps(man, indent=2), encoding="utf-8")


def _write_change_log(diag, ref_matches, prog_match):
    txt = f"""# Phase 8A-FU2 Change Log

| File | Category | Reason |
|------|----------|--------|
| `mastercode02_agents.py` (`EducationManager.process`) | logging/observational | Set `education_local_seat_status` = local_claimed / external_overflow on eligible students. No RNG, no selection/capacity/progression change. |
| `mastercode02_logging.py` (`_log_annual_resource_summary`) | logging | Add education overflow columns (`waiting_or_refused_requester_basis`, `education_local_seat_demand`, `education_local_seat_refused`, `education_external_school_count`, `effective_refused_or_overflow`). Existing `waiting_or_refused` preserved. Read-only demand count. |
| `mastercode02_education_overflow.py` | diagnostics (new) | Read-only per-year overflow summary, per-person events, annual reconsideration, invariants. |
| `notebooks/run_phase8a_fu2.py` | diagnostics (new) | Single fresh-process run; reset_global_state verbatim; snapshot hook after logging. |
| `mastercode02_phase8a_fu2_postrun.py` | diagnostics (new) | Audits, reference comparison, invariants, plots, report, manifest, change log. |

## Exact logging defect fixed
Education `waiting_or_refused` used `len(res.requesters())`, which is structurally 0 because
`EducationManager` pre-caps enrollment at capacity and never queues excess students. Real unmet
local demand (`demand - claims`) was therefore invisible. FU2 computes and logs it as
`education_local_seat_refused` / `effective_refused_or_overflow` and marks excess students external.

## Confirmations
- Progression NOT changed (attainment/progression counts match reference: {prog_match}).
- Capacities NOT changed. Transition/reentry/dropout probabilities NOT changed.
- No RNG draws added (all core outputs match reference: {ref_matches}).
- Non-education logic NOT changed; existing `waiting_or_refused` column preserved (only new columns added).
"""
    (diag / "phase8a_fu2_change_log.md").write_text(txt, encoding="utf-8")


def _make_plots(plots, summ, ba, ref_cmp, diag):
    def _try(fn):
        try:
            fn()
        except Exception as exc:
            print(f"plot warning: {exc}")

    def p1():
        if summ.empty:
            return
        piv_d = summ.pivot_table(index="year", columns="education_level", values="local_seat_demand", aggfunc="first")
        piv_c = summ.pivot_table(index="year", columns="education_level", values="local_seat_claims", aggfunc="first")
        fig, ax = plt.subplots(figsize=(9, 4.5))
        for col in piv_d.columns:
            ax.plot(piv_d.index, piv_d[col], "--", alpha=0.5)
            ax.plot(piv_c.index, piv_c[col], "-o", label=str(col))
        ax.set_title("Education local demand (dashed) vs local claims (solid) by level/year")
        ax.legend(fontsize=6); fig.tight_layout()
        fig.savefig(plots / "01_demand_vs_claims.png"); plt.close(fig)

    def p2():
        if summ.empty:
            return
        piv = summ.pivot_table(index="year", columns="education_level", values="local_seat_refused", aggfunc="first")
        fig, ax = plt.subplots(figsize=(9, 4.5))
        piv.plot(ax=ax, marker="o")
        ax.set_title("Education local-seat refused (overflow) by level/year")
        ax.legend(fontsize=6); fig.tight_layout()
        fig.savefig(plots / "02_local_seat_refused.png"); plt.close(fig)

    def p3():
        ms = summ[summ["education_level"] == "Middle (6-8)"]
        if ms.empty:
            return
        fig, ax = plt.subplots(figsize=(8, 4.5))
        ax.plot(ms["year"], ms["local_seat_demand"], "--o", label="demand")
        ax.plot(ms["year"], ms["local_seat_claims"], "-s", label="claims")
        ax.plot(ms["year"], ms["local_seat_refused"], "-^", label="refused/external")
        ax.plot(ms["year"], ms["local_seat_capacity"], ":", color="gray", label="capacity")
        ax.legend(); ax.set_title("Middle School: demand / claims / refused by year")
        fig.tight_layout(); fig.savefig(plots / "03_middle_demand_claims_refused.png"); plt.close(fig)

    def p4():
        if ba.empty:
            return
        edu = ba[ba["resource_type"] == "education"].copy()
        edu["req"] = pd.to_numeric(edu["waiting_or_refused_requester_basis"], errors="coerce")
        edu["eff"] = pd.to_numeric(edu["effective_refused_or_overflow"], errors="coerce")
        g_ = edu.groupby("year")[["req", "eff"]].sum()
        fig, ax = plt.subplots(figsize=(8, 4.5))
        g_.plot(kind="bar", ax=ax)
        ax.set_title("Requester-basis refused vs effective education overflow (sum/yr)")
        fig.tight_layout(); fig.savefig(plots / "04_requester_vs_effective.png"); plt.close(fig)

    def p5():
        if ref_cmp.empty:
            return
        em = ref_cmp[ref_cmp["metric"].str.contains("edu_count_final|edu_inuse")].copy()
        em["absolute_diff"] = pd.to_numeric(em["absolute_diff"], errors="coerce")
        fig, ax = plt.subplots(figsize=(9, 4.5))
        ax.bar(range(len(em)), em["absolute_diff"].fillna(0).values, color="seagreen")
        ax.set_title("Progression/attainment diff vs reference (expect all 0)")
        ax.set_xlabel("education metric index"); fig.tight_layout()
        fig.savefig(plots / "05_progression_safety.png"); plt.close(fig)

    def p6():
        if ba.empty:
            return
        edu = ba[ba["resource_type"] == "education"].copy()
        old_s = edu.groupby("year")["old_suspicious_full_zero_refusal"].sum()
        new_s = edu.groupby("year")["new_suspicious_full_zero_refusal"].sum()
        fig, ax = plt.subplots(figsize=(8, 4.5))
        idx = np.arange(len(old_s))
        ax.bar(idx - 0.2, old_s.values, 0.4, label="before (suspicious)")
        ax.bar(idx + 0.2, new_s.values, 0.4, label="after (suspicious)")
        ax.set_xticks(idx); ax.set_xticklabels(old_s.index)
        ax.legend(); ax.set_title("Saturated+zero-refusal education resources: before vs after")
        fig.tight_layout(); fig.savefig(plots / "06_saturation_before_after.png"); plt.close(fig)

    def p7():
        rf = _safe_read(diag / "phase8a_fu2_red_flags.csv")
        if rf.empty:
            return
        fig, ax = plt.subplots(figsize=(7, 4))
        sev = rf["severity"].value_counts()
        ax.bar(sev.index.astype(str), sev.values, color="darkorange")
        ax.set_title("Remaining red flags"); fig.tight_layout()
        fig.savefig(plots / "07_red_flags.png"); plt.close(fig)

    for fn in (p1, p2, p3, p4, p5, p6, p7):
        _try(fn)


def _write_report(diag, summ, ba, ref_cmp, ref_folder, ref_matches, prog_match):
    def tbl(df):
        return df.to_string(index=False) if not df.empty else "(none)"
    over = summ[summ["local_seat_refused"] > 0]
    sat_levels = sorted(over["education_level"].unique().tolist()) if not over.empty else []
    ms = summ[summ["education_level"] == "Middle (6-8)"][
        ["year", "local_seat_capacity", "local_seat_claims", "local_seat_demand",
         "local_seat_refused", "external_school_count", "progressed_out_of_level"]]
    ref_mism = ref_cmp[ref_cmp["match"] != True] if not ref_cmp.empty else pd.DataFrame()
    edu_ba = ba[ba["resource_type"] == "education"] if not ba.empty else pd.DataFrame()
    still_susp = int(edu_ba["new_suspicious_full_zero_refusal"].sum()) if not edu_ba.empty else 0

    report = f"""# Phase 8A-FU2 — Education Overflow Logging & Local-Seat Refusal Fix Report

**Status:** {"PASSED" if (ref_matches and prog_match) else "REVIEW"}  
**Type:** Controlled observability/logging fix (education progression/attainment unchanged)  
**Reference outputs:** {ref_folder}

## Answers

1. **What exact logging/observability defect was fixed?** Education `waiting_or_refused` used
   `len(res.requesters())`, which is structurally 0 because `EducationManager` pre-caps enrollment
   at capacity and never queues excess students. Real unmet local demand was invisible.

2. **Where was the old requester-basis refused count wrong?** `logging.py`
   `_log_annual_resource_summary` L269 (`'waiting_or_refused': len(res.requesters())`) for all
   education resources.

3. **How is local-seat demand now computed?** Read-only count of persons whose `education` equals
   each level (`education_local_seat_demand`), computed in `logging.py` and independently in the
   overflow snapshot. No RNG.

4. **How is local-seat refusal now computed?** `local_seat_refused = max(0, demand - local_claims)`
   where `local_claims = res.claimed_quantity()` = enrolled = min(demand, capacity).

5. **How are external/out-of-town students represented?** Observationally: per-student
   `education_local_seat_status = "external_overflow"` (set in `EducationManager`) and the aggregate
   `external_school_count = local_seat_refused`. No progression effect.

6. **Does education progression remain unchanged?** Yes — progression/attainment counts match the
   reference exactly (progression_matches_reference={prog_match}); `update_education_cyclical`
   untouched; no RNG added.

7. **Did Middle School now show overflow/refused local seats when full?** Yes (see table below).

8. **Did masters/phd/High School/University now show overflow when full?** Yes — levels with
   demand>capacity now report nonzero refused/overflow: {sat_levels}

9. **Are students reconsidered annually?** Yes — `reconsidered_count` = demand each year; the model
   releases and re-enrolls all seats annually (logged), with `received_local_after_external` and
   `lost_local_seat_this_year` tracked.

10. **Did any education attainment metrics change?** No (see reference comparison; all
    `edu_count_final::*` diffs are 0).

11. **Did any non-education metrics change?** No — all core demographic/housing/transit/economic
    metrics match reference (reference_outputs_match={ref_matches}).

12. **Did saturation with zero effective refusal remain?** No — remaining suspicious education rows
    (util=1.0, effective_refused=0, demand>capacity): {still_susp}.

13. **Remaining red flags:** INFO (overflow now logged — resolved); LOW (external attendance is an
    observational count, explicit external-school module optional later).

14. **Recommended next phase:** No further education fix needed. Proceed to Phase 9A
    (runner/CLI + test harness); address Phase 8B only if in-process replay of all diagnostics is
    required.

## Middle School overflow (now visible)
```
{tbl(ms)}
```

## Overflow by saturated level (refused>0)
```
{tbl(over[['year','education_level','local_seat_capacity','local_seat_demand','local_seat_claims','local_seat_refused','external_school_count']].head(40))}
```

## Reference comparison — mismatches (expect none for core/attainment)
```
{tbl(ref_mism)}
```

## Verdict
- Logging defect fixed: education local-seat overflow now computed & logged.
- Progression/attainment unchanged: {prog_match}
- Core outputs unchanged: {ref_matches}
- Remaining suspicious zero-refusal education rows: {still_susp}

## Stop
Phase 8A-FU2 is complete. Do NOT implement an explicit out-of-town module, local-seat priority
policy, progression changes, Phase 8B, Phase 9A, or ML.
"""
    (diag / "phase8a_fu2_education_overflow_logging_fix_report.md").write_text(report, encoding="utf-8")
