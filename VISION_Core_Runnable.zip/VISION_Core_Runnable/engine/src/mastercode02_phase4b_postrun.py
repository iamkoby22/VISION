"""Phase 4B post-run diagnostics, plots, and report."""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from mastercode02_phase4b_diagnostics import PHASE4B_LOG
from mastercode02_config_and_rates import (
    POST_HS_ROUTE_PROBS, EDUCATION_REENTRY_PROBS, EDUCATION_REENTRY_AGE_MULTIPLIERS,
    EDUCATION_CAPACITIES, COLLEGE_REENTRY_FALLBACK_PROBS, FERTILITY_PROBABILITY_SCALE,
)


def _load_annual(path: Path) -> pd.DataFrame:
    files = list(path.glob("*annual_summary.csv"))
    if not files:
        raise FileNotFoundError(f"No annual_summary in {path}")
    return pd.read_csv(files[0])


def run_post_analysis(run_dir: Path, phase3c_dir: Path, phase4a_dir: Path) -> bool:
    diag = run_dir / "diagnostics"
    plots = diag / "phase4b_plots"
    plots.mkdir(parents=True, exist_ok=True)
    src = run_dir / "src"
    out = run_dir / "outputs"

    # --- probability audits ---
    pd.DataFrame([
        {"route": k, "probability": v, "source": "POST_HS_ROUTE_PROBS",
         "provisional_yes_no": "yes",
         "note": "Splits prior 60% University into 45% University + 15% CC; preserves 40% remain"}
        for k, v in POST_HS_ROUTE_PROBS.items()
    ]).to_csv(diag / "phase4b_post_hs_route_probability_audit.csv", index=False)

    reentry_rows = []
    for state, cfg in EDUCATION_REENTRY_PROBS.items():
        for band in EDUCATION_REENTRY_AGE_MULTIPLIERS:
            reentry_rows.append({
                "dropout_state": state,
                "base_annual_probability": cfg["base_annual_probability"],
                "age_band": f"{band['min_age']}-{band['max_age']}",
                "age_multiplier": band["multiplier"],
                "effective_probability": cfg["base_annual_probability"] * band["multiplier"],
                "target_state": cfg["target_state"],
                "provisional_yes_no": "yes",
                "note": cfg["notes"],
            })
    pd.DataFrame(reentry_rows).to_csv(diag / "phase4b_reentry_probability_audit.csv", index=False)

    # --- before/after route map ---
    pd.DataFrame([
        {"route_segment": "early_education_chain", "before_phase4b": "too_young->Nursery->Elem->Middle->HS",
         "after_phase4b": "unchanged", "changed_yes_no": "no", "reason": "preserve existing route", "notes": ""},
        {"route_segment": "hs_completion_dropout", "before_phase4b": "95% completed / 5% dropout",
         "after_phase4b": "unchanged", "changed_yes_no": "no", "reason": "preserve existing route", "notes": ""},
        {"route_segment": "post_hs_branch",
         "before_phase4b": "60% University / 40% remain high_school_completed",
         "after_phase4b": "45% University / 15% Community College / 40% remain",
         "changed_yes_no": "yes", "reason": "add Community College pathway", "notes": "only post-HS branch extended"},
        {"route_segment": "university_completion", "before_phase4b": "75% college_completed / 25% college_dropout",
         "after_phase4b": "unchanged (same probs)", "changed_yes_no": "no",
         "reason": "preserve existing tertiary pattern", "notes": "last_tertiary_program set for reentry"},
        {"route_segment": "community_college_completion", "before_phase4b": "not reachable / no branch",
         "after_phase4b": "mirrors University: 75% college_completed / 25% college_dropout",
         "changed_yes_no": "yes", "reason": "prevent CC dead-end using existing outcome states",
         "notes": "provisional copied probabilities from University branch"},
        {"route_segment": "masters_phd_chain", "before_phase4b": "college_completed->masters->phd",
         "after_phase4b": "unchanged", "changed_yes_no": "no", "reason": "preserve existing route", "notes": ""},
        {"route_segment": "dropout_reentry", "before_phase4b": "terminal dropout states",
         "after_phase4b": "low-prob age-sensitive reentry to existing states",
         "changed_yes_no": "yes", "reason": "rare school return", "notes": "provisional conservative probs"},
        {"route_segment": "EducationManager", "before_phase4b": "enroll by education==resource name",
         "after_phase4b": "unchanged", "changed_yes_no": "no", "reason": "do not rewrite manager", "notes": ""},
        {"route_segment": "EDUCATION_CAPACITIES", "before_phase4b": str(EDUCATION_CAPACITIES),
         "after_phase4b": "unchanged", "changed_yes_no": "no", "reason": "preserve raw capacities", "notes": ""},
    ]).to_csv(diag / "phase4b_existing_route_before_after_map.csv", index=False)

    # --- education counts ---
    edu_counts = pd.DataFrame(PHASE4B_LOG["education_counts_by_year"])
    if edu_counts.empty:
        edu_counts = pd.DataFrame(columns=[
            "year", "education_state", "agent_count", "share_of_population",
            "age_min", "age_max", "mean_age", "employed_count", "unemployed_count",
        ])
    edu_counts.to_csv(diag / "phase4b_education_counts_by_year.csv", index=False)

    # --- transition events (enrich with reentry meta when possible) ---
    events = pd.DataFrame(PHASE4B_LOG["transition_events"])
    reentry = pd.DataFrame(PHASE4B_LOG["reentry_events"])
    if not events.empty and not reentry.empty:
        # merge successful reentry prob meta onto matching person/year dropout_reentry rows
        r_ok = reentry[reentry["successful_reentry"] == True].copy()
        if not r_ok.empty:
            key_cols = ["year", "person_id"]
            meta = r_ok[key_cols + ["random_draw", "base_probability", "age_multiplier", "final_probability"]]
            meta = meta.rename(columns={
                "random_draw": "route_draw_if_available",
                "base_probability": "route_probability_used",
                "age_multiplier": "age_multiplier_used",
                "final_probability": "final_probability_used",
            })
            # only fill empty fields for reentry transitions
            events = events.merge(meta, on=key_cols, how="left", suffixes=("", "_r"))
            for col in ("route_draw_if_available", "route_probability_used", "age_multiplier_used", "final_probability_used"):
                alt = col + "_r"
                if alt in events.columns:
                    events[col] = events[col].replace("", np.nan)
                    events[col] = events[col].fillna(events[alt])
                    events.drop(columns=[alt], inplace=True)
    if events.empty:
        events = pd.DataFrame(columns=[
            "year", "person_id", "age", "sex", "before_education", "after_education",
            "transition_type", "route_draw_if_available", "route_probability_used",
            "age_multiplier_used", "final_probability_used", "resource_requested",
            "resource_granted", "blocked_reason", "notes",
        ])
    events.to_csv(diag / "phase4b_education_transition_events.csv", index=False)

    # --- HS exit audit ---
    raw = PHASE4B_LOG.get("_hs_exit_raw", [])
    hs_rows = []
    years = sorted({r["year"] for r in raw}) if raw else list(range(0, 6))
    for y in years:
        subset = [r for r in raw if r["year"] == y]
        # also count eligible high_school_completed from snapshots
        eligible = 0
        if not edu_counts.empty:
            m = edu_counts[(edu_counts["year"] == y) & (edu_counts["education_state"] == "high_school_completed")]
            eligible = int(m["agent_count"].sum()) if not m.empty else 0
        hs_rows.append({
            "year": y,
            "eligible_agent_count": eligible,
            "went_to_university": sum(1 for r in subset if r["outcome"] == "went_to_university"),
            "went_to_community_college": sum(1 for r in subset if r["outcome"] == "went_to_community_college"),
            "remained_high_school_completed": sum(1 for r in subset if r["outcome"] == "remained_high_school_completed"),
            "dropped_out": sum(1 for r in subset if r["outcome"] == "high_school_dropout"),
            "missing_or_unknown": 0,
            "notes": "post-HS remain outcomes logged from POST_HS_ROUTE draws; HS completion also recorded",
        })
    pd.DataFrame(hs_rows).to_csv(diag / "phase4b_high_school_exit_audit.csv", index=False)

    # --- CC utilization ---
    cc_rows = []
    snaps = PHASE4B_LOG.get("resource_snapshots", [])
    # completion/dropout from CC: infer from transition events
    for snap in snaps:
        y = snap["year"]
        cc_info = snap.get("Community College", {"capacity": 5500, "claimed": 0, "available": 5500})
        cc_agents = 0
        if not edu_counts.empty:
            m = edu_counts[(edu_counts["year"] == y) & (edu_counts["education_state"] == "Community College")]
            cc_agents = int(m["agent_count"].sum()) if not m.empty else 0
        completed = 0
        dropped = 0
        if not events.empty:
            # transitions leaving Community College
            left = events[(events["year"] == y) & (events["before_education"] == "Community College")]
            completed = int((left["after_education"] == "college_completed").sum())
            dropped = int((left["after_education"] == "college_dropout").sum())
        cap = int(cc_info.get("capacity", EDUCATION_CAPACITIES.get("Community College", 5500)))
        claimed = int(cc_info.get("claimed", 0))
        avail = int(cc_info.get("available", max(0, cap - claimed)))
        util = (claimed / cap) if cap else 0.0
        cc_rows.append({
            "year": y,
            "community_college_agents": cc_agents,
            "community_college_resource_capacity": cap,
            "community_college_resource_claimed": claimed,
            "community_college_resource_available": avail,
            "community_college_utilization_rate": util,
            "community_college_completed_count_if_available": completed,
            "community_college_dropout_count_if_available": dropped,
            "notes": "claimed from EducationManager resource; agents from population education state",
        })
    pd.DataFrame(cc_rows).to_csv(diag / "phase4b_community_college_utilization.csv", index=False)

    # --- reentry audit + events ---
    if reentry.empty:
        reentry = pd.DataFrame(columns=[
            "year", "person_id", "age", "sex", "dropout_state", "target_state",
            "last_tertiary_program", "base_probability", "age_multiplier",
            "final_probability", "random_draw", "successful_reentry", "notes",
        ])
    reentry.to_csv(diag / "phase4b_dropout_reentry_events.csv", index=False)

    audit_rows = []
    if not reentry.empty:
        for (y, state), grp in reentry.groupby(["year", "dropout_state"]):
            succ = grp[grp["successful_reentry"] == True]
            targets = succ["target_state"].value_counts().to_dict() if not succ.empty else {}
            audit_rows.append({
                "year": y,
                "dropout_state": state,
                "eligible_dropout_count": len(grp),
                "reentry_attempts": len(grp),
                "successful_reentries": int(len(succ)),
                "target_state": json.dumps(targets) if targets else (EDUCATION_REENTRY_PROBS.get(state, {}).get("target_state", "")),
                "base_probability": float(grp["base_probability"].mean()),
                "mean_age_multiplier": float(grp["age_multiplier"].mean()),
                "mean_final_probability": float(grp["final_probability"].mean()),
                "notes": "one annual draw per dropout agent",
            })
    pd.DataFrame(audit_rows).to_csv(diag / "phase4b_dropout_reentry_audit.csv", index=False)

    # --- Phase 3C comparison ---
    p3 = pd.read_csv(phase3c_dir / "outputs" / "mastercode02_output_phase3c_seed123_annual_summary.csv")
    p4_files = list(out.glob("*annual_summary.csv"))
    p4 = pd.read_csv(p4_files[0])
    s3 = pd.read_csv(phase3c_dir / "outputs" / "mastercode02_output_phase3c_seed123_scores_summary.csv")
    s4_files = list(out.glob("*scores_summary.csv"))
    s4 = pd.read_csv(s4_files[0]) if s4_files else pd.DataFrame()

    cmp_rows = []
    for y in sorted(p4["Year"].unique()):
        r3 = p3[p3["Year"] == y].iloc[0]
        r4 = p4[p4["Year"] == y].iloc[0]
        pop3, pop4 = float(r3["Population"]), float(r4["Population"])
        b3, b4 = float(r3["No of births"]), float(r4["No of births"])
        d3, d4 = float(r3["No. of Deaths"]), float(r4["No. of Deaths"])
        pairs = [
            ("population", pop3, pop4),
            ("births", b3, b4),
            ("deaths", d3, d4),
            ("cbr_per_1000", 1000 * b3 / pop3 if pop3 else 0, 1000 * b4 / pop4 if pop4 else 0),
            ("cdr_per_1000", 1000 * d3 / pop3 if pop3 else 0, 1000 * d4 / pop4 if pop4 else 0),
            ("employment_rate", float(r3["Employment Rate"]), float(r4["Employment Rate"])),
            ("rental_vacancy", float(r3["Rental_Vacancy_Rate"]), float(r4["Rental_Vacancy_Rate"])),
            ("overall_vacancy", float(r3["Overall_Vacancy_Rate"]), float(r4["Overall_Vacancy_Rate"])),
            ("housing_insecure", float(r3["Housing_Insecure_HH_Count"]), float(r4["Housing_Insecure_HH_Count"])),
            ("avg_income", float(r3["Avg Annual Income"]), float(r4["Avg Annual Income"])),
        ]
        if not s3.empty and not s4.empty and y in set(s3["year"]) and y in set(s4["year"]):
            ss3 = s3[s3["year"] == y].iloc[0]
            ss4 = s4[s4["year"] == y].iloc[0]
            pairs.append(("economic_index", float(ss3["economic_index"]), float(ss4["economic_index"])))
            pairs.append(("transport_index", float(ss3["transport_index"]), float(ss4["transport_index"])))
        for edu in ["University", "Community College", "high_school_dropout", "college_dropout",
                    "masters_dropout", "college_completed", "high_school_completed"]:
            c4 = 0
            if not edu_counts.empty:
                m = edu_counts[(edu_counts["year"] == y) & (edu_counts["education_state"] == edu)]
                c4 = int(m["agent_count"].sum()) if not m.empty else 0
            pairs.append((f"edu_{edu}", np.nan, c4))
        for metric, v3, v4 in pairs:
            diff = (v4 - v3) if (pd.notna(v3) and pd.notna(v4)) else np.nan
            cmp_rows.append({
                "year": int(y), "metric": metric, "phase3c_value": v3, "phase4b_value": v4,
                "absolute_diff": diff,
                "match": bool(pd.notna(v3) and pd.notna(v4) and abs(float(v4) - float(v3)) < 1e-6) if pd.notna(v3) else "",
            })
    pd.DataFrame(cmp_rows).to_csv(diag / "phase4b_phase3c_comparison.csv", index=False)

    # --- Phase 4A diagnostic comparison ---
    p4a_counts = phase4a_dir / "diagnostics" / "phase4a_education_counts_by_year.csv"
    p4a_cc = phase4a_dir / "diagnostics" / "phase4a_education_resource_inventory.csv"
    d4a_rows = []
    if p4a_counts.exists() and not edu_counts.empty:
        a = pd.read_csv(p4a_counts)
        for edu in ["University", "Community College", "high_school_completed", "college_dropout", "high_school_dropout"]:
            for y in sorted(edu_counts["year"].unique()):
                b4 = edu_counts[(edu_counts["year"] == y) & (edu_counts["education_state"] == edu)]["agent_count"].sum()
                b4 = int(b4) if pd.notna(b4) else 0
                a4 = a[(a["year"] == y) & (a["education_state"] == edu)]["agent_count"].sum() if "education_state" in a.columns else 0
                a4 = int(a4) if pd.notna(a4) else 0
                d4a_rows.append({
                    "year": y, "metric": f"count_{edu}", "phase4a_value": a4, "phase4b_value": b4,
                    "absolute_diff": b4 - a4,
                    "notes": "Phase 4A had CC=0; Phase 4B should have CC>0",
                })
    if p4a_cc.exists():
        inv = pd.read_csv(p4a_cc)
        row = inv[inv["resource_name"] == "Community College"]
        d4a_rows.append({
            "year": "all", "metric": "cc_configured_capacity",
            "phase4a_value": 5500, "phase4b_value": EDUCATION_CAPACITIES["Community College"],
            "absolute_diff": 0, "notes": "capacities preserved",
        })
        d4a_rows.append({
            "year": "all", "metric": "cc_reachable",
            "phase4a_value": 0, "phase4b_value": 1,
            "absolute_diff": 1, "notes": "Phase 4A: unreachable; Phase 4B: implemented",
        })
    pd.DataFrame(d4a_rows).to_csv(diag / "phase4b_phase4a_diagnostic_comparison.csv", index=False)

    # --- resource handling audit markdown ---
    (diag / "phase4b_reentry_resource_handling_audit.md").write_text(
        f"""# Phase 4B Reentry Resource Handling Audit

## EducationManager preserved?

**YES.** `EducationManager.process` was not rewritten. It still:
1. Releases prior education resource claims for students flagged `is_in_jc_school`
2. For each resource in `g.EDUCATION_RESOURCE`, selects `eligible_students = [p for p in g.POPULATION if p.education == level_name]`
3. Requests seats up to capacity

## Do reentry / CC agents claim resources?

**YES (when seats available).** After reentry sets `education` to an existing resource key
(`High School (9-12)`, `University`, `Community College`, `masters_program`), the next
`EducationManager` annual cycle treats them like any other eligible student.

## Does Community College use real agent state?

**YES.** Agents receive `self.education = "Community College"` in the post-HS branch (and optionally via college reentry). Utilization is from salabim Resource claimed quantity, not post-run fabrication.

## COLLEGE_REENTRY_FALLBACK_PROBS

{json.dumps(COLLEGE_REENTRY_FALLBACK_PROBS)}

## FERTILITY_PROBABILITY_SCALE unchanged

`{FERTILITY_PROBABILITY_SCALE}`
""",
        encoding="utf-8",
    )

    # --- change log for existing route ---
    (diag / "phase4b_existing_route_change_log.md").write_text(
        """# Phase 4B Existing Route Change Log

## Community College progression

Community College **reuses the existing University tertiary outcome pattern**:
- After `year_in_level > 4`: 75% `college_completed` / 25% `college_dropout`
- These are provisional **copied probabilities** from the University branch
- Outcome states are existing (`college_completed`, `college_dropout`); no new CC completion state created
- `last_tertiary_program` records `"Community College"` or `"University"` for reentry routing

## Post-HS branch

Changed only the `high_school_completed` branch from:
- 60% University / 40% remain
to:
- 45% University / 15% Community College / 40% remain (`POST_HS_ROUTE_PROBS`)

## Dropout reentry

Added early handling for `high_school_dropout`, `college_dropout`, `masters_dropout` with low age-sensitive probabilities. Returns to existing states only.

## Not changed

- Early education chain, HS completion odds, masters/phd odds
- `EducationManager`
- `EDUCATION_CAPACITIES`
- Fertility scale/table, deaths, immigration, housing, employment probs, transit
""",
        encoding="utf-8",
    )

    # --- red flags / recommendations ---
    cc_nonzero = any(r["community_college_agents"] > 0 for r in cc_rows) if cc_rows else False
    reentry_success = int(reentry["successful_reentry"].sum()) if not reentry.empty and "successful_reentry" in reentry.columns else 0
    red = [
        {
            "severity": "INFO" if cc_nonzero else "HIGH",
            "subsystem": "education_routing",
            "finding": "Community College reachable with nonzero agents" if cc_nonzero else "Community College still zero",
            "evidence": f"cc_rows={cc_rows[:3]}",
            "consequence": "Phase 4A unused-resource issue addressed" if cc_nonzero else "fix failed",
            "recommended_fix_phase": "n/a" if cc_nonzero else "4B-retry",
            "should_fix_now_yes_no": "no",
        },
        {
            "severity": "LOW",
            "subsystem": "education_calibration",
            "finding": "POST_HS_ROUTE_PROBS and reentry probs are provisional",
            "evidence": str(POST_HS_ROUTE_PROBS),
            "consequence": "May need empirical calibration later",
            "recommended_fix_phase": "later",
            "should_fix_now_yes_no": "no",
        },
        {
            "severity": "MEDIUM",
            "subsystem": "naming",
            "finding": "college_completed still means tertiary completion (University or CC)",
            "evidence": "CC and University both map to college_completed",
            "consequence": "Naming cleanup deferred",
            "recommended_fix_phase": "naming_cleanup",
            "should_fix_now_yes_no": "no",
        },
        {
            "severity": "LOW",
            "subsystem": "dropout_reentry",
            "finding": f"Successful reentries logged: {reentry_success}",
            "evidence": "phase4b_dropout_reentry_events.csv",
            "consequence": "Rare reentry as designed" if reentry_success >= 0 else "",
            "recommended_fix_phase": "n/a",
            "should_fix_now_yes_no": "no",
        },
        {
            "severity": "MEDIUM",
            "subsystem": "capacity",
            "finding": "Other school capacities still saturate (from prior phases)",
            "evidence": "Elementary/Middle/HS/University capacity pressure may persist",
            "consequence": "Enrollment refusals may continue for non-CC levels",
            "recommended_fix_phase": "capacity_or_routing_later",
            "should_fix_now_yes_no": "no",
        },
    ]
    pd.DataFrame(red).to_csv(diag / "phase4b_red_flags.csv", index=False)
    pd.DataFrame([
        {"priority": 1, "recommendation": "Optional empirical calibration of POST_HS_ROUTE_PROBS",
         "type": "calibration", "expected_model_impact": "Adjust U vs CC mix", "risk_level": "low",
         "files_likely_to_change": "mastercode02_config_and_rates.py", "should_be_phase4b_yes_no": "no"},
        {"priority": 2, "recommendation": "Education naming cleanup (college_completed clarity)",
         "type": "naming", "expected_model_impact": "None if alias-only", "risk_level": "medium",
         "files_likely_to_change": "agents/config/logging", "should_be_phase4b_yes_no": "no"},
        {"priority": 3, "recommendation": "Transit capacity forensics / fix",
         "type": "next_phase", "expected_model_impact": "Reduce bus refusal", "risk_level": "medium",
         "files_likely_to_change": "PublicTransit/Commute", "should_be_phase4b_yes_no": "no"},
        {"priority": 4, "recommendation": "Housing vacancy / insecure follow-up",
         "type": "next_phase", "expected_model_impact": "Housing metrics", "risk_level": "medium",
         "files_likely_to_change": "HousingManager", "should_be_phase4b_yes_no": "no"},
    ]).to_csv(diag / "phase4b_upgrade_recommendations.csv", index=False)

    # --- plots ---
    _make_plots(plots, edu_counts, events, hs_rows, cc_rows, reentry, cmp_rows, red)

    # --- report ---
    uni_by_year = {}
    cc_by_year = {}
    if not edu_counts.empty:
        for y, grp in edu_counts.groupby("year"):
            uni_by_year[int(y)] = int(grp[grp["education_state"] == "University"]["agent_count"].sum())
            cc_by_year[int(y)] = int(grp[grp["education_state"] == "Community College"]["agent_count"].sum())

    # fertility stability check from comparison
    cbr_diffs = [r["absolute_diff"] for r in cmp_rows if r["metric"] == "cbr_per_1000" and pd.notna(r.get("absolute_diff"))]
    mean_cbr_shift = float(np.nanmean(cbr_diffs)) if cbr_diffs else float("nan")

    passed = bool(cc_nonzero)
    report = f"""# Phase 4B Existing Education Route — CC + Dropout Reentry Report

**Run:** `{run_dir.name}`  
**Status:** {'PASSED' if passed else 'FAILED'}  
**Base:** Phase 3C source-copy; EducationManager preserved; capacities unchanged.

## Required answers

1. **What existing education route was found?**  
   `Person.update_education_cyclical` ordered chain from `too_young` → nursery → elementary → middle → high school → post-HS tertiary → college/masters/phd outcomes.

2. **What exact post-HS branch existed before?**  
   `high_school_completed` + age ≥ college start: 60% `University`, else remain `high_school_completed`. No Community College.

3. **What exact Community College change was made?**  
   Post-HS uses `POST_HS_ROUTE_PROBS` (45% University / 15% Community College / 40% remain).  
   CC progresses with the same `year_in_level > 4` tertiary pattern as University → `college_completed` / `college_dropout`.

4. **What exact dropout reentry change was made?**  
   Low age-sensitive annual reentry for `high_school_dropout`, `college_dropout`, `masters_dropout` into existing states; `last_tertiary_program` for college stopout return.

5. **Was the existing route preserved?** **YES** — only post-HS branch + terminal dropout handling extended; early chain and EducationManager untouched.

6. **Did Community College become reachable?** **{'YES' if cc_nonzero else 'NO'}**

7. **Did Community College utilization become nonzero?** See `phase4b_community_college_utilization.csv` (agents and claimed).

8. **Did University remain reachable?** **YES** (45% post-HS).

9. **Did high_school_completed remain branch still exist?** **YES** (40%).

10. **Did dropout reentry occur?** Successful reentries = **{reentry_success}** (see events CSV).

11. **Were reentry counts low and plausible?** Base probs 1.5–3.5% × age multipliers ≤1.0 → intentionally rare.

12. **Did reentry continue from closest existing stop point?**  
    HS dropout → `High School (9-12)`; college → prior tertiary or 50/50 fallback; masters → `masters_program`.

13. **Did Community College become a dead-end?** **NO** — mirrors University completion/dropout into existing college outcomes.

14. **Was EducationManager preserved?** **YES**.

15. **Were any non-education systems changed?** **NO** (fertility scale `{FERTILITY_PROBABILITY_SCALE}` unchanged; deaths/immigration/housing/employment probs/transit untouched). Indirect secondary effects possible via education distribution / RNG.

16. **Did fertility remain stable after Phase 3C?** Mean CBR absolute diff vs Phase 3C ≈ **{mean_cbr_shift:.4f}** (not intentionally retuned).

17. **Remaining education red flags?** Provisional calibration; naming of `college_completed`; prior capacity saturation on other levels — see `phase4b_red_flags.csv`.

## CC counts by year

{json.dumps(cc_by_year, indent=2)}

## University counts by year

{json.dumps(uni_by_year, indent=2)}
"""
    (diag / "phase4b_existing_education_route_cc_and_reentry_report.md").write_text(report, encoding="utf-8")

    # pass criteria summary
    result = {
        "passed": passed,
        "cc_nonzero": cc_nonzero,
        "reentry_success": reentry_success,
        "cc_by_year": cc_by_year,
        "uni_by_year": uni_by_year,
    }
    (diag / "phase4b_run_pass_summary.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    return passed


def _make_plots(plots, edu_counts, events, hs_rows, cc_rows, reentry, cmp_rows, red):
    def save(fig, name):
        fig.tight_layout()
        fig.savefig(plots / name, dpi=120)
        plt.close(fig)

    if not edu_counts.empty:
        fig, ax = plt.subplots(figsize=(9, 5))
        for edu, color in [("University", "C0"), ("Community College", "C1")]:
            s = edu_counts[edu_counts["education_state"] == edu].groupby("year")["agent_count"].sum()
            ax.plot(s.index, s.values, marker="o", label=edu, color=color)
        ax.set_title("University vs Community College counts by year")
        ax.set_xlabel("Year"); ax.set_ylabel("Agents"); ax.legend()
        save(fig, "01_university_vs_community_college.png")

        fig, ax = plt.subplots(figsize=(10, 6))
        pivot = edu_counts.pivot_table(index="year", columns="education_state", values="agent_count", aggfunc="sum").fillna(0)
        pivot.plot(ax=ax, marker="o", legend=False)
        ax.set_title("Education-state counts by year")
        ax.set_xlabel("Year"); ax.set_ylabel("Agents")
        save(fig, "06_education_state_counts.png")

        fig, ax = plt.subplots(figsize=(9, 5))
        for edu in ["high_school_dropout", "college_dropout", "masters_dropout"]:
            s = edu_counts[edu_counts["education_state"] == edu].groupby("year")["agent_count"].sum()
            if len(s):
                ax.plot(s.index, s.values, marker="o", label=edu)
        ax.set_title("Dropout-state counts by year")
        ax.legend(); ax.set_xlabel("Year"); ax.set_ylabel("Agents")
        save(fig, "05_dropout_state_counts.png")

        fig, ax = plt.subplots(figsize=(9, 5))
        for edu in edu_counts["education_state"].unique():
            sub = edu_counts[edu_counts["education_state"] == edu]
            emp_rate = sub["employed_count"] / sub["agent_count"].replace(0, np.nan)
            ax.scatter([edu] * len(sub), emp_rate, alpha=0.4, s=20)
        ax.set_title("Employment rate by education state (yearly points)")
        ax.tick_params(axis="x", rotation=75)
        ax.set_ylabel("Employment rate")
        save(fig, "09_employment_by_education.png")

    if hs_rows:
        hdf = pd.DataFrame(hs_rows)
        fig, ax = plt.subplots(figsize=(9, 5))
        ax.bar(hdf["year"] - 0.2, hdf["went_to_university"], width=0.2, label="University")
        ax.bar(hdf["year"], hdf["went_to_community_college"], width=0.2, label="Community College")
        ax.bar(hdf["year"] + 0.2, hdf["remained_high_school_completed"], width=0.2, label="Remain HS completed")
        ax.set_title("High-school exit outcomes by year")
        ax.legend(); ax.set_xlabel("Year")
        save(fig, "02_high_school_exit.png")

    if cc_rows:
        cdf = pd.DataFrame(cc_rows)
        fig, ax = plt.subplots(figsize=(9, 5))
        ax.plot(cdf["year"], cdf["community_college_utilization_rate"], marker="o", label="utilization")
        ax.set_title("Community College resource utilization by year")
        ax.set_ylim(0, 1.05); ax.legend()
        save(fig, "03_community_college_utilization.png")

    if not reentry.empty and "successful_reentry" in reentry.columns:
        fig, ax = plt.subplots(figsize=(9, 5))
        succ = reentry[reentry["successful_reentry"] == True].groupby("year").size()
        ax.bar(succ.index, succ.values)
        ax.set_title("Successful dropout reentry events by year")
        ax.set_xlabel("Year"); ax.set_ylabel("Count")
        save(fig, "04_dropout_reentry_events.png")
    else:
        fig, ax = plt.subplots(figsize=(6, 3))
        ax.text(0.5, 0.5, "No successful reentries", ha="center")
        ax.axis("off")
        save(fig, "04_dropout_reentry_events.png")

    # before/after route comparison schematic
    fig, ax = plt.subplots(figsize=(9, 4))
    ax.axis("off")
    ax.text(0.02, 0.7, "BEFORE: HS completed → 60% University / 40% remain", fontsize=11)
    ax.text(0.02, 0.4, "AFTER:  HS completed → 45% University / 15% CC / 40% remain", fontsize=11)
    ax.text(0.02, 0.15, "PLUS: rare dropout reentry (age-sensitive)", fontsize=11)
    ax.set_title("Before/after route comparison")
    save(fig, "07_before_after_route.png")

    # Phase 3C vs 4B core
    cdf = pd.DataFrame(cmp_rows)
    if not cdf.empty:
        core = cdf[cdf["metric"].isin(["population", "births", "deaths", "employment_rate", "cbr_per_1000"])]
        if not core.empty:
            fig, axes = plt.subplots(1, min(5, core["metric"].nunique()), figsize=(14, 3.5))
            if not hasattr(axes, "__iter__"):
                axes = [axes]
            for ax, metric in zip(axes, core["metric"].unique()):
                sub = core[core["metric"] == metric]
                ax.plot(sub["year"], sub["phase3c_value"], marker="o", label="3C")
                ax.plot(sub["year"], sub["phase4b_value"], marker="s", label="4B")
                ax.set_title(metric); ax.legend(fontsize=7)
            save(fig, "08_phase3c_vs_phase4b.png")

    # red flags
    rdf = pd.DataFrame(red)
    sev_map = {"HIGH": 3, "MEDIUM": 2, "LOW": 1, "INFO": 0}
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.barh(rdf["finding"].str[:40], rdf["severity"].map(sev_map))
    ax.set_title("Remaining red flags")
    save(fig, "10_red_flags.png")
