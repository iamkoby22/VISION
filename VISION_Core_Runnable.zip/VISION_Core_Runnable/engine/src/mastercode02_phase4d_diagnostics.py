"""Phase 4D diagnostics — education resource release observation only."""
from __future__ import annotations

from collections import defaultdict

import mastercode02_globals as g
from mastercode02_config_and_rates import EDUCATION_CAPACITIES

PHASE4D_LOG: dict = {
    "release_events": [],
    "death_release_events": [],
    "resource_consistency": [],
    "stale_claims": [],
    "education_counts": [],
    "entry_exits": [],
}


def record_education_release(**kwargs):
    PHASE4D_LOG["release_events"].append(dict(kwargs))


def record_death_education_release(**kwargs):
    PHASE4D_LOG["death_release_events"].append(dict(kwargs))


def wrap_update_education_cyclical(PersonClass) -> None:
    """Observe tertiary leave transitions for Uni/CC audit flows (no logic change)."""
    original = PersonClass.update_education_cyclical

    def wrapped(self):
        before = self.education
        original(self)
        after = self.education
        if before != after:
            PHASE4D_LOG["entry_exits"].append({
                "year": int(self.env.now()) if self.env is not None else -1,
                "before": before,
                "after": after,
            })

    PersonClass.update_education_cyclical = wrapped


def snapshot_yearly_phase4d(year: int) -> None:
    pop = list(g.POPULATION)
    by_edu = defaultdict(list)
    for p in pop:
        by_edu[str(p.education)].append(p)

    for edu, agents in by_edu.items():
        PHASE4D_LOG["education_counts"].append({
            "year": year,
            "education_state": edu,
            "agent_count": len(agents),
        })

    for name, res in g.EDUCATION_RESOURCE.items():
        try:
            claimed = int(res.claimed_quantity())
            cap = int(res.capacity())
        except Exception:
            claimed, cap = 0, int(EDUCATION_CAPACITIES.get(name, 0))
        active = len(by_edu.get(name, []))
        holders = 0
        holders_mismatch = 0
        for p in pop:
            try:
                if res in p.claimed_resources():
                    holders += 1
                    if p.education != name:
                        holders_mismatch += 1
            except Exception:
                pass
        avail = max(0, cap - claimed)
        util = (claimed / cap) if cap else 0.0
        if abs(active - claimed) <= 1 and holders_mismatch == 0:
            status = "consistent"
        elif claimed > active + 5 or holders_mismatch > 5:
            status = "claimed_exceeds_active_or_stale_holders"
        elif active > claimed + 5:
            status = "active_exceeds_claimed"
        else:
            status = "minor_mismatch"

        PHASE4D_LOG["resource_consistency"].append({
            "year": year,
            "resource_name": name,
            "matching_education_state": name,
            "active_agent_count": active,
            "resource_capacity": cap,
            "resource_claimed": claimed,
            "resource_available": avail,
            "utilization_rate": util,
            "active_minus_claimed": active - claimed,
            "claimed_minus_active": claimed - active,
            "consistency_status": status,
            "notes": f"holders_mismatch={holders_mismatch}",
        })
        PHASE4D_LOG["stale_claims"].append({
            "year": year,
            "resource_name": name,
            "stale_claim_holder_count": holders_mismatch,
            "active_matching_state_count": active,
            "claimed_count": claimed,
            "stale_claim_rate": (holders_mismatch / claimed) if claimed else 0.0,
            "notes": "stale = holders whose education != resource name",
        })
