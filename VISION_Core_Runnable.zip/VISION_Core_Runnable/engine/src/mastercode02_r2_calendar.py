# mastercode02_r2_calendar.py
# R2 (Observability and Validation Infrastructure). Purely a lookup helper --
# no state, no RNG, no side effects. Freezes the simulation_year -> calendar_year
# mapping already established as authoritative in Phase V1
# (RESSEARCH/21_PHASE_V1_VALIDATION_FORENSICS/06_phase_v1_calendar_alignment_register.csv)
# and reused by R1 (RESSEARCH/24_PHASE_R1_CORRECTION_CONTRACT/09_r1_arima_scientific_contract.md):
# T0 = calendar year 2000, simulation_year t -> calendar_year 2000 + t.
#
# This module does not change when or how any existing code calls
# self.env.now() -- it only gives new R2 logging code one single, explicit,
# non-ambiguous place to convert a simulation_year into a calendar_year,
# instead of each new logging call site re-deriving (or worse, silently
# assuming) the offset.

T0_CALENDAR_YEAR = 2000

# The canonical corrected historical-evaluation endpoint per Phase V1/V3 is
# calendar 2023 -> simulation_year 23 under the T0=2000 convention above.
CANONICAL_2023_SIMULATION_YEAR = 2023 - T0_CALENDAR_YEAR


def calendar_year_for(simulation_year):
    """Pure function: simulation_year (int, 0-based from T0) -> calendar_year (int)."""
    return T0_CALENDAR_YEAR + int(simulation_year)


def simulation_year_for(calendar_year):
    """Inverse of calendar_year_for. Pure function, no side effects."""
    return int(calendar_year) - T0_CALENDAR_YEAR


def is_canonical_2023(simulation_year):
    """True exactly when simulation_year corresponds to calendar 2023."""
    return int(simulation_year) == CANONICAL_2023_SIMULATION_YEAR
