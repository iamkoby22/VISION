#!/usr/bin/env python
"""Phase 9D-CO: validate config/rates override JSON against the approved contract.

Does not import or mutate model source. Used by the CLI runner and the backend.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from copy import deepcopy
from pathlib import Path
from typing import Any

# Groups confirmed SAFE in Subphase A forensics (see diagnostics/phase9d_co_override_safety_matrix.csv).
SAFE_SCALAR_KEYS = frozenset({
    "SIMULATION_DURATION",
    "FERTILITY_PROBABILITY_SCALE",
    "BANK_SAVINGS_ANNUAL_CAPACITY",
    "BANK_LOAN_ANNUAL_CAPACITY",
    "GOVERNMENT_SPENDING_ANNUAL_CAP",
    "RENTER_TO_OWNER_ENABLED",
    "RENTER_TO_OWNER_ANNUAL_PROBABILITY",
    "RENTER_TO_OWNER_MAX_ANNUAL_RATE",
    "RENTER_TO_OWNER_REQUIRE_AVAILABLE_FOR_SALE",
    "RENTER_TO_OWNER_REQUIRE_LEDGER_RENTAL_CLAIM",
    # R11: city-specific vital-rate calibration scalars (Fable Calibration v1.1).
    # See mastercode02_config_and_rates.py for the default-1.0/no-op guarantee.
    "BIRTH_RATE_MODIFIER",
    "DEATH_RATE_MODIFIER",
    "MARRIAGE_RATE_MODIFIER",
    # R6.1 Gate G correction: explicit scenario discriminator (see
    # mastercode02_config_and_rates.py). Must be settable through the same
    # --config-overrides-json path as every other scenario-scoped field, or
    # the registration contract in run_mastercode02.py has no way to be
    # driven per-scenario without editing source.
    "CITY_ID",
    "PEP_STRUCTURAL_MIGRATION_ENABLED",
    # R7.10: same convention as PEP_STRUCTURAL_MIGRATION_ENABLED -- default-off scalar switch for
    # mastercode02_residual_migration.py.
    "RESIDUAL_MIGRATION_ENABLED",
})

SAFE_DICT_KEYS = frozenset({
    "IMMIGRATION_CONFIG",
    "GOV_SUPPORT_CONFIG",
    "HOUSING_STOCK",
    "HOUSING_MARKET_TARGETS",
    "RATES",
    "HISTORICAL_MACRO_DATA",
    "HISTORICAL_ECONOMIC_DATA",
    "ROAD_NETWORK_CAPACITY",
    "EMPLOYERS",
    "EDUCATION_CAPACITIES",
    "POST_HS_ROUTE_PROBS",
    "INCOME_BANDS",
    "PUBLIC_TRANSIT_CONFIG",
    "CAR_AFFORDABILITY",
    "COST_GRID",
    "COMMUTATION_PURPOSE_RATES",
})

SAFE_LIST_KEYS = frozenset({
    "EMPLOYER_PROBS",
    "SKILL_LEVELS",
    "COMMUTATION_PURPOSES",
})

ALLOWED_TOP_LEVEL = SAFE_SCALAR_KEYS | SAFE_DICT_KEYS | SAFE_LIST_KEYS

# Explicitly blocked (must never be accepted even if someone tries).
BLOCKED_KEYS = frozenset({
    "TENURE_PROBABILITY_MATRIX",  # tuple keys, not JSON-safe
    "RENTER_TO_OWNER_MODE",       # unused / unknown
    "DATA",                       # t=0 generator
    "generator_DATA",
    "t0",
    "t0_DATA",
    "INITIAL_POPULATION_DATA",
})

PROBABILITY_SUM_TOL = 1e-6

CAPACITY_PATH_HINTS = (
    "capacity",
    "CAPACITY",
    "ANNUAL_CAPACITY",
    "ANNUAL_CAP",
    "initial_buses",
    "bus_capacity",
    "trips_per_bus_per_day",
    "ROAD_NETWORK_CAPACITY",
)


class ConfigOverrideValidationError(ValueError):
    def __init__(self, errors: list[str]):
        self.errors = errors
        super().__init__("; ".join(errors) if errors else "validation failed")


def _is_finite_number(v: Any) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(float(v))


def _check_probability(path: str, v: Any, errors: list[str]) -> None:
    if not _is_finite_number(v):
        errors.append(f"{path}: probability must be a finite number, got {type(v).__name__}")
        return
    if float(v) < 0.0 or float(v) > 1.0:
        errors.append(f"{path}: probability must be in [0, 1], got {v}")


def _check_nonneg_capacity(path: str, v: Any, errors: list[str]) -> None:
    if not _is_finite_number(v):
        errors.append(f"{path}: capacity must be a finite number, got {type(v).__name__}")
        return
    if float(v) < 0:
        errors.append(f"{path}: capacity must be >= 0, got {v}")


def _looks_like_capacity_key(key: str) -> bool:
    k = key.lower()
    return any(h.lower() in k for h in CAPACITY_PATH_HINTS) or k in {
        "capacity", "base_annual_rate", "initial_buses", "bus_capacity",
        "trips_per_bus_per_day", "single_parent_support", "food_stamp_per_child",
    }


def _validate_leaf(path: str, key: str, value: Any, errors: list[str]) -> None:
    if value is None:
        errors.append(f"{path}: null is not allowed")
        return
    if isinstance(value, bool):
        return  # bool scalars OK where expected
    if isinstance(value, (int, float)):
        if not math.isfinite(float(value)):
            errors.append(f"{path}: non-finite number")
            return
        kl = key.lower()
        if "prob" in kl or "rate" in kl and "mortality" not in kl and "historical" not in path.lower():
            # Soft: rates in RATES tables are probabilities; HISTORICAL series are not [0,1]
            if "RATES" in path or "PROB" in path.upper() or kl.endswith("_probability") or kl.endswith("_rate") and "annual_rate" in kl:
                if "RATES" in path or "ROUTE_PROBS" in path or "PROBABILITY" in path.upper() or "education_distribution" in path or "POST_HS" in path:
                    _check_probability(path, value, errors)
        if _looks_like_capacity_key(key) or any(c in path for c in ("CAPACITY", "capacity", "ANNUAL_CAP")):
            if float(value) < 0:
                errors.append(f"{path}: negative capacity/cap not allowed ({value})")
        return
    if isinstance(value, str):
        return
    if isinstance(value, list):
        for i, item in enumerate(value):
            if isinstance(item, (dict, list)):
                _walk(f"{path}[{i}]", item, errors)
            elif isinstance(item, (int, float)) and not isinstance(item, bool):
                if not math.isfinite(float(item)):
                    errors.append(f"{path}[{i}]: non-finite number")
            elif item is None:
                errors.append(f"{path}[{i}]: null is not allowed")
        return
    if isinstance(value, dict):
        _walk(path, value, errors)
        return
    errors.append(f"{path}: unsupported value type {type(value).__name__}")


def _walk(path: str, obj: Any, errors: list[str]) -> None:
    if isinstance(obj, dict):
        for k, v in obj.items():
            if not isinstance(k, str):
                errors.append(f"{path}: non-string key {k!r}")
                continue
            child = f"{path}.{k}" if path else k
            _validate_leaf(child, k, v, errors)
    elif isinstance(obj, list):
        _validate_leaf(path or "[]", path.split(".")[-1] if path else "", obj, errors)


def _validate_structured(overrides: dict, errors: list[str]) -> None:
    if "SIMULATION_DURATION" in overrides:
        v = overrides["SIMULATION_DURATION"]
        if not isinstance(v, int) or isinstance(v, bool) or v < 1:
            errors.append("SIMULATION_DURATION: must be an integer >= 1")

    if "FERTILITY_PROBABILITY_SCALE" in overrides:
        v = overrides["FERTILITY_PROBABILITY_SCALE"]
        if not _is_finite_number(v) or float(v) < 0:
            errors.append("FERTILITY_PROBABILITY_SCALE: must be a finite number >= 0")

    for cap_key in ("BANK_SAVINGS_ANNUAL_CAPACITY", "BANK_LOAN_ANNUAL_CAPACITY",
                    "GOVERNMENT_SPENDING_ANNUAL_CAP"):
        if cap_key in overrides:
            _check_nonneg_capacity(cap_key, overrides[cap_key], errors)

    if "RENTER_TO_OWNER_ANNUAL_PROBABILITY" in overrides:
        _check_probability("RENTER_TO_OWNER_ANNUAL_PROBABILITY",
                           overrides["RENTER_TO_OWNER_ANNUAL_PROBABILITY"], errors)
    if "RENTER_TO_OWNER_MAX_ANNUAL_RATE" in overrides:
        _check_probability("RENTER_TO_OWNER_MAX_ANNUAL_RATE",
                           overrides["RENTER_TO_OWNER_MAX_ANNUAL_RATE"], errors)
    for bkey in ("RENTER_TO_OWNER_ENABLED", "RENTER_TO_OWNER_REQUIRE_AVAILABLE_FOR_SALE",
                 "RENTER_TO_OWNER_REQUIRE_LEDGER_RENTAL_CLAIM"):
        if bkey in overrides and not isinstance(overrides[bkey], bool):
            errors.append(f"{bkey}: must be a boolean")

    if "PEP_STRUCTURAL_MIGRATION_ENABLED" in overrides and not isinstance(
            overrides["PEP_STRUCTURAL_MIGRATION_ENABLED"], bool):
        errors.append("PEP_STRUCTURAL_MIGRATION_ENABLED: must be a boolean")
    if "RESIDUAL_MIGRATION_ENABLED" in overrides and not isinstance(
            overrides["RESIDUAL_MIGRATION_ENABLED"], bool):
        errors.append("RESIDUAL_MIGRATION_ENABLED: must be a boolean")
    if "CITY_ID" in overrides and not isinstance(overrides["CITY_ID"], str):
        errors.append("CITY_ID: must be a string")

    if "POST_HS_ROUTE_PROBS" in overrides:
        probs = overrides["POST_HS_ROUTE_PROBS"]
        if not isinstance(probs, dict):
            errors.append("POST_HS_ROUTE_PROBS: must be an object")
        else:
            for k, v in probs.items():
                _check_probability(f"POST_HS_ROUTE_PROBS.{k}", v, errors)
            # If full replacement of known keys, require sum≈1; for partial, skip sum
            if set(probs.keys()) >= {"University", "Community College", "Remain high_school_completed"}:
                s = sum(float(probs[k]) for k in ("University", "Community College",
                                                   "Remain high_school_completed"))
                if abs(s - 1.0) > PROBABILITY_SUM_TOL:
                    errors.append(f"POST_HS_ROUTE_PROBS: values must sum to 1.0, got {s}")

    if "EMPLOYER_PROBS" in overrides:
        probs = overrides["EMPLOYER_PROBS"]
        if not isinstance(probs, list):
            errors.append("EMPLOYER_PROBS: must be an array")
        else:
            for i, v in enumerate(probs):
                _check_probability(f"EMPLOYER_PROBS[{i}]", v, errors)
            if probs:
                s = sum(float(x) for x in probs)
                if abs(s - 1.0) > PROBABILITY_SUM_TOL:
                    errors.append(f"EMPLOYER_PROBS: values must sum to 1.0, got {s}")

    if "COMMUTATION_PURPOSE_RATES" in overrides:
        rates = overrides["COMMUTATION_PURPOSE_RATES"]
        if not isinstance(rates, dict):
            errors.append("COMMUTATION_PURPOSE_RATES: must be an object")
        else:
            for band, vec in rates.items():
                if not isinstance(vec, list):
                    errors.append(f"COMMUTATION_PURPOSE_RATES.{band}: must be an array")
                    continue
                for i, v in enumerate(vec):
                    _check_probability(f"COMMUTATION_PURPOSE_RATES.{band}[{i}]", v, errors)
                if len(vec) == 7:
                    s = sum(float(x) for x in vec)
                    if abs(s - 1.0) > PROBABILITY_SUM_TOL:
                        errors.append(
                            f"COMMUTATION_PURPOSE_RATES.{band}: length-7 vector must sum to 1.0, got {s}")

    if "EDUCATION_CAPACITIES" in overrides:
        caps = overrides["EDUCATION_CAPACITIES"]
        if not isinstance(caps, dict):
            errors.append("EDUCATION_CAPACITIES: must be an object")
        else:
            for k, v in caps.items():
                _check_nonneg_capacity(f"EDUCATION_CAPACITIES.{k}", v, errors)

    if "HOUSING_STOCK" in overrides:
        hs = overrides["HOUSING_STOCK"]
        if not isinstance(hs, dict):
            errors.append("HOUSING_STOCK: must be an object")
        else:
            for unit, fields in hs.items():
                if not isinstance(fields, dict):
                    errors.append(f"HOUSING_STOCK.{unit}: must be an object")
                    continue
                if "capacity" in fields:
                    _check_nonneg_capacity(f"HOUSING_STOCK.{unit}.capacity", fields["capacity"], errors)

    if "PUBLIC_TRANSIT_CONFIG" in overrides:
        ptc = overrides["PUBLIC_TRANSIT_CONFIG"]
        if not isinstance(ptc, dict):
            errors.append("PUBLIC_TRANSIT_CONFIG: must be an object")
        else:
            for k in ("initial_buses", "bus_capacity", "trips_per_bus_per_day", "initial_population"):
                if k in ptc:
                    _check_nonneg_capacity(f"PUBLIC_TRANSIT_CONFIG.{k}", ptc[k], errors)

    if "RATES" in overrides:
        rates = overrides["RATES"]
        if not isinstance(rates, dict):
            errors.append("RATES: must be an object")
        else:
            # All numeric leaves in RATES tables are probabilities in [0,1]
            def walk_rates(prefix: str, node: Any) -> None:
                if isinstance(node, dict):
                    for k, v in node.items():
                        walk_rates(f"{prefix}.{k}", v)
                elif isinstance(node, (int, float)) and not isinstance(node, bool):
                    _check_probability(prefix, node, errors)
                else:
                    errors.append(f"{prefix}: RATES leaves must be numbers")
            for section, body in rates.items():
                walk_rates(f"RATES.{section}", body)

    if "IMMIGRATION_CONFIG" in overrides:
        ic = overrides["IMMIGRATION_CONFIG"]
        if not isinstance(ic, dict):
            errors.append("IMMIGRATION_CONFIG: must be an object")
        else:
            if "base_annual_rate" in ic:
                _check_probability("IMMIGRATION_CONFIG.base_annual_rate", ic["base_annual_rate"], errors)
            if "education_distribution" in ic:
                ed = ic["education_distribution"]
                if not isinstance(ed, dict):
                    errors.append("IMMIGRATION_CONFIG.education_distribution: must be an object")
                else:
                    for k, v in ed.items():
                        _check_probability(f"IMMIGRATION_CONFIG.education_distribution.{k}", v, errors)
                    if ed:
                        s = sum(float(v) for v in ed.values())
                        if abs(s - 1.0) > PROBABILITY_SUM_TOL:
                            errors.append(
                                f"IMMIGRATION_CONFIG.education_distribution: must sum to 1.0, got {s}")


def validate_config_overrides(data: Any) -> dict:
    """Validate override payload. Returns a report dict. Raises on hard failure."""
    errors: list[str] = []
    if not isinstance(data, dict):
        raise ConfigOverrideValidationError(
            [f"override payload must be a JSON object, got {type(data).__name__}"])

    for key in data:
        if key in BLOCKED_KEYS or key.upper() in {k.upper() for k in BLOCKED_KEYS}:
            errors.append(
                f"{key}: blocked — t=0 DATA / tenure matrix / unused mode overrides are not "
                "allowed in Phase 9D-CO")
            continue
        if key not in ALLOWED_TOP_LEVEL:
            errors.append(
                f"{key}: unknown or unsupported top-level override key. "
                f"Allowed: {sorted(ALLOWED_TOP_LEVEL)}")

    # Reject nested DATA smuggling
    raw = json.dumps(data)
    if '"DATA"' in raw and "DATA" in data:
        errors.append("DATA: t=0 generator DATA override is not allowed this phase")

    _walk("", data, errors)
    _validate_structured(data, errors)

    # Deduplicate while preserving order
    seen = set()
    uniq = []
    for e in errors:
        if e not in seen:
            seen.add(e)
            uniq.append(e)

    report = {
        "valid": len(uniq) == 0,
        "errors": uniq,
        "n_top_level_keys": len(data),
        "top_level_keys": sorted(data.keys()),
        "allowed_top_level": sorted(ALLOWED_TOP_LEVEL),
        "blocked_keys_policy": sorted(BLOCKED_KEYS),
    }
    if uniq:
        raise ConfigOverrideValidationError(uniq)
    return report


def parse_and_validate(raw: str) -> tuple[dict, dict]:
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ConfigOverrideValidationError([f"malformed JSON: {exc}"]) from exc
    report = validate_config_overrides(data)
    return data, report


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="Validate Phase 9D-CO config override JSON")
    p.add_argument("--json", type=str, default=None, help="Inline JSON object")
    p.add_argument("--file", type=str, default=None, help="Path to JSON file")
    p.add_argument("--out-json", type=str, default=None, help="Write validation report")
    args = p.parse_args(argv)
    if args.json is None and args.file is None:
        print("Provide --json or --file", file=sys.stderr)
        return 2
    raw = args.json if args.json is not None else Path(args.file).read_text(encoding="utf-8")
    try:
        _, report = parse_and_validate(raw)
    except ConfigOverrideValidationError as exc:
        report = {"valid": False, "errors": exc.errors}
        if args.out_json:
            Path(args.out_json).write_text(json.dumps(report, indent=2), encoding="utf-8")
        print("INVALID")
        for e in exc.errors:
            print(f"  - {e}")
        return 2
    if args.out_json:
        Path(args.out_json).write_text(json.dumps(report, indent=2), encoding="utf-8")
    print("VALID")
    return 0


if __name__ == "__main__":
    sys.exit(main())
