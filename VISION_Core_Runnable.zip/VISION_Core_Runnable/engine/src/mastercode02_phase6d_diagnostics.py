"""Phase 6D diagnostics — observation only."""
from __future__ import annotations

import mastercode02_globals as g
from mastercode02_config_and_rates import HOUSING_STOCK
from mastercode02_housing_ledger import (
    stock_vacancy_snapshot,
    household_has_active_housing_claim,
    get_household_housing_claim,
    get_housing_active_claim_count,
    get_housing_capacity,
    get_housing_available_count,
)
from mastercode02_initial_tenure import PHASE6D_INIT_EVENTS


PHASE6D_LOG: dict = {
    "initial_summary": [],
    "active_by_year": [],
    "stock_vacancy": [],
    "consistency": [],
    "invariants": [],
    "_prior_hh_snap": {},
    "renter_to_owner_count": [],
}


def snapshot_yearly_phase6d(year: int, env=None) -> None:
    snap = stock_vacancy_snapshot()
    interp = (
        "stock_full_insecure_grows"
        if snap["total_housing_available"] <= 0
        else (
            "rental_full_forsale_slack"
            if snap["rental_available"] <= 0 and snap["for_sale_available"] > 0
            else "mixed_or_slack"
        )
    )
    PHASE6D_LOG["stock_vacancy"].append({
        "year": year, **snap,
        "interpretation": interp,
        "notes": "ledger-based vacancy",
    })

    renters = owners = insecure = empty = nonempty = 0
    for name, stock in HOUSING_STOCK.items():
        cap = get_housing_capacity(name)
        claimed = get_housing_active_claim_count(name)
        avail = get_housing_available_count(name)
        PHASE6D_LOG["active_by_year"].append({
            "year": year,
            "housing_unit_name": name,
            "housing_category": stock["type"],
            "tenure_type": "Rental" if stock["type"] == "Rental" else "For-Sale",
            "capacity": cap,
            "active_claims": claimed,
            "available": avail,
            "utilization_rate": claimed / cap if cap else 0.0,
            "vacancy_rate": avail / cap if cap else 0.0,
            "notes": "",
        })

    violations = {
        "claims_gt_capacity": [],
        "housed_without_ledger": [],
        "ledger_without_household": [],
        "insecure_with_claim": [],
        "empty_with_claim": [],
        "renter_nonsale_mismatch": [],
        "owner_nonrental_mismatch": [],
    }

    from mastercode02_housing_ledger import HOUSING_LEDGER_ACTIVE
    for hh_id in list(HOUSING_LEDGER_ACTIVE.keys()):
        if hh_id not in g.HOUSEHOLDS:
            violations["ledger_without_household"].append(hh_id)

    current_snap = {}
    for hh_id, hh in g.HOUSEHOLDS.items():
        members = hh.get("members", []) or []
        n = len(members)
        empty += 1 if n == 0 else 0
        nonempty += 0 if n == 0 else 1
        tenure = hh.get("tenure")
        unit = hh.get("housing_unit_name")
        has_claim = household_has_active_housing_claim(hh_id)
        claim = get_household_housing_claim(hh_id)
        ledger_unit = claim["housing_unit_name"] if claim else ""
        is_renter = tenure == "Renter"
        is_owner = tenure == "Owner"
        is_insecure = tenure == "Insecure"
        if is_renter:
            renters += 1
        elif is_owner:
            owners += 1
        elif is_insecure:
            insecure += 1

        tenure_matches = True
        if has_claim and claim:
            cat = claim.get("housing_category")
            if is_renter and cat != "Rental":
                tenure_matches = False
                violations["renter_nonsale_mismatch"].append(hh_id)
            if is_owner and cat != "For-Sale":
                tenure_matches = False
                violations["owner_nonrental_mismatch"].append(hh_id)

        if (is_renter or is_owner) and unit and not has_claim:
            violations["housed_without_ledger"].append(hh_id)
            cstat = "housed_label_without_ledger"
        elif is_insecure and has_claim:
            violations["insecure_with_claim"].append(hh_id)
            cstat = "insecure_with_active_claim"
        elif n == 0 and has_claim:
            violations["empty_with_claim"].append(hh_id)
            cstat = "empty_with_active_claim"
        elif has_claim and unit == ledger_unit:
            cstat = "ok"
        elif not has_claim and not unit:
            cstat = "ok_unhoused"
        else:
            cstat = "other"

        PHASE6D_LOG["consistency"].append({
            "year": year,
            "household_id": hh_id,
            "household_size": n,
            "is_empty": n == 0,
            "is_renter": is_renter,
            "is_owner": is_owner,
            "is_insecure": is_insecure,
            "housing_unit_name": unit or "",
            "has_active_ledger_claim": has_claim,
            "ledger_housing_unit_name": ledger_unit,
            "tenure_matches_unit": tenure_matches,
            "consistency_status": cstat,
            "notes": "",
        })

        current_snap[hh_id] = {
            "tenure": tenure,
            "status": (
                "empty" if n == 0 else (
                    "insecure" if is_insecure else (
                        "renter" if is_renter else ("owner" if is_owner else "unknown")
                    )
                )
            ),
        }

    for name in HOUSING_STOCK:
        if get_housing_active_claim_count(name) > get_housing_capacity(name):
            violations["claims_gt_capacity"].append(name)

    PHASE6D_LOG["initial_summary"].append({
        "year": year,
        "total_households": len(g.HOUSEHOLDS),
        "renter_households": renters,
        "owner_households": owners,
        "insecure_households": insecure,
        "rental_units_claimed": snap["rental_claimed"],
        "for_sale_units_claimed": snap["for_sale_claimed"],
        "rental_units_available": snap["rental_available"],
        "for_sale_units_available": snap["for_sale_available"],
        "empty_households": empty,
        "nonempty_households": nonempty,
        "notes": "Phase 6D init synthesis at year0" if year == 0 else "",
    })

    prior = PHASE6D_LOG["_prior_hh_snap"]
    r2o = 0
    if prior:
        for hid, after in current_snap.items():
            before = prior.get(hid, {"status": "absent"})
            if before.get("status") == "renter" and after.get("status") == "owner":
                r2o += 1
    PHASE6D_LOG["renter_to_owner_count"].append({"year": year, "renter_to_owner_transitions": r2o})
    PHASE6D_LOG["_prior_hh_snap"] = current_snap

    inv_specs = [
        ("no_unit_overcapacity", "claims_gt_capacity", "HIGH"),
        ("no_housed_without_ledger", "housed_without_ledger", "HIGH"),
        ("no_ledger_without_household", "ledger_without_household", "HIGH"),
        ("no_insecure_with_claim", "insecure_with_claim", "MEDIUM"),
        ("no_empty_with_claim", "empty_with_claim", "HIGH"),
        ("renter_maps_to_rental", "renter_nonsale_mismatch", "MEDIUM"),
        ("owner_maps_to_forsale", "owner_nonrental_mismatch", "MEDIUM"),
    ]
    for inv_name, key, sev in inv_specs:
        ids = violations[key]
        PHASE6D_LOG["invariants"].append({
            "year": year,
            "invariant_name": inv_name,
            "pass_fail": "PASS" if len(ids) == 0 else "FAIL",
            "violation_count": len(ids),
            "example_ids": ";".join(str(x) for x in ids[:8]),
            "severity": sev,
            "notes": "",
        })
