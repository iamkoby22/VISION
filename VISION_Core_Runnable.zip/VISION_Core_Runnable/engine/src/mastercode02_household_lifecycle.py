"""Phase 7A household lifecycle classification — READ-ONLY.

Distinguishes genuine housing insecurity (non-empty households with no active ledger claim)
from empty household shells (zero members, no claim). Uses the Phase 6B/6E housing ledger as
the authoritative source of active housing claims. Performs no state writes and no RNG draws.
"""
from __future__ import annotations

import mastercode02_globals as g
from mastercode02_housing_ledger import (
    household_has_active_housing_claim,
    get_household_housing_claim,
)

# Classification labels
HOUSED_NONEMPTY = "housed_nonempty"
GENUINE_INSECURE = "genuine_insecure_nonempty"
EMPTY_SHELL = "empty_shell"
INCONSISTENT_HOUSED_EMPTY = "inconsistent_housed_empty"
INCONSISTENT_INSECURE_WITH_CLAIM = "inconsistent_insecure_with_claim"
UNKNOWN = "unknown"


def classify_household_housing_status(household_id) -> str:
    """Return the household housing-status classification (ledger-based, read-only)."""
    hh = g.HOUSEHOLDS.get(household_id)
    if hh is None:
        return UNKNOWN
    members = hh.get("members", []) or []
    n = len(members)
    has_claim = household_has_active_housing_claim(household_id)
    label = hh.get("tenure")

    # Safety net: a claim held while labeled Insecure is a label inconsistency
    if has_claim and label == "Insecure":
        return INCONSISTENT_INSECURE_WITH_CLAIM
    if n == 0 and has_claim:
        return INCONSISTENT_HOUSED_EMPTY
    if n == 0 and not has_claim:
        return EMPTY_SHELL
    if n >= 1 and has_claim:
        return HOUSED_NONEMPTY
    # n >= 1 and not has_claim
    return GENUINE_INSECURE


def household_status_counts() -> dict:
    """Aggregate classification counts across all households (read-only)."""
    counts = {
        HOUSED_NONEMPTY: 0,
        GENUINE_INSECURE: 0,
        EMPTY_SHELL: 0,
        INCONSISTENT_HOUSED_EMPTY: 0,
        INCONSISTENT_INSECURE_WITH_CLAIM: 0,
        UNKNOWN: 0,
    }
    for hh_id in g.HOUSEHOLDS:
        counts[classify_household_housing_status(hh_id)] += 1
    return counts


def old_basis_insecure_count() -> int:
    """Legacy label-only insecure count (tenure == 'Insecure'), preserved for audit."""
    return len([h for h in g.HOUSEHOLDS.values() if h.get("tenure") == "Insecure"])
