"""Phase 7B diagnostics — per-year household lifecycle counts and invariants.

Runs after archival (which happens at the start of log_yearly_data). Read-only checks.
"""
from __future__ import annotations

import mastercode02_globals as g
from mastercode02_household_lifecycle import (
    household_status_counts, old_basis_insecure_count,
)
from mastercode02_household_archive import (
    ARCHIVED_HOUSEHOLDS, ARCHIVE_YEARLY, active_household_count, archived_household_count,
    count_active_empty_shells,
)
from mastercode02_housing_ledger import (
    household_has_active_housing_claim, stock_vacancy_snapshot,
)


PHASE7B_LOG: dict = {
    "counts": [],       # per-year counts
    "invariants": [],   # per-year invariant rows (1-5, intra-run)
    "stock": [],        # per-year ledger vacancy
}


def reset_phase7b_diagnostics() -> None:
    PHASE7B_LOG["counts"].clear()
    PHASE7B_LOG["invariants"].clear()
    PHASE7B_LOG["stock"].clear()


def snapshot_yearly_phase7b(year: int, env=None) -> None:
    sc = household_status_counts()
    genuine = sc["genuine_insecure_nonempty"]
    empty_total = sc["empty_shell"]
    active_hh = active_household_count()
    archived_hh = archived_household_count()
    active_empty = count_active_empty_shells()
    total_records = len(g.HOUSEHOLDS)
    archived_this_year = 0
    before = after = 0
    for row in ARCHIVE_YEARLY:
        if int(row["year"]) == int(year):
            archived_this_year = int(row["archived_this_year"])
            before = int(row["empty_shells_before"])
            after = int(row["empty_shells_after"])
    snap = stock_vacancy_snapshot()
    PHASE7B_LOG["stock"].append({"year": year, **snap})
    PHASE7B_LOG["counts"].append({
        "year": year,
        "active_households": active_hh,
        "archived_households_total": archived_hh,
        "archived_this_year": archived_this_year,
        "empty_shells_before_archive": before,
        "empty_shells_after_archive": after,
        "empty_shells_remaining_active": active_empty,
        "empty_shell_count_total": empty_total,
        "genuine_insecure_nonempty": genuine,
        "old_basis_insecure": old_basis_insecure_count(),
        "total_household_records_old_basis": total_records,
        "population": len(g.POPULATION),
    })

    # --- Invariants 1-5 (intra-run) ---
    referenced_ids = set()
    for p in g.POPULATION:
        hid = getattr(p, "household_id", None)
        if hid is not None:
            referenced_ids.add(hid)

    archived_with_members = []
    archived_with_claim = []
    living_ref_archived = []
    archived_that_are_genuine = []
    for hh_id in ARCHIVED_HOUSEHOLDS:
        hh = g.HOUSEHOLDS.get(hh_id)
        if hh is None:
            continue
        if len(hh.get("members", []) or []) != 0:
            archived_with_members.append(hh_id)
        if household_has_active_housing_claim(hh_id):
            archived_with_claim.append(hh_id)
        if hh_id in referenced_ids:
            living_ref_archived.append(hh_id)
    # genuine insecure must exclude archived (archived are empty -> not genuine by construction)
    # verify no archived id is classified genuine
    from mastercode02_household_lifecycle import classify_household_housing_status, GENUINE_INSECURE
    for hh_id in ARCHIVED_HOUSEHOLDS:
        if classify_household_housing_status(hh_id) == GENUINE_INSECURE:
            archived_that_are_genuine.append(hh_id)

    recon_ok = (active_hh + archived_hh) == total_records

    specs = [
        ("no_archived_with_members", archived_with_members, "HIGH"),
        ("no_archived_with_active_claim", archived_with_claim, "HIGH"),
        ("no_living_person_references_archived", living_ref_archived, "HIGH"),
        ("active_plus_archived_reconciles", [] if recon_ok else ["mismatch"], "HIGH"),
        ("genuine_insecure_excludes_archived", archived_that_are_genuine, "MEDIUM"),
    ]
    for name, ids, sev in specs:
        PHASE7B_LOG["invariants"].append({
            "year": year,
            "invariant_name": name,
            "pass_fail": "PASS" if len(ids) == 0 else "FAIL",
            "violation_count": len(ids),
            "example_ids": ";".join(str(x) for x in ids[:8]),
            "severity": sev,
            "notes": "",
        })
