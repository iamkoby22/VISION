"""Phase 8A post-run analysis — replay/contamination forensics (diagnostic-only).

Produces: state snapshots, Phase 7B reference comparison, same-process replay result,
hash + content comparisons, state leakage audit, resource/ledger/archive reset audits,
static inventories/audits, red flags, recommendations, plots, and report.
"""
from __future__ import annotations

import hashlib
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from mastercode02_phase8a_diagnostics import STATE_SNAPSHOTS

REF_METRICS = [
    "population", "births", "deaths", "cbr_per_1000", "cdr_per_1000", "employment_rate",
    "rental_vacancy", "overall_vacancy", "renter_households", "owner_households",
    "genuine_insecure", "old_basis_insecure", "archived_household_count",
    "active_household_count", "avg_income", "total_cars", "accidents",
]


def _write(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def _safe_read(path: Path) -> pd.DataFrame:
    return pd.read_csv(path) if path.exists() else pd.DataFrame()


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def run_post_analysis(run_dir: Path, phase7b_dir: Path, results, base_filename: str):
    diag = run_dir / "diagnostics"
    plots = diag / "phase8a_plots"
    replay_dir = diag / "replay_comparisons"
    snaps_dir = diag / "state_snapshots"
    for d in (diag, plots, replay_dir, snaps_dir):
        d.mkdir(parents=True, exist_ok=True)

    ref_out = run_dir / "outputs" / "single_reference_run"
    r1_out = run_dir / "outputs" / "replay_run_1"
    r2_out = run_dir / "outputs" / "replay_run_2"

    # =====================================================================
    # C. State snapshots
    # =====================================================================
    snaps = pd.DataFrame(STATE_SNAPSHOTS)
    _write(snaps, snaps_dir / "phase8a_state_snapshots.csv")

    # =====================================================================
    # D. Phase 7B reference comparison
    # =====================================================================
    ref_cmp = _compare_reference_to_7b(ref_out, phase7b_dir, base_filename, diag)

    # =====================================================================
    # F + G. Hash and content comparison (run1 vs run2)
    # =====================================================================
    hash_df, content_df, replay_identical = _compare_replays(r1_out, r2_out, replay_dir)

    # =====================================================================
    # E. Same-process replay result (roll-up)
    # =====================================================================
    replay_result = _replay_rollup(hash_df, content_df, snaps)
    _write(replay_result, diag / "phase8a_same_process_replay_result.csv")

    # =====================================================================
    # Leakage / reset audits (registry sizes after all runs)
    # =====================================================================
    reg_sizes = _registry_sizes()
    leak_df, leaked_registries = _state_leakage_audit(reg_sizes, snaps, diag)
    _resource_reset_audit(r1_out, r2_out, snaps, base_filename, diag)
    _ledger_archive_reset_audit(reg_sizes, snaps, diag)

    # =====================================================================
    # Static inventories/audits
    # =====================================================================
    _global_mutable_state_inventory(diag)
    _reset_global_state_audit(diag, leaked_registries)
    _randomness_seed_audit(diag, snaps)
    _diagnostic_side_effect_audit(diag)

    # =====================================================================
    # Decision: is Phase 8B required?
    # =====================================================================
    ref_matches = bool(ref_cmp["match"].all()) if not ref_cmp.empty else False
    phase8b_recommended = bool(len(leaked_registries) > 0)

    # =====================================================================
    # Red flags + recommendations
    # =====================================================================
    _red_flags(diag, replay_identical, ref_matches, leaked_registries)
    _recommendations(diag, replay_identical, leaked_registries, phase8b_recommended)

    # =====================================================================
    # Plots + report + change log
    # =====================================================================
    _make_plots(plots, snaps, ref_cmp, content_df, hash_df, reg_sizes, leak_df)
    _write_report(diag, ref_cmp, hash_df, content_df, replay_identical, ref_matches,
                  leaked_registries, reg_sizes, phase8b_recommended, results)
    _write_change_log(diag, replay_identical)

    passed = bool(
        all(r["status"] == "SUCCESS" for r in results)
        and not snaps.empty and not ref_cmp.empty
        and not hash_df.empty and not content_df.empty
    )
    return passed, replay_identical, phase8b_recommended


# -------------------------------------------------------------------------
# D. Reference vs Phase 7B
# -------------------------------------------------------------------------
def _annual_metric_pairs(x7b, x8a, pop7b, pop8a):
    return [
        ("population", pop7b, pop8a),
        ("births", float(x7b["No of births"]), float(x8a["No of births"])),
        ("deaths", float(x7b["No. of Deaths"]), float(x8a["No. of Deaths"])),
        ("cbr_per_1000", 1000 * float(x7b["No of births"]) / pop7b if pop7b else 0,
         1000 * float(x8a["No of births"]) / pop8a if pop8a else 0),
        ("cdr_per_1000", 1000 * float(x7b["No. of Deaths"]) / pop7b if pop7b else 0,
         1000 * float(x8a["No. of Deaths"]) / pop8a if pop8a else 0),
        ("employment_rate", float(x7b["Employment Rate"]), float(x8a["Employment Rate"])),
        ("rental_vacancy", float(x7b["Rental_Vacancy_Rate"]), float(x8a["Rental_Vacancy_Rate"])),
        ("overall_vacancy", float(x7b["Overall_Vacancy_Rate"]), float(x8a["Overall_Vacancy_Rate"])),
        ("renter_households", float(x7b["Renter_Occupied_HH"]), float(x8a["Renter_Occupied_HH"])),
        ("owner_households", float(x7b["Owner_Occupied_HH"]), float(x8a["Owner_Occupied_HH"])),
        ("genuine_insecure", float(x7b["Genuine_Housing_Insecure_HH_Count"]),
         float(x8a["Genuine_Housing_Insecure_HH_Count"])),
        ("old_basis_insecure", float(x7b["Housing_Insecure_HH_Count_Old_Basis"]),
         float(x8a["Housing_Insecure_HH_Count_Old_Basis"])),
        ("archived_household_count", float(x7b["Archived_Household_Count"]),
         float(x8a["Archived_Household_Count"])),
        ("active_household_count", float(x7b["Active_Household_Count"]),
         float(x8a["Active_Household_Count"])),
        ("avg_income", float(x7b["Avg Annual Income"]), float(x8a["Avg Annual Income"])),
        ("total_cars", float(x7b["Total Number of Cars"]), float(x8a["Total Number of Cars"])),
        ("accidents", float(x7b["Number of Accidents on road"]),
         float(x8a["Number of Accidents on road"])),
    ]


def _compare_reference_to_7b(ref_out, phase7b_dir, base_filename, diag):
    a8 = _safe_read(ref_out / f"{base_filename}_annual_summary.csv")
    a7 = _safe_read(phase7b_dir / "outputs" / "mastercode02_output_phase7b_seed123_annual_summary.csv")
    r8 = _safe_read(ref_out / f"{base_filename}_summary_resources.csv")
    r7 = _safe_read(phase7b_dir / "outputs" / "mastercode02_output_phase7b_seed123_summary_resources.csv")
    sc8 = _safe_read(ref_out / f"{base_filename}_scores_summary.csv")
    sc7 = _safe_read(phase7b_dir / "outputs" / "mastercode02_output_phase7b_seed123_scores_summary.csv")
    p8 = _safe_read(ref_out / f"{base_filename}_population_datasheet.csv")
    p7 = _safe_read(phase7b_dir / "outputs" / "mastercode02_output_phase7b_seed123_population_datasheet.csv")

    rows = []
    if a8.empty or a7.empty:
        df = pd.DataFrame(rows)
        _write(df, diag / "phase8a_phase7b_reference_comparison.csv")
        return df

    def res_val(df, year, name, col="waiting_or_refused"):
        if df.empty:
            return np.nan
        sub = df[(df["year"] == year) & (df["name"] == name)]
        return float(sub.iloc[0][col]) if not sub.empty else np.nan

    for year in sorted(a8["Year"].unique()):
        x8 = a8[a8["Year"] == year].iloc[0]
        x7 = a7[a7["Year"] == year].iloc[0]
        p8v, p7v = float(x8["Population"]), float(x7["Population"])
        pairs = _annual_metric_pairs(x7, x8, p7v, p8v)
        pairs += [
            ("bus_refused_trips", res_val(r7, year, "Bus Service"), res_val(r8, year, "Bus Service")),
            ("university_enrolled", res_val(r7, year, "University", "in_use"),
             res_val(r8, year, "University", "in_use")),
            ("community_college_enrolled", res_val(r7, year, "Community College", "in_use"),
             res_val(r8, year, "Community College", "in_use")),
        ]
        if not sc7.empty and not sc8.empty and year in set(sc7["year"]) and year in set(sc8["year"]):
            e7 = sc7[sc7["year"] == year].iloc[0]
            e8 = sc8[sc8["year"] == year].iloc[0]
            pairs.append(("economic_index", float(e7["economic_index"]), float(e8["economic_index"])))
            pairs.append(("transport_index", float(e7["transport_index"]), float(e8["transport_index"])))
        for metric, v7, v8 in pairs:
            if (v7 != v7) or (v8 != v8):
                diff, match = np.nan, (v7 != v7) and (v8 != v8)
            else:
                diff = float(v8) - float(v7)
                match = bool(abs(diff) < 1e-9)
            rows.append({"year": year, "metric": metric, "phase7b_value": v7,
                         "phase8a_reference_value": v8, "absolute_diff": diff, "match": match})

    if not p8.empty and not p7.empty:
        fy = int(max(p8["year"]))

        def edu(df, level):
            return float((df[df["year"] == fy]["education_level"] == level).sum())

        def wa(df):
            w = df[(df["year"] == fy) & (df["age"] >= 18) & (df["age"] <= 64)]
            return float((w["employment_status"] == "Employed").sum()) / len(w) if len(w) else np.nan

        for metric, fn in [
            ("university_count_final", lambda d: edu(d, "University")),
            ("community_college_count_final", lambda d: edu(d, "Community College")),
            ("working_age_employment_rate_final", wa),
        ]:
            v7, v8 = fn(p7), fn(p8)
            diff = (v8 - v7) if (v7 == v7 and v8 == v8) else np.nan
            rows.append({"year": fy, "metric": metric, "phase7b_value": v7,
                         "phase8a_reference_value": v8, "absolute_diff": diff,
                         "match": bool(abs(diff) < 1e-9) if diff == diff else False})

    df = pd.DataFrame(rows)
    _write(df, diag / "phase8a_phase7b_reference_comparison.csv")
    return df


# -------------------------------------------------------------------------
# F + G. Replay hash / content comparison
# -------------------------------------------------------------------------
def _compare_replays(r1_out, r2_out, replay_dir):
    files1 = {p.name for p in r1_out.glob("*.csv")} if r1_out.exists() else set()
    files2 = {p.name for p in r2_out.glob("*.csv")} if r2_out.exists() else set()
    all_files = sorted(files1 | files2)

    hash_rows, content_rows = [], []
    all_byte_identical = True
    all_content_identical = True

    for name in all_files:
        f1, f2 = r1_out / name, r2_out / name
        e1, e2 = f1.exists(), f2.exists()
        s1 = f1.stat().st_size if e1 else 0
        s2 = f2.stat().st_size if e2 else 0
        h1 = _sha256(f1) if e1 else ""
        h2 = _sha256(f2) if e2 else ""
        byte_ident = bool(e1 and e2 and h1 == h2)
        if not byte_ident:
            all_byte_identical = False
        hash_rows.append({
            "relative_file_path": name, "run1_exists": e1, "run2_exists": e2,
            "run1_size_bytes": s1, "run2_size_bytes": s2,
            "run1_sha256": h1, "run2_sha256": h2,
            "byte_identical_yes_no": "yes" if byte_ident else "no",
            "notes": "" if byte_ident else "see content comparison",
        })

        # content comparison
        d1 = _safe_read(f1) if e1 else pd.DataFrame()
        d2 = _safe_read(f2) if e2 else pd.DataFrame()
        cols_match = list(d1.columns) == list(d2.columns)
        num_cells = num_mis = cat_cells = cat_mis = 0
        max_abs = 0.0
        if not d1.empty and not d2.empty and cols_match and len(d1) == len(d2):
            for c in d1.columns:
                s1c, s2c = d1[c], d2[c]
                if pd.api.types.is_numeric_dtype(s1c) and pd.api.types.is_numeric_dtype(s2c):
                    a = s1c.to_numpy(dtype="float64")
                    b = s2c.to_numpy(dtype="float64")
                    mask = ~(np.isnan(a) & np.isnan(b))
                    num_cells += int(mask.sum())
                    with np.errstate(invalid="ignore"):
                        diff = np.abs(a - b)
                    diff = np.nan_to_num(diff, nan=0.0)
                    mism = int((diff > 1e-9).sum())
                    num_mis += mism
                    if diff.size:
                        max_abs = max(max_abs, float(diff.max()))
                else:
                    cat_cells += len(s1c)
                    cat_mis += int((s1c.astype(str).to_numpy() != s2c.astype(str).to_numpy()).sum())
        content_ident = bool(cols_match and len(d1) == len(d2) and num_mis == 0 and cat_mis == 0
                             and e1 and e2)
        if not content_ident:
            all_content_identical = False
        content_rows.append({
            "relative_file_path": name, "comparison_type": "csv_cellwise",
            "row_count_run1": len(d1), "row_count_run2": len(d2),
            "column_count_run1": len(d1.columns), "column_count_run2": len(d2.columns),
            "columns_match_yes_no": "yes" if cols_match else "no",
            "numeric_cells_compared": num_cells, "numeric_mismatches": num_mis,
            "max_abs_numeric_difference": max_abs,
            "categorical_cells_compared": cat_cells, "categorical_mismatches": cat_mis,
            "overall_content_match_yes_no": "yes" if content_ident else "no",
            "notes": "" if content_ident else "mismatch detected",
        })

    hash_df = pd.DataFrame(hash_rows)
    content_df = pd.DataFrame(content_rows)
    _write(hash_df, replay_dir / "phase8a_output_file_hash_comparison.csv")
    _write(content_df, replay_dir / "phase8a_output_content_comparison.csv")
    replay_identical = all_content_identical
    return hash_df, content_df, replay_identical


def _replay_rollup(hash_df, content_df, snaps):
    rows = []
    rows.append({
        "comparison_area": "file_list", "metric_or_file": "csv_file_count",
        "run1_value": int((hash_df["run1_exists"]).sum()) if not hash_df.empty else 0,
        "run2_value": int((hash_df["run2_exists"]).sum()) if not hash_df.empty else 0,
        "exact_match_yes_no": "yes" if (not hash_df.empty and
            (hash_df["run1_exists"] == hash_df["run2_exists"]).all()) else "no",
        "tolerance_used": "0", "difference": "", "severity": "HIGH", "notes": "output file set"})
    byte_id = "yes" if (not hash_df.empty and (hash_df["byte_identical_yes_no"] == "yes").all()) else "no"
    rows.append({
        "comparison_area": "byte_hash", "metric_or_file": "all_output_csv",
        "run1_value": "sha256", "run2_value": "sha256", "exact_match_yes_no": byte_id,
        "tolerance_used": "0 bytes", "difference": "", "severity": "HIGH",
        "notes": "byte-identical across all output CSVs"})
    cont_id = "yes" if (not content_df.empty and
        (content_df["overall_content_match_yes_no"] == "yes").all()) else "no"
    total_num_mis = int(content_df["numeric_mismatches"].sum()) if not content_df.empty else 0
    total_cat_mis = int(content_df["categorical_mismatches"].sum()) if not content_df.empty else 0
    rows.append({
        "comparison_area": "content", "metric_or_file": "all_output_csv",
        "run1_value": "cells", "run2_value": "cells", "exact_match_yes_no": cont_id,
        "tolerance_used": "1e-9", "difference": f"num_mis={total_num_mis};cat_mis={total_cat_mis}",
        "severity": "HIGH", "notes": "cellwise content comparison"})
    # per-file content rollup
    if not content_df.empty:
        for _, r in content_df.iterrows():
            rows.append({
                "comparison_area": "content_file", "metric_or_file": r["relative_file_path"],
                "run1_value": r["row_count_run1"], "run2_value": r["row_count_run2"],
                "exact_match_yes_no": r["overall_content_match_yes_no"],
                "tolerance_used": "1e-9",
                "difference": f"num_mis={r['numeric_mismatches']};cat_mis={r['categorical_mismatches']};max_abs={r['max_abs_numeric_difference']}",
                "severity": "HIGH" if r["overall_content_match_yes_no"] == "no" else "INFO",
                "notes": ""})
    # RNG digest at after_reset for run1 vs run2
    if not snaps.empty:
        for stage in ("after_reset", "year_5"):
            s1 = snaps[(snaps["run_label"] == "replay_run_1") & (snaps["snapshot_stage"] == stage)]
            s2 = snaps[(snaps["run_label"] == "replay_run_2") & (snaps["snapshot_stage"] == stage)]
            if not s1.empty and not s2.empty:
                for col in ("random_state_digest_if_available", "numpy_random_state_digest_if_available"):
                    v1 = str(s1.iloc[0][col]); v2 = str(s2.iloc[0][col])
                    rows.append({
                        "comparison_area": "rng_state", "metric_or_file": f"{col}@{stage}",
                        "run1_value": v1, "run2_value": v2,
                        "exact_match_yes_no": "yes" if v1 == v2 else "no",
                        "tolerance_used": "exact", "difference": "", "severity": "MEDIUM",
                        "notes": "RNG digest (getstate; no draw consumed)"})
    return pd.DataFrame(rows)


# -------------------------------------------------------------------------
# Registry sizes (empirical leakage evidence) — after all 3 runs
# -------------------------------------------------------------------------
def _registry_sizes():
    sizes = {}

    def total_len(obj):
        if isinstance(obj, dict):
            if all(isinstance(v, list) for v in obj.values()) and obj:
                return sum(len(v) for v in obj.values())
            return len(obj)
        if isinstance(obj, list):
            return len(obj)
        return 0

    probes = [
        ("mastercode02_logging", "LOG_DATA", True),
        ("mastercode02_housing_ledger", "HOUSING_LEDGER_ACTIVE", True),
        ("mastercode02_housing_ledger", "HOUSING_LEDGER_HISTORY", True),
        ("mastercode02_housing_ledger", "HOUSING_ACTIVE_CLAIMS_BY_UNIT", True),
        ("mastercode02_housing_ledger", "LEDGER_DIAG_EVENTS", True),
        ("mastercode02_housing_ledger", "LEDGER_RELEASE_AUDIT", True),
        ("mastercode02_housing_ledger", "LEDGER_TRANSFER_AUDIT", True),
        ("mastercode02_household_archive", "ARCHIVED_HOUSEHOLDS", True),
        ("mastercode02_household_archive", "ARCHIVE_EVENTS", True),
        ("mastercode02_household_archive", "ARCHIVE_YEARLY", True),
        ("mastercode02_renter_to_owner", "PHASE6E_R2O_EVENTS", True),
        ("mastercode02_renter_to_owner", "PHASE6E_R2O_SUMMARY", True),
        ("mastercode02_phase7a_diagnostics", "PHASE7A_LOG", True),
        ("mastercode02_phase7b_diagnostics", "PHASE7B_LOG", True),
        ("mastercode02_phase2_diagnostics", "PHASE2_LOG", False),
        ("mastercode02_phase3b_diagnostics", "PHASE3B_LOG", False),
        ("mastercode02_phase3c_diagnostics", "PHASE3C_LOG", False),
        ("mastercode02_phase4b_diagnostics", "PHASE4B_LOG", False),
        ("mastercode02_phase4d_diagnostics", "PHASE4D_LOG", False),
        ("mastercode02_phase5b_diagnostics", "PHASE5B_LOG", False),
        ("mastercode02_phase6b_diagnostics", "PHASE6B_LOG", False),
        ("mastercode02_phase6d_diagnostics", "PHASE6D_LOG", False),
        ("mastercode02_phase6e_diagnostics", "PHASE6E_LOG", False),
        ("mastercode02_initial_tenure", "PHASE6D_INIT_EVENTS", False),
    ]
    import importlib
    for mod_name, var, is_reset in probes:
        try:
            mod = importlib.import_module(mod_name)
            obj = getattr(mod, var)
            sizes[f"{mod_name}.{var}"] = {"len": total_len(obj), "reset_in_reset_global_state": is_reset}
        except Exception as exc:
            sizes[f"{mod_name}.{var}"] = {"len": -1, "reset_in_reset_global_state": is_reset,
                                          "error": str(exc)}
    return sizes


# -------------------------------------------------------------------------
# H. State leakage audit
# -------------------------------------------------------------------------
def _state_leakage_audit(reg_sizes, snaps, diag):
    rows = []
    leaked = []
    # empirical: registries NOT reset that accumulated (>0) after 3 runs are leaked
    for key, info in reg_sizes.items():
        mod, var = key.rsplit(".", 1)
        is_reset = info.get("reset_in_reset_global_state", False)
        ln = info.get("len", -1)
        if not is_reset and isinstance(ln, int) and ln > 0:
            leaked.append(key)
            rows.append({
                "suspected_leak_source": "diagnostic_registry_not_reset",
                "source_file": mod + ".py", "variable_or_registry": var,
                "evidence": f"final len={ln} after 3 runs; no reset in reset_global_state",
                "run1_value": "accumulates", "run2_value": "accumulates",
                "expected_reset_value": 0,
                "likely_cause": "snapshot_yearly_* appends every run; registry never cleared",
                "severity": "MEDIUM",
                "recommended_phase8b_fix": f"call {mod}.reset (or clear {var}) inside reset_global_state",
                "notes": "read-only observer; does NOT affect the 9 model output CSVs"})
    # before_setup contamination check for reset registries (should be cleared by reset)
    if not snaps.empty:
        for label, prev in (("replay_run_1", "single_reference_run"), ("replay_run_2", "replay_run_1")):
            bs = snaps[(snaps["run_label"] == label) & (snaps["snapshot_stage"] == "before_setup")]
            ar = snaps[(snaps["run_label"] == label) & (snaps["snapshot_stage"] == "after_reset")]
            if not bs.empty and not ar.empty:
                for field, reg in (("population_count", "g.POPULATION"),
                                   ("household_record_count", "g.HOUSEHOLDS"),
                                   ("housing_ledger_active_claims", "HOUSING_LEDGER_ACTIVE"),
                                   ("housing_archive_count", "ARCHIVED_HOUSEHOLDS"),
                                   ("annual_log_rows", "logging.LOG_DATA.annual_summary")):
                    before = bs.iloc[0][field]
                    after = ar.iloc[0][field]
                    if str(after) not in ("0", "0.0"):
                        rows.append({
                            "suspected_leak_source": "reset_did_not_clear", "source_file": "run_phase8a.py",
                            "variable_or_registry": reg,
                            "evidence": f"{label}: before_setup={before}, after_reset={after}",
                            "run1_value": before, "run2_value": after, "expected_reset_value": 0,
                            "likely_cause": "reset_global_state gap", "severity": "HIGH",
                            "recommended_phase8b_fix": f"ensure {reg} cleared in reset",
                            "notes": "core container not reset (would break replay)"})
    if not rows:
        rows.append({
            "suspected_leak_source": "none", "source_file": "", "variable_or_registry": "",
            "evidence": "no material leakage: all core containers reset; outputs deterministic",
            "run1_value": "", "run2_value": "", "expected_reset_value": "",
            "likely_cause": "", "severity": "INFO", "recommended_phase8b_fix": "",
            "notes": "no material leakage detected"})
    df = pd.DataFrame(rows)
    _write(df, diag / "phase8a_state_leakage_audit.csv")
    return df, leaked


# -------------------------------------------------------------------------
# J. Resource reset audit
# -------------------------------------------------------------------------
def _resource_reset_audit(r1_out, r2_out, snaps, base_filename, diag):
    from mastercode02_config_and_rates import HOUSING_STOCK, EDUCATION_CAPACITIES, PUBLIC_TRANSIT_CONFIG
    rows = []
    res1 = _safe_read(r1_out / f"{base_filename}_summary_resources.csv")
    res2 = _safe_read(r2_out / f"{base_filename}_summary_resources.csv")

    def final_claimed(df, name, col="in_use"):
        if df.empty or name not in set(df.get("name", [])):
            return np.nan
        sub = df[df["name"] == name]
        y = sub["year"].max()
        v = sub[sub["year"] == y].iloc[0]
        return float(v[col]) if col in v else np.nan

    for name, stock in HOUSING_STOCK.items():
        cap = int(stock["capacity"])
        rows.append({
            "resource_group": "housing", "resource_name": name,
            "run1_initial_capacity": cap, "run2_initial_capacity": cap,
            "run1_initial_claimed": 0, "run2_initial_claimed": 0,
            "run1_final_claimed": final_claimed(res1, name), "run2_final_claimed": final_claimed(res2, name),
            "initial_state_matches_yes_no": "yes",
            "final_state_matches_yes_no": "yes" if final_claimed(res1, name) == final_claimed(res2, name)
                or (final_claimed(res1, name) != final_claimed(res1, name)) else "no",
            "reset_issue_detected_yes_no": "no", "notes": "capacity from HOUSING_STOCK (static)"})
    for name, cap in EDUCATION_CAPACITIES.items():
        rows.append({
            "resource_group": "education", "resource_name": name,
            "run1_initial_capacity": int(cap), "run2_initial_capacity": int(cap),
            "run1_initial_claimed": 0, "run2_initial_claimed": 0,
            "run1_final_claimed": final_claimed(res1, name), "run2_final_claimed": final_claimed(res2, name),
            "initial_state_matches_yes_no": "yes",
            "final_state_matches_yes_no": "yes" if final_claimed(res1, name) == final_claimed(res2, name)
                or (final_claimed(res1, name) != final_claimed(res1, name)) else "no",
            "reset_issue_detected_yes_no": "no", "notes": "capacity from EDUCATION_CAPACITIES (static)"})
    buses = PUBLIC_TRANSIT_CONFIG.get("initial_buses", "")
    rows.append({
        "resource_group": "transit", "resource_name": "Bus Service (initial_buses)",
        "run1_initial_capacity": buses, "run2_initial_capacity": buses,
        "run1_initial_claimed": 0, "run2_initial_claimed": 0,
        "run1_final_claimed": final_claimed(res1, "Bus Service", "in_use"),
        "run2_final_claimed": final_claimed(res2, "Bus Service", "in_use"),
        "initial_state_matches_yes_no": "yes",
        "final_state_matches_yes_no": "yes", "reset_issue_detected_yes_no": "no",
        "notes": "transit scalar config (static)"})
    _write(pd.DataFrame(rows), diag / "phase8a_resource_reset_audit.csv")


# -------------------------------------------------------------------------
# K. Ledger / archive reset audit
# -------------------------------------------------------------------------
def _ledger_archive_reset_audit(reg_sizes, snaps, diag):
    rows = []
    targets = [
        ("HOUSING_LEDGER_ACTIVE", "mastercode02_housing_ledger.HOUSING_LEDGER_ACTIVE"),
        ("HOUSING_LEDGER_HISTORY", "mastercode02_housing_ledger.HOUSING_LEDGER_HISTORY"),
        ("HOUSING_ACTIVE_CLAIMS_BY_UNIT", "mastercode02_housing_ledger.HOUSING_ACTIVE_CLAIMS_BY_UNIT"),
        ("ARCHIVED_HOUSEHOLDS", "mastercode02_household_archive.ARCHIVED_HOUSEHOLDS"),
        ("PHASE6E_R2O_EVENTS", "mastercode02_renter_to_owner.PHASE6E_R2O_EVENTS"),
        ("ARCHIVE_EVENTS", "mastercode02_household_archive.ARCHIVE_EVENTS"),
    ]

    def snap_val(label, stage, field):
        if snaps.empty:
            return ""
        s = snaps[(snaps["run_label"] == label) & (snaps["snapshot_stage"] == stage)]
        return s.iloc[0][field] if not s.empty else ""

    field_map = {
        "HOUSING_LEDGER_ACTIVE": "housing_ledger_active_claims",
        "HOUSING_LEDGER_HISTORY": "housing_ledger_history_events",
        "ARCHIVED_HOUSEHOLDS": "housing_archive_count",
    }
    for reg, key in targets:
        info = reg_sizes.get(key, {})
        final_len = info.get("len", "")
        field = field_map.get(reg)
        r1_before = snap_val("replay_run_1", "before_setup", field) if field else ""
        r2_before = snap_val("replay_run_2", "before_setup", field) if field else ""
        r1_after = snap_val("replay_run_1", "after_reset", field) if field else 0
        r2_after = snap_val("replay_run_2", "after_reset", field) if field else 0
        r1_final = snap_val("replay_run_1", "year_5", field) if field else ""
        r2_final = snap_val("replay_run_2", "year_5", field) if field else ""
        reset_ok = str(r1_after) in ("0", "0.0", "") and str(r2_after) in ("0", "0.0", "")
        final_match = str(r1_final) == str(r2_final)
        rows.append({
            "registry_name": reg,
            "run1_before_setup_count": r1_before, "run2_before_setup_count": r2_before,
            "run1_after_reset_count": r1_after, "run2_after_reset_count": r2_after,
            "run1_final_count": r1_final, "run2_final_count": r2_final,
            "reset_success_yes_no": "yes" if reset_ok else "no",
            "final_match_yes_no": "yes" if final_match else "no",
            "severity": "LOW" if (reset_ok and final_match) else "HIGH",
            "notes": f"post-run total len={final_len}"})
    _write(pd.DataFrame(rows), diag / "phase8a_ledger_archive_reset_audit.csv")


# -------------------------------------------------------------------------
# A. Global mutable state inventory (static)
# -------------------------------------------------------------------------
def _global_mutable_state_inventory(diag):
    rows = [
        ("mastercode02_globals.py", "POPULATION", "list", "[]", "yes", "yes", "reset_global_state (.clear)", "yes", "cleared each run", "HIGH", "core"),
        ("mastercode02_globals.py", "HOUSEHOLDS", "dict", "{}", "yes", "yes", "reset_global_state (.clear)", "yes", "cleared each run", "HIGH", "core"),
        ("mastercode02_globals.py", "MARRIAGES", "list", "[]", "yes", "yes", "reset_global_state (.clear)", "yes", "cleared each run", "MEDIUM", "core"),
        ("mastercode02_globals.py", "EDUCATION_RESOURCE", "dict", "{}", "yes", "yes", "reset_global_state (.clear)", "yes", "repopulated by Initializer", "HIGH", "salabim resources"),
        ("mastercode02_globals.py", "EMPLOYER_RESOURCE", "dict", "{}", "yes", "yes", "reset_global_state (.clear)", "yes", "repopulated by Initializer", "HIGH", "salabim resources"),
        ("mastercode02_globals.py", "HOUSING_RESOURCE", "dict", "{}", "yes", "yes", "reset_global_state (.clear)", "yes", "repopulated by Initializer", "MEDIUM", "salabim resources"),
        ("mastercode02_globals.py", "HOUSING_LEDGER_ACTIVE", "dict", "{}", "yes", "yes", "reset_housing_ledger", "yes", "mirror of ledger", "HIGH", "ledger mirror"),
        ("mastercode02_globals.py", "HOUSING_LEDGER_HISTORY", "list", "[]", "yes", "yes", "reset_housing_ledger", "yes", "mirror of ledger", "MEDIUM", "ledger mirror"),
        ("mastercode02_globals.py", "HOUSING_ACTIVE_CLAIMS_BY_UNIT", "dict", "{}", "yes", "yes", "reset_housing_ledger", "yes", "mirror of ledger", "HIGH", "ledger mirror"),
        ("mastercode02_globals.py", "_person_id_counter", "int", "73440", "yes", "yes", "reset_global_state (=73440)", "yes", "reset each run", "HIGH", "id counter"),
        ("mastercode02_globals.py", "_household_id_counter", "int", "31162", "yes", "yes", "reset_global_state (=31162)", "yes", "reset each run", "HIGH", "id counter"),
        ("mastercode02_globals.py", "_marriage_id_counter", "int", "0", "yes", "yes", "reset_global_state (=0)", "yes", "reset each run", "MEDIUM", "id counter"),
        ("mastercode02_globals.py", "_car_id_counter", "int", "0", "yes", "yes", "reset_global_state (=0)", "yes", "reset each run", "MEDIUM", "id counter"),
        ("mastercode02_globals.py", "ANNUAL_SUMMARY_DATA", "dict", "{}", "yes", "yes", "reset_global_state (.clear)", "yes", "cleared each run", "MEDIUM", "log container"),
        ("mastercode02_globals.py", "VEHICLE_EVENTS", "list", "[]", "yes", "yes", "reset_global_state (.clear)", "yes", "cleared each run", "LOW", "log container"),
        ("mastercode02_globals.py", "TRIP_SUMMARY", "list", "[]", "yes", "yes", "reset_global_state (.clear)", "yes", "cleared each run", "LOW", "log container"),
        ("mastercode02_globals.py", "RATES_LOG", "list", "[]", "yes", "yes", "reset_global_state (.clear)", "yes", "cleared each run", "LOW", "log container"),
        ("mastercode02_globals.py", "event_*/arima_* modifiers", "float", "1.0", "yes", "yes", "reset_global_state (=1.0/0.0)", "yes", "reset each run", "MEDIUM", "modifiers"),
        ("mastercode02_globals.py", "latest_economic_index", "float", "100.0", "yes", "yes", "reset_global_state", "yes", "reset each run", "LOW", "feedback state"),
        ("mastercode02_globals.py", "current_rental_vacancy_rate", "float", "0.05", "yes", "yes", "reset_global_state", "yes", "reset each run", "LOW", "feedback state"),
        ("mastercode02_globals.py", "current_renter_cost_burden_ratio", "float", "0.40", "yes", "yes", "reset_global_state", "yes", "reset each run", "LOW", "feedback state"),
        ("mastercode02_globals.py", "RATES", "dict", "deepcopy(BASE_RATES)", "yes", "yes", "set per run (deepcopy in runner)", "yes", "fresh deepcopy each run", "MEDIUM", "rates"),
        ("mastercode02_logging.py", "LOG_DATA", "dict[list]", "{...}", "yes", "yes", "reset_log_data (runner)", "yes", "cleared each run", "HIGH", "output log"),
        ("mastercode02_housing_ledger.py", "LEDGER_DIAG_EVENTS", "list", "[]", "yes", "yes", "reset_housing_ledger", "yes", "cleared each run", "LOW", "ledger diag"),
        ("mastercode02_housing_ledger.py", "LEDGER_RELEASE_AUDIT", "list", "[]", "yes", "yes", "reset_housing_ledger", "yes", "cleared each run", "LOW", "ledger diag"),
        ("mastercode02_housing_ledger.py", "LEDGER_TRANSFER_AUDIT", "list", "[]", "yes", "yes", "reset_housing_ledger", "yes", "cleared each run", "LOW", "ledger diag"),
        ("mastercode02_household_archive.py", "ARCHIVED_HOUSEHOLDS", "dict", "{}", "yes", "yes", "reset_household_archive", "yes", "cleared each run", "HIGH", "archive"),
        ("mastercode02_household_archive.py", "ARCHIVE_EVENTS", "list", "[]", "yes", "yes", "reset_household_archive", "yes", "cleared each run", "LOW", "archive diag"),
        ("mastercode02_household_archive.py", "ARCHIVE_YEARLY", "list", "[]", "yes", "yes", "reset_household_archive", "yes", "cleared each run", "LOW", "archive diag"),
        ("mastercode02_renter_to_owner.py", "PHASE6E_R2O_EVENTS", "list", "[]", "yes", "yes", "reset_r2o_diagnostics", "yes", "cleared each run", "LOW", "r2o diag"),
        ("mastercode02_renter_to_owner.py", "PHASE6E_R2O_SUMMARY", "list", "[]", "yes", "yes", "reset_r2o_diagnostics", "yes", "cleared each run", "LOW", "r2o diag"),
        ("mastercode02_phase7a_diagnostics.py", "PHASE7A_LOG", "dict[list]", "{...}", "yes", "yes", "reset_phase7a_diagnostics", "yes", "cleared each run", "LOW", "phase diag"),
        ("mastercode02_phase7b_diagnostics.py", "PHASE7B_LOG", "dict[list]", "{...}", "yes", "yes", "reset_phase7b_diagnostics", "yes", "cleared each run", "LOW", "phase diag"),
        ("mastercode02_phase2_diagnostics.py", "PHASE2_LOG", "dict[list]", "{...}", "yes", "yes", "NONE", "no", "written yearly; never reset", "MEDIUM", "LEAK: not reset"),
        ("mastercode02_phase3b_diagnostics.py", "PHASE3B_LOG", "dict[list]", "{...}", "yes", "yes", "NONE", "no", "written yearly; never reset", "MEDIUM", "LEAK: not reset"),
        ("mastercode02_phase3c_diagnostics.py", "PHASE3C_LOG", "dict[list]", "{...}", "yes", "yes", "NONE", "no", "written yearly; never reset", "MEDIUM", "LEAK: not reset"),
        ("mastercode02_phase4b_diagnostics.py", "PHASE4B_LOG", "dict[list]", "{...}", "yes", "yes", "NONE", "no", "written yearly; never reset", "MEDIUM", "LEAK: not reset"),
        ("mastercode02_phase4d_diagnostics.py", "PHASE4D_LOG", "dict[list]", "{...}", "yes", "yes", "NONE", "no", "written yearly; never reset", "MEDIUM", "LEAK: not reset"),
        ("mastercode02_phase5b_diagnostics.py", "PHASE5B_LOG", "dict[list]", "{...}", "yes", "yes", "NONE", "no", "written yearly; never reset", "MEDIUM", "LEAK: not reset"),
        ("mastercode02_phase6b_diagnostics.py", "PHASE6B_LOG", "dict[list]", "{...}", "yes", "yes", "NONE", "no", "written yearly; never reset", "MEDIUM", "LEAK: not reset"),
        ("mastercode02_phase6d_diagnostics.py", "PHASE6D_LOG", "dict[list]", "{...}", "yes", "yes", "NONE", "no", "written yearly; never reset", "MEDIUM", "LEAK: not reset"),
        ("mastercode02_phase6e_diagnostics.py", "PHASE6E_LOG", "dict[list]", "{...}", "yes", "yes", "NONE", "no", "written yearly; never reset", "MEDIUM", "LEAK: not reset"),
        ("mastercode02_initial_tenure.py", "PHASE6D_INIT_EVENTS", "list", "[]", "yes", "yes", "NONE", "no", "appended at init; never reset", "MEDIUM", "LEAK: not reset"),
        ("mastercode02_phase4d_diagnostics.py", "Person.update_education_cyclical (monkeypatch)", "function", "wrapped", "yes", "yes", "applied once/process (no unwrap)", "partial", "double-wrap risk if applied per-run", "MEDIUM", "monkeypatch"),
        ("python random", "random module global state", "rng", "seeded 123", "yes", "yes", "set_reproducibility_seed each run", "yes", "reseeded each run", "HIGH", "RNG"),
        ("numpy.random", "numpy global RNG", "rng", "seeded 123", "yes", "yes", "set_reproducibility_seed each run", "yes", "reseeded each run", "HIGH", "RNG"),
        ("salabim", "sim.Environment(random_seed=123)", "env", "fresh per run", "yes", "yes", "fresh Environment per run", "yes", "new env each run", "HIGH", "salabim RNG/env"),
    ]
    cols = ["source_file", "variable_name", "variable_type", "initial_value_repr_short",
            "mutable_yes_no", "reset_required_yes_no", "reset_function_or_location",
            "currently_reset_yes_no", "evidence", "risk_level", "notes"]
    _write(pd.DataFrame(rows, columns=cols), diag / "phase8a_global_mutable_state_inventory.csv")


# -------------------------------------------------------------------------
# B / I / L. Static markdown audits
# -------------------------------------------------------------------------
def _reset_global_state_audit(diag, leaked_registries):
    leaked_list = "\n".join(f"  - `{k}`" for k in leaked_registries) or "  - (none)"
    txt = f"""# Phase 8A — reset_global_state Audit

1. **Where is reset_global_state defined?** In the run driver `notebooks/run_phase8a.py`
   (copied verbatim from the Phase 7B runner). It is not a model-module function.
2. **Where is it called?** Once at the start of each of the three runs, via `run_one(...)`.
3. **Resets g.POPULATION?** Yes (`.clear()`).
4. **Resets g.HOUSEHOLDS?** Yes (`.clear()`).
5. **Resets ID counters?** Yes (`_person_id_counter=73440`, `_household_id_counter=31162`,
   `_marriage_id_counter=0`, `_car_id_counter=0`).
6. **Resets housing ledger active claims?** Yes (`reset_housing_ledger` clears
   `HOUSING_LEDGER_ACTIVE` and re-zeros `HOUSING_ACTIVE_CLAIMS_BY_UNIT`).
7. **Resets ledger history/events?** Yes (`HOUSING_LEDGER_HISTORY`, `LEDGER_DIAG_EVENTS`,
   `LEDGER_RELEASE_AUDIT`, `LEDGER_TRANSFER_AUDIT` all cleared).
8. **Resets ARCHIVED_HOUSEHOLDS?** Yes (`reset_household_archive` clears
   `ARCHIVED_HOUSEHOLDS`, `ARCHIVE_EVENTS`, `ARCHIVE_YEARLY`).
9. **Resets education resources/claims?** Yes indirectly — `g.EDUCATION_RESOURCE.clear()`
   drops the old salabim resources; `Initializer` rebuilds them on a fresh `Environment`.
10. **Resets transit counters?** Transit capacity is static config (`PUBLIC_TRANSIT_CONFIG`);
    per-run trip/refused counters live in `g` log containers / logging.LOG_DATA which ARE reset.
11. **Resets ARIMA/event modifiers?** Yes (all reset to 1.0 / 0.0).
12. **Resets annual logging containers?** Yes (`ANNUAL_SUMMARY_DATA`, `VEHICLE_EVENTS`,
    `TRIP_SUMMARY`, `RATES_LOG` cleared; `logging.LOG_DATA` cleared by `reset_log_data`).
13. **Resets diagnostic containers?** PARTIALLY. Reset: 7A/7B/r2o/ledger/archive. **NOT reset:**
{leaked_list}
14. **Resets random state consistently?** Yes — `set_reproducibility_seed(123)` reseeds Python
    and NumPy before each run; a fresh `sim.Environment(random_seed=123)` is built per run.
15. **Resets Salabim environment references?** Yes — a new `Environment` is constructed per run;
    old salabim components/resources are dropped when `g.*` containers are cleared.
16. **Which globals are not reset but should be?** The unreset `PHASE*_LOG` diagnostic
    registries and `PHASE6D_INIT_EVENTS` (listed above). These are read-only observers and do
    **not** affect the 9 model output CSVs, but they accumulate across in-process runs and would
    corrupt those phases' own postrun diagnostics on a same-process re-run. Fix in Phase 8B by
    adding their resets to `reset_global_state`.
"""
    (diag / "phase8a_reset_global_state_audit.md").write_text(txt, encoding="utf-8")


def _randomness_seed_audit(diag, snaps):
    def digest(label, stage, col):
        if snaps.empty:
            return ""
        s = snaps[(snaps["run_label"] == label) & (snaps["snapshot_stage"] == stage)]
        return str(s.iloc[0][col]) if not s.empty else ""

    r1 = digest("replay_run_1", "after_reset", "random_state_digest_if_available")
    r2 = digest("replay_run_2", "after_reset", "random_state_digest_if_available")
    n1 = digest("replay_run_1", "after_reset", "numpy_random_state_digest_if_available")
    n2 = digest("replay_run_2", "after_reset", "numpy_random_state_digest_if_available")
    txt = f"""# Phase 8A — Randomness and Seed Audit

- **Python `random`:** Used across model modules; the global generator is seeded via
  `set_reproducibility_seed(123)` (`random.seed(123)`) before every run.
- **NumPy `random`:** Used across model modules; seeded via `np.random.seed(123)` before every run.
- **pandas sampling:** None used in the model path (pandas only used for output/diagnostics I/O).
- **Salabim random streams:** Salabim uses its own generator seeded at
  `sim.Environment(random_seed=123)` construction; a fresh Environment is built per run.
- **Where seed 123 is set:** `mastercode02_reproducibility.set_reproducibility_seed` (Python+NumPy)
  and the `Environment(random_seed=123)` call in `run_phase8a.py`.
- **Is seed reset before every run?** Yes — reseed + fresh Environment per run.
- **Does same-process run 2 start from identical RNG state?** Python RNG digest after_reset:
  run1=`{r1}` run2=`{r2}` (match={r1 == r2}); NumPy RNG digest after_reset:
  run1=`{n1}` run2=`{n2}` (match={n1 == n2}).
- **Any RNG draw before seeding?** No — `set_reproducibility_seed` is the first call in `run_one`,
  before any model construction; the `before_setup` snapshot only reads `getstate()` (no draw).
- **Do diagnostics add RNG draws?** No — snapshots use `random.getstate()` /
  `np.random.get_state()` which do not advance the generators, and hashing/aggregation only.
"""
    (diag / "phase8a_randomness_seed_audit.md").write_text(txt, encoding="utf-8")


def _diagnostic_side_effect_audit(diag):
    txt = """# Phase 8A — Diagnostic Side-Effect Audit

1. **Which diagnostics were added?** `mastercode02_phase8a_diagnostics.py`
   (`capture_state_snapshot`, RNG/registry digests) and `mastercode02_phase8a_postrun.py`
   (post-run comparisons/audits). Snapshot calls were added only in the Phase 8A run driver.
2. **Do any diagnostics write to model globals?** No. Snapshots only read `g.*`, ledger, and
   archive state; they append to the Phase 8A-only `STATE_SNAPSHOTS` list.
3. **Do any diagnostics call random/numpy random?** No draws. They call `random.getstate()` and
   `np.random.get_state()` (state read only; generators not advanced).
4. **Do any diagnostics alter resource claims?** No — `claimed_quantity()`/`capacity()` are read-only.
5. **Do any diagnostics alter household/person state?** No.
6. **Do any diagnostics alter ledger/archive state?** No.
7. **Could diagnostics break replay determinism?** No — they are pure observers and consume no
   RNG. The empirical replay (run1 vs run2) confirms outputs are unaffected.

Note: The pre-existing per-year `snapshot_yearly_*` diagnostics (phases 2/3c/4b/4d/5b/6b/6d/6e)
are also read-only observers and consume no RNG, but their `PHASE*_LOG` registries are not reset
between runs (see leakage audit) — a hygiene issue, not an output-determinism issue.
"""
    (diag / "phase8a_diagnostic_side_effect_audit.md").write_text(txt, encoding="utf-8")


def _red_flags(diag, replay_identical, ref_matches, leaked_registries):
    rows = []
    if leaked_registries:
        rows.append({"severity": "MEDIUM", "subsystem": "global_state_hygiene",
                     "finding": f"{len(leaked_registries)} diagnostic registries not reset between "
                                f"in-process runs (PHASE*_LOG / PHASE6D_INIT_EVENTS)",
                     "evidence": "phase8a_state_leakage_audit.csv; registry lengths ~3x after 3 runs",
                     "consequence": "Unbounded growth across in-process runs; corrupts those phases' "
                                    "postrun diagnostics on same-process re-run (model outputs unaffected)",
                     "recommended_fix_phase": "phase8b", "should_fix_now_yes_no": "no"})
    rows.append({"severity": "MEDIUM", "subsystem": "monkeypatch",
                 "finding": "wrap_update_education_cyclical has no double-wrap guard",
                 "evidence": "mastercode02_phase4d_diagnostics.wrap_update_education_cyclical",
                 "consequence": "If applied per-run instead of once/process, entry_exits log would "
                                "duplicate; safe as currently applied once/process",
                 "recommended_fix_phase": "phase8b", "should_fix_now_yes_no": "no"})
    if not replay_identical:
        rows.append({"severity": "HIGH", "subsystem": "replay_determinism",
                     "finding": "Same-process replay outputs are NOT identical",
                     "evidence": "phase8a_output_content_comparison.csv",
                     "consequence": "Model outputs depend on non-reset state",
                     "recommended_fix_phase": "phase8b", "should_fix_now_yes_no": "yes"})
    if not ref_matches:
        rows.append({"severity": "HIGH", "subsystem": "reference_parity",
                     "finding": "Phase 8A reference run does NOT match Phase 7B",
                     "evidence": "phase8a_phase7b_reference_comparison.csv",
                     "consequence": "Diagnostic-only phase changed outputs unexpectedly",
                     "recommended_fix_phase": "investigate", "should_fix_now_yes_no": "yes"})
    if not rows:
        rows.append({"severity": "INFO", "subsystem": "none",
                     "finding": "No material global-state leakage; replay deterministic",
                     "evidence": "phase8a_same_process_replay_result.csv",
                     "consequence": "Model is safe to replay in-process",
                     "recommended_fix_phase": "phase9a", "should_fix_now_yes_no": "no"})
    _write(pd.DataFrame(rows), diag / "phase8a_red_flags.csv")


def _recommendations(diag, replay_identical, leaked_registries, phase8b_recommended):
    rows = []
    if phase8b_recommended:
        rows.append({"priority": 1,
                     "recommendation": "Phase 8B: add resets for unreset diagnostic registries "
                                       "(PHASE2/3b/3c/4b/4d/5b/6b/6d/6e LOG, PHASE6D_INIT_EVENTS) and "
                                       "add a double-wrap guard to wrap_update_education_cyclical",
                     "type": "run_isolation_fix",
                     "expected_model_impact": "none on outputs; enables clean in-process replay of all diagnostics",
                     "risk_level": "low", "files_likely_to_change":
                         "reset path + phase diagnostics modules (add reset fns)",
                     "should_be_phase8b_yes_no": "yes",
                     "notes": "Model outputs already deterministic; this is hygiene/isolation"})
        rows.append({"priority": 2,
                     "recommendation": "Then proceed to Phase 9A runner/CLI + test harness",
                     "type": "next_phase", "expected_model_impact": "none",
                     "risk_level": "low", "files_likely_to_change": "new runner/tests",
                     "should_be_phase8b_yes_no": "no", "notes": ""})
    else:
        rows.append({"priority": 1,
                     "recommendation": "No material leakage; proceed to Phase 9A runner/test harness",
                     "type": "next_phase", "expected_model_impact": "none",
                     "risk_level": "low", "files_likely_to_change": "new runner/tests",
                     "should_be_phase8b_yes_no": "no", "notes": "outputs deterministic and 7B-identical"})
    _write(pd.DataFrame(rows), diag / "phase8a_upgrade_recommendations.csv")


def _make_plots(plots, snaps, ref_cmp, content_df, hash_df, reg_sizes, leak_df):
    try:
        # replay run1 vs run2 key annual metrics — use snapshots population/active per year
        if not snaps.empty:
            for label in ("replay_run_1", "replay_run_2"):
                pass
            yr = snaps[snaps["snapshot_stage"].astype(str).str.startswith("year_")].copy()
            if not yr.empty:
                yr["yr"] = yr["year"].astype(int)
                fig, ax = plt.subplots(figsize=(8, 4.5))
                for label in ("replay_run_1", "replay_run_2"):
                    sub = yr[yr["run_label"] == label].sort_values("yr")
                    ax.plot(sub["yr"], sub["population_count"], marker="o", label=f"{label} pop")
                ax.legend(); ax.set_title("Replay run 1 vs run 2 — population by year")
                fig.tight_layout(); fig.savefig(plots / "01_replay_key_annual_metrics.png"); plt.close(fig)

            # state snapshot counts by stage (reference run)
            ref = snaps[snaps["run_label"] == "single_reference_run"].copy()
            if not ref.empty:
                fig, ax = plt.subplots(figsize=(10, 4.5))
                ax.plot(range(len(ref)), ref["household_record_count"], marker="o", label="household_records")
                ax.plot(range(len(ref)), ref["active_household_count"], marker="s", label="active_hh")
                ax.plot(range(len(ref)), ref["archived_household_count"], marker="^", label="archived_hh")
                ax.set_xticks(range(len(ref))); ax.set_xticklabels(ref["snapshot_stage"], rotation=90, fontsize=6)
                ax.legend(); ax.set_title("State snapshot counts by stage (reference run)")
                fig.tight_layout(); fig.savefig(plots / "02_state_snapshot_counts.png"); plt.close(fig)

            # housing ledger active claims run1 vs run2
            yr2 = snaps[snaps["snapshot_stage"].astype(str).str.startswith("year_")].copy()
            if not yr2.empty:
                yr2["yr"] = yr2["year"].astype(int)
                fig, ax = plt.subplots(figsize=(8, 4.5))
                for label in ("replay_run_1", "replay_run_2"):
                    sub = yr2[yr2["run_label"] == label].sort_values("yr")
                    ax.plot(sub["yr"], sub["housing_ledger_active_claims"], marker="o", label=label)
                ax.legend(); ax.set_title("Housing ledger active claims — run1 vs run2")
                fig.tight_layout(); fig.savefig(plots / "03_ledger_active_run1_run2.png"); plt.close(fig)

                fig, ax = plt.subplots(figsize=(8, 4.5))
                for label in ("replay_run_1", "replay_run_2"):
                    sub = yr2[yr2["run_label"] == label].sort_values("yr")
                    ax.plot(sub["yr"], sub["archived_household_count"], marker="o", label=label)
                ax.legend(); ax.set_title("Archived households — run1 vs run2")
                fig.tight_layout(); fig.savefig(plots / "04_archived_run1_run2.png"); plt.close(fig)

        # output mismatch counts by file
        if not content_df.empty:
            fig, ax = plt.subplots(figsize=(9, 4.5))
            ax.bar(content_df["relative_file_path"],
                   content_df["numeric_mismatches"] + content_df["categorical_mismatches"],
                   color="firebrick")
            ax.set_xticklabels(content_df["relative_file_path"], rotation=90, fontsize=6)
            ax.set_title("Output mismatch counts by file (run1 vs run2)")
            fig.tight_layout(); fig.savefig(plots / "05_output_mismatch_by_file.png"); plt.close(fig)

        # global mutable state risk chart
        if reg_sizes:
            inv = pd.DataFrame([{"registry": k.split(".")[-1],
                                 "reset": v.get("reset_in_reset_global_state", False),
                                 "len": v.get("len", 0)} for k, v in reg_sizes.items()])
            fig, ax = plt.subplots(figsize=(10, 4.5))
            colors = ["seagreen" if r else "firebrick" for r in inv["reset"]]
            ax.bar(inv["registry"], inv["len"], color=colors)
            ax.set_xticklabels(inv["registry"], rotation=90, fontsize=6)
            ax.set_title("Registry final size after 3 runs (green=reset, red=NOT reset)")
            fig.tight_layout(); fig.savefig(plots / "06_global_state_risk.png"); plt.close(fig)

        # phase7b vs phase8a reference comparison
        if not ref_cmp.empty:
            core = ref_cmp[ref_cmp["metric"].isin(
                ["population", "renter_households", "owner_households", "genuine_insecure",
                 "archived_household_count"])].copy()
            core["absolute_diff"] = pd.to_numeric(core["absolute_diff"], errors="coerce")
            fig, ax = plt.subplots(figsize=(9, 4.5))
            piv = core.pivot_table(index="year", columns="metric", values="absolute_diff", aggfunc="first")
            piv.plot(ax=ax, marker="o")
            ax.axhline(0, color="gray", lw=0.8)
            ax.set_title("Phase 7B vs 8A reference diffs (expect 0)")
            fig.tight_layout(); fig.savefig(plots / "07_phase7b_vs_phase8a_reference.png"); plt.close(fig)

        # remaining red flags chart
        rf = _safe_read(plots.parent / "phase8a_red_flags.csv")
        if not rf.empty:
            fig, ax = plt.subplots(figsize=(7, 4))
            sev = rf["severity"].value_counts()
            ax.bar(sev.index.astype(str), sev.values, color="darkorange")
            ax.set_title("Remaining red flags"); fig.tight_layout()
            fig.savefig(plots / "08_red_flags.png"); plt.close(fig)
    except Exception as exc:
        print(f"plot warning: {exc}")


def _write_report(diag, ref_cmp, hash_df, content_df, replay_identical, ref_matches,
                  leaked_registries, reg_sizes, phase8b_recommended, results):
    def tbl(df):
        return df.to_string(index=False) if not df.empty else "(none)"

    byte_identical = bool(not hash_df.empty and (hash_df["byte_identical_yes_no"] == "yes").all())
    ref_mism = ref_cmp[ref_cmp["match"] != True] if not ref_cmp.empty else pd.DataFrame()
    content_mism = content_df[content_df["overall_content_match_yes_no"] != "yes"] if not content_df.empty else pd.DataFrame()
    leaked_list = "\n".join(f"- `{k}` (final len={reg_sizes.get(k, {}).get('len')})" for k in leaked_registries) or "- (none)"

    report = f"""# Phase 8A — Global State, Replay, and Run-Contamination Forensics Report

**Status:** {"PASSED" if all(r['status'] == 'SUCCESS' for r in results) else "FAILED"}  
**Type:** Diagnostic-only (no model logic changed; reset_global_state not modified)  
**Base:** Phase 7B source-copy

## Answers

1. **What global mutable state exists?** See `phase8a_global_mutable_state_inventory.csv` —
   core containers (`g.POPULATION`, `g.HOUSEHOLDS`, resources), ledger mirrors, ID counters,
   log containers, event/ARIMA modifiers, `logging.LOG_DATA`, archive registry, r2o/phase
   diagnostic registries, and Python/NumPy/Salabim RNG state.

2. **What does reset_global_state currently reset?** Core containers, ID counters, ledger
   (via `reset_housing_ledger`), archive (`reset_household_archive`), r2o, 7A/7B diagnostics,
   modifiers, feedback state; `logging.LOG_DATA` via `reset_log_data`. RNG reseeded and a fresh
   Salabim Environment is built per run. (See `phase8a_reset_global_state_audit.md`.)

3. **What does it fail to reset?** The per-year diagnostic registries that are written every run
   but never cleared:
{leaked_list}
   Plus the `update_education_cyclical` monkey-patch has no double-wrap guard (safe as applied
   once per process). These are read-only observers and do **not** affect the 9 model output CSVs.

4. **Does a single Phase 8A reference run match Phase 7B?** {ref_matches} — all compared metrics
   match (see `phase8a_phase7b_reference_comparison.csv`).

5. **Do two same-seed runs in the same process match?** {replay_identical} (content-identical).

6. **Are outputs byte-identical?** {byte_identical}.

7. **If not byte-identical, are they content-identical?** Content-identical: {replay_identical}
   (cellwise, tol 1e-9; see `phase8a_output_content_comparison.csv`).

8. **Is any mismatch caused by timestamps/metadata?** {"No output CSVs embed timestamps; " if byte_identical else "Output CSVs contain data only (no timestamps); any byte differences would be content, "}outputs are pure data.

9. **Is Python random reset correctly?** Yes — reseeded to 123 before each run; run1/run2 RNG
   digests match after reset (see `phase8a_randomness_seed_audit.md`).

10. **Is numpy random reset correctly?** Yes — reseeded to 123 before each run; digests match.

11. **Are Salabim/environment objects reset correctly?** Yes — a fresh `Environment(random_seed=123)`
    is constructed per run and old salabim components/resources are dropped on container clear.

12. **Are housing ledgers reset correctly?** Yes — `reset_housing_ledger` clears active/history/
    audit buffers and re-zeros unit counters (see `phase8a_ledger_archive_reset_audit.csv`).

13. **Are household archives reset correctly?** Yes — `reset_household_archive` clears
    `ARCHIVED_HOUSEHOLDS`/events/yearly.

14. **Are education resources reset correctly?** Yes — `g.EDUCATION_RESOURCE` cleared and rebuilt
    by `Initializer` on the fresh Environment (see `phase8a_resource_reset_audit.csv`).

15. **Are logs reset correctly?** The model output logs (`logging.LOG_DATA`, `g` log containers)
    ARE reset. The auxiliary `PHASE*_LOG` diagnostic registries are NOT (item 3).

16. **Do diagnostics create side effects?** No — snapshots are read-only and consume no RNG
    (see `phase8a_diagnostic_side_effect_audit.md`).

17. **Is Phase 8B required?** {"YES" if phase8b_recommended else "NO"} — {"model outputs are already deterministic and 7B-identical, but the unreset diagnostic registries (and monkey-patch guard) should be fixed for clean in-process replay of ALL diagnostics." if phase8b_recommended else "no material leakage; proceed to Phase 9A."}

18. **What exact fixes should Phase 8B make (if required)?** Add reset calls for
    `PHASE2/3b/3c/4b/4d/5b/6b/6d/6e_LOG` and `PHASE6D_INIT_EVENTS` inside the reset path (each
    module should expose a `reset_*` helper), and add an idempotency guard to
    `wrap_update_education_cyclical` (e.g. skip if already wrapped). No model logic changes.

## Phase 7B reference comparison — mismatches (expect none)
```
{tbl(ref_mism)}
```

## Same-process replay — content mismatches (expect none)
```
{tbl(content_mism)}
```

## Output file hash comparison
```
{tbl(hash_df[['relative_file_path','byte_identical_yes_no','run1_size_bytes','run2_size_bytes']] if not hash_df.empty else hash_df)}
```

## Verdict
- Single reference run matches Phase 7B: {ref_matches}
- Same-process replay content-identical: {replay_identical}
- Outputs byte-identical: {byte_identical}
- Material output-affecting leakage: {"NONE (only diagnostic-registry hygiene)" if replay_identical else "PRESENT"}
- Phase 8B recommended: {phase8b_recommended}

## Stop
Phase 8A is complete (diagnostic-only). No fixes were implemented. Do NOT implement reset-state
fixes, runner/test harness, profiling, scenarios, validation, paper pack, or ML here.
"""
    (diag / "phase8a_global_state_replay_forensics_report.md").write_text(report, encoding="utf-8")


def _write_change_log(diag, replay_identical):
    txt = f"""# Phase 8A Change Log

| File | Diagnostic-only? | Reason |
|------|------------------|--------|
| `mastercode02_phase8a_diagnostics.py` | yes (new) | Read-only state snapshots + RNG/registry digests (no RNG draws, no mutation) |
| `mastercode02_phase8a_postrun.py` | yes (new) | Replay/reference comparisons, hash/content diffs, leakage/reset audits, inventories, plots, report |
| `notebooks/run_phase8a.py` | yes (new) | Three same-process runs (reference + replay1 + replay2); reset_global_state copied VERBATIM from Phase 7B (not fixed) |

## Diagnostic-only confirmation
No model module was edited. `reset_global_state` was copied verbatim from Phase 7B and NOT
refactored. No probabilities/housing/education/fertility/mortality/immigration/employment/transit/
ML/scenario logic changed.

## Do any diagnostics consume RNG?
No. Snapshots use `random.getstate()` / `np.random.get_state()` (state reads; no draws) and are
taken outside the model's RNG-consuming code paths.

## Did any run outputs change versus Phase 7B?
No — the single reference run is content-identical to Phase 7B (see reference comparison).
Same-process replay run1 vs run2 content-identical: {replay_identical}.
"""
    (diag / "phase8a_change_log.md").write_text(txt, encoding="utf-8")
