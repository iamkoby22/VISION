# mastercode02_r5_arima.py
# R5 (ARIMA Rebuild and Out-of-Sample Historical Forecast Validation).
#
# Replaces the pre-remediation WorldManager/EconomicManager._train_models()
# pattern, which trained ARIMA(1,1,1) on HISTORICAL_MACRO_DATA/
# HISTORICAL_ECONOMIC_DATA spanning 'Year': list(range(2000,2024)) -- the
# COMPLETE 2000-2023 evaluation window itself -- then consumed
# forecast_data['mean'].iloc[year] positionally, so simulated year t received
# the model's forecast for calendar ~2024+t, never the year actually being
# simulated (RESSEARCH/22_PHASE_V2_ARIMA_FORENSICS, RESSEARCH/24_PHASE_R1_
# CORRECTION_CONTRACT/09_r1_arima_scientific_contract.md).
#
# This module trains exclusively on the F_1999 information boundary (RESSEARCH/
# 29_PHASE_R4_PRE2000_ARIMA_ACQUISITION/normalized/*_train_pre2000.csv, all
# years <= 1999, R4/R4.1-acquired), forecasts calendar 2000-2023 explicitly,
# and exposes an explicit calendar_year-keyed lookup. No raw positional
# ("forecast[year_index]") consumption is possible through this module's
# public interface.
#
# Consolidates the previously-duplicated 30-Yr Mortgage forecast (two
# independent ARIMA(1,1,1) fits/draws in the pre-remediation code, one in
# WorldManager for the owner-preference modifier, one in EconomicManager for
# the mortgage_rate level -- R1 AD-03 / 11_r1_mortgage_duplicate_path_
# decision.md) into ONE fit and ONE stochastic draw per calendar year, shared
# by both existing, unmodified consumer formulas.
#
# Does NOT alter: any decision-node formula, any base rate table, any city
# calibration value, ARIMA order (still (1,1,1), the existing approved
# architecture -- see RESSEARCH/30_PHASE_R5_ARIMA_REBUILD/06_r5_model_order_
# selection_evidence.csv), or the stochastic-perturbation mechanism
# (np.random.normal(loc=mean, scale=se), unchanged).

import os
import csv
import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_TRAIN_DATA_DIR = os.path.join(_THIS_DIR, "r5_arima_training_data")

TRAINING_END_YEAR = 1999
FORECAST_START_YEAR = 2000
FORECAST_END_YEAR = 2023  # inclusive
FORECAST_HORIZON = FORECAST_END_YEAR - FORECAST_START_YEAR + 1  # 24
ARIMA_ORDER = (1, 1, 1)

# Maps the exact runtime variable name (as used in mastercode02_agents.py) to
# its R4/R4.1-acquired training-file basename. Employment Rate is deliberately
# ABSENT -- confirmed dead code (Phase V1/V2: trained pre-remediation, never
# consumed by any decision node); no pre-2000 data was acquired for it and it
# must not be revived here.
SERIES_TRAIN_FILES = {
    "Mortality Rate": "MORT_train_pre2000.csv",
    "Birth Rate": "BIRTH_train_pre2000.csv",
    "Top Tax Rate": "TAX_train_pre2000.csv",
    "Salary Inflation": "SALARY_train_pre2000.csv",
    "Cost Inflation (CPI)": "CPI_train_pre2000.csv",
    "30-Yr Mortgage": "MORTGAGE_train_pre2000.csv",
}

# Source-class disclosure per RESSEARCH/29_PHASE_R4_PRE2000_ARIMA_ACQUISITION/
# 28_r4_1_final_six_series_acceptance.csv -- Mortality is the one series on an
# APPROVED SECONDARY source (World Bank SP.DYN.CDRT.IN), not a direct CDC/NCHS
# primary series (blocked by infrastructure access, not a data-quality choice;
# see RESSEARCH/29_.../11_r4_1_mortality_primary_source_report.md). All others
# are ACCEPTED_FOR_R5 primary sources.
SERIES_SOURCE_CLASS = {
    "Mortality Rate": "APPROVED_SECONDARY_SOURCE (World Bank SP.DYN.CDRT.IN)",
    "Birth Rate": "PRIMARY_SOURCE (CDC/NCHS, data.cdc.gov e6fc-ccez)",
    "Top Tax Rate": "PRIMARY_SOURCE (Tax Foundation historical income tax rates table)",
    "Salary Inflation": "PRIMARY_SOURCE (BLS CES0500000008)",
    "Cost Inflation (CPI)": "PRIMARY_SOURCE (BLS CUUR0000SA0)",
    "30-Yr Mortgage": "PRIMARY_SOURCE (Freddie Mac PMMS, direct)",
}


class R5TrainingWindowViolation(Exception):
    """Raised instead of fitting if any training observation is dated >= 2000.
    Never silently excluded -- a hard blocker, per RESSEARCH/24_PHASE_R1_
    CORRECTION_CONTRACT and the R5 spec's explicit 'prove they are not passed
    to the fitting function' requirement."""


def _load_training_series(variable_name):
    path = os.path.join(_TRAIN_DATA_DIR, SERIES_TRAIN_FILES[variable_name])
    years, values = [], []
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            year = int(row["year"])
            if year > TRAINING_END_YEAR:
                raise R5TrainingWindowViolation(
                    f"{variable_name}: training file {path} contains year {year} "
                    f"> {TRAINING_END_YEAR} -- refusing to fit."
                )
            years.append(year)
            values.append(float(row["value"]))
    if len(set(years)) != len(years):
        raise R5TrainingWindowViolation(f"{variable_name}: duplicate year in training file {path}")
    years_sorted, values_sorted = zip(*sorted(zip(years, values)))
    return pd.Series(list(values_sorted), index=list(years_sorted))


# Module-level cache: one fit per series per process lifetime (each VISION
# Core run is its own OS process via tools/run_mastercode02.py, so this cache
# never persists across separate simulation runs).
_forecast_cache = {}


def _reset_caches_for_testing():
    """Test-only hook -- clears all module-level caches so repeated in-process
    unit tests (as opposed to separate run_mastercode02.py subprocess
    invocations) do not see stale state. Never called by runtime code."""
    _forecast_cache.clear()
    _mortgage_draw_cache.clear()


def _fit_and_forecast(variable_name):
    if variable_name in _forecast_cache:
        return _forecast_cache[variable_name]
    series = _load_training_series(variable_name)
    if int(series.index.max()) > TRAINING_END_YEAR:
        raise R5TrainingWindowViolation(f"{variable_name}: max training year {series.index.max()} > {TRAINING_END_YEAR}")
    model = ARIMA(series.values, order=ARIMA_ORDER).fit()
    pred = model.get_forecast(steps=FORECAST_HORIZON)
    mean = np.asarray(pred.predicted_mean)
    se = np.asarray(pred.se_mean)
    mean_by_year = {FORECAST_START_YEAR + i: float(mean[i]) for i in range(FORECAST_HORIZON)}
    se_by_year = {FORECAST_START_YEAR + i: float(se[i]) for i in range(FORECAST_HORIZON)}
    result = {
        "mean_by_year": mean_by_year,
        "se_by_year": se_by_year,
        # base_value conventions are the SAME FORMULAS as the pre-remediation
        # code (last training observation for the rate-modifier series;
        # training-window mean for the mortgage series) -- only the WINDOW
        # they are computed over is corrected (was 2000-2023, now <=1999),
        # per RESSEARCH/30_PHASE_R5_ARIMA_REBUILD/10_r5_normalization_
        # semantics.csv. Both are exposed; each consumer uses the one it
        # already used pre-remediation.
        "base_value_last_train_obs": float(series.iloc[-1]),
        "base_value_train_mean": float(series.mean()),
        "training_start_year": int(series.index.min()),
        "training_end_year": int(series.index.max()),
        "n_train_obs": int(len(series)),
        "arima_order": ARIMA_ORDER,
        "source_class": SERIES_SOURCE_CLASS[variable_name],
    }
    _forecast_cache[variable_name] = result
    return result


def get_forecast(variable_name, calendar_year):
    """Explicit calendar_year -> (mean, se, base_value_last_train_obs,
    base_value_train_mean) lookup. Raises KeyError for any calendar_year
    outside the supported 2000-2023 forecast range -- this module has no
    concept of a raw positional index and cannot silently return the wrong
    year's value."""
    data = _fit_and_forecast(variable_name)
    if calendar_year not in data["mean_by_year"]:
        raise KeyError(
            f"R5: no forecast for '{variable_name}' at calendar_year={calendar_year} "
            f"(supported range {FORECAST_START_YEAR}-{FORECAST_END_YEAR})"
        )
    return (
        data["mean_by_year"][calendar_year],
        data["se_by_year"][calendar_year],
        data["base_value_last_train_obs"],
        data["base_value_train_mean"],
    )


def get_forecast_metadata(variable_name):
    """Non-forecast metadata (training window, n_obs, ARIMA order, source
    class) for provenance/reporting -- triggers the same cached fit."""
    return _fit_and_forecast(variable_name)


# --- Consolidated 30-Yr Mortgage: ONE stochastic draw per calendar year ---
# R1 AD-03: the pre-remediation code fit and drew this series independently
# in both WorldManager (owner-preference modifier) and EconomicManager
# (mortgage_rate level). This cache guarantees both consumers see the
# identical stochastic realization for a given calendar year, and that
# np.random.normal is called exactly ONCE per calendar year for this series
# (previously twice) -- an intended, documented reduction in RNG consumption,
# not an accidental side effect (see RESSEARCH/30_PHASE_R5_ARIMA_REBUILD/
# 22_r5_rng_behavior_audit.csv).
_mortgage_draw_cache = {}


def get_consolidated_mortgage_draw(calendar_year, rng=None):
    """Returns the single shared stochastic 30-Yr Mortgage draw for
    calendar_year, computing it on first access that year and returning the
    cached value to any subsequent caller the same year (regardless of
    WorldManager/EconomicManager registration or process() execution order,
    which this module does not alter)."""
    if calendar_year in _mortgage_draw_cache:
        return _mortgage_draw_cache[calendar_year]
    mean, se, _base_last, _base_mean = get_forecast("30-Yr Mortgage", calendar_year)
    generator = rng if rng is not None else np.random
    draw = float(generator.normal(loc=mean, scale=se))
    _mortgage_draw_cache[calendar_year] = draw
    return draw
