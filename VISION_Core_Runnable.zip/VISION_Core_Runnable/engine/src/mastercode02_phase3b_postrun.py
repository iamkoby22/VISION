"""Phase 3B post-run analysis: comparison, plots, reports."""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from mastercode02_phase3b_diagnostics import PHASE3B_LOG
from mastercode02_config_and_rates import FERTILITY_PROBABILITY_SCALE, TARGET_CRUDE_BIRTH_RATE_PER_1000


def write_calibration_factor_artifacts(diag_dir: Path) -> None:
    phase3a = Path(__file__).resolve().parents[2] / "phase3a_fertility_forensics_20260629_184040" / "diagnostics" / "phase3a_expected_vs_actual_births.csv"
    df = pd.read_csv(phase3a)
    df = df[df["expected_cbr_per_1000"] > 0].copy()
    df["scale_by_year"] = TARGET_CRUDE_BIRTH_RATE_PER_1000 / df["expected_cbr_per_1000"]
    primary = df[df["year"] >= 1]
    median_scale = float(primary["scale_by_year"].median())
    by_year = df[["year", "expected_cbr_per_1000", "actual_cbr_per_1000", "scale_by_year"]].copy()
    by_year["target_cbr"] = TARGET_CRUDE_BIRTH_RATE_PER_1000
    by_year["used_in_median"] = by_year["year"] >= 1
    by_year.to_csv(diag_dir / "phase3b_calibration_factor_by_year.csv", index=False)
    manifest = {
        "target_crude_birth_rate_per_1000": TARGET_CRUDE_BIRTH_RATE_PER_1000,
        "fertility_probability_scale": FERTILITY_PROBABILITY_SCALE,
        "method": "median(TARGET_CBR / expected_cbr_per_1000) over Phase 3A years 1-5",
        "source_file": str(phase3a),
        "years_used_for_median": [int(y) for y in primary["year"].tolist()],
        "scales_by_year": {int(r.year): float(r.scale_by_year) for r in by_year.itertuples()},
        "median_scale_years_1_to_5": median_scale,
        "config_constant_matches_median": abs(median_scale - FERTILITY_PROBABILITY_SCALE) < 1e-12,
        "raw_fertility_table_preserved": True,
    }
    (diag_dir / "phase3b_calibration_factor.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")


def write_diagnostic_csvs(diag_dir: Path, annual: pd.DataFrame) -> pd.DataFrame:
    metrics = pd.DataFrame(PHASE3B_LOG["calibration_metrics"])
    # Prefer annual births for actuals (authoritative) if snapshot timing differs
    births_map = dict(zip(annual["Year"], annual["No of births"]))
    pop_map = dict(zip(annual["Year"], annual["Population"]))
    if len(metrics):
        metrics["actual_births"] = metrics["year"].map(births_map)
        metrics["population"] = metrics["year"].map(pop_map)
        metrics["actual_cbr_per_1000"] = metrics.apply(
            lambda r: (r["actual_births"] / r["population"] * 1000) if r["population"] else 0, axis=1
        )
        metrics["births_per_fertile_female"] = metrics.apply(
            lambda r: (r["actual_births"] / r["fertile_female_count"]) if r["fertile_female_count"] else 0, axis=1
        )
        metrics.to_csv(diag_dir / "phase3b_fertility_calibration_metrics.csv", index=False)
    else:
        metrics = pd.DataFrame()

    trace = pd.DataFrame(PHASE3B_LOG["birth_trace"])
    trace.to_csv(diag_dir / "phase3b_birth_trace_sample.csv", index=False)

    imm = pd.DataFrame(PHASE3B_LOG["immigration_by_year"])
    imm_map = dict(zip(imm["year"], imm["immigration_count"])) if len(imm) else {}
    rows = []
    for i, row in annual.iterrows():
        y = int(row["Year"])
        pop_end = int(row["Population"])
        pop_start = int(annual.iloc[i - 1]["Population"]) if i > 0 else pop_end
        births = int(row["No of births"])
        deaths = int(row["No. of Deaths"])
        immigration = int(imm_map.get(y, 0))
        explained = births - deaths + immigration
        delta = pop_end - pop_start
        rows.append({
            "year": y,
            "population_start": pop_start,
            "births": births,
            "deaths": deaths,
            "immigration": immigration,
            "unexplained_delta": delta - explained,
            "population_end": pop_end,
            "population_change": delta,
        })
    decomp = pd.DataFrame(rows)
    decomp.to_csv(diag_dir / "phase3b_population_growth_decomposition.csv", index=False)
    return metrics, decomp, trace


def compare_phase2(phase3b_out: Path, phase2_out: Path, metrics: pd.DataFrame) -> pd.DataFrame:
    p3 = pd.read_csv(phase3b_out / "mastercode02_output_phase3b_seed123_annual_summary.csv")
    p2 = pd.read_csv(phase2_out / "mastercode02_output_phase2_seed123_annual_summary.csv")
    p3s = pd.read_csv(phase3b_out / "mastercode02_output_phase3b_seed123_scores_summary.csv")
    p2s = pd.read_csv(phase2_out / "mastercode02_output_phase2_seed123_scores_summary.csv")
    p2_emp_path = phase2_out.parent / "diagnostics" / "phase2_employment_metrics.csv"
    p2_emp = pd.read_csv(p2_emp_path) if p2_emp_path.exists() else pd.DataFrame()

    # Working-age rates from final population datasheets (year 5 only for microdata)
    def wa_rate(path: Path) -> float:
        if not path.exists():
            return float("nan")
        pop = pd.read_csv(path)
        wa = pop[(pop["age"] >= 18) & (pop["age"] < 65)]
        if len(wa) == 0:
            return float("nan")
        return float((wa["employment_status"] == "Employed").sum() / len(wa))

    wa3_final = wa_rate(phase3b_out / "mastercode02_output_phase3b_seed123_population_datasheet.csv")
    wa2_final = wa_rate(phase2_out / "mastercode02_output_phase2_seed123_population_datasheet.csv")

    rows = []
    for y in range(6):
        r3 = p3[p3["Year"] == y].iloc[0]
        r2 = p2[p2["Year"] == y].iloc[0]
        pairs = [
            ("population", float(r2["Population"]), float(r3["Population"])),
            ("births", float(r2["No of births"]), float(r3["No of births"])),
            ("deaths", float(r2["No. of Deaths"]), float(r3["No. of Deaths"])),
            ("cbr_per_1000", float(r2["No of births"]) / float(r2["Population"]) * 1000,
             float(r3["No of births"]) / float(r3["Population"]) * 1000),
            ("cdr_per_1000", float(r2["No. of Deaths"]) / float(r2["Population"]) * 1000,
             float(r3["No. of Deaths"]) / float(r3["Population"]) * 1000),
            ("employment_rate", float(r2["Employment Rate"]), float(r3["Employment Rate"])),
            ("rental_vacancy", float(r2["Rental_Vacancy_Rate"]), float(r3["Rental_Vacancy_Rate"])),
            ("overall_vacancy", float(r2["Overall_Vacancy_Rate"]), float(r3["Overall_Vacancy_Rate"])),
            ("housing_insecure", float(r2["Housing_Insecure_HH_Count"]), float(r3["Housing_Insecure_HH_Count"])),
            ("avg_income", float(r2["Avg Annual Income"]), float(r3["Avg Annual Income"])),
        ]
        for label, v2, v3 in pairs:
            rows.append({
                "year": y, "metric": label, "phase2_value": v2, "phase3b_value": v3,
                "absolute_diff": v3 - v2,
                "relative_diff_pct": ((v3 - v2) / v2 * 100) if v2 != 0 else (0 if v3 == 0 else np.nan),
            })
        wa2 = float(p2_emp.loc[p2_emp["year"] == y, "employment_rate_working_age_18_64"].iloc[0]) if len(p2_emp) and y in set(p2_emp["year"]) else (wa2_final if y == 5 else np.nan)
        wa3 = wa3_final if y == 5 else np.nan
        rows.append({
            "year": y, "metric": "working_age_employment_rate",
            "phase2_value": wa2, "phase3b_value": wa3,
            "absolute_diff": (wa3 - wa2) if pd.notna(wa2) and pd.notna(wa3) else np.nan,
            "relative_diff_pct": ((wa3 - wa2) / wa2 * 100) if pd.notna(wa2) and pd.notna(wa3) and wa2 != 0 else np.nan,
        })
        for label, col in [("economic_index", "economic_index"), ("transport_index", "transport_index")]:
            v2 = float(p2s.loc[p2s["year"] == y, col].iloc[0])
            v3 = float(p3s.loc[p3s["year"] == y, col].iloc[0])
            rows.append({
                "year": y, "metric": label, "phase2_value": v2, "phase3b_value": v3,
                "absolute_diff": v3 - v2,
                "relative_diff_pct": ((v3 - v2) / v2 * 100) if v2 != 0 else 0,
            })
    return pd.DataFrame(rows)


def generate_plots(
    diag_dir: Path,
    comparison: pd.DataFrame,
    metrics: pd.DataFrame,
    decomp: pd.DataFrame,
    trace: pd.DataFrame,
    red_flags: pd.DataFrame,
) -> None:
    pdir = diag_dir / "phase3b_plots"
    pdir.mkdir(parents=True, exist_ok=True)

    def series(metric):
        sub = comparison[comparison["metric"] == metric].sort_values("year")
        return sub["year"], sub["phase2_value"], sub["phase3b_value"]

    y, p2b, p3b = series("births")
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(y, p2b, "o--", label="Phase 2")
    ax.plot(y, p3b, "s-", label="Phase 3B")
    ax.set_title("Births by Year: Phase 2 vs Phase 3B")
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(pdir / "01_births_comparison.png", dpi=150)
    plt.close(fig)

    y, p2p, p3p = series("population")
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(y, p2p, "o--", label="Phase 2")
    ax.plot(y, p3p, "s-", label="Phase 3B")
    ax.set_title("Population by Year: Phase 2 vs Phase 3B")
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(pdir / "02_population_comparison.png", dpi=150)
    plt.close(fig)

    y, p2c, p3c = series("cbr_per_1000")
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(y, p2c, "o--", label="Phase 2 CBR")
    ax.plot(y, p3c, "s-", label="Phase 3B CBR")
    ax.axhline(12.0, color="gray", linestyle=":", label="Target 12")
    ax.axhline(10.0, color="green", linestyle=":", alpha=0.5)
    ax.axhline(14.0, color="green", linestyle=":", alpha=0.5, label="Target band 10–14")
    ax.set_title("Crude Birth Rate: Phase 2 vs Phase 3B")
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(pdir / "03_cbr_comparison.png", dpi=150)
    plt.close(fig)

    if len(metrics):
        fig, ax = plt.subplots(figsize=(8, 5))
        ax.plot(metrics["year"], metrics["raw_expected_cbr_per_1000"], "o--", label="Raw expected CBR")
        ax.plot(metrics["year"], metrics["scaled_expected_cbr_per_1000"], "s--", label="Scaled expected CBR")
        ax.plot(metrics["year"], metrics["actual_cbr_per_1000"], "^-", label="Actual CBR")
        ax.axhline(12.0, color="gray", linestyle=":")
        ax.set_title("Raw vs Scaled Expected vs Actual CBR")
        ax.legend()
        ax.grid(True, alpha=0.3)
        fig.tight_layout()
        fig.savefig(pdir / "04_raw_scaled_actual_cbr.png", dpi=150)
        plt.close(fig)

        fig, ax = plt.subplots(figsize=(8, 5))
        ax.plot(metrics["year"], metrics["births_per_fertile_female"], "o-")
        ax.set_title("Births per Fertile Female by Year")
        ax.grid(True, alpha=0.3)
        fig.tight_layout()
        fig.savefig(pdir / "05_births_per_fertile_female.png", dpi=150)
        plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.bar(decomp["year"], decomp["births"], label="Births", alpha=0.8)
    ax.bar(decomp["year"], -decomp["deaths"], label="Deaths", alpha=0.8)
    ax.bar(decomp["year"], decomp["immigration"], bottom=decomp["births"], label="Immigration", alpha=0.6)
    ax.set_title("Population Growth Decomposition (Phase 3B)")
    ax.legend()
    fig.tight_layout()
    fig.savefig(pdir / "06_population_growth_decomposition.png", dpi=150)
    plt.close(fig)

    if len(trace) and "final_scaled_birth_probability" in trace.columns:
        fig, ax = plt.subplots(figsize=(8, 5))
        ax.hist(trace["final_scaled_birth_probability"].dropna(), bins=30, color="C0", edgecolor="white")
        ax.set_title("Final Scaled Birth Probability Distribution (births)")
        ax.set_xlabel("final_scaled_birth_probability")
        fig.tight_layout()
        fig.savefig(pdir / "07_scaled_birth_prob_distribution.png", dpi=150)
        plt.close(fig)

    if len(red_flags):
        fig, ax = plt.subplots(figsize=(8, 5))
        sev = red_flags["severity"].value_counts()
        ax.bar(sev.index.astype(str), sev.values, color=["C3", "C1", "C2"][:len(sev)])
        ax.set_title("Remaining Red Flags by Severity")
        fig.tight_layout()
        fig.savefig(pdir / "08_remaining_red_flags.png", dpi=150)
        plt.close(fig)


def build_red_flags(metrics: pd.DataFrame, comparison: pd.DataFrame, annual: pd.DataFrame) -> pd.DataFrame:
    flags = []
    active = annual[annual["Year"] >= 1]
    avg_cbr = float((active["No of births"] / active["Population"] * 1000).mean())
    in_band = 10.0 <= avg_cbr <= 14.0
    flags.append({
        "severity": "LOW" if in_band else "HIGH",
        "category": "fertility_calibration",
        "finding": f"Average CBR years 1–5 = {avg_cbr:.2f} per 1,000",
        "detail": "Target band 10–14; scale={:.6f}".format(FERTILITY_PROBABILITY_SCALE),
    })
    # Births should decrease vs phase 2
    birth_rows = comparison[(comparison["metric"] == "births") & (comparison["year"] >= 1)]
    if len(birth_rows) and (birth_rows["phase3b_value"] < birth_rows["phase2_value"]).all():
        flags.append({
            "severity": "LOW", "category": "births_reduced",
            "finding": "Births decreased in all years 1–5 vs Phase 2",
            "detail": "Expected after fertility scale",
        })
    else:
        flags.append({
            "severity": "HIGH", "category": "births_reduced",
            "finding": "Births did not decrease uniformly vs Phase 2",
            "detail": "Investigate calibration application",
        })
    pop_end_diff = float(
        comparison[(comparison["metric"] == "population") & (comparison["year"] == 5)]["absolute_diff"].iloc[0]
    )
    flags.append({
        "severity": "MEDIUM", "category": "population_path",
        "finding": f"Year 5 population difference vs Phase 2 = {pop_end_diff:.0f}",
        "detail": "Downstream of fewer births",
    })
    flags.append({
        "severity": "MEDIUM", "category": "deferred",
        "finding": "Marital classification case-sensitivity not fixed",
        "detail": "Deferred to Phase 3C+",
    })
    flags.append({
        "severity": "MEDIUM", "category": "deferred",
        "finding": "Community College unused route not fixed",
        "detail": "Deferred",
    })
    flags.append({
        "severity": "MEDIUM", "category": "deferred",
        "finding": "Bus refusal / transit saturation not fixed",
        "detail": "Deferred",
    })
    return pd.DataFrame(flags)


def build_upgrade_recommendations(avg_cbr: float) -> pd.DataFrame:
    return pd.DataFrame([
        {"priority": 1, "phase": "3C", "area": "fine_tune_fertility_scale",
         "rationale": f"Avg CBR={avg_cbr:.2f}; adjust scale only if outside 10–14"},
        {"priority": 2, "phase": "3C", "area": "marital_status_classification",
         "rationale": "Case-sensitive 'Married' check still routes 'Now married' to Unmarried table"},
        {"priority": 3, "phase": "3C", "area": "education_routing",
         "rationale": "Community College unused"},
        {"priority": 4, "phase": "3C", "area": "transit_capacity",
         "rationale": "Bus refusal remains high"},
        {"priority": 5, "phase": "3C", "area": "housing_metric_definitions",
         "rationale": "Rental vacancy / insecure HH cliff"},
    ])


def write_report(
    diag_dir: Path,
    run_dir: Path,
    passed: bool,
    metrics: pd.DataFrame,
    comparison: pd.DataFrame,
    avg_cbr: float,
) -> None:
    birth_cmp = comparison[(comparison["metric"] == "births")].sort_values("year")
    cbr_cmp = comparison[(comparison["metric"] == "cbr_per_1000")].sort_values("year")
    pop5 = comparison[(comparison["metric"] == "population") & (comparison["year"] == 5)].iloc[0]
    lines = [
        "# Phase 3B Fertility Calibration Report",
        "",
        f"**Run:** `{run_dir.name}`",
        f"**Status:** {'PASSED' if passed else 'FAILED'}",
        "",
        "## Calibration",
        "",
        f"- Target CBR: `{TARGET_CRUDE_BIRTH_RATE_PER_1000}` per 1,000",
        f"- Fertility probability scale: `{FERTILITY_PROBABILITY_SCALE}`",
        "- Method: median(TARGET / expected_cbr) over Phase 3A years 1–5",
        "- Raw fertility table: **preserved**",
        "",
        "## Results",
        "",
        f"- Average CBR years 1–5: **{avg_cbr:.2f}** per 1,000 (target band 10–14)",
        f"- Year 5 population Phase 2 → Phase 3B: {pop5['phase2_value']:.0f} → {pop5['phase3b_value']:.0f} (Δ {pop5['absolute_diff']:.0f})",
        "",
        "## Births by year (Phase 2 vs Phase 3B)",
        "",
        "| Year | Phase 2 | Phase 3B | Diff |",
        "|-----:|--------:|---------:|-----:|",
    ]
    for _, r in birth_cmp.iterrows():
        lines.append(f"| {int(r['year'])} | {r['phase2_value']:.0f} | {r['phase3b_value']:.0f} | {r['absolute_diff']:.0f} |")
    lines += [
        "",
        "## CBR by year (Phase 2 vs Phase 3B)",
        "",
        "| Year | Phase 2 CBR | Phase 3B CBR |",
        "|-----:|------------:|-------------:|",
    ]
    for _, r in cbr_cmp.iterrows():
        lines.append(f"| {int(r['year'])} | {r['phase2_value']:.2f} | {r['phase3b_value']:.2f} |")
    lines += [
        "",
        "## Pass criteria notes",
        "",
        "- Non-fertility model logic unchanged",
        "- Scale applied after ARIMA/event/marriage multipliers, clamped to [0, 1]",
        "- See `phase3b_change_log.md` and `phase3b_red_flags.csv`",
        "",
        "## Recommended Phase 3C",
        "",
        "1. Fine-tune scale only if CBR outside band",
        "2. Marital classification fix",
        "3. Education routing (Community College)",
        "4. Transit capacity",
        "5. Housing metric definitions",
    ]
    (diag_dir / "phase3b_fertility_calibration_report.md").write_text("\n".join(lines), encoding="utf-8")


def run_post_analysis(run_dir: Path, phase2_dir: Path) -> bool:
    diag_dir = run_dir / "diagnostics"
    out_dir = run_dir / "outputs"
    write_calibration_factor_artifacts(diag_dir)

    annual = pd.read_csv(out_dir / "mastercode02_output_phase3b_seed123_annual_summary.csv")
    metrics, decomp, trace = write_diagnostic_csvs(diag_dir, annual)
    comparison = compare_phase2(out_dir, phase2_dir / "outputs", metrics)
    comparison.to_csv(diag_dir / "phase3b_phase2_comparison.csv", index=False)

    active = annual[annual["Year"] >= 1]
    avg_cbr = float((active["No of births"] / active["Population"] * 1000).mean())
    red = build_red_flags(metrics, comparison, annual)
    red.to_csv(diag_dir / "phase3b_red_flags.csv", index=False)
    build_upgrade_recommendations(avg_cbr).to_csv(diag_dir / "phase3b_upgrade_recommendations.csv", index=False)

    generate_plots(diag_dir, comparison, metrics, decomp, trace, red)
    in_band = 10.0 <= avg_cbr <= 14.0
    births_down = (
        comparison[(comparison["metric"] == "births") & (comparison["year"] >= 1)]["phase3b_value"]
        < comparison[(comparison["metric"] == "births") & (comparison["year"] >= 1)]["phase2_value"]
    ).all()
    passed = bool(in_band and births_down and len(trace) > 0)
    write_report(diag_dir, run_dir, passed, metrics, comparison, avg_cbr)
    return passed
