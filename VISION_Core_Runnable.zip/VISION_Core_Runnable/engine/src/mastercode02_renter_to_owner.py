"""Phase 6E controlled renter-to-owner transition (stock-constrained, low-frequency)."""
from __future__ import annotations

import random

import mastercode02_globals as g
from mastercode02_config_and_rates import (
    HOUSING_STOCK,
    HOUSING_MARKET_TARGETS,
    RENTER_TO_OWNER_ENABLED,
    RENTER_TO_OWNER_ANNUAL_PROBABILITY,
    RENTER_TO_OWNER_MAX_ANNUAL_RATE,
    RENTER_TO_OWNER_REQUIRE_AVAILABLE_FOR_SALE,
    RENTER_TO_OWNER_REQUIRE_LEDGER_RENTAL_CLAIM,
)
from mastercode02_housing_ledger import (
    get_household_housing_claim,
    get_housing_available_count,
    stock_vacancy_snapshot,
    transfer_household_housing_claim,
)


# Cheapest for-sale first
_FOR_SALE_ORDER = [
    "For-Sale: Starter",
    "For-Sale: Mid-Range",
    "For-Sale: High-End",
]

PHASE6E_R2O_EVENTS: list = []
PHASE6E_R2O_SUMMARY: list = []


def reset_r2o_diagnostics() -> None:
    PHASE6E_R2O_EVENTS.clear()
    PHASE6E_R2O_SUMMARY.clear()


def _forsale_available_total() -> int:
    return sum(get_housing_available_count(u) for u in _FOR_SALE_ORDER)


def _select_affordable_forsale(income: float, savings, savings_known: bool) -> tuple[str | None, str]:
    """Try cheapest available for-sale unit household can afford."""
    min_dp = float(HOUSING_MARKET_TARGETS.get("min_down_payment", 10000))
    for unit in _FOR_SALE_ORDER:
        if get_housing_available_count(unit) <= 0:
            continue
        value = float(HOUSING_STOCK[unit].get("base_value", 0) or 0)
        needed_dp = max(min_dp, value * 0.20)
        loan = max(0.0, value - needed_dp)
        annual_own_cost = loan * 0.06
        if income <= 0:
            continue
        if annual_own_cost / income > 0.30:
            continue
        if savings_known and savings < needed_dp:
            continue
        return unit, ""
    return None, "no_affordable_available_forsale"


def evaluate_eligibility(hh_id, hh: dict) -> dict:
    """Return eligibility assessment dict."""
    members = hh.get("members", []) or []
    claim = get_household_housing_claim(hh_id)
    income = float(hh.get("total_income", 0) or 0)
    required = float(hh.get("required_cost", 0) or 0)
    has_savings_key = "savings_balance" in hh
    savings = float(hh.get("savings_balance", 0) or 0) if has_savings_key else None
    tenure = hh.get("tenure")
    result = {
        "eligible": False,
        "failure_reason": "",
        "income": income,
        "savings_if_available": savings if has_savings_key else "",
        "required_cost": required,
        "affordability_pass": False,
        "down_payment_pass": False,
        "savings_known": has_savings_key,
        "target_unit": None,
        "target_category": "",
        "prior_unit": (claim or {}).get("housing_unit_name", "") if claim else "",
        "notes": "",
    }

    if len(members) == 0:
        result["failure_reason"] = "empty_household"
        return result
    if tenure != "Renter":
        result["failure_reason"] = "not_renter"
        return result
    if tenure == "Insecure" or tenure == "Owner":
        result["failure_reason"] = "wrong_tenure"
        return result
    if RENTER_TO_OWNER_REQUIRE_LEDGER_RENTAL_CLAIM:
        if not claim or claim.get("tenure_type") != "Renter" or claim.get("housing_category") != "Rental":
            result["failure_reason"] = "no_rental_ledger_claim"
            return result
    if RENTER_TO_OWNER_REQUIRE_AVAILABLE_FOR_SALE and _forsale_available_total() <= 0:
        result["failure_reason"] = "blocked_no_for_sale_stock"
        return result
    if income <= 0 and required <= 0:
        result["failure_reason"] = "blocked_missing_finance_data"
        return result
    if income <= 0:
        result["failure_reason"] = "blocked_missing_finance_data"
        return result

    # Affordability: income >= required_cost; not extreme burden if flagged
    afford_ok = income >= required if required > 0 else income > 0
    if hh.get("is_cost_burdened") and income < required * 1.1:
        afford_ok = False
    result["affordability_pass"] = afford_ok
    if not afford_ok:
        result["failure_reason"] = "blocked_affordability"
        return result

    # Down-payment / unit selection
    if has_savings_key:
        unit, why = _select_affordable_forsale(income, savings, True)
        if unit is None:
            # Could be stock or down-payment
            if _forsale_available_total() <= 0:
                result["failure_reason"] = "blocked_no_for_sale_stock"
            else:
                result["failure_reason"] = "blocked_down_payment"
                result["down_payment_pass"] = False
            return result
        result["down_payment_pass"] = True
        result["target_unit"] = unit
        result["target_category"] = HOUSING_STOCK[unit]["type"]
        result["eligible"] = True
        result["notes"] = "savings_known_down_payment_gate"
        return result

    # Savings unknown: income-screen only; still pick cheapest affordable unit by income
    unit, why = _select_affordable_forsale(income, 0, False)
    if unit is None:
        result["failure_reason"] = why or "blocked_affordability"
        if _forsale_available_total() <= 0:
            result["failure_reason"] = "blocked_no_for_sale_stock"
        return result
    result["down_payment_pass"] = False
    result["target_unit"] = unit
    result["target_category"] = HOUSING_STOCK[unit]["type"]
    result["eligible"] = True
    result["notes"] = "savings_unknown_income_screen_only"
    return result


def process_renter_to_owner(year: int) -> dict:
    """Annual controlled R2O. Call from HousingManager after finance fields available."""
    if not RENTER_TO_OWNER_ENABLED:
        return {}

    snap_start = stock_vacancy_snapshot()
    avail_start = snap_start["for_sale_available"]

    renters = [
        hh for hh in g.HOUSEHOLDS.values()
        if hh.get("tenure") == "Renter" and (hh.get("members") or [])
    ]
    n_renters = len(renters)
    annual_cap = max(0, int(n_renters * RENTER_TO_OWNER_MAX_ANNUAL_RATE))
    # Cap also by available for-sale stock
    annual_cap = min(annual_cap, max(0, int(avail_start)))

    counts = {
        "year": year,
        "renter_households": n_renters,
        "owner_households": sum(1 for h in g.HOUSEHOLDS.values() if h.get("tenure") == "Owner"),
        "insecure_households": sum(1 for h in g.HOUSEHOLDS.values() if h.get("tenure") == "Insecure"),
        "eligible_renter_count": 0,
        "attempted_transitions": 0,
        "successful_transitions": 0,
        "blocked_no_for_sale_stock": 0,
        "blocked_affordability": 0,
        "blocked_down_payment": 0,
        "blocked_missing_finance_data": 0,
        "blocked_probability": 0,
        "annual_cap": annual_cap,
        "available_for_sale_start": avail_start,
        "available_for_sale_end": 0,
        "rental_units_freed": 0,
        "notes": f"p={RENTER_TO_OWNER_ANNUAL_PROBABILITY}; max_rate={RENTER_TO_OWNER_MAX_ANNUAL_RATE}",
    }

    eligible = []
    for hh in renters:
        hh_id = hh.get("id")
        assess = evaluate_eligibility(hh_id, hh)
        if assess["eligible"]:
            counts["eligible_renter_count"] += 1
            eligible.append((hh_id, hh, assess))
        else:
            fr = assess["failure_reason"]
            if fr == "blocked_no_for_sale_stock":
                counts["blocked_no_for_sale_stock"] += 1
            elif fr == "blocked_affordability":
                counts["blocked_affordability"] += 1
            elif fr == "blocked_down_payment":
                counts["blocked_down_payment"] += 1
            elif fr == "blocked_missing_finance_data":
                counts["blocked_missing_finance_data"] += 1

    random.shuffle(eligible)
    successes = 0

    for hh_id, hh, assess in eligible:
        if successes >= annual_cap:
            break
        if _forsale_available_total() <= 0:
            counts["blocked_no_for_sale_stock"] += 1
            PHASE6E_R2O_EVENTS.append({
                "year": year, "household_id": hh_id,
                "household_size": len(hh.get("members") or []),
                "prior_unit": assess["prior_unit"], "prior_tenure": "Renter",
                "target_unit": "", "target_category": "",
                "income": assess["income"],
                "savings_if_available": assess["savings_if_available"],
                "required_cost": assess["required_cost"],
                "affordability_pass": assess["affordability_pass"],
                "down_payment_pass": assess["down_payment_pass"],
                "probability_draw": "",
                "annual_probability": RENTER_TO_OWNER_ANNUAL_PROBABILITY,
                "selected_for_attempt": False,
                "transition_success": False,
                "failure_reason": "blocked_no_for_sale_stock",
                "rollback_performed": False,
                "notes": "cap_or_stock_exhausted_mid_loop",
            })
            continue

        draw = random.random()
        selected = draw < RENTER_TO_OWNER_ANNUAL_PROBABILITY
        if not selected:
            counts["blocked_probability"] += 1
            PHASE6E_R2O_EVENTS.append({
                "year": year, "household_id": hh_id,
                "household_size": len(hh.get("members") or []),
                "prior_unit": assess["prior_unit"], "prior_tenure": "Renter",
                "target_unit": assess["target_unit"] or "",
                "target_category": assess["target_category"],
                "income": assess["income"],
                "savings_if_available": assess["savings_if_available"],
                "required_cost": assess["required_cost"],
                "affordability_pass": assess["affordability_pass"],
                "down_payment_pass": assess["down_payment_pass"],
                "probability_draw": draw,
                "annual_probability": RENTER_TO_OWNER_ANNUAL_PROBABILITY,
                "selected_for_attempt": False,
                "transition_success": False,
                "failure_reason": "blocked_probability",
                "rollback_performed": False,
                "notes": assess["notes"],
            })
            continue

        # Re-select unit in case stock changed
        unit = assess["target_unit"]
        if not unit or get_housing_available_count(unit) <= 0:
            unit, _ = _select_affordable_forsale(
                assess["income"],
                assess["savings_if_available"] if assess["savings_known"] else 0,
                assess["savings_known"],
            )
        if not unit:
            counts["blocked_no_for_sale_stock"] += 1
            PHASE6E_R2O_EVENTS.append({
                "year": year, "household_id": hh_id,
                "household_size": len(hh.get("members") or []),
                "prior_unit": assess["prior_unit"], "prior_tenure": "Renter",
                "target_unit": "", "target_category": "",
                "income": assess["income"],
                "savings_if_available": assess["savings_if_available"],
                "required_cost": assess["required_cost"],
                "affordability_pass": True,
                "down_payment_pass": assess["down_payment_pass"],
                "probability_draw": draw,
                "annual_probability": RENTER_TO_OWNER_ANNUAL_PROBABILITY,
                "selected_for_attempt": True,
                "transition_success": False,
                "failure_reason": "blocked_no_for_sale_stock",
                "rollback_performed": False,
                "notes": "stock_gone_at_attempt",
            })
            continue

        counts["attempted_transitions"] += 1
        prior_unit = assess["prior_unit"]
        ok = transfer_household_housing_claim(
            hh_id, to_unit_name=unit, to_tenure="Owner",
            year=year, reason="renter_to_owner", from_tenure="Renter",
        )
        if ok:
            successes += 1
            counts["successful_transitions"] += 1
            counts["rental_units_freed"] += 1
            PHASE6E_R2O_EVENTS.append({
                "year": year, "household_id": hh_id,
                "household_size": len(hh.get("members") or []),
                "prior_unit": prior_unit, "prior_tenure": "Renter",
                "target_unit": unit,
                "target_category": HOUSING_STOCK[unit]["type"],
                "income": assess["income"],
                "savings_if_available": assess["savings_if_available"],
                "required_cost": assess["required_cost"],
                "affordability_pass": True,
                "down_payment_pass": assess["down_payment_pass"],
                "probability_draw": draw,
                "annual_probability": RENTER_TO_OWNER_ANNUAL_PROBABILITY,
                "selected_for_attempt": True,
                "transition_success": True,
                "failure_reason": "",
                "rollback_performed": False,
                "notes": assess["notes"],
            })
        else:
            PHASE6E_R2O_EVENTS.append({
                "year": year, "household_id": hh_id,
                "household_size": len(hh.get("members") or []),
                "prior_unit": prior_unit, "prior_tenure": "Renter",
                "target_unit": unit,
                "target_category": HOUSING_STOCK[unit]["type"],
                "income": assess["income"],
                "savings_if_available": assess["savings_if_available"],
                "required_cost": assess["required_cost"],
                "affordability_pass": True,
                "down_payment_pass": assess["down_payment_pass"],
                "probability_draw": draw,
                "annual_probability": RENTER_TO_OWNER_ANNUAL_PROBABILITY,
                "selected_for_attempt": True,
                "transition_success": False,
                "failure_reason": "transfer_failed_rolled_back",
                "rollback_performed": True,
                "notes": "left_as_renter",
            })

    snap_end = stock_vacancy_snapshot()
    counts["available_for_sale_end"] = snap_end["for_sale_available"]
    counts["owner_households"] = sum(1 for h in g.HOUSEHOLDS.values() if h.get("tenure") == "Owner")
    counts["renter_households"] = sum(
        1 for h in g.HOUSEHOLDS.values() if h.get("tenure") == "Renter" and (h.get("members") or [])
    )
    counts["insecure_households"] = sum(1 for h in g.HOUSEHOLDS.values() if h.get("tenure") == "Insecure")
    PHASE6E_R2O_SUMMARY.append(counts)
    return counts
