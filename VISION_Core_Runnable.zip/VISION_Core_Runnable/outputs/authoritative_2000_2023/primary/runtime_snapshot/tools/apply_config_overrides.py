#!/usr/bin/env python
"""Phase 9D-CO: apply validated config overrides to mastercode02_config_and_rates.

Must be called AFTER `import mastercode02_config_and_rates as config` and BEFORE
importing consumer modules that from-import config names (agents, setup, utils,
logging, renter_to_owner).

Mechanics:
- scalars: setattr(config, key, value)
- dicts: recursive in-place update (preserve object identity for from-imported refs)
- lists: slice assignment target[:] = new_list (preserve list identity)
- IMMIGRATION_CONFIG.age_range: JSON list → tuple
"""
from __future__ import annotations

from typing import Any

from validate_config_overrides import (
    ALLOWED_TOP_LEVEL,
    SAFE_DICT_KEYS,
    SAFE_LIST_KEYS,
    SAFE_SCALAR_KEYS,
    ConfigOverrideValidationError,
    validate_config_overrides,
)


def _coerce_leaf(path: str, key: str, value: Any) -> Any:
    # age_range is a 2-tuple in the model
    if key == "age_range" and isinstance(value, list) and len(value) == 2:
        return (int(value[0]), int(value[1]))
    # INCOME_BANDS entries are lists of (lo, hi) tuples
    if isinstance(value, list) and value and all(
        isinstance(x, list) and len(x) == 2 and all(isinstance(n, (int, float)) for n in x)
        for x in value
    ):
        # Only coerce when nested under INCOME_BANDS
        if "INCOME_BANDS" in path:
            return [(float(a), float(b)) for a, b in value]
    return value


def _inplace_update_dict(target: dict, patch: dict, path: str) -> None:
    for k, v in patch.items():
        child = f"{path}.{k}" if path else k
        if k not in target:
            # Allow adding known nested keys for partial overrides of structured tables
            if isinstance(v, dict):
                target[k] = {}
                _inplace_update_dict(target[k], v, child)
            elif isinstance(v, list):
                target[k] = list(_coerce_leaf(child, k, v) if k == "age_range" else v)
            else:
                target[k] = _coerce_leaf(child, k, v)
            continue
        cur = target[k]
        coerced = _coerce_leaf(child, k, v)
        if isinstance(cur, dict) and isinstance(coerced, dict):
            _inplace_update_dict(cur, coerced, child)
        elif isinstance(cur, list) and isinstance(coerced, list):
            cur[:] = coerced
        else:
            target[k] = coerced


def apply_config_overrides(config_module: Any, overrides: dict) -> dict:
    """Apply overrides to the live config module. Returns application report."""
    validate_config_overrides(overrides)  # re-validate; raises ConfigOverrideValidationError

    applied: list[str] = []
    for key, value in overrides.items():
        if key not in ALLOWED_TOP_LEVEL:
            raise ConfigOverrideValidationError([f"{key}: not allowed"])
        if not hasattr(config_module, key):
            raise ConfigOverrideValidationError(
                [f"{key}: not present on config module (refusing to invent attributes)"])

        if key in SAFE_SCALAR_KEYS:
            setattr(config_module, key, value)
            applied.append(key)
        elif key in SAFE_DICT_KEYS:
            target = getattr(config_module, key)
            if not isinstance(target, dict) or not isinstance(value, dict):
                raise ConfigOverrideValidationError(
                    [f"{key}: expected dict override against dict target"])
            _inplace_update_dict(target, value, key)
            applied.append(key)
        elif key in SAFE_LIST_KEYS:
            target = getattr(config_module, key)
            if not isinstance(target, list) or not isinstance(value, list):
                raise ConfigOverrideValidationError(
                    [f"{key}: expected list override against list target"])
            target[:] = value
            applied.append(key)
        else:
            raise ConfigOverrideValidationError([f"{key}: unsupported class"])

    return {
        "applied_keys": applied,
        "n_applied": len(applied),
        "config_overrides_applied": bool(applied),
    }
